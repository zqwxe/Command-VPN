package com.dsh.quickvpn;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Shader;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;

/**
 * 大号滑动开关：向右拖满=打开，向左拖回=关闭。
 * 进度条两端都是圆的（不是被裁直的），中间带提示文字。
 */
public class SlideBar extends View {

    public interface Listener {
        void onSlideOn();

        void onSlideOff();
    }

    private Listener listener;
    private float frac = 0f;          // 0..1 滑块位置
    private boolean onState = false;
    private boolean connecting = false;   // 正在连接：文案单独区分
    private boolean tracking = false;
    private float downX = 0f;

    private final Paint trackPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint fillPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint thumbPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint ringPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint textPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF rect = new RectF();
    private final RectF thumbRect = new RectF();

    private int colorTrack = 0xFFE2EAF7;
    private int colorTrackStroke = 0xFFCFDCF0;
    private int colorBlue = 0xFF2F6FE0;
    private int colorBlue2 = 0xFF5A9BFF;
    private int colorText = 0xFF6B7A90;

    public SlideBar(Context c) {
        super(c);
        init();
    }

    public SlideBar(Context c, AttributeSet a) {
        super(c, a);
        init();
    }

    private void init() {
        trackPaint.setStyle(Paint.Style.FILL);
        fillPaint.setStyle(Paint.Style.FILL);
        thumbPaint.setStyle(Paint.Style.FILL);
        thumbPaint.setColor(Color.WHITE);
        ringPaint.setStyle(Paint.Style.STROKE);
        ringPaint.setColor(colorBlue);
        textPaint.setColor(colorText);
        textPaint.setTextAlign(Paint.Align.CENTER);
    }

    public void setColors(int track, int stroke, int blue1, int blue2, int text) {
        colorTrack = track;
        colorTrackStroke = stroke;
        colorBlue = blue1;
        colorBlue2 = blue2;
        colorText = text;
        ringPaint.setColor(blue1);
        textPaint.setColor(text);
        invalidate();
    }

    public void setListener(Listener l) {
        listener = l;
    }

    public void setOnState(boolean on) {
        if (onState == on && (frac == 1f || frac == 0f)) {
            return;   // 状态没变就不要把滑块位置重置
        }
        onState = on;
        frac = on ? 1f : 0f;
        invalidate();
    }

    public boolean isOn() {
        return onState;
    }

    /** 用户正捏着滑块时为 true：外部同步状态时不能动它，否则会闪。 */
    public boolean isTracking() {
        return tracking;
    }

    /** 连接中：滑块拉满，但文案显示"正在连接…"。 */
    public void setConnecting(boolean c) {
        connecting = c;
        invalidate();
    }

    @Override
    protected void onDraw(Canvas canvas) {
        float w = getWidth();
        float h = getHeight();
        if (w <= 0 || h <= 0) return;
        float trackH = h * 0.86f;
        float pad = trackH / 2f;
        float cy = h / 2f;
        rect.set(0, cy - trackH / 2f, w, cy + trackH / 2f);

        // 轨道
        trackPaint.setColor(colorTrack);
        canvas.drawRoundRect(rect, trackH / 2f, trackH / 2f, trackPaint);
        ringPaint.setStrokeWidth(Math.max(1f, h * 0.012f));
        canvas.drawRoundRect(rect, trackH / 2f, trackH / 2f, ringPaint);

        // 已滑过的部分：整段圆角（两端都是圆的）
        float thumbR = trackH / 2f;
        float thumbX = pad + frac * (w - 2 * pad);
        if (thumbX > pad + 1) {
            fillPaint.setShader(new LinearGradient(0, 0, w, 0,
                    new int[]{colorBlue2, colorBlue}, null, Shader.TileMode.CLAMP));
            // 右端一直是圆的；同时往滑块中心多画一点，保证蓝色和滑块之间没有缝
            float right = Math.min(w, thumbX + thumbR * 0.55f);
            canvas.drawRoundRect(new RectF(0, cy - trackH / 2f, Math.max(right, trackH * 1.2f),
                    cy + trackH / 2f), trackH / 2f, trackH / 2f, fillPaint);
        }

        // 文字
        String text;
        if (connecting) {
            // 正在连接：绝不能显示"已连接"；只有真的拉到取消区间才说"松手即可取消"
            text = tracking ? (frac <= 0.15f ? "松手即可取消" : "继续往左滑…")
                    : "正在连接…";
        } else if (onState) {
            text = tracking ? (frac <= 0.15f ? "松手即可断开" : "继续往左滑…")
                    : "已连接 · 向左滑动断开";
        } else {
            text = tracking ? (frac >= 0.85f ? "松手即可连接" : "继续往右滑…")
                    : "滑动开启";
        }
        textPaint.setTextSize(h * 0.30f);
        float tw = textPaint.measureText(text);
        boolean covered = (w / 2f + tw / 2f) <= thumbX + thumbR * 0.4f;
        textPaint.setColor(covered ? Color.WHITE : colorText);
        canvas.drawText(text, w / 2f, cy + h * 0.10f, textPaint);

        // 滑块
        thumbRect.set(thumbX - thumbR, cy - thumbR, thumbX + thumbR, cy + thumbR);
        thumbPaint.setShadowLayer(h * 0.03f, 0, h * 0.02f, 0x33000000);
        canvas.drawCircle(thumbX, cy, thumbR * 0.94f, thumbPaint);
        thumbPaint.clearShadowLayer();
        ringPaint.setStrokeWidth(Math.max(2f, h * 0.05f));
        canvas.drawCircle(thumbX, cy, thumbR * 0.94f, ringPaint);
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        float w = getWidth();
        float pad = getHeight() * 0.43f;
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                downX = e.getX();
                tracking = true;
                getParent().requestDisallowInterceptTouchEvent(true);
                updateFrac(e.getX(), w, pad);
                return true;
            case MotionEvent.ACTION_MOVE:
                updateFrac(e.getX(), w, pad);
                return true;
            case MotionEvent.ACTION_CANCEL:
            case MotionEvent.ACTION_UP:
                tracking = false;
                boolean want = frac >= 0.85f;
                boolean wantOff = frac <= 0.15f;
                if (!onState && want) {
                    onState = true;
                    frac = 1f;
                    invalidate();
                    if (listener != null) listener.onSlideOn();
                } else if (onState && wantOff) {
                    onState = false;
                    frac = 0f;
                    invalidate();
                    if (listener != null) listener.onSlideOff();
                } else {
                    frac = onState ? 1f : 0f;
                    invalidate();
                }
                getParent().requestDisallowInterceptTouchEvent(false);
                return true;
        }
        return super.onTouchEvent(e);
    }

    private void updateFrac(float x, float w, float pad) {
        float f = (x - pad) / Math.max(1f, (w - 2 * pad));
        frac = Math.max(0f, Math.min(1f, f));
        invalidate();
    }
}
