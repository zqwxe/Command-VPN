#!/bin/bash
set -e
BT=/opt/android/sdk/build-tools/34.0.0
PLATFORM=/opt/android/sdk/platforms/android-34/android.jar
APP=/root/build/app
OUT=/root/build/apkout
rm -rf $OUT && mkdir -p $OUT/cls $OUT/apk $OUT/gen

echo "== 1. aapt package（资源 + assets + R.java）=="
aapt package -f -M $APP/AndroidManifest.xml -S $APP/res -A $APP/assets \
  -I $PLATFORM -J $OUT/gen -F $OUT/apk/base.apk
echo "   R.java: $(find $OUT/gen -name R.java | head -1)"

echo "== 2. javac =="
javac -nowarn -source 8 -target 8 -encoding UTF-8 -cp $PLATFORM:/tmp/stubcls \
  -d $OUT/cls $(ls $APP/src/com/dsh/quickvpn/*.java | grep -v GenForTest) $(find $OUT/gen -name R.java)
echo "   classes: $(ls $OUT/cls/com/dsh/quickvpn/*.class | wc -l)"

echo "== 3. d8 =="
java -cp $BT/lib/d8.jar com.android.tools.r8.D8 --lib $PLATFORM --min-api 26 \
  --output $OUT/apk $(find $OUT/cls -name '*.class')
ls -la $OUT/apk/classes.dex

echo "== 4. 合入 dex / so =="
python3 - <<'PY'
import zipfile, os
base='/root/build/apkout/apk/base.apk'
out='/root/build/apkout/apk/merged.apk'
src=zipfile.ZipFile(base)
z=zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED,compresslevel=6)
for it in src.infolist():
    z.writestr(it, src.read(it.filename))
src.close()
z.write('/root/build/apkout/apk/classes.dex','classes.dex')
z.write('/root/build/sfa/ext/classes.dex','classes2.dex')
z.write('/root/build/sfa/ext/lib/arm64-v8a/libbox.so','lib/arm64-v8a/libbox.so')
z.close()
print('merged %.1f MB' % (os.path.getsize(out)/1e6))
PY

echo "== 5. zipalign + 签名 =="
cd $OUT/apk
zipalign -f -p 4 merged.apk aligned.apk
if [ ! -f /root/build/ks.jks ]; then
  keytool -genkeypair -keystore /root/build/ks.jks -alias qv -keyalg RSA -keysize 2048 \
    -validity 10950 -storepass qvpass123 -keypass qvpass123 \
    -dname "CN=QuickVPN, O=DSH, C=CN" >/dev/null 2>&1
fi
apksigner sign --ks /root/build/ks.jks --ks-pass pass:qvpass123 --key-pass pass:qvpass123 \
  --ks-key-alias qv --v1-signing-enabled true --v2-signing-enabled true \
  --out QuickVPN.apk aligned.apk
apksigner verify --print-certs QuickVPN.apk | head -3
ls -la QuickVPN.apk

echo "== 6. 源码快照 =="
VER=$(grep -o 'versionName="[0-9.]*"' /root/build/app/AndroidManifest.xml | cut -d'"' -f2)
SNAP=/sdcard/Download/CommandVPN-source-$VER.zip
rm -rf /tmp/snapbuild && mkdir -p /tmp/snapbuild
cp -r /root/build/app/src /root/build/app/res /root/build/app/AndroidManifest.xml /root/build/app/assets /root/build/build-apk.sh /tmp/snapbuild/
python3 - "$SNAP" <<'PY'
import zipfile,os,sys
out=sys.argv[1]
z=zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED)
for r,_,fs in os.walk('/tmp/snapbuild'):
    for f in fs:
        p=os.path.join(r,f); z.write(p,os.path.relpath(p,'/tmp/snapbuild'))
z.close()
print("snapshot:",out)
PY
rm -rf /tmp/snapbuild
# 只保留最近 2 个内测快照；更旧的移到中文回收站目录，不永久删除；正式版(-official)和 -ref 不参与清理
TRASH="/sdcard/Download/命令方块-源码回收站"
mkdir -p "$TRASH"
ls -1t /sdcard/Download/CommandVPN-source-*.zip 2>/dev/null | grep -vE -- "-(official|ref)\.zip$" | tail -n +3 | while read -r f; do
  ts=$(date +%Y%m%d-%H%M%S)
  base=$(basename "$f" .zip)
  mv "$f" "$TRASH/${base}-$ts.zip" && echo "旧快照已移到回收站: $base"
done
