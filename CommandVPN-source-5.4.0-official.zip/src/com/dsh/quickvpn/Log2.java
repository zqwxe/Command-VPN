package com.dsh.quickvpn;

import android.content.ContentUris;
import android.content.ContentValues;
import android.content.Context;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Log;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.text.SimpleDateFormat;
import java.util.ArrayDeque;
import java.util.Date;
import java.util.Locale;

/**
 * 日志：logcat + 内存环 + 两个文件
 *   1) App 私有目录（快，闪退前的最后一行也留得住）
 *   2) /sdcard/Download/CommandVPN-log-YYYYMMDD.txt（通过 MediaStore，别的工具/脚本能读到）
 * 全部方法同步，且不共用 SimpleDateFormat。
 */
public class Log2 {

    /** 是否记录内核详细日志（TRACE/DEBUG），默认关。 */
    public static boolean kernelEnabled(Context ctx) {
        return ctx.getSharedPreferences("qv", Context.MODE_PRIVATE)
                .getBoolean("log_kernel", false);
    }

    public static void setKernelEnabled(Context ctx, boolean on) {
        ctx.getSharedPreferences("qv", Context.MODE_PRIVATE).edit()
                .putBoolean("log_kernel", on).apply();
    }

    /** 去掉内核日志里的 ANSI 颜色控制符（[37m 之类）。 */
    public static String stripAnsi(String s) {
        if (s == null) return "";
        return s.replaceAll("\u001B\\[[0-9;]*[A-Za-z]", "").replaceAll("\\[[0-9;]*m", "");
    }

    private static final int MAX = 300;
    private static final ArrayDeque<String> RING = new ArrayDeque<String>();
    private static File file;
    private static BufferedWriter writer;
    private static BufferedWriter extWriter;
    private static String extName = "";
    private static final SimpleDateFormat DAY = new SimpleDateFormat("yyyyMMdd", Locale.US);
    private static long lastExtFlush = 0;
    private static long lastPrivateFlush = 0;

    public static synchronized void init(Context ctx) {
        if (writer != null && extWriter != null) return;
        // 1) 私有文件
        if (writer == null) {
            try {
                File dir = ctx.getFilesDir();
                if (dir != null) {
                    file = new File(dir, "quickvpn.log");
                    if (file.length() > 512 * 1024) file.delete();
                    writer = new BufferedWriter(new FileWriter(file, true), 8192);
                }
            } catch (Throwable ignored) {
            }
        }
        // 2) 外部可见文件（Download 目录）
        if (extWriter == null) {
            try {
                String name = "CommandVPN-log-" + DAY.format(new Date()) + ".txt";
                Uri uri = findOrCreate(ctx, name);
                OutputStream os = null;
                if (uri != null) {
                    try {
                        os = ctx.getContentResolver().openOutputStream(uri, "wa");
                    } catch (Throwable ignored) {
                        os = null;
                    }
                }
                if (os == null && uri != null) {
                    try {
                        os = ctx.getContentResolver().openOutputStream(uri, "w");   // 截断续用同一个文件
                    } catch (Throwable ignored) {
                        os = null;
                    }
                }
                if (os == null) {
                    // 已有文件不是本 App 创建的（没写权限）→ 自己新建一个
                    Uri fresh = createNew(ctx, name);
                    if (fresh != null) {
                        try {
                            os = ctx.getContentResolver().openOutputStream(fresh);
                            uri = fresh;
                        } catch (Throwable ignored) {
                            os = null;
                        }
                    }
                }
                if (true) {
                    if (os != null) {
                        extWriter = new BufferedWriter(new OutputStreamWriter(os, "UTF-8"), 8192);
                        extName = "Download/CommandVPN/" + name;
                    }
                }
            } catch (Throwable ignored) {
            }
        }
        // 清理旧的日志/报告，别把手机 Download 塞满
        prune(ctx, "CommandVPN-log-", 2);
        prune(ctx, "CommandVPN-scan-", 1);

        // 把上次内核崩溃报告也带进外部日志，方便排查
        if (extWriter != null) {
            try {
                File crash = new File(ctx.getCacheDir(), "CrashReport-CommandVPN.log");
                if (crash.isFile() && crash.length() > 0) {
                    byte[] buf = new byte[(int) Math.min(crash.length(), 64000)];
                    java.io.FileInputStream in = new java.io.FileInputStream(crash);
                    int n = in.read(buf);
                    in.close();
                    if (n > 0) {
                        extWriter.write("\n===== 上次内核崩溃报告 =====\n");
                        extWriter.write(new String(buf, 0, n, "UTF-8"));
                        extWriter.write("\n===== 崩溃报告结束 =====\n");
                        extWriter.flush();
                    }
                }
            } catch (Throwable ignored) {
            }
        }
    }

    /** 在 Download 里找到同名文件（没有就新建），返回它的 Uri。 */
    /** 新建一个日志文件（放在 Download/CommandVPN/）。 */
    private static Uri createNew(Context ctx, String name) {
        if (Build.VERSION.SDK_INT < 29) return null;
        try {
            ContentValues v = new ContentValues();
            v.put(MediaStore.MediaColumns.DISPLAY_NAME, name);
            v.put(MediaStore.MediaColumns.MIME_TYPE, "text/plain");
            v.put(MediaStore.MediaColumns.RELATIVE_PATH,
                    Environment.DIRECTORY_DOWNLOADS + "/CommandVPN");
            return ctx.getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v);
        } catch (Throwable t) {
            return null;
        }
    }

    private static Uri findOrCreate(Context ctx, String name) {
        if (Build.VERSION.SDK_INT < 29) return null;
        for (Uri collection : new Uri[]{MediaStore.Downloads.EXTERNAL_CONTENT_URI,
                MediaStore.Files.getContentUri("external")}) {
            try {
                android.database.Cursor c = ctx.getContentResolver().query(collection,
                        new String[]{MediaStore.MediaColumns._ID},
                        MediaStore.MediaColumns.DISPLAY_NAME + " LIKE ?",
                        new String[]{name + "%"},
                        MediaStore.MediaColumns.DATE_ADDED + " DESC");
                if (c != null) {
                    try {
                        if (c.moveToFirst()) {
                            return ContentUris.withAppendedId(collection, c.getLong(0));
                        }
                    } finally {
                        c.close();
                    }
                }
            } catch (Throwable ignored) {
            }
        }
        return null;
    }

    /** 只保留最新的 keep 个（按 DATE_ADDED 倒序），其余从 Download 删掉。 */
    private static void prune(Context ctx, String prefix, int keep) {
        if (Build.VERSION.SDK_INT < 29) return;
        for (Uri collection : new Uri[]{MediaStore.Downloads.EXTERNAL_CONTENT_URI,
                MediaStore.Files.getContentUri("external")}) {
            pruneIn(ctx, collection, prefix, keep);
        }
    }

    private static void pruneIn(Context ctx, Uri collection, String prefix, int keep) {
        try {
            android.database.Cursor c = ctx.getContentResolver().query(collection,
                    new String[]{MediaStore.MediaColumns._ID},
                    MediaStore.MediaColumns.DISPLAY_NAME + " LIKE ?",
                    new String[]{prefix + "%"},
                    MediaStore.MediaColumns.DATE_ADDED + " DESC");
            if (c == null) return;
            java.util.List<Long> old = new java.util.ArrayList<Long>();
            int seen = 0;
            try {
                while (c.moveToNext()) {
                    seen++;
                    if (seen > keep) old.add(c.getLong(0));
                }
            } finally {
                c.close();
            }
            for (long id : old) {
                try {
                    ctx.getContentResolver().delete(ContentUris.withAppendedId(collection, id), null, null);
                } catch (Throwable ignored) {
                }
            }
        } catch (Throwable ignored) {
        }
    }

    /** 清空日志（尽力而为），返回"还没删掉、需要系统确认"的文件 Uri。 */
    public static synchronized java.util.List<Uri> clear(Context ctx) {
        RING.clear();
        try {
            if (writer != null) {
                try {
                    writer.flush();
                } catch (Throwable ignored) {
                }
                try {
                    writer.close();
                } catch (Throwable ignored) {
                }
                writer = null;
            }
            if (file != null) {
                try {
                    if (file.exists()) file.delete();
                } catch (Throwable ignored) {
                }
                file = null;
            }
        } catch (Throwable ignored) {
        }
        try {
            if (extWriter != null) {
                try {
                    extWriter.flush();
                } catch (Throwable ignored) {
                }
                try {
                    extWriter.close();
                } catch (Throwable ignored) {
                }
                extWriter = null;
            }
            extName = "";
            deleteFolderContents(ctx);
        } catch (Throwable ignored) {
        }
        java.util.List<Uri> left = folderUris(ctx);
        init(ctx);
        i("日志已清空（用户操作）");
        return left;
    }

    /** 找出 Download/CommandVPN 里还剩的文件（给"系统确认删除"用）。 */
    public static java.util.List<Uri> folderUris(Context ctx) {
        java.util.List<Uri> out = new java.util.ArrayList<Uri>();
        if (Build.VERSION.SDK_INT < 29) return out;
        String rel = Environment.DIRECTORY_DOWNLOADS + "/CommandVPN";
        for (Uri collection : new Uri[]{MediaStore.Downloads.EXTERNAL_CONTENT_URI,
                MediaStore.Files.getContentUri("external")}) {
            try {
                android.database.Cursor c = ctx.getContentResolver().query(collection,
                        new String[]{MediaStore.MediaColumns._ID},
                        MediaStore.MediaColumns.RELATIVE_PATH + " LIKE ?",
                        new String[]{rel + "%"}, null);
                if (c != null) {
                    try {
                        while (c.moveToNext()) {
                            out.add(ContentUris.withAppendedId(collection, c.getLong(0)));
                        }
                    } finally {
                        c.close();
                    }
                }
            } catch (Throwable ignored) {
            }
        }
        return out;
    }

    /** 删掉 Download/CommandVPN 里的所有文件（日志、体检报告等），相当于清空这个目录。 */
    private static void deleteFolderContents(Context ctx) {
        if (Build.VERSION.SDK_INT < 29) return;
        String rel = Environment.DIRECTORY_DOWNLOADS + "/CommandVPN";
        for (Uri collection : new Uri[]{MediaStore.Downloads.EXTERNAL_CONTENT_URI,
                MediaStore.Files.getContentUri("external")}) {
            java.util.List<Long> ids = new java.util.ArrayList<Long>();
            // 1) 按相对路径（Android 10+ 的 MediaStore 记录方式）
            try {
                android.database.Cursor c = ctx.getContentResolver().query(collection,
                        new String[]{MediaStore.MediaColumns._ID},
                        MediaStore.MediaColumns.RELATIVE_PATH + " LIKE ?",
                        new String[]{rel + "%"}, null);
                if (c != null) {
                    try {
                        while (c.moveToNext()) ids.add(c.getLong(0));
                    } finally {
                        c.close();
                    }
                }
            } catch (Throwable ignored) {
            }
            // 2) 老式按绝对路径兜底（有的系统不填 RELATIVE_PATH）
            try {
                android.database.Cursor c = ctx.getContentResolver().query(collection,
                        new String[]{MediaStore.MediaColumns._ID},
                        MediaStore.MediaColumns.DATA + " LIKE ?",
                        new String[]{"%/Download/CommandVPN/%"}, null);
                if (c != null) {
                    try {
                        while (c.moveToNext()) ids.add(c.getLong(0));
                    } finally {
                        c.close();
                    }
                }
            } catch (Throwable ignored) {
            }
            for (long id : ids) {
                try {
                    ctx.getContentResolver().delete(ContentUris.withAppendedId(collection, id), null, null);
                } catch (Throwable ignored) {
                }
            }
        }
        // 3) 直接删除目录（有真实路径权限时最彻底）
        try {
            File dir = new File(Environment.getExternalStoragePublicDirectory(
                    Environment.DIRECTORY_DOWNLOADS), "CommandVPN");
            File[] kids = dir.listFiles();
            if (kids != null) {
                for (File k : kids) {
                    try {
                        k.delete();
                    } catch (Throwable ignored) {
                    }
                }
            }
        } catch (Throwable ignored) {
        }
    }

    private static void deleteAll(Context ctx, String prefix) {
        if (Build.VERSION.SDK_INT < 29) return;
        for (Uri collection : new Uri[]{MediaStore.Downloads.EXTERNAL_CONTENT_URI,
                MediaStore.Files.getContentUri("external")}) {
            try {
                android.database.Cursor c = ctx.getContentResolver().query(collection,
                        new String[]{MediaStore.MediaColumns._ID},
                        MediaStore.MediaColumns.DISPLAY_NAME + " LIKE ?",
                        new String[]{prefix + "%"}, null);
                if (c == null) continue;
                java.util.List<Long> ids = new java.util.ArrayList<Long>();
                try {
                    while (c.moveToNext()) ids.add(c.getLong(0));
                } finally {
                    c.close();
                }
                for (long id : ids) {
                    try {
                        ctx.getContentResolver().delete(ContentUris.withAppendedId(collection, id), null, null);
                    } catch (Throwable ignored) {
                    }
                }
            } catch (Throwable ignored) {
            }
        }
    }

    /** 外部日志的路径（给界面显示用），没有就返回 null。 */
    public static synchronized String externalPath() {
        return extName.length() == 0 ? null : extName;
    }

    private static String stamp() {
        // 每行都带完整日期（yyyy-MM-dd HH:mm:ss），方便跨天排查
        try {
            return new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(new Date());
        } catch (Throwable t) {
            long sec = System.currentTimeMillis() / 1000L;
            return String.format(Locale.US, "%02d:%02d:%02d",
                    (int) ((sec / 3600) % 24), (int) ((sec / 60) % 60), (int) (sec % 60));
        }
    }

    public static synchronized void add(String level, String msg) {
        String line = stamp() + " " + level + " " + msg;
        RING.addLast(line);
        while (RING.size() > MAX) RING.removeFirst();
        try {
            int prio = "E".equals(level) ? Log.ERROR : ("W".equals(level) ? Log.WARN : Log.INFO);
            Log.println(prio, "CommandVPN", msg);
        } catch (Throwable ignored) {
        }
        if (writer != null) {
            try {
                writer.write(line);
                writer.newLine();
                // 普通信息也节流：内核 debug 日志每秒可能上千行，
                // 每行都 flush 会让手机卡顿、也伤闪存
                long now = System.currentTimeMillis();
                if (!"I".equals(level) || now - lastPrivateFlush > 500) {
                    writer.flush();
                    lastPrivateFlush = now;
                }
            } catch (Throwable ignored) {
            }
        }
        if (extWriter != null) {
            try {
                extWriter.write(line);
                extWriter.newLine();
                long now = System.currentTimeMillis();
                // 普通信息半秒刷一次就够（内核 debug 日志太多），错误/警告立刻刷
                if (!"I".equals(level) || now - lastExtFlush > 500) {
                    extWriter.flush();
                    lastExtFlush = now;
                }
            } catch (Throwable ignored) {
            }
        }
    }

    public static void i(String msg) {
        add("I", msg);
    }

    public static void w(String msg) {
        add("W", msg);
    }

    public static void e(String msg, Throwable t) {
        StringBuilder sb = new StringBuilder(msg);
        if (t != null) {
            sb.append(" : ").append(t);
            StackTraceElement[] st = t.getStackTrace();
            int n = Math.min(st.length, 8);
            for (int i = 0; i < n; i++) sb.append("\n    at ").append(st[i]);
            Throwable cause = t.getCause();
            if (cause != null && cause != t) sb.append("\n  caused by ").append(cause);
        }
        add("E", sb.toString());
    }

    public static synchronized String dump() {
        StringBuilder sb = new StringBuilder();
        for (String s : RING) sb.append(s).append('\n');
        return sb.length() == 0 ? "(暂无日志)" : sb.toString();
    }
}
