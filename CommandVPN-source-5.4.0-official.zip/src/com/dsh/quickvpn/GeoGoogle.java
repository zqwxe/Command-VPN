package com.dsh.quickvpn;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.InetSocketAddress;
import java.net.Proxy;
import java.net.URL;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

/**
 * 用 Google 自己的判断看某个节点"在哪个地区"：
 * 先把扫描内核的 selector 切到 node-i，再通过内核的本地 http 入口访问
 * https://www.google.com/searchdomaincheck?format=domain
 * Google 会返回该出口 IP 对应的域名后缀，例如 ".com.hk" / ".co.jp" / ".de"。
 *
 * 注意：只在"多源比对结果矛盾"时才会调用（每次几十~几百毫秒）。
 */
public class GeoGoogle {

    /** Google 返回的域名后缀 → 国家码。 .com 太模糊（美国以外很多国家也用），不映射。 */
    private static final Map<String, String> TLD = new HashMap<String, String>();

    static {
        put(".com.hk", "HK"); put(".co.jp", "JP"); put(".co.kr", "KR"); put(".com.tw", "TW");
        put(".com.sg", "SG"); put(".com.my", "MY"); put(".co.th", "TH"); put(".com.vn", "VN");
        put(".co.id", "ID"); put(".com.ph", "PH"); put(".com.pk", "PK"); put(".co.in", "IN");
        put(".com.au", "AU"); put(".co.nz", "NZ"); put(".co.uk", "GB"); put(".de", "DE");
        put(".fr", "FR"); put(".it", "IT"); put(".es", "ES"); put(".nl", "NL"); put(".se", "SE");
        put(".no", "NO"); put(".fi", "FI"); put(".dk", "DK"); put(".ch", "CH"); put(".at", "AT");
        put(".be", "BE"); put(".pl", "PL"); put(".pt", "PT"); put(".gr", "GR"); put(".cz", "CZ");
        put(".hu", "HU"); put(".ro", "RO"); put(".ru", "RU"); put(".ua", "UA"); put(".tr", "TR");
        put(".il", "IL"); put(".sa", "SA"); put(".ae", "AE"); put(".com.br", "BR");
        put(".com.mx", "MX"); put(".com.ar", "AR"); put(".cl", "CL"); put(".com.co", "CO");
        put(".com.pe", "PE"); put(".ca", "CA"); put(".com.eg", "EG"); put(".co.za", "ZA");
        put(".com.ng", "NG"); put(".ie", "IE"); put(".is", "IS"); put(".lt", "LT");
        put(".lv", "LV"); put(".ee", "EE"); put(".bg", "BG"); put(".hr", "HR"); put(".rs", "RS");
        put(".sk", "SK"); put(".si", "SI"); put(".lu", "LU"); put(".kz", "KZ"); put(".by", "BY");
        put(".am", "AM"); put(".ge", "GE"); put(".az", "AZ"); put(".uz", "UZ"); put(".mn", "MN");
        put(".kh", "KH"); put(".la", "LA"); put(".mm", "MM"); put(".np", "NP"); put(".lk", "LK");
        put(".bd", "BD"); put(".com.bn", "BN"); put(".com.mt", "MT"); put(".cy", "CY");
    }

    private static void put(String k, String v) {
        TLD.put(k, v);
    }

    /**
     * 把扫描内核切到 node-index，再问 Google。
     *
     * @return 两位国家码；拿不到（Google 没给地区 / 只返回 .com / 网络失败）返回 ""
     */
    /** 直接通过本地 http 入口问 Google（单节点/候选池配置里已经固定走代理）。 */
    public static String queryDomain(int httpPort, int timeoutMs) {
        return googleDomain(httpPort, timeoutMs);
    }

    /**
     * 以"实际出口"为准判定地区（这才是 VPN 把网络带到哪里）：
     * 1) Google 的域名后缀（如 .ru）
     * 2) 经代理查 ip-api（它返回的是出口 IP 的国家）
     * 3) 经代理查 ipwho.is
     */
    public static String exitRegion(int httpPort, int timeoutMs) {
        if (httpPort <= 0) return "";
        String dom = googleDomain(httpPort, timeoutMs);
        String cc = ccFromDomain(dom);
        if (cc.length() == 2) {
            Log2.i("出口地区：Google " + dom + " → " + cc);
            return cc;
        }
        String body = getViaProxy(httpPort, "http://ip-api.com/json/?fields=countryCode", timeoutMs);
        String api = jsonField(body, "countryCode");
        if (api.length() == 2) {
            Log2.i("出口地区：ip-api（经代理）→ " + api);
            return api;
        }
        body = getViaProxy(httpPort, "https://ipwho.is/", timeoutMs);
        String who = jsonField(body, "country_code");
        if (who.length() == 2) {
            Log2.i("出口地区：ipwho（经代理）→ " + who);
            return who;
        }
        Log2.w("出口地区：三个都没取到（Google 返回 " + dom + "）");
        return "";
    }

    private static String jsonField(String body, String field) {
        if (body == null) return "";
        try {
            java.util.regex.Matcher m = java.util.regex.Pattern
                    .compile("\"" + field + "\"\\s*:\\s*\"([A-Za-z]{2})\"").matcher(body);
            if (m.find()) return m.group(1);
        } catch (Throwable ignored) {
        }
        return "";
    }

    private static String getViaProxy(int httpPort, String url, int timeoutMs) {
        HttpURLConnection c = null;
        try {
            Proxy proxy = new Proxy(Proxy.Type.HTTP, new InetSocketAddress("127.0.0.1", httpPort));
            c = (HttpURLConnection) new URL(url).openConnection(proxy);
            c.setConnectTimeout(Math.min(2500, timeoutMs));
            c.setReadTimeout(timeoutMs);
            c.setRequestProperty("User-Agent", "Mozilla/5.0");
            if (c.getResponseCode() != 200) return "";
            InputStream in = c.getInputStream();
            ByteArrayOutputStream bos = new ByteArrayOutputStream();
            byte[] buf = new byte[1024];
            int len;
            while ((len = in.read(buf)) > 0) {
                bos.write(buf, 0, len);
                if (bos.size() > 8192) break;
            }
            in.close();
            return new String(bos.toByteArray(), "UTF-8");
        } catch (Throwable t) {
            return "";
        } finally {
            if (c != null) c.disconnect();
        }
    }

    /** 把 Google 返回的域名后缀（如 .com.hk）转成国家码；认不出返回 ""。 */
    public static String ccFromDomain(String tld) {
        if (tld == null) return "";
        String key = tld.trim().toLowerCase(Locale.ROOT);
        if (key.length() == 0) return "";
        int slash = key.indexOf('/');
        if (slash > 0) key = key.substring(0, slash);
        return TLD.containsKey(key) ? TLD.get(key) : "";
    }

    public static String regionOf(int clashPort, String secret, int httpPort, int index, int timeoutMs) {
        if (httpPort <= 0) return "";
        try {
            selectNode(clashPort, secret, "node-" + index, timeoutMs);
        } catch (Throwable t) {
            return "";
        }
        String tld = googleDomain(httpPort, timeoutMs);
        if (tld == null || tld.length() == 0) return "";
        String key = tld.toLowerCase(Locale.ROOT);
        int dot = key.indexOf(".com/");   // 少数返回带路径，截断
        if (dot > 0) key = key.substring(0, dot + 4);
        return TLD.containsKey(key) ? TLD.get(key) : "";
    }

    private static void selectNode(int clashPort, String secret, String tag, int timeoutMs) throws Exception {
        HttpURLConnection c = null;
        try {
            c = (HttpURLConnection) new URL("http://127.0.0.1:" + clashPort + "/proxies/proxy")
                    .openConnection();
            c.setConnectTimeout(Math.min(1500, timeoutMs));
            c.setReadTimeout(timeoutMs);
            c.setRequestMethod("PUT");
            c.setDoOutput(true);
            c.setRequestProperty("Content-Type", "application/json");
            if (secret != null) c.setRequestProperty("Authorization", "Bearer " + secret);
            OutputStream os = c.getOutputStream();
            os.write(("{\"name\":\"" + tag + "\"}").getBytes("UTF-8"));
            os.close();
            c.getResponseCode();
        } finally {
            if (c != null) c.disconnect();
        }
    }

    /** 通过本地 http 代理访问 Google，返回例如 ".com.hk"。 */
    private static String googleDomain(int httpPort, int timeoutMs) {
        HttpURLConnection c = null;
        try {
            Proxy proxy = new Proxy(Proxy.Type.HTTP, new InetSocketAddress("127.0.0.1", httpPort));
            c = (HttpURLConnection) new URL(
                    "https://www.google.com/searchdomaincheck?format=domain")
                    .openConnection(proxy);
            c.setConnectTimeout(Math.min(2500, timeoutMs));
            c.setReadTimeout(timeoutMs);
            c.setRequestProperty("User-Agent", "Mozilla/5.0");
            c.setInstanceFollowRedirects(false);
            int code = c.getResponseCode();
            if (code != 200) {
                Log2.w("Google 地区查询返回 HTTP " + code);
                return "";
            }
            InputStream in = c.getInputStream();
            ByteArrayOutputStream bos = new ByteArrayOutputStream();
            byte[] buf = new byte[512];
            int len;
            while ((len = in.read(buf)) > 0) {
                bos.write(buf, 0, len);
                if (bos.size() > 2048) break;
            }
            in.close();
            return new String(bos.toByteArray(), "UTF-8").trim();
        } catch (Throwable t) {
            Log2.w("Google 地区查询失败：" + t);
            return "";
        } finally {
            if (c != null) c.disconnect();
        }
    }
}
