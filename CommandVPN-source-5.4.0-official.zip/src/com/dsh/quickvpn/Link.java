package com.dsh.quickvpn;

import java.util.HashMap;
import java.util.Map;

/** 极简的分享链接解析器（不依赖 java.net.URI，避免 emoji / 非法字符抛异常）。 */
public class Link {
    public String scheme = "";
    public String userInfo = "";
    public String host = "";
    public int port = 0;
    public String path = "";
    public Map<String, String> query = new HashMap<>();
    public String fragment = "";

    public String q(String... keys) {
        for (String k : keys) {
            String v = query.get(k);
            if (v != null && v.length() > 0) return v;
        }
        return "";
    }

    public boolean flag(String... keys) {
        String v = q(keys);
        return "1".equals(v) || "true".equalsIgnoreCase(v);
    }

    public static Link parse(String uri) {
        Link l = new Link();
        int p = uri.indexOf("://");
        if (p < 0) return l;
        l.scheme = uri.substring(0, p).toLowerCase();
        String rest = uri.substring(p + 3);

        int hash = rest.indexOf('#');
        if (hash >= 0) {
            l.fragment = decode(rest.substring(hash + 1));
            rest = rest.substring(0, hash);
        }
        int qm = rest.indexOf('?');
        if (qm >= 0) {
            parseQuery(rest.substring(qm + 1), l.query);
            rest = rest.substring(0, qm);
        }
        int slash = rest.indexOf('/');
        if (slash >= 0) {
            l.path = rest.substring(slash);
            rest = rest.substring(0, slash);
        }
        int at = rest.lastIndexOf('@');
        String hostPort = rest;
        if (at >= 0) {
            l.userInfo = rest.substring(0, at);
            hostPort = rest.substring(at + 1);
        }
        if (hostPort.startsWith("[")) {
            int end = hostPort.indexOf(']');
            if (end > 0) {
                l.host = hostPort.substring(1, end);
                int colon = hostPort.indexOf(':', end);
                if (colon > 0) l.port = toInt(hostPort.substring(colon + 1));
            }
        } else {
            int colon = hostPort.lastIndexOf(':');
            if (colon > 0) {
                l.host = hostPort.substring(0, colon);
                l.port = toInt(hostPort.substring(colon + 1));
            } else {
                l.host = hostPort;
            }
        }
        return l;
    }

    private static void parseQuery(String s, Map<String, String> out) {
        for (String kv : s.split("&")) {
            if (kv.length() == 0) continue;
            int eq = kv.indexOf('=');
            if (eq < 0) {
                out.put(decode(kv).trim(), "");
            } else {
                out.put(decode(kv.substring(0, eq)).trim(), decode(kv.substring(eq + 1)));
            }
        }
    }

    public static String decode(String s) {
        if (s == null) return "";
        if (s.indexOf('%') < 0) return s;
        try {
            StringBuilder sb = new StringBuilder(s.length());
            for (int i = 0; i < s.length(); i++) {
                char c = s.charAt(i);
                if (c == '%' && i + 2 < s.length()) {
                    int v = Integer.parseInt(s.substring(i + 1, i + 3), 16);
                    sb.append((char) v);
                    i += 2;
                } else if (c == '+') {
                    sb.append(' ');
                } else {
                    sb.append(c);
                }
            }
            return sb.toString();
        } catch (Exception e) {
            return s;
        }
    }

    private static int toInt(String s) {
        try {
            return Integer.parseInt(s.trim());
        } catch (Exception e) {
            return 0;
        }
    }
}
