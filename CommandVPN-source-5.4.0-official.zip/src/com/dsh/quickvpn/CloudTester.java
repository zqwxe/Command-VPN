package com.dsh.quickvpn;

import android.content.Context;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * 连接云节点：下载某个节点源 → 解析 → 测 TCP 延迟 → 交给界面挑最快的那个。
 * 云节点不进主列表，也不参与体检/翻新。
 */
public class CloudTester {

    public interface Listener {
        void onProgress(int done, int total, int alive);
        void onDone(int alive, int dead, Node fastest, int fastestMs);
        void onError(String msg);
    }

    static volatile boolean running = false;
    /** 本次测通的节点，按延迟从低到高（界面用来"连不上就换下一个"）。 */
    static volatile java.util.List<Node> aliveSorted = new java.util.ArrayList<Node>();
    static volatile boolean cancel = false;

    public static boolean isRunning() { return running; }

    public static void stop() {
        cancel = true;
        running = false;      // 立刻释放，别让下一次连接一直提示"正在测试中"
        startedAt = 0;
    }

    static volatile long startedAt = 0;

    /** 测试上限开关（设置里那个，默认开=只测前 300 个）。 */
    public static boolean limit300(Context ctx) {
        return ctx.getSharedPreferences("qv", Context.MODE_PRIVATE)
                .getBoolean("cloud_limit_300", true);
    }

    public static void setLimit300(Context ctx, boolean on) {
        ctx.getSharedPreferences("qv", Context.MODE_PRIVATE).edit()
                .putBoolean("cloud_limit_300", on).apply();
    }

    private static String cacheKey(String url) {
        try {
            java.security.MessageDigest md = java.security.MessageDigest.getInstance("MD5");
            byte[] d = md.digest(url.getBytes("UTF-8"));
            StringBuilder sb = new StringBuilder();
            for (byte b : d) sb.append(String.format("%02x", b));
            return "cloud_state_" + sb;
        } catch (Throwable t) {
            return "cloud_state_" + Math.abs(url.hashCode());
        }
    }

    /** 读缓存的测试结果：uri → "state\tms"（state: 1 可用 / 2 不可用）。 */
    public static Map<String, String> loadCache(Context ctx, String url) {
        Map<String, String> m = new ConcurrentHashMap<String, String>();
        try {
            String raw = ctx.getSharedPreferences("qv", Context.MODE_PRIVATE)
                    .getString(cacheKey(url), "");
            if (raw == null) return m;
            for (String line : raw.split("\n")) {
                String[] p = line.split("\t");
                if (p.length >= 3 && p[0].length() > 8) m.put(p[0], p[1] + "\t" + p[2]);
            }
        } catch (Throwable ignored) {
        }
        return m;
    }

    /** 每个源的节点清单（含国家与状态），供"展开看所有节点"用。 */
    public static String nodesKey(String url) {
        return "cloud_nodes_" + cacheKey(url).substring("cloud_state_".length());
    }

    /** 源里一共解析出多少个节点（用来告诉用户"还有多少没测"）。 */
    public static int totalOf(Context ctx, String url) {
        try {
            return ctx.getSharedPreferences("qv", Context.MODE_PRIVATE)
                    .getInt("cloud_total_" + cacheKey(url), 0);
        } catch (Throwable t) {
            return 0;
        }
    }

    public static java.util.List<String[]> loadNodes(Context ctx, String url) {
        java.util.List<String[]> out = new java.util.ArrayList<String[]>();
        try {
            String raw = ctx.getSharedPreferences("qv", Context.MODE_PRIVATE)
                    .getString(nodesKey(url), "");
            if (raw == null) return out;
            for (String line : raw.split("\n")) {
                String[] p = line.split("\t");
                if (p.length >= 3) out.add(p);   // uri, cc, title, state, ms
            }
        } catch (Throwable ignored) {
        }
        return out;
    }

    /** 一次性清理：旧版把"没测到的"也存成未实测，清掉这些行（列表里只该有测过的）。 */
    public static void cleanStaleCaches(Context ctx) {
        try {
            android.content.SharedPreferences sp = ctx.getSharedPreferences("qv", Context.MODE_PRIVATE);
            if (sp.getBoolean("cloud_cache_clean_v1", false)) return;
            java.util.Map<String, ?> all = sp.getAll();
            android.content.SharedPreferences.Editor ed = sp.edit();
            int cleaned = 0;
            for (java.util.Map.Entry<String, ?> e : all.entrySet()) {
                String k = e.getKey();
                if (!k.startsWith("cloud_nodes_")) continue;
                Object v = e.getValue();
                if (!(v instanceof String)) continue;
                StringBuilder sb = new StringBuilder();
                for (String line : ((String) v).split("\n")) {
                    String[] p = line.split("\t");
                    if (p.length >= 4 && "0".equals(p[3])) { cleaned++; continue; }
                    if (line.trim().length() > 0) sb.append(line).append('\n');
                }
                ed.putString(k, sb.toString());
            }
            ed.putBoolean("cloud_cache_clean_v1", true).apply();
            if (cleaned > 0) Log2.i("云节点缓存清理：移除 " + cleaned + " 条旧的未实测记录");
        } catch (Throwable t) {
            Log2.w("清理云节点缓存失败：" + t);
        }
    }

    /**
     * 云节点测完后按 IP 补地区：云节点不进主节点库，之前没有任何一步给它识别地区，
     * 所以列表里会整片显示「未识别地区」。
     */
    private static void fillCountries(Context ctx, java.util.List<Node> nodes) {
        if (nodes == null || nodes.isEmpty()) return;
        try {
            java.util.Map<String, String> ipOf = new java.util.HashMap<String, String>();
            java.util.List<String> ips = new java.util.ArrayList<String>();
            for (Node n : nodes) {
                try {
                    n.resolveHost(1500);
                } catch (Throwable ignored) {
                }
                String ip = n.resolvedHost != null ? n.resolvedHost : n.host;
                if (ip == null || !ip.matches("^\\d+\\.\\d+\\.\\d+\\.\\d+$")) continue;
                ipOf.put(n.uri, ip);
                if (!ips.contains(ip)) ips.add(ip);
            }
            if (ips.isEmpty()) return;
            java.util.Map<String, String> ccByIp = GeoClassifier.identifyIpCountries(ctx, ips);
            int filled = 0;
            for (Node n : nodes) {
                String ip = ipOf.get(n.uri);
                String cc = ip == null ? null : ccByIp.get(ip);
                if (cc != null && cc.length() == 2) {
                    if (!cc.equalsIgnoreCase(n.cc)) filled++;
                    n.cc = cc;
                } else if (Country.isUnknown(n.cc)) {
                    n.cc = "ZZ";
                }
            }
            Log2.i("云节点地区识别：为 " + ipOf.size() + " 个节点补地区，改变 " + filled + " 个");
        } catch (Throwable t) {
            Log2.w("云节点地区识别失败：" + t);
        }
    }

    static void saveNodes(Context ctx, String url, java.util.List<Node> nodes,
                          Map<String, Integer> msByUri, java.util.Set<String> tested) {
        try {
            StringBuilder sb = new StringBuilder();
            for (Node n : nodes) {
                Integer ms = msByUri.get(n.uri);
                String state = !tested.contains(n.uri) ? "0" : (ms != null && ms > 0 ? "1" : "2");
                sb.append(n.uri).append('\t').append(n.cc).append('\t').append(n.title)
                        .append('\t').append(state).append('\t')
                        .append(ms != null && ms > 0 ? ms : 0).append('\n');
            }
            ctx.getSharedPreferences("qv", Context.MODE_PRIVATE).edit()
                    .putString(nodesKey(url), sb.toString()).apply();
        } catch (Throwable ignored) {
        }
    }

    static void saveCache(Context ctx, String url, Map<String, String> add) {
        try {
            Map<String, String> m = loadCache(ctx, url);
            m.putAll(add);
            StringBuilder sb = new StringBuilder();
            int n = 0;
            for (Map.Entry<String, String> e : m.entrySet()) {
                if (n++ > 3000) break;
                String[] p = e.getValue().split("\t");
                if (p.length < 2) continue;
                sb.append(e.getKey()).append('\t').append(p[0]).append('\t').append(p[1]).append('\n');
            }
            ctx.getSharedPreferences("qv", Context.MODE_PRIVATE).edit()
                    .putString(cacheKey(url), sb.toString()).apply();
        } catch (Throwable ignored) {
        }
    }

    public static void start(final Context ctx, final String name, final String url,
                             final Listener listener) {
        if (running) {
            long age = startedAt > 0 ? (System.currentTimeMillis() - startedAt) : Long.MAX_VALUE;
            if (age < 5 * 60 * 1000L) {
                Log2.w("云节点：上一次测试还没结束（" + (age / 1000) + " 秒），忽略本次请求");
                if (listener != null) listener.onError("上一次测试还没结束，请等一下再试");
                return;
            }
            Log2.w("云节点：上一次测试卡了 " + (age / 60000) + " 分钟，强制重置后重新开始");
            running = false;
            cancel = true;
        }
        startedAt = System.currentTimeMillis();
        cancel = false;
        running = true;
        cancel = false;
        new Thread(new Runnable() {
            @Override
            public void run() {
                int alive = 0, dead = 0;
                Node fastest = null;
                int fastestMs = 0;
                try {
                    Log2.i("云节点：开始测试 " + name);
                    String body = http(url, 15000);
                    if (body == null || body.length() == 0) {
                        String mirror = mirrorUrl(url);
                        if (mirror != null) body = http(mirror, 15000);
                    }
                    if (body == null || body.length() == 0) {
                        Log2.w("云节点：" + name + " 下载失败（直连和镜像都没拿到内容）");
                        if (listener != null) listener.onError("下载失败：这个源没拉到内容。\n\n"
                                + "可能是网络被拦（GitHub 打不开）、链接失效，或源站很慢。\n"
                                + "可以换个源，或稍后再试。");
                        return;
                    }
                    String text = decode(body);
                    LinkedHashSet<String> uris = new LinkedHashSet<String>();
                    for (String line : text.split("\r?\n")) {
                        String l = line.trim();
                        if (l.length() < 10 || !l.contains("://")) continue;
                        uris.add(l);
                    }
                    List<Node> nodes = new ArrayList<Node>();
                    int skippedCn = 0;
                    for (String u : uris) {
                        try {
                            String cc = Country.detectFromUri(u);
                            Node n = new Node(u, cc != null && cc.length() == 2 ? cc : "ZZ", "");
                            if (!n.supported) continue;
                            if ("CN".equalsIgnoreCase(n.cc)) {
                                skippedCn++;   // 中国大陆节点连上也上不了 Google，直接跳过
                                continue;
                            }
                            nodes.add(n);
                        } catch (Throwable ignored) {
                        }
                    }
                    if (skippedCn > 0) Log2.i("云节点：跳过 " + skippedCn + " 个中国大陆节点（连上也无法访问 Google）");
                    if (nodes.isEmpty()) {
                        if (listener != null) listener.onError("这个源里没有能识别的节点（可能是 Clash 配置或网页）");
                        return;
                    }
                    // 按 IP 复查国家：名称里没写国家的节点，实际可能就在中国大陆，
                    // 连上照样打不开 Google。这里统一查一次 IP 归属地，CN 全部剔除。
                    try {
                        java.util.Map<String, String> ipCc = new java.util.HashMap<String, String>();
                        java.util.List<String> ips = new java.util.ArrayList<String>();
                        for (Node n : nodes) {
                            String ip = n.host;
                            if (ip == null) continue;
                            // 只处理字面 IP：域名解析在部分网络下会卡很久，宁可跳过
                            if (!ip.matches("^\\d+\\.\\d+\\.\\d+\\.\\d+$")) continue;
                            if (!ipCc.containsKey(ip) && !ips.contains(ip)) ips.add(ip);
                        }
                        for (int i = 0; i < ips.size() && i < 300; i += 100) {
                            java.util.List<String> chunk = ips.subList(i, Math.min(ips.size(), i + 100));
                            try {
                                java.net.HttpURLConnection c = (java.net.HttpURLConnection)
                                        new java.net.URL("http://ip-api.com/batch?fields=status,countryCode,query")
                                                .openConnection();
                                c.setConnectTimeout(6000);
                                c.setReadTimeout(8000);
                                c.setDoOutput(true);
                                c.setRequestProperty("Content-Type", "application/json");
                                StringBuilder req = new StringBuilder("[");
                                for (int k = 0; k < chunk.size(); k++) {
                                    if (k > 0) req.append(',');
                                    req.append('"').append(chunk.get(k)).append('"');
                                }
                                req.append(']');
                                java.io.OutputStream os = c.getOutputStream();
                                os.write(req.toString().getBytes("UTF-8"));
                                os.close();
                                java.io.InputStream in = c.getInputStream();
                                java.io.ByteArrayOutputStream bos = new java.io.ByteArrayOutputStream();
                                byte[] buf = new byte[4096];
                                int len;
                                while ((len = in.read(buf)) > 0) bos.write(buf, 0, len);
                                in.close();
                                String json = new String(bos.toByteArray(), "UTF-8");
                                // ip-api 返回的字段顺序不固定，逐个对象单独取 "query" 和 "countryCode"
                                for (String obj : json.split("\\{")) {
                                    java.util.regex.Matcher mq = java.util.regex.Pattern
                                            .compile("\"query\"\\s*:\\s*\"([^\"]+)\"").matcher(obj);
                                    java.util.regex.Matcher mc = java.util.regex.Pattern
                                            .compile("\"countryCode\"\\s*:\\s*\"([A-Z]{2})\"").matcher(obj);
                                    if (mq.find() && mc.find()) ipCc.put(mq.group(1), mc.group(1));
                                }
                            } catch (Throwable ignored) {
                            }
                        }
                        if (!ipCc.isEmpty()) {
                            java.util.List<Node> filtered = new java.util.ArrayList<Node>();
                            int cn2 = 0;
                            for (Node n : nodes) {
                                String ip = n.host;
                                if (ip != null && !ip.matches("^\\d+\\.\\d+\\.\\d+\\.\\d+$")) ip = null;
                                String cc2 = ip == null ? null : ipCc.get(ip);
                                if ("CN".equalsIgnoreCase(cc2)) {
                                    cn2++;
                                    continue;
                                }
                                filtered.add(n);
                            }
                            if (cn2 > 0) Log2.i("云节点：按 IP 复查后又剔除 " + cn2 + " 个中国大陆节点");
                            nodes = filtered;
                        }
                    } catch (Throwable t) {
                        Log2.w("云节点：IP 归属复查失败（继续按原列表测试）");
                    }
                    boolean limit = limit300(ctx);
                    final java.util.List<Node> allNodesForCache = new java.util.ArrayList<Node>(nodes);
                    int total = nodes.size();
                    if (limit && total > 300) {
                        nodes = new ArrayList<Node>(nodes.subList(0, 300));
                        total = 300;
                        Log2.i("云节点：按上限只测前 300 个（源共 " + nodes.size() + "）");
                    }
                    final java.util.List<Node> testNodes = nodes;
                    final AtomicInteger done = new AtomicInteger(0);
                    final AtomicInteger ok = new AtomicInteger(0);
                    final Map<String, Integer> delays = new ConcurrentHashMap<String, Integer>();
                    ExecutorService pool = Executors.newFixedThreadPool(32);
                    final CountDownLatch latch = new CountDownLatch(testNodes.size());
                    for (final Node n : testNodes) {
                        try {
                            pool.execute(new Runnable() {
                            @Override
                            public void run() {
                                try {
                                    if (cancel) return;
                                    int ms = tcpDelay(n.host, n.port, 4000);
                                    delays.put(n.uri, ms);
                                    if (ms > 0) ok.incrementAndGet();
                                } catch (Throwable ignored) {
                                } finally {
                                    int d = done.incrementAndGet();
                                    if (listener != null && (d % 10 == 0 || d == testNodes.size())) {
                                        listener.onProgress(d, testNodes.size(), ok.get());
                                    }
                                    latch.countDown();
                                }
                            }
                            });
                        } catch (Throwable t) {
                            latch.countDown();
                        }
                    }
                    boolean finished = false;
                    try {
                        // 最多等 (节点数/32*5 秒 + 20 秒)，避免个别线程卡死把整轮拖住
                        long waitMs = Math.max(30000L, nodes.size() / 32L * 5000L + 20000L);
                        finished = latch.await(waitMs, java.util.concurrent.TimeUnit.MILLISECONDS);
                    } catch (InterruptedException ignored) {
                    }
                    if (!finished) Log2.w("云节点：部分节点测试超时，按已测到的结果继续");
                    pool.shutdownNow();
                    Map<String, String> cache = new java.util.HashMap<String, String>();
                    final Map<String, Integer> okMs = new java.util.HashMap<String, Integer>();
                    for (Node n : nodes) {
                        Integer ms = delays.get(n.uri);
                        if (ms == null) continue;
                        if (ms > 0) {
                            alive++;
                            cache.put(n.uri, "1\t" + ms);
                            okMs.put(n.uri, ms);
                            if (fastest == null || ms < fastestMs) {
                                fastest = n;
                                fastestMs = ms;
                            }
                        } else {
                            dead++;
                            cache.put(n.uri, "2\t0");
                        }
                    }
                    // 测通的按延迟排序，界面连不上时可以依次换下一个
                    java.util.List<Node> sorted = new java.util.ArrayList<Node>();
                    for (Node n : nodes) if (okMs.containsKey(n.uri)) sorted.add(n);
                    java.util.Collections.sort(sorted, new java.util.Comparator<Node>() {
                        @Override
                        public int compare(Node a, Node b) {
                            int x = okMs.get(a.uri), y = okMs.get(b.uri);
                            return x - y;
                        }
                    });
                    aliveSorted = sorted;
                    try {
                        ctx.getSharedPreferences("qv", Context.MODE_PRIVATE).edit()
                                .putInt("cloud_total_" + cacheKey(url), allNodesForCache.size()).apply();
                    } catch (Throwable ignored) {
                    }
                    saveCache(ctx, url, cache);
                    java.util.Set<String> testedSet = new java.util.HashSet<String>();
                    for (Node n : testNodes) if (delays.containsKey(n.uri)) testedSet.add(n.uri);
                    // 只保存"真正测过的"节点：不然源里有几千个没测的，列表里全是"未实测"
                    java.util.List<Node> testedNodes = new java.util.ArrayList<Node>();
                    for (Node n : allNodesForCache) if (testedSet.contains(n.uri)) testedNodes.add(n);
                    fillCountries(ctx, testedNodes);   // 给云节点补"是哪个地区"
                    saveNodes(ctx, url, testedNodes, okMs, testedSet);
                    Log2.i("云节点：" + name + " 测到 " + alive + " 可用 / " + dead + " 不可用"
                            + (fastest == null ? "" : "，最快 " + fastestMs + " ms（" + fastest.title + "）"));
                    if (listener != null) listener.onDone(alive, dead, fastest, fastestMs);
                } catch (Throwable t) {
                    Log2.w("云节点测试失败：" + t);
                    if (listener != null) listener.onError("测试失败：" + t);
                } finally {
                    running = false;
                    startedAt = 0;
                }
            }
        }, "cloud-test").start();
    }

    private static int tcpDelay(String host, int port, int timeoutMs) {
        Socket s = null;
        try {
            long t0 = System.currentTimeMillis();
            s = new Socket();
            s.connect(new InetSocketAddress(host, port), timeoutMs);
            return (int) Math.max(1, System.currentTimeMillis() - t0);
        } catch (Throwable t) {
            return -1;
        } finally {
            try {
                if (s != null) s.close();
            } catch (Throwable ignored) {
            }
        }
    }

    private static String http(String url, int timeoutMs) {
        java.net.HttpURLConnection c = null;
        try {
            c = (java.net.HttpURLConnection) new java.net.URL(url).openConnection();
            c.setConnectTimeout(timeoutMs / 2);
            c.setReadTimeout(timeoutMs);
            c.setRequestProperty("User-Agent", "Mozilla/5.0");
            c.setInstanceFollowRedirects(true);
            if (c.getResponseCode() != 200) return null;
            InputStream in = c.getInputStream();
            ByteArrayOutputStream bos = new ByteArrayOutputStream();
            byte[] buf = new byte[8192];
            int len;
            long deadline = System.currentTimeMillis() + timeoutMs * 2L;   // 总时长上限
            while ((len = in.read(buf)) > 0) {
                if (System.currentTimeMillis() > deadline) {
                    Log2.w("云节点：下载超过总时长上限，放弃");
                    in.close();
                    return null;
                }
                bos.write(buf, 0, len);
            }
            in.close();
            return new String(bos.toByteArray(), "UTF-8");
        } catch (Throwable t) {
            return null;
        } finally {
            if (c != null) c.disconnect();
        }
    }

    private static String mirrorUrl(String url) {
        try {
            String marker = "raw.githubusercontent.com/";
            int i = url.indexOf(marker);
            if (i < 0) return null;
            String rest = url.substring(i + marker.length());
            String[] p = rest.split("/", 4);
            if (p.length < 4) return null;
            return "https://cdn.jsdelivr.net/gh/" + p[0] + "/" + p[1] + "@" + p[2] + "/" + p[3];
        } catch (Throwable t) {
            return null;
        }
    }

    private static String decode(String body) {
        try {
            String clean = body.replaceAll("\\s", "");
            byte[] dec = android.util.Base64.decode(clean, android.util.Base64.DEFAULT);
            String s = new String(dec, "UTF-8");
            if (s.contains("://")) return s;
        } catch (Throwable ignored) {
        }
        return body;
    }
}
