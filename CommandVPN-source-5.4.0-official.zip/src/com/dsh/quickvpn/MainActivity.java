package com.dsh.quickvpn;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.BroadcastReceiver;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.VpnService;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseExpandableListAdapter;
import android.widget.Button;
import android.widget.ExpandableListView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Map;

/** 主界面：国家分组 + 三种连接模式 + 体检 + 编辑模式 + 置顶。 */
public class MainActivity extends Activity {

    private ExpandableListView list;
    private TextView status;
    private TextView stats;

    // 底部选项卡 + 设置 + 开关模式
    private View viewList, viewSwitch, viewSettings, viewSources;
    private View tabVpn, tabSettings, tabSource, tabAbout;
    private android.widget.ImageView icTabVpn, icTabSettings, icTabSource, icTabAbout;
    private TextView tvTabVpn, tvTabSettings, tvTabSource, tvTabAbout;
    private View indTabVpn, indTabSettings, indTabSource, indTabAbout;
    private View viewAbout;
    private RadioGroup rgTheme, rgMode;
    private TextView swFlag, swCountry, swNode, swStatus;
    private android.widget.Switch swToggle;
    private Button btnPickNode;
    private boolean suppressToggle = false;
    /** 防连点：手指连击时只认第一次。 */
    private long lastTapAt = 0;
    private boolean tapAllowed() {
        long now = System.currentTimeMillis();
        if (now - lastTapAt < 600L) return false;
        lastTapAt = now;
        return true;
    }

    private int currentTab = 0;          // 0=VPN 1=设置
    private static int pendingTab = -1;  // recreate 后要恢复的选项卡
    private boolean switchMode = false;
    private TextView conn;
    private Button btnConnect;
    private Button btnEdit;
    private CountryAdapter adapter;
    private List<Country> countries = new ArrayList<Country>();
    private final Handler ui = new Handler(Looper.getMainLooper());
    private final LatencyTester tester = new LatencyTester();
    private Node pendingNode;
    private int pendingMode = TunnelService.MODE_AUTO;
    private boolean pendingForce = false;
    private boolean pendingCloud = false;
    private String selectedUri = "";
    private String lastNetKey = "";
    private boolean editMode = false;

    /** 编辑模式下是否显示"已隐藏"的节点（对应顶栏那只眼睛）。 */
    private boolean showHiddenInEdit = false;   // 默认划线：看不到隐藏节点

    /** 选中类型：0=没选 1=最快地区 2=某个国家 3=某个节点 */
    private static final int SEL_NONE = 0, SEL_FAST = 1, SEL_COUNTRY = 2, SEL_NODE = 3;
    private int selectedKind = SEL_NONE;
    private String selectedCc = "";

    /** 列表第一行固定是"最快地区" */
    private Country fastCountry;

    private final BroadcastReceiver stateReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            String msg = intent.getStringExtra("msg");
            boolean error = intent.getBooleanExtra(TunnelService.EXTRA_ERROR, false);
            refreshState(msg);
            if (error && msg != null && cloudRetryActive
                    && System.currentTimeMillis() - TunnelService.lastDisconnectAt < 5000L) {
                Log2.i("云节点：用户刚断开，停止继续尝试");
                cloudRetryActive = false;
                cloudRetry.clear();
                cloudRetryTried = 0;
            }
            if (error && msg != null && cloudSwitching) {
                cloudSwitching = false;
                final String prevUri = cloudSwitchPrevUri;
                final String prevCc = cloudSwitchPrevCc;
                final String prevTitle = cloudSwitchPrevTitle;
                Log2.w("换节点失败：换回原节点 " + prevTitle);
                ui.post(new Runnable() {
                    @Override
                    public void run() {
                        toast("已经没有其他节点可以连了，已换回之前的节点");
                        if (prevUri == null || prevUri.length() < 8) return;
                        Node prev = new Node(prevUri, prevCc == null ? "ZZ" : prevCc,
                                prevTitle == null ? "" : prevTitle);
                        requestVpn(prev, TunnelService.MODE_NODE, true, true);
                    }
                });
                return;
            }
            if (error && msg != null && cloudRetryActive && !cloudRetry.isEmpty()
                    && cloudRetryTried < 5) {
                final Node next = cloudRetry.pollFirst();
                Log2.i("云节点：连接失败，换下一个 " + (next == null ? "" : next.title));
                ui.post(new Runnable() {
                    @Override
                    public void run() {
                        if (next == null) {
                            cloudRetryActive = false;
                            return;
                        }
                        cloudRetryTried++;
                        toast("这个节点连不上，换下一个…");
                        status.setText("云节点：第 " + cloudRetryTried + " 个连不上，换下一个…（最多 5 个）");
                        requestVpn(next, TunnelService.MODE_NODE, true, true);   // 跳过 2 秒连点保护
                    }
                });
                return;
            }
            if (error && msg != null) {
                cloudRetryActive = false;
                Log2.i("收到错误广播，长度=" + msg.length());
                final String errText = msg;
                ui.post(new Runnable() {
                    @Override
                    public void run() {
                        try {
                            showError(errText);
                        } catch (Throwable t) {
                            Log2.w("弹错误窗失败：" + t);
                            toast("连接失败：" + errText);
                        }
                    }
                });
            }
            if (intent.hasExtra("scan_total_n") && scanBar != null) {
                try {
                    scanBar.setMax(Math.max(1, intent.getIntExtra("scan_total_n", 1)));
                } catch (Throwable ignored) {
                }
            }
            if (intent.getBooleanExtra("batch_start", false)) {
                if (scanText2 != null) scanText2.setText("本批：0%");
                if (scanBar2 != null) { scanBar2.setMax(100); scanBar2.setProgress(0); }
            }
            if (intent.getBooleanExtra("probe_active", false)) {
                int pd = intent.getIntExtra("probe_done", 0);
                int pt = Math.max(1, intent.getIntExtra("probe_total", 1));
                if (scanText2 != null) {
                    int pct = (int) (pd * 100L / pt);
                    scanText2.setText("本批测速：" + Math.min(100, pct) + "%");
                }
                if (scanBar2 != null) { scanBar2.setMax(pt); scanBar2.setProgress(Math.min(pd, pt)); }
            }
            if (intent.getBooleanExtra("geo_active", false)) {
                int gd = intent.getIntExtra("geo_done", 0);
                int gt = Math.max(1, intent.getIntExtra("geo_total", 1));
                if (scanText2 != null) {
                    int pct = (int) (gd * 100L / gt);
                    scanText2.setText("本批识别地区：" + Math.min(100, pct) + "%");
                }
                if (scanBar2 != null) { scanBar2.setMax(gt); scanBar2.setProgress(Math.min(gd, gt)); }
            }
            if (intent.getBooleanExtra(TunnelService.EXTRA_SCAN_PROGRESS, false)) {
                String stage = intent.getStringExtra("scan_stage");
                if (stage != null && stage.length() > 0) {
                    if (scanText != null) scanText.setText(stage);
                } else {
                    updateScanProgress(intent.getIntExtra("scan_done_n", 0),
                            intent.getIntExtra("scan_total_n", 1),
                            intent.getIntExtra("scan_alive_n", 0));
                }
            }
            if (intent.getBooleanExtra(TunnelService.EXTRA_SCAN_DONE, false)) {
                lastScanTrashDead = intent.getBooleanExtra("scan_trash_dead", false);
                pendingScanAlive = intent.getIntExtra(TunnelService.EXTRA_SCAN_ALIVE, 0);
                pendingScanDead = intent.getIntExtra(TunnelService.EXTRA_SCAN_DEAD, 0);
                pendingScanSummary = intent.getStringExtra(TunnelService.EXTRA_SCAN_SUMMARY);
                pendingScanHidden = intent.getIntExtra("scan_hidden", 0);
                pendingScanReport = intent.getStringExtra("scan_report");
                pendingScan = true;
                // 注意：不能判 hasWindowFocus()——体检进度弹窗本身会抢走窗口焦点，
                // 那样结果就会被无限期推迟到下次 onResume（表现为"必须切后台再回来"）
                if (!uiDead()) {
                    consumeScanResult();
                } else {
                    Log2.i("界面已销毁，体检结果先记下");
                }
            }
        }
    };

    /** Activity 已经销毁/正在结束后，绝不再弹窗、不再碰 View。 */
    private boolean uiDead() {
        return isFinishing() || isDestroyed() || ui == null;
    }

    private boolean pendingScan;
    private int pendingScanAlive, pendingScanDead, pendingScanHidden;
    private String pendingScanSummary, pendingScanReport;

    /** 体检结果需要弹窗时统一在这里消费（回到前台才弹，避免抢焦点）。 */
    private void consumeScanResult() {
        if (!pendingScan) return;
        pendingScan = false;
        showScanResult(pendingScanAlive, pendingScanDead, pendingScanSummary,
                pendingScanHidden, pendingScanReport);
    }

    private String lastStateFp = "";

    private final Runnable ticker = new Runnable() {
        @Override
        public void run() {
            updateConnLine();
            ui.postDelayed(this, 1000);
        }
    };

    /** 列表状态刷新：从 onCreate 一直跑到 onDestroy，不受前后台切换影响。 */
    private final Runnable listTicker = new Runnable() {
        @Override
        public void run() {
            tickListState();
            ui.postDelayed(this, 1000);
        }
    };

    /** 连接状态变了就刷新列表：正在连接 / 已连接 / 当前节点 变化时表格立即更新。 */
    /** 手指按在列表上时暂停自动重绘，否则长按会被每秒的 notify 打断。 */
    private volatile boolean listTouching = false;

    private boolean wasScanningForUi = false;
    private int cacheHintTick = 0;
    private int firstDefaultTick = 0;
    private java.util.Map<String, Integer> countryHiddenCounts =
            new java.util.HashMap<String, Integer>();
    private android.widget.ProgressBar scanBar2;
    private TextView scanText2;
    private AlertDialog opDialog;
    private android.widget.ProgressBar opBar;
    private TextView opText;
    private volatile long lastRowLongAt = 0;
    /** 批量操作（导入/删除/还原）进行中：暂停列表重绘，避免主线程被拖死。 */
    private volatile boolean bulkBusy = false;
    private boolean wasRunningForTip = false;

    private interface OpJob {
        String run(OpProg p) throws Exception;
    }

    private class OpProg {
        void step(final int done, final int total, final String label) {
            ui.post(new Runnable() {
                @Override
                public void run() {
                    if (opBar != null) {
                        opBar.setMax(Math.max(1, total));
                        opBar.setProgress(Math.min(done, total));
                    }
                    if (opText != null) {
                        int pct = total <= 0 ? 0 : (int) (done * 100L / total);
                        opText.setText(label + "\n" + Math.max(0, Math.min(100, pct)) + "%");
                    }
                }
            });
        }
    }

    /** 批量操作统一后台 + 进度条。 */
    private void runOp(String title, final OpJob job) {
        if (uiDead()) return;
        android.widget.LinearLayout box = new android.widget.LinearLayout(this);
        box.setOrientation(android.widget.LinearLayout.VERTICAL);
        int pad = (int) (getResources().getDisplayMetrics().density * 20);
        box.setPadding(pad, pad, pad, pad);
        opText = new TextView(this);
        opText.setText("准备中…");
        opText.setTextSize(14f);
        opText.setTextColor(0xFFF0F3F8);
        box.addView(opText);
        opBar = new android.widget.ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        opBar.setMax(100);
        opBar.setProgress(0);
        try {
            opBar.setProgressTintList(android.content.res.ColorStateList.valueOf(Palette.green(this)));
        } catch (Throwable ignored) {
        }
        android.widget.LinearLayout.LayoutParams lp = new android.widget.LinearLayout.LayoutParams(
                android.widget.LinearLayout.LayoutParams.MATCH_PARENT,
                (int) (getResources().getDisplayMetrics().density * 10));
        lp.topMargin = pad / 2;
        box.addView(opBar, lp);
        opDialog = new AlertDialog.Builder(this)
                .setTitle(title)
                .setView(box)
                .setCancelable(false)
                .create();
        opDialog.show();
        final OpProg prog = new OpProg();
        bulkBusy = true;
        new Thread(new Runnable() {
            @Override
            public void run() {
                String result = "完成";
                try {
                    result = job.run(prog);
                } catch (Throwable t) {
                    Log2.w("批量操作失败：" + t);
                    result = "操作失败：" + t;
                }
                final String msg = result;
                // 重建列表（可能上万节点）放到后台做，避免主线程卡住
                java.util.List<Country> newCountries = null;
                try {
                    NodeStore.reload(MainActivity.this);
                    newCountries = NodeStore.countries(MainActivity.this,
                            editMode && showHiddenInEdit);
                } catch (Throwable t) {
                    Log2.w("后台刷新列表失败：" + t);
                }
                final java.util.List<Country> built = newCountries;
                bulkBusy = false;
                ui.post(new Runnable() {
                    @Override
                    public void run() {
                        try {
                            if (opDialog != null && opDialog.isShowing()) opDialog.dismiss();
                        } catch (Throwable ignored) {
                        }
                        opDialog = null;
                        opBar = null;
                        opText = null;
                        if (built != null) countries = built;
                        adapter.notifyDataSetChanged();
                        updateStats();
                        status.setText(msg);
                        toast(msg);
                    }
                });
            }
        }, "bulk-op").start();
    }

    private java.util.List<String> urisOf(java.util.List<Node> nodes) {
        java.util.List<String> out = new ArrayList<String>();
        for (Node n : nodes) if (n != null && n.uri != null) out.add(n.uri);
        return out;
    }

    private void tickListState() {
        try {
            updateSpeedView();
        } catch (Throwable ignored) {
        }
        try {
            if (currentTab == 1 && (++cacheHintTick % 3 == 0)) updateCacheHint();
            if (++firstDefaultTick % 2 == 0) ensureFirstDefaultUs();
        } catch (Throwable ignored) {
        }
        try {
            boolean scanningNow = TunnelService.isScanning();
            if (wasScanningForUi && !scanningNow) {
                NodeStore.reload(this);
                countries = NodeStore.countries(this, editMode && showHiddenInEdit);
                adapter.notifyDataSetChanged();
                updateStats();
                Log2.i("体检结束：列表已按最新识别结果刷新");
            }
            wasScanningForUi = scanningNow;
        } catch (Throwable ignored) {
        }
        try {
            if (!uiDead()) {
                if (RefreshRunner.isRunning() && refreshMon == null && !refreshCancelRequested) {
                    showRefreshMonitor();
                }
                if (TunnelService.isScanning() && scanDialog == null) {
                    Log2.i("界面在前台且体检在跑：弹出体检进度窗");
                    showScanMonitorIfNeeded();
                } else if (!TunnelService.isScanning() && scanDialog != null) {
                    Log2.i("体检已结束，收起残留的进度窗");
                    dismissScanProgress();
                }
            }
        } catch (Throwable ignored) {
        }
        Node cur = TunnelService.currentNode();
        Node con = TunnelService.connectingNode();
        String fp = (TunnelService.isRunning() ? "R" : "-")
                + (TunnelService.isConnecting() ? "C" : "-")
                + (cur == null ? "" : cur.cc)
                + "|" + (con == null ? "" : con.cc);
        try {
            // 每秒都重绘：列表里可见的只有十来行，开销可以忽略，
            // 这样"正在连接 / 已连接 / 延迟"永远是实时的（不再靠广播碰巧触发）
            if (bulkBusy) {          // 批量操作期间别在界面线程读节点，避免卡死
                return;
            }
            if (!listTouching) adapter.notifyDataSetChanged();
            updateConnectButton();
            if (switchMode) updateSwitchView();
            if (!fp.equals(lastStateFp)) {
                lastStateFp = fp;
                updateStats();
                if (currentTab == 2) renderSources();   // 节点源页跟着刷新（绿色标记/已连接标题）
                Log2.i("列表状态刷新 finger=" + fp);
            }
            if (currentTab == 2 && srcConnTip != null
                    && TunnelService.isRunning() && TunnelService.cloudSource() != null) {
                long since = TunnelService.connectedSince();
                long sec = since > 0 ? Math.max(0, (System.currentTimeMillis() - since) / 1000) : 0;
                int d = TunnelService.connectedDelay();
                srcConnTip.setText("已连接 " + (cloudConnectedTitle == null ? "" : cloudConnectedTitle)
                        + " 节点 · " + String.format(java.util.Locale.US, "%02d:%02d:%02d",
                        sec / 3600, (sec / 60) % 60, sec % 60)
                        + (d > 0 ? " · 代理延迟 " + d + " ms" : ""));
            }
            // 云节点连接时：状态栏写"已连接云节点"（黄色）
            if (TunnelService.isRunning() && TunnelService.cloudSource() != null) {
                status.setText("已连接云节点");
                status.setTextColor(0xFFE0B44A);
            } else {
                status.setTextColor(Palette.textDim(this));
            }
        } catch (Throwable t) {
            Log2.w("刷新列表状态失败：" + t);
        }
    }

    private final android.os.Handler lpHandler =
            new android.os.Handler(android.os.Looper.getMainLooper());
    private float lpDownX = 0, lpDownY = 0;
    private boolean lpArmed = false;
    private final Runnable lpTask = new Runnable() {
        @Override
        public void run() {
            try {
                if (!lpArmed || uiDead() || currentTab != 0) return;
                lpArmed = false;
                // 开关模式下列表是隐藏的（父容器 GONE），此时不能再弹列表菜单
                if (switchMode || list == null || !list.isShown()) return;
                int[] loc = new int[2];
                list.getLocationOnScreen(loc);
                if (lpDownY < loc[1] || lpDownY > loc[1] + list.getHeight()
                        || lpDownX < loc[0] || lpDownX > loc[0] + list.getWidth()) {
                    return;
                }
                int x = (int) lpDownX - loc[0];
                int y = (int) lpDownY - loc[1];
                int pos = list.pointToPosition(x, y);
                Log2.i("长按判定 pos=" + pos);
                if (pos >= 0) {
                    lastRowLongAt = System.currentTimeMillis();
                    showItemMenuAt(pos);
                }
            } catch (Throwable t) {
                Log2.w("长按判定失败：" + t);
            }
        }
    };

    @Override
    public boolean dispatchTouchEvent(android.view.MotionEvent ev) {
        try {
            int a = ev.getActionMasked();
            if (a == android.view.MotionEvent.ACTION_DOWN) {
                lpDownX = ev.getRawX();
                lpDownY = ev.getRawY();
                lpArmed = true;
                lpHandler.removeCallbacks(lpTask);
                lpHandler.postDelayed(lpTask, 400);
            } else if (a == android.view.MotionEvent.ACTION_MOVE) {
                if (Math.abs(ev.getRawX() - lpDownX) > 30
                        || Math.abs(ev.getRawY() - lpDownY) > 30) {
                    lpHandler.removeCallbacks(lpTask);
                    lpArmed = false;
                }
            } else if (a == android.view.MotionEvent.ACTION_UP
                    || a == android.view.MotionEvent.ACTION_CANCEL) {
                lpHandler.removeCallbacks(lpTask);
                lpArmed = false;
            }
        } catch (Throwable ignored) {
        }
        return super.dispatchTouchEvent(ev);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Theme.applyWindow(this);
        Log2.init(this);

        list = (ExpandableListView) findViewById(R.id.list);
        list.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, android.view.MotionEvent e) {
                int a = e.getActionMasked();
                listTouching = (a == android.view.MotionEvent.ACTION_DOWN
                        || a == android.view.MotionEvent.ACTION_MOVE);
                if (a == android.view.MotionEvent.ACTION_UP
                        || a == android.view.MotionEvent.ACTION_CANCEL) {
                    // 松手后延迟一点再恢复重绘，避免把长按判定吃掉
                    ui.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            listTouching = false;
                        }
                    }, 700);
                }
                return false;
            }
        });
        status = (TextView) findViewById(R.id.status);
        stats = (TextView) findViewById(R.id.stats);
        conn = (TextView) findViewById(R.id.conn);
        btnConnect = (Button) findViewById(R.id.btnConnect);
        btnEdit = (Button) findViewById(R.id.btnImport);

        countries = NodeStore.countries(this);
        fastCountry = new Country("FAST", new ArrayList<Node>());
        restoreSelection();
        adapter = new CountryAdapter();
        list.setAdapter(adapter);
        // 长按交给系统判定（行自己接管触摸在展开列表里不可靠）
        list.setOnItemLongClickListener(new android.widget.AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(android.widget.AdapterView<?> parent, View view,
                                           final int position, long id) {
                if (System.currentTimeMillis() - lastRowLongAt < 1500) return true;
                lastRowLongAt = System.currentTimeMillis();
                showItemMenuAt(position);
                return true;
            }
        });

        list.setOnGroupExpandListener(new ExpandableListView.OnGroupExpandListener() {
            @Override
            public void onGroupExpand(int groupPosition) {
                adapter.notifyDataSetChanged();
            }
        });
        list.setOnGroupCollapseListener(new ExpandableListView.OnGroupCollapseListener() {
            @Override
            public void onGroupCollapse(int groupPosition) {
                adapter.notifyDataSetChanged();
            }
        });
        list.setOnGroupClickListener(new ExpandableListView.OnGroupClickListener() {
            @Override
            public boolean onGroupClick(ExpandableListView parent, View v, int groupPosition, long id) {
                if (groupPosition == 0) {
                    selectFast();
                    return true;
                }
                Country cc = countries.get(groupPosition - 1);
                Log2.i("组点击 pos=" + groupPosition + " cc=" + cc.cc);
                selectCountry(cc);
                return true;              // 只选中，不展开（展开点箭头）
            }
        });

        list.setOnChildClickListener(new ExpandableListView.OnChildClickListener() {
            @Override
            public boolean onChildClick(ExpandableListView parent, View v, int groupPosition, int childPosition, long id) {
                Node n = countries.get(groupPosition - 1).nodes.get(childPosition);
                if (editMode && n.hidden) {
                    NodeStore.blacklistRemove(MainActivity.this, n.uri);
                    refreshAfterEdit("已恢复显示：" + n.title);
                } else if (editMode && !NodeStore.isGood(MainActivity.this, n.uri)) {
                    showUnverifiedMenu(n);
                } else if (editMode) {
                    showNodeEditMenu(n);
                } else {
                    selectNode(n);
                }
                return true;
            }
        });

        btnConnect.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!tapAllowed()) return;
                if (TunnelService.isRunning() || TunnelService.isConnecting()) {
                    TunnelService.disconnect(MainActivity.this);
                    btnConnect.setText("连接");
                    status.setText("已断开");
                    updateConnectButton();
                } else {
                    connectSelected();
                }
            }
        });


        btnEdit.setText("编辑");
        btnEdit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                setEditMode(!editMode);
            }
        });

        // 测试延迟 = 快速 TCP 测速（几十秒扫完，用来排序）；体检 = 逐个真连（慢，用来判定死活）
        findViewById(R.id.btnLatency).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (editMode) {
                    showImportDialog();
                    return;
                }
                if (TunnelService.isRunning() || TunnelService.isConnecting()) {
                    toast("先断开连接再测延迟");
                    return;
                }
                runGlobalTest();
            }
        });
        findViewById(R.id.btnSpeed).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (editMode) {
                    showTrash();
                } else {
                    toggleScan();
                }
            }
        });
        findViewById(R.id.btnSpeed).setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                restoreHidden();
                return true;
            }
        });
        bindAutoRefreshSettings();
        bindSourcePage();
        bindTiktokTip();
        findViewById(R.id.btnRefreshNodes).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!tapAllowed()) return;
                showFastScanTipThen(new Runnable() {
                    @Override
                    public void run() {
                        askRefreshSourceCount();
                    }
                });
            }
        });
        findViewById(R.id.btnLog).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (editMode) {
                    toggleHiddenVisible();
                } else {
                    showLogs();
                }
            }
        });
        // 长按眼睛：删除全部隐藏节点（永久）
        findViewById(R.id.btnLog).setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                confirmPurgeAllHidden();
                return true;
            }
        });
        // 开机后或首次启用时，把下一次自动翻新重新排上
        try {
            if (AutoRefresh.enabled(this)) AutoRefresh.schedule(this);
        } catch (Throwable t) {
            Log2.w("安排自动翻新失败：" + t);
        }
        // 从"VPN 已断开"通知点回来：记住要重连的国家
        try {
            Intent it = getIntent();
            if (it != null && it.hasExtra("reconnect_cc")) {
                pendingReconnectCc = it.getStringExtra("reconnect_cc");
                pendingReconnectFastest = getSharedPreferences("qv", MODE_PRIVATE)
                        .getBoolean("reconnect_fastest", false);
                Log2.i("从断开通知进入，准备重连：" + pendingReconnectCc);
                // 关键：读完就把这个 extra 去掉，否则切主题/重建会再触发一次重连
                it.removeExtra("reconnect_cc");
            } else {
                // 正常打开：清掉上次留下的重连记录（两个 key 都要清）
                getSharedPreferences("qv", MODE_PRIVATE).edit()
                        .remove("reconnect_cc").remove("reconnect_fastest").apply();
            }
            android.app.NotificationManager nm = (android.app.NotificationManager) getSystemService(NOTIFICATION_SERVICE);
            if (nm != null) nm.cancel(0x53);      // 去掉"VPN 已断开"那条提醒
        } catch (Throwable ignored) {
        }
        // 首次打开（没有任何节点）：引导先翻新
        maybeForceFirstRefresh();
        if (RefreshRunner.isRunning()) {
            // 后台任务正在跑：直接接管显示，不另起任务
            Log2.i("打开界面时发现翻新正在进行，接续显示进度");
            ui.postDelayed(new Runnable() {
                @Override
                public void run() {
                    showRefreshMonitor();
                }
            }, 400);
        }
        status.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                showLogs();
                return true;
            }
        });
        findViewById(R.id.btnGoogle).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openUrl("https://www.google.com");
            }
        });
        findViewById(R.id.btnTiktok).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openUrl("https://www.tiktok.com");
            }
        });
        findViewById(R.id.btnInstagram).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openUrl("https://www.instagram.com");
            }
        });

        bindTabsAndSettings();
        applyUi();

        int total = NodeStore.all(this).size();
        int hidden = NodeStore.blacklistSize(this);
        boolean showAll = NodeStore.showAll(this);
        status.setText(hidden > 0 ? ("已隐藏 " + hidden + " 个节点") : "");
        Log2.i("界面就绪：" + countries.size() + " 组 / " + total + " 节点 / 隐藏 " + hidden);

        updateConnectButton();
        updateStats();

        ui.post(listTicker);
        try {
            registerReceiver(stateReceiver, new IntentFilter(TunnelService.ACTION_STATE));
            IntentFilter rf = new IntentFilter(RefreshRunner.ACTION_REFRESH_STATE);
            registerReceiver(refreshStateReceiver, rf);
            Log2.i("状态广播接收器已注册");
        } catch (Throwable t) {
            Log2.w("注册广播失败：" + t);
        }

        if (Crashes.hasCrash(this)) {
            ui.postDelayed(new Runnable() {
                @Override
                public void run() {
                    showCrashReport();
                }
            }, 400);
        }
    }

    /* -------------------------- 选项卡 / 设置 / 开关模式 -------------------------- */

    private void bindTabsAndSettings() {
        viewList = findViewById(R.id.viewList);
        viewSwitch = findViewById(R.id.viewSwitch);
        viewSettings = findViewById(R.id.viewSettings);
        viewSources = findViewById(R.id.viewSources);
        tabVpn = findViewById(R.id.tabVpn);
        tabSettings = findViewById(R.id.tabSettings);
        tabSource = findViewById(R.id.tabSource);
        tabAbout = findViewById(R.id.tabAbout);
        icTabVpn = (android.widget.ImageView) findViewById(R.id.icTabVpn);
        icTabSettings = (android.widget.ImageView) findViewById(R.id.icTabSettings);
        icTabSource = (android.widget.ImageView) findViewById(R.id.icTabSource);
        icTabAbout = (android.widget.ImageView) findViewById(R.id.icTabAbout);
        tvTabVpn = (TextView) findViewById(R.id.tvTabVpn);
        tvTabSettings = (TextView) findViewById(R.id.tvTabSettings);
        tvTabSource = (TextView) findViewById(R.id.tvTabSource);
        tvTabAbout = (TextView) findViewById(R.id.tvTabAbout);
        indTabVpn = findViewById(R.id.indTabVpn);
        indTabSettings = findViewById(R.id.indTabSettings);
        indTabSource = findViewById(R.id.indTabSource);
        indTabAbout = findViewById(R.id.indTabAbout);
        viewAbout = findViewById(R.id.viewAbout);
        if (tabAbout != null) {
            tabAbout.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (!tapAllowed()) return;
                    showTab(3);
                }
            });
        }
        rgTheme = (RadioGroup) findViewById(R.id.rgTheme);
        rgMode = (RadioGroup) findViewById(R.id.rgMode);

        tabVpn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!tapAllowed()) return;
                showTab(0);
            }
        });
        tabSource.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showTab(2);
            }
        });
        tabSettings.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!tapAllowed()) return;
                showTab(1);
            }
        });

        int theme = Theme.pref(this);
        ((RadioButton) findViewById(theme == Theme.LIGHT ? R.id.rbLight
                : theme == Theme.SYSTEM ? R.id.rbSystem : R.id.rbDark)).setChecked(true);
        int mode = getPreferencesMode();
        ((RadioButton) findViewById(mode == 1 ? R.id.rbSwitchMode : R.id.rbListMode)).setChecked(true);
        switchMode = (mode == 1);

        rgTheme.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                int v = checkedId == R.id.rbLight ? Theme.LIGHT
                        : checkedId == R.id.rbSystem ? Theme.SYSTEM : Theme.DARK;
                if (v == Theme.pref(MainActivity.this)) return;
                Log2.i("切换外观，重建");
                Theme.setPref(MainActivity.this, v);
                Log2.i("外观切换为 " + (v == Theme.LIGHT ? "浅色" : v == Theme.SYSTEM ? "跟随系统" : "深色"));
                pendingTab = currentTab;     // recreate 之后仍停在设置页
                recreate();
            }
        });
        rgMode.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                int v = checkedId == R.id.rbSwitchMode ? 1 : 0;
                setPreferencesMode(v);
                switchMode = (v == 1);
                Log2.i("VPN 界面切换为 " + (switchMode ? "开关模式" : "列表模式"));
                // 停留在设置页，只更新可见性，不切回 VPN 页
                viewList.setVisibility(currentTab == 0 && !switchMode ? View.VISIBLE : View.GONE);
                viewSwitch.setVisibility(currentTab == 0 && switchMode ? View.VISIBLE : View.GONE);
                applyUi();
            }
        });

        swFlag = (TextView) findViewById(R.id.swFlag);
        swCountry = (TextView) findViewById(R.id.swCountry);
        swNode = (TextView) findViewById(R.id.swNode);
        swStatus = (TextView) findViewById(R.id.swStatus);
        swToggle = null;   // 开关模式改成大按钮，不再有 Switch 控件
        btnPickNode = (Button) findViewById(R.id.btnPickNode);

        if (swToggle != null) {
            swToggle.setOnCheckedChangeListener(new android.widget.CompoundButton.OnCheckedChangeListener() {
                @Override
                public void onCheckedChanged(android.widget.CompoundButton buttonView, boolean isChecked) {
                    if (suppressToggle) return;
                    if (!tapAllowed()) {
                        suppressToggle = true;
                        swToggle.setChecked(!isChecked);
                        suppressToggle = false;
                        return;
                    }
                    Log2.i("大开关 " + (isChecked ? "打开" : "关闭"));
                    if (isChecked) {
                        connectSelected();
                    } else {
                        cancelCloudRetryChain();
                        TunnelService.disconnect(MainActivity.this, "用户在界面关掉大开关");
                        status.setText("已断开");
                    }
                }
            });
        }
        swSlide = (com.dsh.quickvpn.SlideBar) findViewById(R.id.swSlide);
        if (swSlide != null) {
            swSlide.setColors(Theme.isDark(this) ? 0xFF1B2330 : 0xFFE2EAF7,
                    Theme.isDark(this) ? 0xFF2C3646 : 0xFFCFDCF0,
                    Palette.blue(this), Palette.blue(this),
                    Theme.isDark(this) ? 0xFF9AA4B2 : 0xFF6B7A90);
            swSlide.setListener(new com.dsh.quickvpn.SlideBar.Listener() {
                @Override
                public void onSlideOn() {
                    if (!tapAllowed()) {
                        snapSlideToState();
                        return;
                    }
                    if (selectedKind == SEL_NONE
                            || (selectedKind == SEL_COUNTRY && selectedCc == null)
                            || (selectedKind == SEL_NODE && selectedUri == null)) {
                        // 没选地区/节点：不能"假装连上"，滑回原位并提示
                        toast("先在「选择地区 / 节点」里挑一个，再滑动连接");
                        snapSlideToState();
                        return;
                    }
                    Log2.i("滑动条：连接");
                    slidePending = true;
                    slidePendingAt = System.currentTimeMillis();
                    // 立刻进入"正在连接"文案，避免先闪一下"已连接"
                    if (swSlide != null) {
                        swSlide.setOnState(true);
                        swSlide.setConnecting(true);
                    }
                    connectSelected();
                }

                @Override
                public void onSlideOff() {
                    if (!tapAllowed()) {
                        snapSlideToState();
                        return;
                    }
                    Log2.i("滑动条：断开");
                    slidePending = false;
                    cancelCloudRetryChain();
                    TunnelService.disconnect(MainActivity.this, "用户在开关模式滑动断开");
                    status.setText("已断开");
                }
            });
        }
        btnPickNode.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!tapAllowed()) return;
                showNodePickerForSwitch();
            }
        });

        findViewById(R.id.swGoogle).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openUrl("https://www.google.com");
            }
        });
        findViewById(R.id.swTiktok).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openUrl("https://www.tiktok.com");
            }
        });
        findViewById(R.id.swInstagram).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openUrl("https://www.instagram.com");
            }
        });

        if (pendingTab >= 0) {
            showTab(pendingTab);
            pendingTab = -1;
        } else {
            showTab(0);
        }
        if (switchMode) ensureSwitchDefault();
        updateSwitchView();
    }

    private boolean containsUri(Country c, String uri) {
        if (c == null || uri == null) return false;
        for (Node n : c.nodes) if (uri.equals(n.uri)) return true;
        return false;
    }

    /** 去掉字符串里的国旗 emoji（区域指示符号 U+1F1E6~U+1F1FF 成对出现）。 */
    private static String stripFlagEmoji(String s) {
        if (s == null) return "";
        StringBuilder sb = new StringBuilder(s.length());
        for (int i = 0; i < s.length(); ) {
            int cp = s.codePointAt(i);
            int len = Character.charCount(cp);
            boolean regional = cp >= 0x1F1E6 && cp <= 0x1F1FF;
            boolean vs16 = cp == 0xFE0F || cp == 0x200D;
            if (!regional && !vs16) sb.appendCodePoint(cp);
            i += len;
        }
        return sb.toString().trim();
    }

    /** 开关模式默认选中美国（没有美国就退而选第一个地区）。 */
    private void updateCacheHint() {
        TextView cacheHint = (TextView) findViewById(R.id.tvCacheHint);
        if (cacheHint == null) return;
        long bytes = NodeStore.cacheBytes(this);
        cacheHint.setText("缓存：" + NodeStore.formatBytes(bytes)
                + "（云节点测速结果、延迟表、地区识别结果）");
        cacheHint.setTextColor(Palette.textFaint(this));
    }

    private void startClearCacheFlow() {
        final long bytes = NodeStore.cacheBytes(this);
        new AlertDialog.Builder(this)
                .setTitle("清除全部缓存？")
                .setMessage("当前缓存 " + NodeStore.formatBytes(bytes) + "。\n\n"
                        + "会清掉：\n"
                        + "· 云节点测速结果（含地区）\n"
                        + "· 节点延迟表\n"
                        + "· 地区识别结果（会恢复成未识别地区，下次体检重新识别）\n\n"
                        + "不会清掉：回收站、已隐藏/已显示状态、永久删除名单、节点源、日志")
                .setPositiveButton("清除", new android.content.DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(android.content.DialogInterface d, int w) {
                        long freed = NodeStore.clearAllCaches(MainActivity.this);
                        updateCacheHint();
                        refreshAfterEdit("已清除缓存：" + NodeStore.formatBytes(freed));
                    }
                })
                .setNegativeButton("取消", null)
                .show();
    }

    private void ensureFirstDefaultUs() {
        try {
            android.content.SharedPreferences sp = getSharedPreferences("qv", MODE_PRIVATE);
            if (sp.getBoolean("sel_default_us_v1", false)) return;
            if (selectedKind != SEL_NONE) {
                sp.edit().putBoolean("sel_default_us_v1", true).apply();
                return;
            }
            if (countries == null || countries.isEmpty()) return;
            for (Country c : countries) {
                if ("US".equalsIgnoreCase(c.cc)) {
                    selectCountry(c);
                    sp.edit().putBoolean("sel_default_us_v1", true).apply();
                    Log2.i("首次启动默认选中美国（" + c.nodes.size() + " 个节点）");
                    return;
                }
            }
        } catch (Throwable ignored) {
        }
    }

    private void ensureSwitchDefault() {
        if (selectedKind != SEL_NONE) return;
        if (countries == null || countries.isEmpty()) return;
        for (Country c : countries) {
            if ("US".equalsIgnoreCase(c.cc)) {
                selectCountry(c);
                Log2.i("开关模式默认选中美国");
                return;
            }
        }
        selectCountry(countries.get(0));
    }

    private int getPreferencesMode() {
        try {
            return getSharedPreferences("qv", MODE_PRIVATE).getInt("ui_mode", 1);
        } catch (Throwable t) {
            return 0;
        }
    }

    private void setPreferencesMode(int v) {
        try {
            getSharedPreferences("qv", MODE_PRIVATE).edit().putInt("ui_mode", v).apply();
        } catch (Throwable ignored) {
        }
    }

    /** 切换底部选项卡：0=VPN 1=设置 2=节点源 3=关于 */
    /** 上传/下载速度：从 TunnelService 每秒差值取数。 */
    private void updateSpeedView() {
        View row = findViewById(R.id.speedRow);
        TextView up = (TextView) findViewById(R.id.spdUp);
        TextView down = (TextView) findViewById(R.id.spdDown);
        if (row == null) return;
        boolean run = TunnelService.isRunning();
        if (row != null) row.setVisibility(run ? View.VISIBLE : View.GONE);
        if (run) {
            if (up != null) up.setText("\u2191 " + fmtSpeed(TunnelService.speedUp()));
            if (down != null) down.setText("\u2193 " + fmtSpeed(TunnelService.speedDown()));
        }
        try {
            TextView sup = (TextView) findViewById(R.id.swSpdUp);
            TextView sdown = (TextView) findViewById(R.id.swSpdDown);
            if (sup != null) sup.setText(run ? fmtSpeed(TunnelService.speedUp()) : "0 KB/s");
            if (sdown != null) sdown.setText(run ? fmtSpeed(TunnelService.speedDown()) : "0 KB/s");
        } catch (Throwable ignored) {
        }
    }

    private String fmtSpeed(long bps) {
        if (bps < 1024) return bps + " B/s";
        if (bps < 1024L * 1024L) {
            return String.format(java.util.Locale.US, "%.1f KB/s", bps / 1024.0);
        }
        return String.format(java.util.Locale.US, "%.2f MB/s", bps / 1048576.0);
    }

    /** 设置页的开关统一配色：开=绿色、关=灰蓝。 */
    private void styleSwitchTints() {
        int[] ids = {R.id.swAutoRefresh, R.id.swAutoBoot, R.id.swAutoScan, R.id.swCloudLimit,
                R.id.swScanHidden, R.id.swFastScan, R.id.swLogKernel, R.id.swAutoNotify,
                R.id.swLimitAuto, R.id.swLimitManual};
        android.content.res.ColorStateList thumb = new android.content.res.ColorStateList(
                new int[][]{{android.R.attr.state_checked}, {}},
                new int[]{0xFF5FD08A, 0xFF6B7488});
        android.content.res.ColorStateList track = new android.content.res.ColorStateList(
                new int[][]{{android.R.attr.state_checked}, {}},
                new int[]{0x665FD08A, 0xFF262C38});
        for (int id : ids) {
            try {
                View v = findViewById(id);
                if (v instanceof android.widget.Switch) {
                    ((android.widget.Switch) v).setThumbTintList(thumb);
                    ((android.widget.Switch) v).setTrackTintList(track);
                }
            } catch (Throwable ignored) {
            }
        }
    }

    /** 底部选项卡：选中项图标/文字变绿加粗，下方出现指示条。 */
    private void styleTab(int idx, boolean on) {
        android.widget.ImageView[] ics = {icTabVpn, icTabSettings, icTabSource, icTabAbout};
        TextView[] tvs = {tvTabVpn, tvTabSettings, tvTabSource, tvTabAbout};
        View[] inds = {indTabVpn, indTabSettings, indTabSource, indTabAbout};
        int color = on ? Palette.green(this) : 0xFF8A93A6;
        if (idx < 0 || idx > 3) return;
        if (tvs[idx] != null) {
            tvs[idx].setTextColor(color);
            tvs[idx].setTypeface(null, on ? android.graphics.Typeface.BOLD
                    : android.graphics.Typeface.NORMAL);
        }
        if (ics[idx] != null) ics[idx].setColorFilter(color);
        if (inds[idx] != null) inds[idx].setVisibility(on ? View.VISIBLE : View.INVISIBLE);
    }

    private void showTab(int tab) {
        currentTab = tab;
        viewSettings.setVisibility(tab == 1 ? View.VISIBLE : View.GONE);
        if (viewSources != null) viewSources.setVisibility(tab == 2 ? View.VISIBLE : View.GONE);
        if (viewAbout != null) viewAbout.setVisibility(tab == 3 ? View.VISIBLE : View.GONE);
        viewList.setVisibility(tab == 0 && !switchMode ? View.VISIBLE : View.GONE);
        viewSwitch.setVisibility(tab == 0 && switchMode ? View.VISIBLE : View.GONE);
        for (int i = 0; i < 4; i++) styleTab(i, tab == i);
        if (tab == 0 && switchMode) updateSwitchView();
        if (tab == 1) updateCacheHint();
        if (tab == 2) renderSources();
        if (tab == 3) bindAbout();
    }

    private static final String UPDATE_REPO = "zqwxe/Command-VPN";
    private static final String GITHUB_URL = "https://github.com/zqwxe/Command-VPN";
    private boolean updateChecking = false;

    private String appVersion() {
        try {
            return getPackageManager().getPackageInfo(getPackageName(), 0).versionName;
        } catch (Throwable t) {
            return "?";
        }
    }

    private void bindAbout() {
        try {
            TextView name = (TextView) findViewById(R.id.aboutName);
            if (name != null) name.setTextColor(Palette.text(this));
            TextView ver = (TextView) findViewById(R.id.aboutVersion);
            if (ver != null) {
                ver.setText("v" + appVersion());
                ver.setTextColor(Palette.textDim(this));
            }
            TextView hint = (TextView) findViewById(R.id.tvAboutHint);
            if (hint != null) hint.setTextColor(Palette.textFaint(this));
            android.widget.ImageView icon = (android.widget.ImageView) findViewById(R.id.aboutIcon);
            if (icon != null) {
                try {
                    icon.setImageResource(getApplicationInfo().icon);
                } catch (Throwable ignored) {
                }
            }
            Button gh = (Button) findViewById(R.id.btnAboutGithub);
            if (gh != null) {
                gh.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if (!tapAllowed()) return;
                        openUrl(GITHUB_URL);
                        toast("已打开官方 GitHub 存储库");
                    }
                });
            }
            Button clAll = (Button) findViewById(R.id.btnChangelogAll);
            if (clAll != null) {
                clAll.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if (!tapAllowed()) return;
                        showChangelogDialog("更新日志", "changelog_all.html", true);
                    }
                });
            }
            Button clOff = (Button) findViewById(R.id.btnChangelogOfficial);
            if (clOff != null) {
                clOff.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if (!tapAllowed()) return;
                        showChangelogDialog("正式版更新日志", "changelog_official.html", false);
                    }
                });
            }
            Button chk = (Button) findViewById(R.id.btnCheckUpdate);
            if (chk != null) {
                chk.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if (!tapAllowed()) return;
                        checkUpdate(false);
                    }
                });
            }
        } catch (Throwable t) {
            Log2.w("关于页初始化失败：" + t);
        }
    }

    /** 用自绘白底弹窗显示与 Word 完全一致的更新日志（白纸黑字，配色照 Word）。
     *  withJump=true 时底部多一个「翻到最下面」按钮（只有普通更新日志有）。 */
    private android.app.Dialog changelogDialog;

    private void showChangelogDialog(final String title, final String asset, boolean withJump) {
        try {
            if (changelogDialog != null && changelogDialog.isShowing()) changelogDialog.dismiss();
        } catch (Throwable ignored) {
        }
        String html;
        try {
            java.io.InputStream in = getAssets().open(asset);
            java.io.ByteArrayOutputStream bos = new java.io.ByteArrayOutputStream();
            byte[] buf = new byte[8192];
            int len;
            while ((len = in.read(buf)) > 0) bos.write(buf, 0, len);
            in.close();
            html = new String(bos.toByteArray(), "UTF-8");
        } catch (Throwable t) {
            toast("读取更新日志失败：" + t);
            return;
        }
        float dp = getResources().getDisplayMetrics().density;
        int pad = (int) (dp * 16);
        // 弹窗整体（标题+网页+按钮）不能超出可用高度，小屏/横屏时网页区域自动缩
        int screenH = getResources().getDisplayMetrics().heightPixels;
        final int h = Math.max((int) (screenH * 0.30f),
                Math.min((int) (screenH * 0.62f), (int) (screenH * 0.80f - dp * 150)));

        final android.widget.LinearLayout root = new android.widget.LinearLayout(this);
        root.setOrientation(android.widget.LinearLayout.VERTICAL);
        root.setBackgroundColor(0xFFFFFFFF);

        android.widget.TextView tvTitle = new android.widget.TextView(this);
        tvTitle.setText(title);
        tvTitle.setTextColor(0xFF111111);
        tvTitle.setTextSize(17f);
        tvTitle.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
        tvTitle.setPadding(pad, pad, pad, (int) (dp * 8));
        root.addView(tvTitle);

        android.view.View divider = new android.view.View(this);
        divider.setBackgroundColor(0xFFE6E6E6);
        root.addView(divider, new android.widget.LinearLayout.LayoutParams(
                android.widget.LinearLayout.LayoutParams.MATCH_PARENT,
                Math.max(1, (int) dp)));

        final android.webkit.WebView wv = new android.webkit.WebView(this);
        boolean webOk = true;
        try {
            wv.setBackgroundColor(0xFFFFFFFF);
            android.webkit.WebSettings ws = wv.getSettings();
            ws.setJavaScriptEnabled(false);
            ws.setSupportZoom(true);
            ws.setBuiltInZoomControls(false);
            ws.setDisplayZoomControls(false);
            ws.setUseWideViewPort(true);
            ws.setLoadWithOverviewMode(false);
            ws.setAllowFileAccess(true);
            try {
                ws.setAllowFileAccessFromFileURLs(true);
                ws.setAllowUniversalAccessFromFileURLs(true);
            } catch (Throwable ignored) {
            }
            wv.setLayoutParams(new android.widget.LinearLayout.LayoutParams(
                    android.widget.LinearLayout.LayoutParams.MATCH_PARENT, h));
            wv.loadDataWithBaseURL("file:///android_asset/", html, "text/html", "UTF-8", null);
            wv.setWebViewClient(new android.webkit.WebViewClient() {
                @Override
                public void onReceivedError(android.webkit.WebView view,
                                            android.webkit.WebResourceRequest req,
                                            android.webkit.WebResourceError err) {
                    toast("更新日志加载出错：" + err.getDescription());
                }
            });
            root.addView(wv);
        } catch (Throwable t) {
            webOk = false;
            android.widget.TextView fb = new android.widget.TextView(this);
            fb.setText(plainFromMarkup(asset));
            fb.setTextSize(12.5f);
            fb.setTextColor(0xFF111111);
            fb.setBackgroundColor(0xFFFFFFFF);
            fb.setTextIsSelectable(true);
            fb.setPadding(pad, pad, pad, pad);
            android.widget.ScrollView sv = new android.widget.ScrollView(this);
            sv.setBackgroundColor(0xFFFFFFFF);
            sv.addView(fb);
            sv.setLayoutParams(new android.widget.LinearLayout.LayoutParams(
                    android.widget.LinearLayout.LayoutParams.MATCH_PARENT, h));
            root.addView(sv);
        }

        android.widget.LinearLayout bar = new android.widget.LinearLayout(this);
        bar.setOrientation(android.widget.LinearLayout.HORIZONTAL);
        bar.setGravity(android.view.Gravity.END);
        bar.setPadding(pad, (int) (dp * 4), pad, (int) (dp * 4));

        final android.app.Dialog dlg = new android.app.Dialog(this);
        if (withJump) {
            android.widget.TextView jump = new android.widget.TextView(this);
            jump.setText("翻到最下面");
            jump.setTextColor(0xFF00897B);
            jump.setTextSize(15f);
            jump.setPadding((int) (dp * 12), (int) (dp * 10), (int) (dp * 12), (int) (dp * 10));
            final boolean okWeb = webOk;
            jump.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (okWeb) {
                        wv.post(new Runnable() {
                            @Override
                            public void run() {
                                wv.scrollTo(0, (int) (wv.getContentHeight() * wv.getScale()));
                            }
                        });
                    }
                }
            });
            bar.addView(jump);
        }
        android.widget.TextView close = new android.widget.TextView(this);
        close.setText("关闭");
        close.setTextColor(0xFF00897B);
        close.setTextSize(15f);
        close.setPadding((int) (dp * 12), (int) (dp * 10), (int) (dp * 12), (int) (dp * 10));
        close.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dlg.dismiss();
            }
        });
        bar.addView(close);
        root.addView(bar);

        changelogDialog = dlg;
        dlg.setContentView(root);
        android.view.Window win = dlg.getWindow();
        if (win != null) {
            win.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(0xFFFFFFFF));
        }
        dlg.show();
        if (dlg.getWindow() != null) {
            dlg.getWindow().setLayout(android.view.ViewGroup.LayoutParams.MATCH_PARENT,
                    android.view.ViewGroup.LayoutParams.WRAP_CONTENT);
        }
    }

    /** 兜底：WebView 不可用时，直接读 HTML 去掉标签当纯文本显示。 */
    private CharSequence plainFromMarkup(String asset) {
        try {
            java.io.InputStream in = getAssets().open(asset);
            java.io.ByteArrayOutputStream bos = new java.io.ByteArrayOutputStream();
            byte[] buf = new byte[8192];
            int len;
            while ((len = in.read(buf)) > 0) bos.write(buf, 0, len);
            in.close();
            String html = new String(bos.toByteArray(), "UTF-8");
            String t = html.replaceAll("<\\s*br\\s*/?>", "\n")
                    .replaceAll("</(div|p|h1|h2|h3|tr|td)>", "\n")
                    .replaceAll("<[^>]+>", "")
                    .replace("&nbsp;", " ").replace("&amp;", "&")
                    .replace("&lt;", "<").replace("&gt;", ">")
                    .replace("&quot;", "\"");
            t = t.replaceAll("\n{3,}", "\n\n");
            return t.trim();
        } catch (Throwable t) {
            return "读取更新日志失败：" + t;
        }
    }



    /** 旧接口：直接显示文本（保留给其它地方用）。 */
    private void showChangelogPlain(String title, String asset) {
        try {
            java.io.InputStream in = getAssets().open(asset);
            java.io.ByteArrayOutputStream bos = new java.io.ByteArrayOutputStream();
            byte[] buf = new byte[8192];
            int len;
            while ((len = in.read(buf)) > 0) bos.write(buf, 0, len);
            in.close();
            String text = new String(bos.toByteArray(), "UTF-8");
            TextView tv = new TextView(this);
            tv.setText(text);
            tv.setTextSize(13f);
            tv.setTextColor(0xFFF0F3F8);
            tv.setTextIsSelectable(true);
            android.widget.ScrollView sv = new android.widget.ScrollView(this);
            sv.addView(tv);
            new AlertDialog.Builder(this)
                    .setTitle(title)
                    .setView(sv)
                    .setPositiveButton("关闭", null)
                    .show();
        } catch (Throwable t) {
            toast("读取更新日志失败：" + t);
        }
    }

    /** 检查更新：读 GitHub 最新正式版（Pre-release 不会被返回）。 */
    private void checkUpdate(final boolean silent) {
        if (updateChecking) return;
        updateChecking = true;
        if (!silent) toast("正在检查更新…");
        new Thread(new Runnable() {
            @Override
            public void run() {
                String tag = null, body = null, apkUrl = null, err = null;
                String[] urls = new String[]{
                        "https://api.github.com/repos/" + UPDATE_REPO + "/releases/latest",
                        "https://gh-proxy.com/https://api.github.com/repos/" + UPDATE_REPO + "/releases/latest"
                };
                for (String u : urls) {
                    try {
                        java.net.HttpURLConnection c =
                                (java.net.HttpURLConnection) new java.net.URL(u).openConnection();
                        c.setConnectTimeout(8000);
                        c.setReadTimeout(10000);
                        c.setRequestProperty("User-Agent", "CommandVPN");
                        c.setRequestProperty("Accept", "application/vnd.github+json");
                        int code = c.getResponseCode();
                        if (code != 200) {
                            err = "HTTP " + code;
                            c.disconnect();
                            continue;
                        }
                        java.io.InputStream in = c.getInputStream();
                        java.io.ByteArrayOutputStream bos = new java.io.ByteArrayOutputStream();
                        byte[] buf = new byte[4096];
                        int len;
                        while ((len = in.read(buf)) > 0) bos.write(buf, 0, len);
                        in.close();
                        c.disconnect();
                        String json = new String(bos.toByteArray(), "UTF-8");
                        org.json.JSONObject o = new org.json.JSONObject(json);
                        tag = o.optString("tag_name", "");
                        body = o.optString("body", "");
                        org.json.JSONArray assets = o.optJSONArray("assets");
                        if (assets != null) {
                            for (int i = 0; i < assets.length(); i++) {
                                org.json.JSONObject a = assets.optJSONObject(i);
                                if (a == null) continue;
                                String nm = a.optString("name", "");
                                if (nm.endsWith(".apk")) {
                                    apkUrl = a.optString("browser_download_url", "");
                                    break;
                                }
                            }
                        }
                        err = null;
                        break;
                    } catch (Throwable t) {
                        err = String.valueOf(t);
                    }
                }
                final String fTag = tag, fBody = body, fApk = apkUrl, fErr = err;
                ui.post(new Runnable() {
                    @Override
                    public void run() {
                        updateChecking = false;
                        if (uiDead()) return;
                        if (fTag == null || fTag.length() == 0) {
                            if (!silent) {
                                toast("检查更新失败" + (fErr == null ? "" : "：" + fErr));
                            }
                            return;
                        }
                        String latest = fTag.startsWith("v") || fTag.startsWith("V")
                                ? fTag.substring(1) : fTag;
                        String cur = appVersion();
                        if (compareVersion(latest, cur) <= 0) {
                            if (!silent) toast("已是最新版本（v" + cur + "）");
                            return;
                        }
                        String msg = "发现新版本 v" + latest + "\n\n"
                                + (fBody == null || fBody.trim().length() == 0
                                ? "（这一版没有写更新说明）" : fBody.trim().substring(0,
                                Math.min(600, fBody.trim().length())));
                        new AlertDialog.Builder(MainActivity.this)
                                .setTitle("发现新版本")
                                .setMessage(msg)
                                .setPositiveButton("下载", new android.content.DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(android.content.DialogInterface d, int w) {
                                        if (fApk != null && fApk.length() > 0) {
                                            openUrl(fApk);
                                        } else {
                                            openUrl(GITHUB_URL + "/releases/latest");
                                        }
                                    }
                                })
                                .setNegativeButton("以后再说", null)
                                .show();
                    }
                });
            }
        }, "check-update").start();
    }

    /** 比较 x.y.z 版本号：a>b 返回 1，相等 0，小于 -1。 */
    private static int compareVersion(String a, String b) {
        try {
            String[] x = a.split("\\.");
            String[] y = b.split("\\.");
            int n = Math.max(x.length, y.length);
            for (int i = 0; i < n; i++) {
                int vx = i < x.length ? Integer.parseInt(x[i].replaceAll("[^0-9]", "")) : 0;
                int vy = i < y.length ? Integer.parseInt(y[i].replaceAll("[^0-9]", "")) : 0;
                if (vx != vy) return vx > vy ? 1 : -1;
            }
        } catch (Throwable ignored) {
        }
        return 0;
    }

    /** 把当前主题的颜色刷到所有静态控件上。 */
    private void applyUi() {
        Theme.applyWindow(this);   // 主题切换后重新配色状态栏，否则浅色下时间看不见
        View root = findViewById(R.id.root);
        root.setBackgroundColor(Palette.bg(this));
        ((TextView) findViewById(R.id.title)).setTextColor(Palette.text(this));
        status.setTextColor(Palette.textDim(this));
        stats.setTextColor(Palette.textFaint(this));
        conn.setTextColor(Palette.green(this));
        findViewById(R.id.div1).setBackgroundColor(Palette.divider(this));
        findViewById(R.id.div2).setBackgroundColor(Palette.divider(this));
        findViewById(R.id.divTab).setBackgroundColor(Palette.divider(this));
        findViewById(R.id.tabBar).setBackgroundColor(Palette.panel(this));
        list.setDivider(new android.graphics.drawable.ColorDrawable(Palette.divider(this)));
        list.setChildDivider(new android.graphics.drawable.ColorDrawable(Palette.divider(this)));

        // 开关模式整页背景：浅色=淡蓝渐变+世界地图，深色=深蓝渐变+同一张地图（降透明度）
        try {
            View swPage = findViewById(R.id.viewSwitch);
            if (swPage != null) {
                // 页面是纯色底；世界地图放在卡片里面（参考图就是这样）
                swPage.setBackgroundColor(Theme.isDark(this) ? 0xFF1C1F24 : 0xFFDCE8F8);
            }
        } catch (Throwable ignored) {
        }

        // 开关模式的卡片与提示
        try {
            View swCard = findViewById(R.id.swCard);
            if (swCard != null) {
                android.graphics.drawable.GradientDrawable g = new android.graphics.drawable.GradientDrawable();
                g.setShape(android.graphics.drawable.GradientDrawable.RECTANGLE);
                g.setCornerRadius(getResources().getDisplayMetrics().density * 24);
                // 卡片是"上浅下白"的渐变：上面的世界地图（本身带很淡的蓝底）能自然融进去
                g.setOrientation(android.graphics.drawable.GradientDrawable.Orientation.TOP_BOTTOM);
                if (Theme.isDark(this)) {
                    g.setColors(new int[]{0xFF2B2F37, 0xFF23272E});
                } else {
                    g.setColors(new int[]{0xFFDCE9FB, 0xFFFFFFFF});
                }
                g.setStroke((int) getResources().getDisplayMetrics().density,
                        Theme.isDark(this) ? 0x22FFFFFF : 0x55DCE6F5);
                swCard.setBackground(g);
                // 卡片内的地图超出圆角时裁掉；地图衬在国旗/国名后面，不铺满整张卡片
                swCard.setClipToOutline(true);
                // 地图作为卡片背景层，绘制时四边就地羽化（不会有方形边界、也不会覆盖文字）
                try {
                    android.graphics.Bitmap bm = switchMapBitmap;
                    if (bm == null) {
                        bm = android.graphics.BitmapFactory.decodeResource(
                                getResources(), R.drawable.switch_map);
                        switchMapBitmap = bm;
                    }
                    if (bm != null) {
                        com.dsh.quickvpn.MapBackdropDrawable map =
                                new com.dsh.quickvpn.MapBackdropDrawable(bm);
                        boolean dark = Theme.isDark(this);
                        map.setTopFraction(0.55f);
                        // 深色模式：整体乘一层暗蓝，让浅蓝地图自动变成深色系
                        map.setGrayscale(dark);
                        // 深色：反相后海洋变黑、大陆留亮灰，轮廓明显又不刺眼
                        map.setNight(dark);
                        map.setTintColor(0xFFFFFFFF);
                        map.setAlphaInt(dark ? 170 : 225);
                        android.graphics.drawable.LayerDrawable layers =
                                new android.graphics.drawable.LayerDrawable(
                                        new android.graphics.drawable.Drawable[]{g, map});
                        swCard.setBackground(layers);
                    }
                } catch (Throwable ignored) {
                }
                android.widget.ImageView swPin = (android.widget.ImageView) findViewById(R.id.swPin);
                if (swPin != null) swPin.setColorFilter(Palette.textDim(this));
            }
            TextView swLabel = (TextView) findViewById(R.id.swLabel);
            if (swLabel != null) swLabel.setTextColor(Palette.textFaint(this));
            View spCard = findViewById(R.id.swSpeedCard);
            if (spCard != null) {
                android.graphics.drawable.GradientDrawable sg = new android.graphics.drawable.GradientDrawable();
                sg.setShape(android.graphics.drawable.GradientDrawable.RECTANGLE);
                sg.setCornerRadius(getResources().getDisplayMetrics().density * 18);
                sg.setColor(Palette.panel(this));
                sg.setStroke((int) getResources().getDisplayMetrics().density, Palette.divider(this));
                spCard.setBackground(sg);
            }
            View lineL = findViewById(R.id.swLineL);
            if (lineL != null) lineL.setBackgroundColor(Palette.divider(this));
            View lineR = findViewById(R.id.swLineR);
            if (lineR != null) lineR.setBackgroundColor(Palette.divider(this));
            TextView spUp = (TextView) findViewById(R.id.swSpdUp);
            if (spUp != null) spUp.setTextColor(Palette.blue(this));
            TextView spDown = (TextView) findViewById(R.id.swSpdDown);
            if (spDown != null) spDown.setTextColor(Palette.green(this));
            TextView swHint = (TextView) findViewById(R.id.swHint);
            if (swHint != null) swHint.setTextColor(Palette.textFaint(this));
            for (int id : new int[]{R.id.swGoogle, R.id.swTiktok, R.id.swInstagram}) {
                Button b = (Button) findViewById(id);
                if (b == null) continue;
                try {
                    // 恢复图标原色：Google 是彩色 PNG、Instagram 是彩色矢量，不动；
                    // TikTok 是白色矢量，浅色主题下要染成深色才看得见
                    if (id == R.id.swTiktok && !Theme.isDark(this)) {
                        android.graphics.drawable.Drawable[] ds = b.getCompoundDrawables();
                        for (android.graphics.drawable.Drawable d : ds) {
                            if (d != null) d.setTint(Palette.text(this));
                        }
                    }
                } catch (Throwable ignored) {
                }
                android.graphics.drawable.GradientDrawable g = new android.graphics.drawable.GradientDrawable();
                g.setShape(android.graphics.drawable.GradientDrawable.RECTANGLE);
                g.setCornerRadius(getResources().getDisplayMetrics().density * 14);
                g.setColor(Palette.panel(this));
                g.setStroke((int) getResources().getDisplayMetrics().density, Palette.divider(this));
                b.setBackground(g);
                b.setTextColor(Palette.textDim(this));
            }
            if (swCountry != null) swCountry.setTextColor(Palette.text(this));
            if (swNode != null) swNode.setTextColor(Palette.textDim(this));
        } catch (Throwable ignored) {
        }
        TextView setTitle = (TextView) findViewById(R.id.setTitle);
        setTitle.setTextColor(Palette.text(this));
        for (int id : new int[]{R.id.setThemeLabel, R.id.setModeLabel}) {
            ((TextView) findViewById(id)).setTextColor(Palette.textDim(this));
        }
        ((TextView) findViewById(R.id.setFoot)).setTextColor(Palette.textFaint(this));
        findViewById(R.id.setDiv).setBackgroundColor(Palette.divider(this));
        for (int id : new int[]{R.id.rbDark, R.id.rbLight, R.id.rbSystem, R.id.rbListMode, R.id.rbSwitchMode}) {
            ((RadioButton) findViewById(id)).setTextColor(Palette.text(this));
        }


        for (int sid : new int[]{R.id.swAutoRefresh, R.id.swAutoBoot, R.id.swAutoScan, R.id.swAutoNotify,
                R.id.swLimitAuto, R.id.swLimitManual, R.id.swLogKernel, R.id.swCloudLimit,
                R.id.swScanHidden, R.id.swFastScan}) {
            android.widget.Switch sw = (android.widget.Switch) findViewById(sid);
            if (sw == null) continue;
            sw.setTextColor(Palette.text(this));
            try {
                int accent = Palette.green(this);
                boolean dark = Theme.isDark(this);
                // 选中：绿色轨道（半透明）；未选中：比背景略亮的灰，深色主题也不会"只剩一个绿圆"
                int trackOn = (accent & 0x00FFFFFF) | 0x77000000;
                int trackOff = dark ? 0x3DFFFFFF : 0x33000000;
                sw.setTrackTintList(new android.content.res.ColorStateList(
                        new int[][]{{android.R.attr.state_checked}, {}},
                        new int[]{trackOn, trackOff}));
                sw.setThumbTintList(new android.content.res.ColorStateList(
                        new int[][]{{android.R.attr.state_checked}, {}},
                        new int[]{accent, dark ? 0xFFB7BFCF : 0xFF8A93A6}));
            } catch (Throwable ignored) {
            }
        }
        TextView rh = (TextView) findViewById(R.id.tvRefreshHint);
        if (rh != null) rh.setTextColor(Palette.textFaint(this));

        swFlag.setTextColor(Palette.text(this));
        swCountry.setTextColor(Palette.text(this));
        swNode.setTextColor(Palette.textDim(this));
        swStatus.setTextColor(Palette.textDim(this));
        showTab(currentTab);
        if (adapter != null) adapter.notifyDataSetChanged();
    }

    /** 开关模式：国旗 + 国家 + 节点 + 状态 */
    private void updateSwitchView() {
        if (swFlag == null) return;
        if (switchMode && selectedKind == SEL_NONE) ensureSwitchDefault();
        Country c = null;
        Node picked = null;
        if (selectedKind == SEL_FAST) {
            swFlag.setText("\u26A1");
            swCountry.setText("最快地区");
            swNode.setText("自动挑全部节点里最快的那个");
            refreshToggleState();
            return;
        }
        if (selectedKind == SEL_COUNTRY) {
            for (Country x : countries) if (x.cc.equals(selectedCc)) c = x;
        } else if (selectedKind == SEL_NODE) {
            picked = findNodeByUri(selectedUri);
            if (picked != null) for (Country x : countries) if (x.cc.equals(picked.cc)) c = x;
        }
        if (c == null) {
            swFlag.setText("\uD83C\uDF10");
            swCountry.setText("未选择节点");
            swNode.setText("点下面「选择节点」挑一个");
        } else {
            swFlag.setText(c.flag());
            boolean recCc = NodeStore.isRecommendedCountry(this, c.cc);
            swCountry.setText(recCc ? (c.name + "  ★推荐") : c.name);
            if (picked != null) {
                swNode.setText("已选： " + picked.title);
            } else {
                swNode.setText("将自动挑该国最快的节点");
            }
        }
        refreshToggleState();
    }

    /** 只刷新大开关与状态文字（国旗/国家那部分由调用方决定）。 */
    private Boolean lastToggleBusy;

    /** 把状态文字做成胶囊：淡色底 + 同色描边；fill/stroke 都为 0 时恢复透明。 */
    private String lastChipKey = "";
    private void styleStatusChip(int fill, int stroke) {
        try {
            if (swStatus == null) return;
            // 每秒都会调一次：同样的配色就不要重复建 drawable（省 GC）
            String key = fill + "/" + stroke;
            if (key.equals(lastChipKey)) return;
            lastChipKey = key;
            android.graphics.drawable.GradientDrawable g = new android.graphics.drawable.GradientDrawable();
            g.setShape(android.graphics.drawable.GradientDrawable.RECTANGLE);
            g.setCornerRadius(getResources().getDisplayMetrics().density * 99);
            g.setColor(fill);
            if (stroke != 0) g.setStroke((int) getResources().getDisplayMetrics().density, stroke);
            swStatus.setBackground(g);
            int ph = (int) (getResources().getDisplayMetrics().density * 12);
            int pv = (int) (getResources().getDisplayMetrics().density * 6);
            swStatus.setPadding(ph, pv, ph, pv);
        } catch (Throwable ignored) {
        }
    }

    private void refreshToggleState() {
        boolean busy = TunnelService.isRunning() || TunnelService.isConnecting();
        // 开关只在"状态真的变了"时写，否则用户刚关掉、下一 tick 又被弹回去
        if (swToggle != null) {
            if (lastToggleBusy == null || lastToggleBusy != busy || swToggle.isChecked() != busy) {
                lastToggleBusy = busy;
                suppressToggle = true;
                swToggle.setChecked(busy);
                suppressToggle = false;
                swToggle.setThumbTintList(android.content.res.ColorStateList.valueOf(0xFFFFFFFF));
                swToggle.setTrackTintList(android.content.res.ColorStateList.valueOf(
                        busy ? Palette.green(this) : (Theme.isDark(this) ? 0xFF6B7280 : 0xFFB8BEC9)));
            }
        }
        snapSlideToState();
        if (TunnelService.isConnecting()) {
            swStatus.setText("正在连接…");
            swStatus.setTextColor(Palette.orange(this));
            styleStatusChip(0x33E0A33C, Palette.orange(this));
        } else if (TunnelService.isRunning()) {
            if (TunnelService.cloudSource() != null) {
                swStatus.setText("\u26A1 ● 已连接云节点");
                swStatus.setTextColor(0xFFE0B44A);
                styleStatusChip(0x33E0B44A, 0xFFE0B44A);
                return;
            }
            Node cur = TunnelService.currentNode();
            String extra = cur == null ? "" : (" · " + Country.displayName(cur.cc) + " " + cur.title);
            int d = TunnelService.connectedDelay();
            swStatus.setText("\u26A1 ● 已连接" + extra + (d > 0 ? "  |  " + d + " ms" : ""));
            swStatus.setTextColor(Palette.green(this));
            styleStatusChip(0x225FD08A, Palette.green(this));
        } else {
            swStatus.setText("未连接");
            swStatus.setTextColor(Palette.textDim(this));
            styleStatusChip(0x00000000, 0x00000000);
        }
    }

    /** 滑块吸回当前状态：已连接→最右，未连接→最左。 */
    private void snapSlideToState() {
        try {
            if (swSlide == null) return;
            if (swSlide.isTracking()) {
                return;   // 用户正拉着滑块，别去动它（否则一直闪）
            }
            boolean connectingNow = TunnelService.isConnecting();
            boolean busy = TunnelService.isRunning() || connectingNow;
            boolean pendingNow = slidePending && !TunnelService.isRunning();
            swSlide.setConnecting((connectingNow || pendingNow) && !TunnelService.isRunning());
            if (busy) {
                slidePending = false;
            } else if (slidePending) {
                // 刚松手、连接流程还没真正开始：先保持拉满，别弹回左边再弹回来
                if (System.currentTimeMillis() - slidePendingAt > 8000) {
                    slidePending = false;
                } else {
                    busy = true;
                }
            }
            swSlide.setOnState(busy);
        } catch (Throwable ignored) {
        }
    }

    /** 世界地图只解码一次（切主题时复用，避免反复分配 6MB 位图）。 */
    private android.graphics.Bitmap switchMapBitmap = null;

    private boolean slidePending = false;
    private long slidePendingAt = 0;

    private com.dsh.quickvpn.SlideBar swSlide;

    /** 开关模式的"选择节点"：先选地区，本国若有推荐节点就直接用它。 */
    private void showNodePickerForSwitch() {
        // 正在连接/已连接时禁止换节点，统一提示"请先断开"
        if (blockIfBusy()) return;
        final List<Country> list2 = new ArrayList<Country>();
        for (Country c : countries) if (c.nodes.size() > 0) list2.add(c);
        if (list2.isEmpty()) {
            toast("没有可选节点");
            return;
        }
        String[] items = new String[list2.size() + 1];
        items[0] = "\u26A1 最快地区（自动挑全部里最快的）";
        for (int i = 0; i < list2.size(); i++) {
            Country c = list2.get(i);
            boolean hasRec = NodeStore.isRecommendedCountry(this, c.cc);
            items[i + 1] = c.flag() + " " + c.name + "   （" + c.nodes.size() + " 个"
                    + (hasRec ? "，推荐" : "") + "）";
        }
        new AlertDialog.Builder(this)
                .setTitle("选择节点")
                .setItems(items, new android.content.DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(android.content.DialogInterface d, int which) {
                        if (which == 0) {
                            selectFast();
                        } else {
                            selectCountry(list2.get(which - 1));
                        }
                        updateSwitchView();
                    }
                })
                .show();
    }

    /* -------------------------- 选中 & 连接 -------------------------- */

    private void restoreSelection() {
        try {
            android.content.SharedPreferences sp = getSharedPreferences("qv", MODE_PRIVATE);
            selectedKind = sp.getInt("sel_kind", SEL_NONE);
            selectedCc = sp.getString("sel_cc", "");
            selectedUri = sp.getString("sel_uri", "");
            if (selectedKind == SEL_COUNTRY) {
                boolean found = false;
                for (Country c : countries) if (c.cc.equals(selectedCc)) found = true;
                if (!found) selectedKind = SEL_NONE;
            } else if (selectedKind == SEL_NODE) {
                if (findNodeByUri(selectedUri) == null) selectedKind = SEL_NONE;
            }
        } catch (Throwable ignored) {
            selectedKind = SEL_NONE;
        }
    }

    private void saveSelection() {
        try {
            getSharedPreferences("qv", MODE_PRIVATE).edit()
                    .putInt("sel_kind", selectedKind)
                    .putString("sel_cc", selectedCc)
                    .putString("sel_uri", selectedUri)
                    .apply();
        } catch (Throwable ignored) {
        }
    }

    private Node findNodeByUri(String uri) {
        if (uri == null || uri.length() == 0) return null;
        for (Country c : countries) {
            for (Node n : c.nodes) if (n.uri.equals(uri)) return n;
        }
        return null;
    }

    private void selectFast() {
        selectedKind = SEL_FAST;
        selectedCc = "";
        selectedUri = "";
        saveSelection();
        updateSelectionUi();
        status.setText("已选择「最快地区」— 点下面的「连接」开始");
    }

    private void selectCountry(Country c) {
        selectedKind = SEL_COUNTRY;
        selectedCc = c.cc;
        selectedUri = "";
        saveSelection();
        updateSelectionUi();
        status.setText("已选择「" + c.name + "」— 点下面的「连接」连该国最快的节点");
    }

    private void selectNode(Node n) {
        selectedKind = SEL_NODE;
        selectedUri = n.uri;
        selectedCc = n.cc;
        NodeStore.setSelectedUri(this, n.uri);
        saveSelection();
        updateSelectionUi();
        status.setText("已选择：" + n.title + " — 点下面的「连接」");
    }

    /** 顶部统计行：国家数 / 显示节点数 / 全部节点数 / 隐藏 / 回收站。始终显示。 */
    private void updateStats() {
        if (stats == null) return;
        try {
            countryHiddenCounts = NodeStore.hiddenCountsByCountry(this);
            int groups = 0;
            int shown = 0;
            int usableShown = 0;
            for (Country c : countries) {
                groups++;
                for (Node n : c.nodes) {
                    shown++;
                    if (NodeStore.isGood(this, n.uri)) usableShown++;
                }
            }
            int total = NodeStore.totalCount(this);
            String net = NodeStore.netLabel(this);
            String shownPart = (shown == usableShown)
                    ? ("已显示实测可用节点 " + shown + " 个")
                    : ("已显示 " + shown + " 个节点（其中 " + usableShown + " 个实测可用）");
            // 统计行改成"显示 / 隐藏 / 全部"，不再用"内置 + 导入"：
            // 没有内置节点时，"内置"这个口径只会误导（之前还把隐藏的算成内置）
            int hiddenCount = Math.max(0, total - shown);
            stats.setText(groups + " 个国家/地区 · " + shownPart
                    + " · 已隐藏 " + hiddenCount + " 个"
                    + " · 全部 " + total + " 个 · 网络 " + net
                    + "\n隐藏的节点在「编辑」模式里点眼睛查看");
        } catch (Throwable t) {
            stats.setText("");
        }
    }

    private void updateSelectionUi() {
        adapter.notifyDataSetChanged();
        updateConnectButton();
        updateStats();
    }

    /** 没选中任何东西时，底部「连接」变灰。 */
    private String lastConnLabel;

    private void updateConnectButton() {
        boolean busy = TunnelService.isRunning() || TunnelService.isConnecting();
        boolean can = busy || selectedKind != SEL_NONE;
        String lbl = (busy ? "断开" : "连接") + "|" + can + "|" + selectedKind;
        if (lastConnLabel == null || !lastConnLabel.equals(lbl)) {
            lastConnLabel = lbl;
            Log2.i("连接按钮状态: kind=" + selectedKind + " cc=" + selectedCc + " enabled=" + can);
        }
        btnConnect.setEnabled(can);
        btnConnect.setAlpha(can ? 1f : 0.45f);
        btnConnect.setText(busy ? "断开" : "连接");
    }

    private void connectSelected() {
        if (TunnelService.isConnecting()) {
            Log2.w("忽略重复的连接请求（已经在连接中）");
            return;
        }
        switch (selectedKind) {
            case SEL_FAST:
                autoConnectFastest();
                break;
            case SEL_COUNTRY: {
                for (Country c : countries) {
                    if (c.cc.equals(selectedCc)) {
                        connectCountry(c);
                        return;
                    }
                }
                toast("这个地区已不在列表里，重新选一个");
                break;
            }
            case SEL_NODE: {
                Node n = findNodeByUri(selectedUri);
                if (n == null) {
                    toast("这个节点已不在列表里，重新选一个");
                    break;
                }
                connectNode(n);
                break;
            }
            default:
                toast("先在列表里选中一个国家或节点");
                break;
        }
    }

    /* ---------------------------- 连接 ---------------------------- */

    private boolean blockIfBusy() {
        if (TunnelService.isConnecting()) {
            Node n = TunnelService.connectingNode();
            String name = n == null ? "" : (Country.displayName(n.cc) + " · " + n.title);
            String msg = "正在连接「" + name + "」…\n\n要换节点或地区，请先点下面的「断开」。";
            status.setText("正在连接" + name + "… 要换请先断开");
            warnDialog("请先断开再重试", msg);
            return true;
        }
        if (TunnelService.isRunning()) {
            Node n = TunnelService.currentNode();
            String name = n == null ? "" : (Country.displayName(n.cc) + " · " + n.title);
            String msg = "当前已连接「" + name + "」。\n\n要换节点或地区，请先点下面的「断开」。";
            status.setText("已连接" + name + "，要换请先断开");
            warnDialog("请先断开再重试", msg);
            return true;
        }
        return false;
    }

    /** 醒目的提示弹窗（红标题 + 高亮文字）。 */
    private void warnDialog(String title, String message) {
        AlertDialog d = new AlertDialog.Builder(this)
                .setTitle("⚠ " + title)
                .setMessage(message)
                .setPositiveButton("知道了", null)
                .create();
        d.show();
        try {
            TextView tv = (TextView) d.findViewById(android.R.id.message);
            if (tv != null) tv.setTextSize(15f);
        } catch (Throwable ignored) {
        }
    }

    private void connectNode(Node n) {
        if (n == null) {
            toast("还没有节点：去「设置」点「翻新节点」拉取，或打开「自动翻新」");
            return;
        }
        if (blockIfBusy()) return;
        selectedUri = n.uri;
        NodeStore.setSelectedUri(this, n.uri);
        adapter.notifyDataSetChanged();
        requestVpn(n, TunnelService.MODE_NODE);
    }

    private void connectCountry(final Country country) {
        if (country == null || country.nodes.isEmpty()) return;
        if (blockIfBusy()) return;
        int visible = 0;
        for (Node x : country.nodes) if (!x.hidden) visible++;
        if (visible == 0) {
            new AlertDialog.Builder(this)
                    .setTitle("没有已启用的节点")
                    .setMessage("「" + country.name + "」的 " + country.nodes.size()
                            + " 个节点全部处于「已隐藏」状态。\n\n"
                            + "请先在编辑模式里把它显示出来（点节点 → 显示，或长按国家行 → 显示该国全部），"
                            + "再来点闪电连接。")
                    .setPositiveButton("知道了", null)
                    .show();
            return;
        }
        if (visible > 50) {
            new AlertDialog.Builder(this)
                    .setTitle("节点较多")
                    .setMessage("「" + country.name + "」有 " + visible + " 个已显示的节点，"
                            + "全部测一遍可能需要较久（约 " + Math.max(5, visible / 12) + " 秒以上）。\n\n"
                            + "是否继续？")
                    .setPositiveButton("继续", new android.content.DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(android.content.DialogInterface d, int w) {
                            connectCountryNow(country);
                        }
                    })
                    .setNegativeButton("取消", null)
                    .show();
            return;
        }
        connectCountryNow(country);
    }

    private void connectCountryNow(Country country) {
        // 选中的国家必须跟着切换，否则界面（尤其开关模式）还显示上一次的国家
        try {
            selectedKind = SEL_COUNTRY;
            selectedCc = country.cc;
            selectedUri = "";
            NodeStore.setSelectedUri(this, "");      // 清掉上次选中的具体节点
            try {
                getPreferences(MODE_PRIVATE).edit().putString("sel_cc", country.cc)
                        .putInt("sel_kind", SEL_COUNTRY).apply();
            } catch (Throwable ignored) {
            }
            updateSwitchView();
        } catch (Throwable ignored) {
        }
        Node hint = null;
        String good = NodeStore.countryGoodUri(this, country.cc);
        if (good.length() > 0) {
            for (Node n : country.nodes) {
                if (n.uri.equals(good) && !n.hidden) {   // 已隐藏的不作为首选
                    hint = n;
                    break;
                }
            }
        }
        if (hint == null) hint = country.fastestVisible();   // 只在"已显示"的节点里挑
        if (hint == null) {
            for (Node n : country.nodes) {
                if (!n.hidden) { hint = n; break; }
            }
        }
        if (hint == null) hint = country.nodes.get(0);
        Log2.i("点国家闪电：hint=" + (hint == null ? "null" : hint.title)
                + " hidden=" + (hint != null && hint.hidden));
        requestVpn(hint, TunnelService.MODE_COUNTRY);
    }

    private void requestVpn(Node n, int mode) {
        requestVpn(n, mode, false);
    }

    private void requestVpn(Node n, int mode, final boolean force) {
        requestVpn(n, mode, force, false);
    }

    private void requestVpn(Node n, int mode, final boolean force, final boolean cloud) {
        if (!cloud && cloudRetryActive) {
            warnDialog("正在逐个尝试云节点",
                    "现在正在一个接一个地试云节点，最多试 5 个。\n\n"
                            + "请等它结束，或在 VPN 页点「断开」取消。");
            return;
        }
        if (!cloud) {
            // 普通连接：把上一次"云节点"的痕迹清掉，别让节点源页一直是绿的，
            // 也别让服务端从本地记录里把普通连接认成云节点
            cloudConnectingSource = null;
            TunnelService.setCloudSource(null);
            try {
                getSharedPreferences("qv", MODE_PRIVATE).edit()
                        .remove("cloud_active_source").apply();
            } catch (Throwable ignored) {
            }
        }
        if (TunnelService.isScanning()) {
            new AlertDialog.Builder(this)
                    .setTitle("正在体检节点，不能连接 VPN")
                    .setMessage("体检期间开 VPN 会让结果全部失真（测到的是 VPN 自己的出口）。\n\n"
                            + "等它结束，或先在进度窗点「结束体检」。")
                    .setPositiveButton("知道了", null)
                    .show();
            return;
        }
        if (tester.isRunning()) tester.cancel();
        Intent prep = VpnService.prepare(this);
        if (prep != null) {
            pendingNode = n;
            pendingMode = mode;
            pendingForce = force;
            pendingCloud = cloud;
            startActivityForResult(prep, 1);
        } else {
            startTunnel(n, mode, force, cloud);
        }
    }

    private void startTunnel(final Node n, final int mode) {
        startTunnel(n, mode, false, false);
    }

    private void startTunnel(final Node n, final int mode, final boolean force) {
        startTunnel(n, mode, force, false);
    }

    private void startTunnel(final Node n, final int mode, final boolean force, final boolean cloud) {
        final String cloudSrcForThis = cloud ? cloudConnectingSource : null;
        Log2.i("发起连接：cloud=" + cloud + " src=" + cloudSrcForThis + " mode=" + mode);
        try {
            if (cloud && cloudSrcForThis != null) {
                getSharedPreferences("qv", MODE_PRIVATE).edit()
                        .putString("cloud_active_source", cloudSrcForThis).apply();
            }
        } catch (Throwable ignored) {
        }
        if (n == null) {
            toast("没有可用节点");
            return;
        }
        if (mode == TunnelService.MODE_NODE) {
            status.setText("正在连接 " + n.title + " …（只连这一个）");
        } else if (mode == TunnelService.MODE_COUNTRY) {
            status.setText("正在测「" + Country.displayName(n.cc) + "」的节点，挑最快的…");
        } else {
            status.setText("正在全部节点里挑最快且能通的…");
        }
        btnConnect.setText("断开");
        TunnelService.connect(this, n, mode, force, cloudSrcForThis);
    }

    @Override
    protected void onSaveInstanceState(android.os.Bundle out) {
        super.onSaveInstanceState(out);
        out.putInt("tab", currentTab);
        out.putInt("guideStep", guideStep);   // 引导进行到第几步（从系统设置返回后要接着显示）
        out.putBoolean("tiktokClosed", tiktokTipSessionClosed);
        out.putInt("pendingGuideStep", pendingGuideStep);
        out.putBoolean("editMode", editMode);
        out.putBoolean("eye", showHiddenInEdit);
        out.putInt("selKind", selectedKind);
        out.putString("selCc", selectedCc);
        out.putString("selUri", selectedUri);
        if (pendingNode != null) {
            out.putString("pendUri", pendingNode.uri);
            out.putString("pendCc", pendingNode.cc);
            out.putString("pendTitle", pendingNode.title);
            out.putInt("pendMode", pendingMode);
        }
    }

    @Override
    protected void onRestoreInstanceState(android.os.Bundle in) {
        super.onRestoreInstanceState(in);
        if (in == null) return;
        try {
            currentTab = in.getInt("tab", 0);
            guideStep = in.getInt("guideStep", 0);
            tiktokTipSessionClosed = in.getBoolean("tiktokClosed", false);
            pendingGuideStep = in.getInt("pendingGuideStep", 0);
            // onCreate 里已经按"未关闭"把卡片显示出来了，恢复状态后要重新按标记收起来
            bindTiktokTip();
            editMode = in.getBoolean("editMode", false);
            showHiddenInEdit = in.getBoolean("eye", false);
            selectedKind = in.getInt("selKind", SEL_NONE);
            selectedCc = in.getString("selCc", "");
            selectedUri = in.getString("selUri", "");
            String pu = in.getString("pendUri", null);
            if (pu != null) {
                pendingNode = new Node(pu, in.getString("pendCc", ""), in.getString("pendTitle", ""));
                pendingMode = in.getInt("pendMode", TunnelService.MODE_COUNTRY);
            }
            // super() 里恢复 RadioGroup 会触发监听器、把界面切到 VPN 页；
            // 这里按保存的值再同步一次按钮/眼睛/列表，避免"编辑模式没生效""要点两次编辑"
            NodeStore.setShowAll(this, showHiddenInEdit);
            setEditMode(editMode);
            showTab(currentTab);
            countries = NodeStore.countries(this, editMode && showHiddenInEdit);
            adapter.notifyDataSetChanged();
            updateStats();
            Log2.i("已恢复界面状态：tab=" + currentTab + " edit=" + editMode + " eye=" + showHiddenInEdit);
        } catch (Throwable t) {
            Log2.w("恢复界面状态失败：" + t);
        }
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) {
            try {
                resumeGuideIfNeeded();
            } catch (Throwable ignored) {
            }
        }
    }

    protected void onResume() {
        super.onResume();
        // 回到前台：恢复两个 ticker（onPause 时停过）
        ui.removeCallbacks(ticker);
        ui.post(ticker);
        ui.removeCallbacks(listTicker);
        ui.post(listTicker);
        lastStateFp = "";
        refreshState(null);
        updateStats();
        String nk = NodeStore.netKey(this);
        if (lastNetKey.length() > 0 && !nk.equals(lastNetKey)) {
            NodeStore.setShowAll(this, NodeStore.showAll(this));
            countries = NodeStore.countries(this, editMode && showHiddenInEdit);
            adapter.notifyDataSetChanged();
            status.setText("网络已切换到「" + NodeStore.netLabel(this) + "」，列表已重新加载");
            updateStats();
            Log2.i("网络类型变化 " + lastNetKey + " → " + nk + "，重载节点列表");
        }
        lastNetKey = nk;

        if (RefreshRunner.isRunning()) {
            status.setText("正在翻新节点…");
            showRefreshMonitor();
        } else if (TunnelService.isScanning()) {
            status.setText("正在体检节点（" + TunnelService.getScanDone() + "/"
                    + Math.max(1, TunnelService.getScanTotal()) + "）");
            showScanMonitorIfNeeded();
        }
        resumeGuideIfNeeded();
        tryReconnectFromNotification();
        // 体检中回到前台：如果进度很久没动，说明后台被系统冻结过
        if (TunnelService.isScanning()) {
            long startedAt = TunnelService.getScanStartedAt();
            long lp = TunnelService.getScanLastProgress();
            long now = System.currentTimeMillis();
            long gapMs = lp > 0 ? (now - lp) : 0;
            boolean ranLongEnough = startedAt > 0 && (now - startedAt) > 150000L;
            if (ranLongEnough && gapMs > 120000L
                    && !getSharedPreferences("qv", MODE_PRIVATE).getBoolean("skip_freeze_warn", false)) {
                final long mins = gapMs / 60000L;
                Log2.w("体检在后台被冻结了约 " + mins + " 分钟（进度长时间未推进）");
                new AlertDialog.Builder(this)
                        .setTitle("体检在后台被系统冻结了")
                        .setMessage("刚回来时发现体检进度有 " + mins + " 分钟没动，"
                                + "是系统把后台冻结了（不是体检坏了）。\n\n"
                                + "建议二选一：\n"
                                + "1. 设置 → 电池 → 应用速冻（有的机型叫「后台冻结 / 应用休眠」）"
                                + "→ 找到「命令方块」→ 关闭；\n"
                                + "2. 设置 → 应用管理 → 命令方块 → 耗电管理 → 允许完全后台行为。\n\n"
                                + "关掉之后，夜里体检才能一直跑完，不用点回来。")
                        .setPositiveButton("知道了", null)
                        .setNegativeButton("知道了", null)
                        .show();
            }
        }
        if (permGoPendingStage > 0) {
            final int st = permGoPendingStage;
            permGoPendingStage = 0;
            Log2.i("从系统设置返回：重新检查第 " + st + " 项权限");
            preflightStage = st;
            ui.postDelayed(new Runnable() {
                @Override
                public void run() {
                    if (!uiDead()) runPreflight();
                }
            }, 400);
        }
        if (pendingClearAfterGrant) {
            boolean ok = android.os.Build.VERSION.SDK_INT < 30
                    || android.os.Environment.isExternalStorageManager();
            Log2.i("从所有文件访问授权页返回：已授予=" + ok);
            if (ok) {
                pendingClearAfterGrant = false;
                Log2.i("已获得所有文件访问权限，准备询问是否清除日志");
                ui.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        askClearLog();      // 拿到权限后再问用户"要不要清除"
                    }
                }, 400);
            } else {
                pendingClearAfterGrant = false;
                toast("还没有授权，旧日志删不掉");
            }
        }
        if (pendingScan) ui.postDelayed(new Runnable() {
            @Override
            public void run() {
                consumeScanResult();
            }
        }, 300);
        ui.removeCallbacks(ticker);
        ui.post(ticker);
        ui.removeCallbacks(listTicker);
        ui.post(listTicker);
    }

    @Override
    protected void onPause() {
        super.onPause();
        ui.removeCallbacks(ticker);
        ui.removeCallbacks(listTicker);     // 后台不再每秒重绘列表
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        try {
            ui.removeCallbacksAndMessages(null);   // 连错误弹窗、延迟回调一起取消
        } catch (Throwable ignored) {
        }
        try {
            if (tester != null) tester.cancel();   // 别让 48 个线程继续打到已销毁的界面
        } catch (Throwable ignored) {
        }
        try {
            if (scanDialog != null && scanDialog.isShowing()) scanDialog.dismiss();
        } catch (Throwable ignored) {
        }
        scanDialog = null;
        try {
            if (refreshMon != null && refreshMon.isShowing()) refreshMon.dismiss();
        } catch (Throwable ignored) {
        }
        refreshMon = null;
        try {
            if (guideDialog != null && guideDialog.isShowing()) guideDialog.dismiss();
        } catch (Throwable ignored) {
        }
        guideDialog = null;
        try {
            if (tiktokDialog != null && tiktokDialog.isShowing()) tiktokDialog.dismiss();
        } catch (Throwable ignored) {
        }
        tiktokDialog = null;
        pendingRefreshSummary = false;
        try {
            // 注意：这里**不能**取消翻新——翻新跑在前台服务里，
            // 界面销毁（划掉最近任务、切主题）不该中断它。
            if (RefreshRunner.isRunning()) {
                Log2.i("界面销毁：翻新仍在后台服务里继续跑");
            }
        } catch (Throwable ignored) {
        }
        try {
            if (refreshDialog != null && refreshDialog.isShowing()) refreshDialog.dismiss();
        } catch (Throwable ignored) {
        }
        try {
            if (activeDialog != null && activeDialog.isShowing()) activeDialog.dismiss();
        } catch (Throwable ignored) {
        }
        activeDialog = null;
        try {
            if (cloudDialog != null && cloudDialog.isShowing()) cloudDialog.dismiss();
        } catch (Throwable ignored) {
        }
        cloudDialog = null;
        cloudText = null;
        try {
            if (opDialog != null && opDialog.isShowing()) opDialog.dismiss();
        } catch (Throwable ignored) {
        }
        opDialog = null;
        try {
            if (changelogDialog != null && changelogDialog.isShowing()) changelogDialog.dismiss();
        } catch (Throwable ignored) {
        }
        changelogDialog = null;
        try {
            unregisterReceiver(stateReceiver);
        } catch (Throwable ignored) {
        }
        try {
            unregisterReceiver(refreshStateReceiver);
        } catch (Throwable ignored) {
        }
    }

    private final BroadcastReceiver refreshStateReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            try {
                if (intent == null) return;
                int state = intent.getIntExtra("state", 0);
                if (state == 3) {
                    // 服务端没能开始翻新（正忙/启动失败）
                    final String err = intent.getStringExtra("error");
                    refreshRunning = false;
                    refreshFinishHandled = true;
                    pendingRefreshSummary = false;
                    dismissRefreshMonitorHard();
                    status.setText(err == null ? "翻新没能开始" : err);
                    if (!uiDead()) toast(err == null ? "翻新没能开始" : err);
                } else if (state == 2) {
                    if (!uiDead()) onRefreshMonitorFinished();
                } else if (RefreshRunner.isRunning() && !uiDead()) {
                    // 后台在跑且界面在前台：保证进度窗存在
                    if (refreshMon == null) showRefreshMonitor();
                }
            } catch (Throwable ignored) {
            }
        }
    };

    private AlertDialog activeDialog;

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 1) {
            if (resultCode == RESULT_OK) {
                startTunnel(pendingNode, pendingMode, pendingForce, pendingCloud);
            } else {
                toast("没有获得 VPN 授权");
            }
            // 允许 / 拒绝都要清：否则拒绝后下一次普通连接会被当成云节点连接
            pendingForce = false;
            pendingCloud = false;
            pendingNode = null;
        } else if (requestCode == REQ_DELETE_LOGS) {
            Log2.i("系统删除确认返回：resultCode=" + resultCode);
            toast(resultCode == RESULT_OK ? "日志已清空" : "已取消删除");
        } else if (requestCode == REQ_IMPORT_FILE) {
            if (resultCode == RESULT_OK && data != null && data.getData() != null) {
                importFromUri(data.getData());
            }
        }
    }

    /** 「连接」= 「自动」：全部节点里挑最快且能通的。 */
    private void autoConnectFastest() {
        if (TunnelService.isRunning()) {
            TunnelService.disconnect(this);
            return;
        }
        if (blockIfBusy()) return;
        String lastGood = NodeStore.lastGoodUri(this);
        if (lastGood != null && lastGood.length() > 0) {
            for (Country c : countries) {
                for (Node n : c.nodes) {
                    if (n.uri.equals(lastGood)) {
                        status.setText("自动：先试上次连通的 " + n.title);
                        requestVpn(n, TunnelService.MODE_AUTO);
                        return;
                    }
                }
            }
        }
        Node best = fastestOverall();
        if (best != null) {
            status.setText("自动：全部节点里挑最快且能通的…");
            requestVpn(best, TunnelService.MODE_AUTO);
            return;
        }
        for (Country c : countries) {
            if (c.nodes.size() > 0) {
                status.setText("自动：全部节点里挑最快且能通的…");
                requestVpn(c.nodes.get(0), TunnelService.MODE_AUTO);
                return;
            }
        }
        toast("没有可用节点");
    }

    private Node fastestOverall() {
        Node best = null;
        for (Country c : countries) {
            Node n = c.fastestMeasured();
            if (n != null && (best == null || n.latency < best.latency)) best = n;
        }
        return best;
    }

    /* ---------------------------- 体检 ---------------------------- */

    private void toggleScan() {
        if (!TunnelService.isScanning()) {
            showFastScanTipThen(new Runnable() {
                @Override
                public void run() {
                    preflightThen(new Runnable() {
                        @Override
                        public void run() {
                            toggleScanInner();
                        }
                    });
                }
            });
            return;
        }
        toggleScanInner();
    }

    /** 体检/翻新前提示一次：可以在设置里开「快速体检」。不提供直接开启。 */
    private void showFastScanTipThen(final Runnable next) {
        try {
            if (getSharedPreferences("qv", MODE_PRIVATE).getBoolean("skip_fast_scan_tip", false)) {
                next.run();
                return;
            }
        } catch (Throwable ignored) {
        }
        float dp = getResources().getDisplayMetrics().density;
        int pad = (int) (dp * 18);
        android.widget.LinearLayout box = new android.widget.LinearLayout(this);
        box.setOrientation(android.widget.LinearLayout.VERTICAL);
        box.setPadding(pad, pad, pad, (int) (dp * 8));

        TextView tv = new TextView(this);
        tv.setText("节点多的时候，到 设置 → 快速体检 打开它，"
                + "体检（以及翻新后的体检）能快一半左右：\n\n"
                + "1 万个节点：约 23 分钟 → 约 12 分钟。\n\n"
                + "程序不会自动替你开启，需要你自己去设置里开。");
        tv.setTextSize(14f);
        tv.setTextColor(0xFFF0F3F8);
        box.addView(tv);

        final AlertDialog[] holder = new AlertDialog[1];
        final Runnable closeNow = new Runnable() {
            @Override
            public void run() {
                try {
                    if (holder[0] != null && holder[0].isShowing()) holder[0].dismiss();
                } catch (Throwable ignored) {
                }
                next.run();
            }
        };

        int h = (int) (dp * 44);
        Button b1 = new Button(this);
        b1.setText("关闭（下次再提醒我）");
        b1.setAllCaps(false);
        b1.setTextSize(14f);
        android.widget.LinearLayout.LayoutParams lp1 = new android.widget.LinearLayout.LayoutParams(
                android.widget.LinearLayout.LayoutParams.MATCH_PARENT, h);
        lp1.topMargin = (int) (dp * 10);
        box.addView(b1, lp1);

        Button b2 = new Button(this);
        b2.setText("关闭（下次不再提示）");
        b2.setAllCaps(false);
        b2.setTextSize(14f);
        android.widget.LinearLayout.LayoutParams lp2 = new android.widget.LinearLayout.LayoutParams(
                android.widget.LinearLayout.LayoutParams.MATCH_PARENT, h);
        lp2.topMargin = (int) (dp * 8);
        box.addView(b2, lp2);

        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                closeNow.run();
            }
        });
        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    getSharedPreferences("qv", MODE_PRIVATE).edit()
                            .putBoolean("skip_fast_scan_tip", true).apply();
                } catch (Throwable ignored) {
                }
                closeNow.run();
            }
        });

        holder[0] = new AlertDialog.Builder(this)
                .setTitle("提示：可以开启快速体检")
                .setView(box)
                .setCancelable(false)
                .create();
        holder[0].show();
    }

    private void toggleScanInner() {
        if (TunnelService.isScanning()) {
            confirmStopScan();
            return;
        }
        if (TunnelService.isRunning() || TunnelService.isConnecting()) {
            toast("先断开连接再做体检");
            return;
        }
        // 体检测的是"全部节点"，不是当前列表里显示的这些
        final int total = NodeStore.everything(this).size();
        if (total == 0) {
            toast("没有可体检的节点");
            return;
        }
        new AlertDialog.Builder(this)
                .setTitle("节点体检")
                .setMessage("体检会让内核把全部 " + total + " 个节点逐个真的连一次外网。\n\n"
                        + "【会改动什么】\n"
                        + "· 连得上的 → 标为「实测可用」（绿色）\n"
                        + "· 连不上的 → 标为「已隐藏」（灰色，不再出现在列表里）\n"
                        + "· 之前隐藏、这次又通了的 → 自动恢复成「已显示」\n\n"
                        + "也就是说，体检会整体重排这三个状态。\n\n"
                        + "【改坏了可以还原】\n"
                        + "体检结束后会弹窗，里面可以点「恢复体检前状态」，"
                        + "把实测可用 / 显示 / 隐藏都还原成现在这样。\n\n"
                        + "全部测完约 " + etaText(total)
                        + "（按 40 并发、每个最多等 5.5 秒估算），中途再点一次「体检」可停止。\n\n"
                        + "⚠ 开始前请确保没有开启「外部应用的 VPN」（别的 VPN 软件），"
                        + "否则体检结果会受影响。")
                .setPositiveButton("开始体检", new android.content.DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(android.content.DialogInterface d, int w) {
                        ensureNotificationsThen(new Runnable() {
                            @Override
                            public void run() {
                                status.setText("体检开始…");
                                showScanProgress(total);
                                TunnelService.startScan(MainActivity.this);
                            }
                        });
                    }
                })
                .setNegativeButton("取消", null)
                .show();
    }

    private AlertDialog scanDialog;
    private android.widget.ProgressBar scanBar;
    private TextView scanText;

    /** 体检进行中的弹窗：标题 + 进度条 + 当前数量。 */
    private void showScanProgress(int total) {
        if (uiDead()) return;
        dismissScanProgress();
        android.widget.LinearLayout box = new android.widget.LinearLayout(this);
        box.setOrientation(android.widget.LinearLayout.VERTICAL);
        int pad = (int) (getResources().getDisplayMetrics().density * 20);
        box.setPadding(pad, pad, pad, pad);

        scanText = new TextView(this);
        scanText.setText("正在体检：0 / " + total + "\n可用 0 个");
        scanText.setTextSize(14f);
        // 弹窗底色始终是深色（Theme.Material），文字必须固定浅色，
        // 否则浅色主题下会变成"深底 + 黑字"看不清
        scanText.setTextColor(0xFFF0F3F8);
        box.addView(scanText);

        scanBar = new android.widget.ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        scanBar.setMax(Math.max(1, total));
        scanBar.setProgress(0);
        try {
            scanBar.setProgressTintList(android.content.res.ColorStateList.valueOf(Palette.green(this)));
        } catch (Throwable ignored) {
        }
        android.widget.LinearLayout.LayoutParams lp = new android.widget.LinearLayout.LayoutParams(
                android.widget.LinearLayout.LayoutParams.MATCH_PARENT,
                (int) (getResources().getDisplayMetrics().density * 10));
        lp.topMargin = pad / 2;
        box.addView(scanBar, lp);

        scanText2 = new TextView(this);
        scanText2.setText("本批：0%");
        scanText2.setTextSize(13f);
        scanText2.setTextColor(0xFFBFC6D4);
        android.widget.LinearLayout.LayoutParams lp2 = new android.widget.LinearLayout.LayoutParams(
                android.widget.LinearLayout.LayoutParams.MATCH_PARENT,
                android.widget.LinearLayout.LayoutParams.WRAP_CONTENT);
        lp2.topMargin = pad;
        box.addView(scanText2, lp2);

        scanBar2 = new android.widget.ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        scanBar2.setMax(100);
        scanBar2.setProgress(0);
        try {
            scanBar2.setProgressTintList(android.content.res.ColorStateList.valueOf(Palette.green(this)));
        } catch (Throwable ignored) {
        }
        android.widget.LinearLayout.LayoutParams lp3 = new android.widget.LinearLayout.LayoutParams(
                android.widget.LinearLayout.LayoutParams.MATCH_PARENT,
                (int) (getResources().getDisplayMetrics().density * 6));
        lp3.topMargin = pad / 4;
        box.addView(scanBar2, lp3);

        Button stopBtn = new Button(this);
        stopBtn.setText("结束体检");
        stopBtn.setAllCaps(false);
        stopBtn.setTextSize(14f);
        stopBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                confirmStopScan();      // 只弹确认，不改变体检状态
            }
        });
        box.addView(stopBtn, new android.widget.LinearLayout.LayoutParams(
                android.widget.LinearLayout.LayoutParams.MATCH_PARENT,
                (int) (getResources().getDisplayMetrics().density * 44)));
        scanDialog = new AlertDialog.Builder(this)
                .setTitle("节点体检中…")
                .setView(box)
                .setCancelable(false)
                .create();
        scanDialog.show();
        activeDialog = scanDialog;
    }

    /** 结束体检前确认：说明中途结束会留下"未验证的可用节点"。 */
    private void confirmStopScan() {
        if (uiDead()) return;
        new AlertDialog.Builder(this)
                .setTitle("结束体检？")
                .setMessage("体检还没跑完。\n\n"
                        + "现在结束的话，还没测到的节点会保持原样（可能仍被当成可用），"
                        + "连接部分国家时可能出现报错 / 连不上，"
                        + "而且点连接时会更慢——内核会先把这些连不上的节点逐个试一遍，才轮到能用的那个。\n\n"
                        + "之后可以在列表模式顶部点「体检」重新做一遍。")
                .setPositiveButton("结束体检", new android.content.DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(android.content.DialogInterface d, int w) {
                        TunnelService.stopScan(MainActivity.this);
                        status.setText("正在结束体检…");
                        dismissScanProgress();
                        if (pendingRefreshSummary) {
                            pendingRefreshSummary = false;
                            final int n = refreshImported;
                            ui.postDelayed(new Runnable() {
                                @Override
                                public void run() {
                                    showRefreshSummaryNoScan(n);
                                }
                            }, 400);
                        }
                    }
                })
                .setNegativeButton("继续体检", null)
                .show();
    }

    private void updateScanProgress(int done, int total, int alive) {
        if (scanBar == null || scanText == null) return;
        if (scanDialog != null && !scanDialog.isShowing()) return;
        scanBar.setMax(Math.max(1, total));
        scanBar.setProgress(Math.min(done, total));
        int pct = total <= 0 ? 0 : (int) (done * 100L / total);
        scanText.setText("正在体检：" + done + " / " + total + "（" + pct + "%）\n可用 " + alive + " 个");
    }

    private void dismissScanProgress() {
        try {
            ui.removeCallbacks(scanMonitorTicker);
        } catch (Throwable ignored) {
        }
        try {
            if (scanDialog != null && scanDialog.isShowing()) scanDialog.dismiss();
        } catch (Throwable ignored) {
        }
        scanDialog = null;
        scanBar = null;
        scanText = null;
        scanBar2 = null;
        scanText2 = null;
    }

    private void showScanResult(final int alive, final int dead, final String summary,
                                final int hidden, final String reportPath) {
        dismissScanProgress();
        if (uiDead()) {
            Log2.w("界面已销毁，跳过体检结果弹窗");
            return;
        }
        showHiddenInEdit = false;
        NodeStore.setShowAll(this, false);
        NodeStore.reload(this);
        syncShowAll(false);
        countries = NodeStore.countries(this, editMode && showHiddenInEdit);
        adapter.notifyDataSetChanged();
        updateStats();

        final String label = NodeStore.netLabel(this);
        StringBuilder msg = new StringBuilder();
        msg.append("可用 ").append(alive).append(" 个，连不通 ").append(dead).append(" 个。\n\n");
        if (summary != null && summary.length() > 0) {
            msg.append("可用节点分布：\n").append(summary).append("\n\n");
        }
        boolean trashDead = lastScanTrashDead;
        msg.append("已把这次测通的标为「实测可用」，连不通的 ")
                .append(trashDead ? "已经丢进回收站（可还原）。\n" : "已隐藏。\n");
        msg.append(trashDead
                ? "（不能用的节点在「回收站」里，可以还原或清空）\n"
                : "（想看或清理这些隐藏节点：长按眼睛按钮可「删除全部隐藏节点」）\n");
        msg.append("（只对当前网络「").append(label).append("」生效）\n\n");
        msg.append("现在列表里有 ").append(NodeStore.all(this).size()).append(" 个节点。\n");
        if (reportPath != null && reportPath.length() > 0) {
            msg.append("\n报告：").append(reportPath);
        }
        msg.append("\n\n如果不满意，可以点下面的「恢复体检前状态」，");
        msg.append("把实测可用 / 显示 / 隐藏全部还原成体检前的样子。");

        final AlertDialog resultDialog = new AlertDialog.Builder(this)
                .setTitle("体检完成")
                .setMessage(msg.toString())
                .setPositiveButton("完成", new android.content.DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(android.content.DialogInterface d, int w) {
                        NodeStore.clearSnapshot(MainActivity.this);
                        toast("已保留本次体检结果");
                    }
                })
                .setNegativeButton("恢复体检前状态", new android.content.DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(android.content.DialogInterface d, int w) {
                        boolean ok = NodeStore.restoreSnapshot(MainActivity.this);
                        NodeStore.setShowAll(MainActivity.this, false);
                        NodeStore.reload(MainActivity.this);
                        countries = NodeStore.countries(MainActivity.this, editMode && showHiddenInEdit);
                        adapter.notifyDataSetChanged();
                        updateStats();
                        status.setText(ok ? "已恢复到体检前的状态" : "没有可恢复的体检前状态");
                        toast(ok ? "已恢复到体检前的状态" : "没有可恢复的状态");
                    }
                })
                .setNeutralButton("看报告", null)
                .create();
        final int sAlive = alive, sDead = dead;
        final String sReport = reportPath;
        resultDialog.setOnDismissListener(new android.content.DialogInterface.OnDismissListener() {
            @Override
            public void onDismiss(android.content.DialogInterface d) {
                if (pendingRefreshSummary) {
                    showRefreshSummary(sAlive, sDead, sReport);
                }
            }
        });
        resultDialog.show();
        activeDialog = resultDialog;
        // 关键：AlertDialog 的按钮默认点一下就关窗，这里改成"只提示、不关窗"
        android.widget.Button reportBtn = resultDialog.getButton(AlertDialog.BUTTON_NEUTRAL);
        if (reportBtn != null) {
            reportBtn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (reportPath == null || reportPath.length() == 0) {
                        toast("这次没有生成报告文件");
                        return;
                    }
                    final String rel = reportPath;
                    final String abs = reportPath.startsWith("/") ? reportPath : ("/sdcard/" + reportPath);
                    final String msg = "报告位置（相对 Download）：\n" + rel
                            + "\n\n完整路径：\n" + abs
                            + "\n\n用文件管理器打开：内部存储 → Download → CommandVPN";
                    final AlertDialog rd = new AlertDialog.Builder(MainActivity.this)
                            .setTitle("体检报告")
                            .setMessage(msg)
                            .setPositiveButton("关闭", null)
                            .setNeutralButton("复制路径", null)
                            .create();
                    rd.show();
                    setSelectable(rd);
                    try {
                        rd.getButton(AlertDialog.BUTTON_NEUTRAL).setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View vv) {
                                copy(abs);
                                toast("路径已复制");
                            }
                        });
                    } catch (Throwable ignored) {
                    }
                }
            });
        }
    }

    /** 清空全部导入的节点（内置节点不动）。 */
    private void confirmClearImported() {
        // 数量 = 已显示 + 已隐藏 + 回收站（含隐藏），即导入清单里除"永久删除"外的全部
        final int n = NodeStore.clearableCount(this);
        if (n <= 0) {
            toast("当前没有导入的节点");
            return;
        }
        new AlertDialog.Builder(this)
                .setTitle("清空导入的节点？")
                .setMessage("将删除全部导入的节点，共 " + n + " 个：\n\n"
                        + "· 已显示的节点\n"
                        + "· 已隐藏的节点\n"
                        + "· 回收站里的节点\n\n"
                        + "本应用没有内置节点，所以清空后列表会是空的。\n"
                        + "隐藏名单与可用名单也会一起清掉；删除后需要重新翻新/导入才能恢复。\n\n确定吗？")
                .setPositiveButton("清空", new android.content.DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(android.content.DialogInterface d, int w) {
                        int c = NodeStore.clearImported(MainActivity.this);
                        NodeStore.reload(MainActivity.this);
                        countries = NodeStore.countries(MainActivity.this, editMode && showHiddenInEdit);
                        adapter.notifyDataSetChanged();
                        updateStats();
                        toast("已清空 " + c + " 个导入节点");
                    }
                })
                .setNegativeButton("取消", null)
                .show();
    }

    /** 永久删除全部隐藏节点（不可恢复，只能重新导入）。 */
    private void confirmPurgeAllHidden() {
        final int hidden = NodeStore.hiddenNodeCount(this);   // 与界面口径一致
        if (hidden <= 0) {
            toast("当前没有已隐藏的节点");
            return;
        }
        new AlertDialog.Builder(this)
                .setTitle("删除全部隐藏节点？")
                .setMessage("当前有 " + hidden + " 个已隐藏的节点。\n\n"
                        + "它们会被移入「回收站」，之后可以在回收站里还原，"
                        + "不会直接消失。\n\n确定吗？")
                .setPositiveButton("移入回收站", new android.content.DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(android.content.DialogInterface d, int w) {
                        int n = NodeStore.trashAllHiddenNodes(MainActivity.this);
                        NodeStore.reload(MainActivity.this);
                        countries = NodeStore.countries(MainActivity.this, editMode && showHiddenInEdit);
                        adapter.notifyDataSetChanged();
                        updateStats();
                        toast("已把 " + n + " 个隐藏节点移入回收站");
                        status.setText("已把 " + n + " 个隐藏节点移入回收站（可在回收站还原）");
                    }
                })
                .setNegativeButton("取消", null)
                .show();
    }

    /** 长按「体检」：切换"只显示实测可用 / 显示全部"，以及按国家恢复隐藏的。 */
    private void restoreHidden() {
        final boolean all = NodeStore.showAll(this);
        java.util.List<Node> listNow = NodeStore.all(this);
        final int shown = listNow.size();
        int goodNow = 0;
        for (Node x : listNow) if (NodeStore.isGood(this, x.uri)) goodNow++;
        final int total = NodeStore.totalCount(this);
        final int hidden = NodeStore.blacklistSize(this);
        final String label = NodeStore.netLabel(this);
        String title = all ? ("当前显示全部 " + shown + " 个节点")
                : ("当前只显示实测可用的 " + goodNow + " 个节点");
        String msg = "当前一共 " + total + " 个节点，其中 " + goodNow + " 个实测能用，"
                + (shown > goodNow ? ("另外 " + (shown - goodNow) + " 个是手动显示但没体检通过的。\n\n")
                : "其余都还没验证过。\n\n")
                + (hidden > 0 ? "另有 " + hidden + " 个体检判定不通、已被隐藏（当前网络「" + label + "」）。\n\n" : "")
                + "想看到全部节点，点下面的按钮。";
        new AlertDialog.Builder(this)
                .setTitle(title)
                .setMessage(msg)
                .setPositiveButton(all ? "只显示实测可用的" : "显示全部节点", new android.content.DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(android.content.DialogInterface d, int w) {
                        NodeStore.reload(MainActivity.this);
                        syncShowAll(!all);
                        java.util.List<Node> now = NodeStore.all(MainActivity.this);
                        int g = 0;
                        for (Node x : now) if (NodeStore.isGood(MainActivity.this, x.uri)) g++;
                        status.setText(NodeStore.showAll(MainActivity.this)
                                ? "已显示全部 " + now.size() + " 个节点"
                                : "只显示实测可用的 " + g + " 个节点");
                    }
                })
                .setNeutralButton("按国家恢复隐藏的", new android.content.DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(android.content.DialogInterface d, int w) {
                        showHiddenByCountry();
                    }
                })
                .setNegativeButton("关闭", null)
                .show();
    }

    /** 按国家列出被隐藏的节点，点某个国家就恢复它。 */
    private void showHiddenByCountry() {
        final Map<String, List<String>> map = NodeStore.blacklistByCountry(this);
        if (map.isEmpty()) {
            toast("没有隐藏的节点");
            return;
        }
        final List<String> ccs = new ArrayList<String>(map.keySet());
        Collections.sort(ccs, new Comparator<String>() {
            @Override
            public int compare(String a, String b) {
                return map.get(b).size() - map.get(a).size();
            }
        });
        final String[] items = new String[ccs.size()];
        for (int i = 0; i < ccs.size(); i++) {
            String name = Country.displayName(ccs.get(i));
            items[i] = (name.length() == 0 ? ccs.get(i) : name) + "   （" + map.get(ccs.get(i)).size() + " 个已隐藏）";
        }
        new AlertDialog.Builder(this)
                .setTitle("按国家恢复")
                .setItems(items, new android.content.DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(android.content.DialogInterface d, int which) {
                        String cc = ccs.get(which);
                        int removed = NodeStore.blacklistRemoveCountry(MainActivity.this, cc);
                        NodeStore.reload(MainActivity.this);
                        countries = NodeStore.countries(MainActivity.this, editMode && showHiddenInEdit);
                        updateStats();
                        adapter.notifyDataSetChanged();
                        String name = Country.displayName(cc);
                        status.setText("已恢复 " + (name.length() == 0 ? cc : name) + " 的 " + removed + " 个节点");
                        toast("已恢复 " + removed + " 个");
                    }
                })
                .setNegativeButton("关闭", null)
                .show();
    }

    /** 测试延迟：对全部节点做 TCP 握手，几十秒扫完，用来排序（不判断节点死活）。 */
    private void runGlobalTest() {
        if (TunnelService.isScanning()) {
            toast("正在体检中，等它结束再测延迟");
            return;
        }
        Log2.i("点了「测试延迟」");
        List<Node> nodes = NodeStore.all(this);   // 只测列表里显示的那些
        if (nodes.isEmpty()) {
            nodes = NodeStore.everything(this);   // 列表空了就退回测全部，至少能用
            Log2.i("列表为空，改为测全部 " + nodes.size() + " 个");
        }
        final List<Node> all = nodes;
        Log2.i("测试延迟开始，共 " + all.size() + " 个节点，上一轮是否还在跑=" + tester.isRunning());
        if (all.isEmpty()) {
            toast("没有可测的节点");
            return;
        }
        if (tester.isRunning()) {
            tester.cancel();
            status.setText("已停止测延迟");
            return;
        }
        status.setText("正在测延迟 " + all.size() + " 个节点…");
        tester.test(all, 1500, 48, new LatencyTester.Callback() {
            private long lastPost;

            @Override
            public void onResult(Node node) {
                long now = System.currentTimeMillis();
                if (now - lastPost < 300) return;
                lastPost = now;
                ui.post(new Runnable() {
                    @Override
                    public void run() {
                        for (Country c : countries) c.sortByLatency();
                        adapter.notifyDataSetChanged();
                    }
                });
            }

            @Override
            public void onFinished() {
                ui.post(new Runnable() {
                    @Override
                    public void run() {
                        for (Country c : countries) c.sortByLatency();
                        NodeStore.saveLatencies(MainActivity.this, all);
                        adapter.notifyDataSetChanged();
                        int ok = 0;
                        for (Node n : all) if (n.latency > 0) ok++;
                        Log2.i("测试延迟结束：可达 " + ok + " / " + all.size());
                        status.setText("延迟测完：TCP 可达 " + ok + " / " + all.size()
                                + "（这是握手延迟，能不能真正连出去要看「体检」）");
                    }
                });
            }
        });
    }

    /* ---------------------------- 编辑 ---------------------------- */

    /** 编辑模式那只眼睛：划掉 = 不显示已隐藏的节点。 */
    /** 单一入口：同时更新 prefs、眼睛状态、列表与状态栏，避免三者不一致。 */
    /** 顶栏 4 个按钮按当前模式重设（编辑模式：导入/回收站/完成/眼睛；否则：测试延迟/体检/编辑/日志）。 */
    private void refreshToolbar() {
        if (btnEdit != null) btnEdit.setText(editMode ? "完成" : "编辑");
        Button lat = (Button) findViewById(R.id.btnLatency);
        Button spd = (Button) findViewById(R.id.btnSpeed);
        if (lat != null) lat.setText(editMode ? "导入" : "测试延迟");
        if (spd != null) spd.setText(editMode ? "回收站" : "体检");
        Button log = (Button) findViewById(R.id.btnLog);
        if (log == null) return;
        if (editMode) {
            updateEyeButton(log);
        } else {
            log.setText("日志");
            log.setPaintFlags(log.getPaintFlags() & ~android.graphics.Paint.STRIKE_THRU_TEXT_FLAG);
            log.setAlpha(1f);
        }
    }

    private void syncShowAll(boolean showAll) {
        showHiddenInEdit = showAll;
        NodeStore.setShowAll(this, showAll);
        refreshToolbar();
        countries = NodeStore.countries(this, editMode && showAll);
        adapter.notifyDataSetChanged();
        updateStats();
        updateSwitchView();
    }

    private void toggleHiddenVisible() {
        showHiddenInEdit = !showHiddenInEdit;
        // 眼睛和"显示全部"必须同步，否则会出现
        // 「只显示 64 个实测可用」但列表里却有 568 个的矛盾
        NodeStore.setShowAll(this, showHiddenInEdit);
        Button log = (Button) findViewById(R.id.btnLog);
        updateEyeButton(log);
        countries = NodeStore.countries(this, editMode && showHiddenInEdit);
        adapter.notifyDataSetChanged();
        updateStats();
        updateSwitchView();
        int trashed = showHiddenInEdit ? NodeStore.trashSize(this) : NodeStore.trashVisibleSize(this);
        int total = 0;
        int good = 0;
        int grey = 0;
        for (Country c : countries) {
            for (Node n : c.nodes) {
                total++;
                if (NodeStore.isGood(this, n.uri)) good++;
                if (n.hidden) grey++;      // 真正灰掉的（没测通且没手动显示）
            }
        }
        if (showHiddenInEdit) {
            status.setText("眼睛不划线：显示全部 " + total + " 个节点，其中 " + grey
                    + " 个是灰色（没通过体检或已隐藏）：点一下 = 选中它，长按 = 显示/删除。"
                    + "（回收站 " + trashed + " 个）");
        } else {
            status.setText("眼睛已划线：只显示 " + total + " 个实测可用节点，其余 "
                    + Math.max(0, NodeStore.totalCount(this) - total) + " 个看不到。"
                    + "（回收站 " + trashed + " 个）");
        }
    }

    private void updateEyeButton(Button b) {
        if (b == null) return;
        b.setText("\uD83D\uDC41");            // 👁
        int flags = b.getPaintFlags();
        if (!showHiddenInEdit) {
            b.setPaintFlags(flags | android.graphics.Paint.STRIKE_THRU_TEXT_FLAG);
            b.setAlpha(0.5f);
        } else {
            b.setPaintFlags(flags & ~android.graphics.Paint.STRIKE_THRU_TEXT_FLAG);
            b.setAlpha(1f);
        }
    }

    private void setEditMode(boolean on) {
        if (!on) {
            showHiddenInEdit = false;
            NodeStore.setShowAll(this, false);   // 退出编辑必须回到"只看实测可用"
        }
        editMode = on;
        refreshToolbar();
        if (on) {
            status.setText("编辑模式：已隐藏的节点会灰色显示，点它可直接恢复；长按国家行＝更多；顶栏「导入」「回收站」");
        } else {
            status.setText("共 " + NodeStore.all(this).size() + " 个节点");
        }
        countries = NodeStore.countries(this, editMode && showHiddenInEdit);
        adapter.notifyDataSetChanged();
        updateStats();
    }

    private void confirmRemoveNode(final Node n) {
        new AlertDialog.Builder(this)
                .setTitle("移除节点")
                .setMessage(n.title + "\n" + n.subtitle() + "\n\n移除后不再出现在列表里（只是隐藏，长按「体检」可恢复）。")
                .setPositiveButton("移除", new android.content.DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(android.content.DialogInterface d, int w) {
                        NodeStore.blacklistAdd(MainActivity.this, n.cc, n.uri);
                        NodeStore.reload(MainActivity.this);
                        countries = NodeStore.countries(MainActivity.this, editMode && showHiddenInEdit);
                        updateStats();
                        adapter.notifyDataSetChanged();
                        toast("已移除");
                    }
                })
                .setNegativeButton("取消", null)
                .show();
    }

    /** 已隐藏的节点：显示（恢复）或删除（移到回收站）。 */
    /** 已隐藏的节点：显示（放进列表，但不改实测可用）/ 删除。 */
    private void showUnverifiedMenu(final Node n) {
        showHiddenNodeMenu(n);
    }

    private void showHiddenNodeMenu(final Node n) {
        Log2.i("打开已隐藏节点菜单：" + n.title);
        final boolean good = NodeStore.isGood(this, n.uri);      // 是"实测可用但被隐藏"还是"没测通"
        String[] items = new String[]{
                good ? "显示（放回列表，已实测可用）" : "显示（放进列表，仍不算实测可用）",
                "删除（移到回收站，可恢复）"
        };
        new AlertDialog.Builder(this)
                .setTitle(n.title + "\n" + n.subtitle())
                .setItems(items, new android.content.DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(android.content.DialogInterface d, int which) {
                        if (which == 0) {
                            NodeStore.blacklistRemove(MainActivity.this, n.uri);
                            NodeStore.addShown(MainActivity.this, n.uri);   // 只是显示，不是实测可用
                            Log2.i("显示后检查：isShown=" + NodeStore.isShown(MainActivity.this, n.uri)
                                    + " isGood=" + NodeStore.isGood(MainActivity.this, n.uri));
                            refreshAfterEdit(good ? ("已显示：" + n.title)
                                    : ("已显示：" + n.title + "（未实测）"));
                        } else {
                            confirmTrash(n);
                        }
                    }
                })
                .show();
    }

    /** 编辑模式点/长按节点：选择 / 隐藏 / 删除到回收站。 */
    private void showNodeEditMenu(final Node n) {
        Log2.i("打开节点编辑菜单：" + n.title + " hidden=" + n.hidden);
        String[] items = new String[]{
                "选择这个节点（在底部点「连接」）",
                "隐藏（不出现在列表，可随时显示）",
                "删除（移到回收站，可恢复）"
        };
        new AlertDialog.Builder(this)
                .setTitle(n.title + "\n" + n.subtitle())
                .setItems(items, new android.content.DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(android.content.DialogInterface d, int which) {
                        if (which == 0) {
                            selectNode(n);
                        } else if (which == 1) {
                            NodeStore.blacklistAdd(MainActivity.this, n.cc, n.uri);
                            NodeStore.removeShown(MainActivity.this, n.uri);
                            refreshAfterEdit("已隐藏：" + n.title);
                        } else {
                            confirmTrash(n);
                        }
                    }
                })
                .show();
    }

    /** 删除（移入回收站）前确认。 */
    private void confirmTrash(final Node n) {
        new AlertDialog.Builder(this)
                .setTitle("确定删除？")
                .setMessage("把「" + n.title + "」移到回收站？\n\n"
                        + "回收站里的节点不会出现在列表里，但可以随时恢复，"
                        + "也可以在回收站里永久删除。")
                .setPositiveButton("删除", new android.content.DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(android.content.DialogInterface d, int w) {
                        NodeStore.trashAdd(MainActivity.this, n.cc, n.uri);
                        NodeStore.blacklistRemove(MainActivity.this, n.uri);
                        refreshAfterEdit("已移到回收站：" + n.title);
                    }
                })
                .setNegativeButton("取消", null)
                .show();
    }

    /** 把某个国家的全部节点（含未验证）显示出来 —— 只放进列表，不算实测可用。 */
    private void showAllOfCountry(final Country c) {
        final String cc = c.cc;
        final String name = c.name;
        runOp("正在显示 " + name + " 的全部节点…", new OpJob() {
            @Override
            public String run(OpProg p) {
                java.util.List<Node> all = NodeStore.countryNodesAll(MainActivity.this, cc);
                int total = all.size();
                java.util.List<String> uris = urisOf(all);
                p.step(0, Math.max(1, total), "正在显示…");
                NodeStore.blacklistRemoveUrisAllNets(MainActivity.this, uris);
                NodeStore.addShownAll(MainActivity.this, uris);
                p.step(total, Math.max(1, total), "正在整理列表…");
                return "已显示 " + name + " 的全部 " + total + " 个节点";
            }
        });
    }

    private void confirmTrashCountry(final Country c) {
        new AlertDialog.Builder(this)
                .setTitle("确定删除？")
                .setMessage("把「" + c.name + "」的 " + c.nodes.size() + " 个节点全部移到回收站？\n\n"
                        + "可以随时从回收站恢复。")
                .setPositiveButton("删除", new android.content.DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(android.content.DialogInterface d, int w) {
                        final java.util.List<Node> nodes = new ArrayList<Node>(c.nodes);
                        final String name = c.name;
                        runOp("正在把 " + name + " 移到回收站…", new OpJob() {
                            @Override
                            public String run(OpProg p) {
                                int total = nodes.size();
                                int moved = 0;
                                java.util.List<String> uris = new ArrayList<String>();
                                for (int i = 0; i < total; i += 300) {
                                    int end = Math.min(total, i + 300);
                                    java.util.List<Node> chunk = nodes.subList(i, end);
                                    moved += NodeStore.trashAddChunk(MainActivity.this, chunk);
                                    for (Node x : chunk) uris.add(x.uri);
                                    p.step(end, Math.max(1, total), "正在移到回收站…");
                                    try {
                                        Thread.sleep(6);   // 让出锁，界面不卡
                                    } catch (InterruptedException ignored) {
                                    }
                                }
                                NodeStore.trashSaveNow(MainActivity.this);
                                NodeStore.blacklistRemoveManyUris(MainActivity.this, uris);
                                return "已移到回收站 " + moved + " 个";
                            }
                        });
                    }
                })
                .setNegativeButton("取消", null)
                .show();
    }

    /** 「最快地区」不是真实国家，长按只给一个灰掉的说明菜单。 */
    /** 每次连上 VPN 提示一次：点 Google 按钮确认能正常访问。 */
    private void maybeShowGoogleTip() {
        try {
            if (getSharedPreferences("qv", MODE_PRIVATE).getBoolean("skip_google_tip", false)) return;
            if (uiDead() || isFinishing()) return;
            android.widget.LinearLayout box = new android.widget.LinearLayout(this);
            box.setOrientation(android.widget.LinearLayout.VERTICAL);
            float dp = getResources().getDisplayMetrics().density;
            int pad = (int) (dp * 18);
            box.setPadding(pad, pad, pad, pad);
            TextView tv = new TextView(this);
            tv.setText("VPN 已连接。\n\n"
                    + "请点击 VPN 选项卡左下角的「Google」按钮，"
                    + "打开 Google 确认这个节点能正常使用。\n\n"
                    + "如果打不开、提示连接被重置、或者出现 404，"
                    + "说明这个节点被 Google 拦截，建议换一个节点。");
            tv.setTextSize(14f);
            tv.setTextColor(0xFFF0F3F8);
            box.addView(tv);
            final android.widget.CheckBox cb = new android.widget.CheckBox(this);
            cb.setText("不再提示");
            cb.setTextColor(0xFFF0F3F8);
            android.widget.LinearLayout.LayoutParams lp = new android.widget.LinearLayout.LayoutParams(
                    android.widget.LinearLayout.LayoutParams.MATCH_PARENT,
                    android.widget.LinearLayout.LayoutParams.WRAP_CONTENT);
            lp.topMargin = pad;
            box.addView(cb, lp);
            new AlertDialog.Builder(this)
                    .setTitle("确认 VPN 是否可用")
                    .setView(box)
                    .setPositiveButton("知道了", new android.content.DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(android.content.DialogInterface d, int w) {
                            if (cb.isChecked()) {
                                getSharedPreferences("qv", MODE_PRIVATE).edit()
                                        .putBoolean("skip_google_tip", true).apply();
                            }
                        }
                    })
                    .show();
        } catch (Throwable t) {
            Log2.w("Google 提示弹窗失败：" + t);
        }
    }

    private void showFastRegionMenu() {
        final String[] items = new String[]{
                "置顶这个国家",
                "显示这个国家的全部节点",
                "隐藏这个国家的全部节点",
                "删除这个国家（移到回收站）",
                "连接这个国家最快的节点"
        };
        android.widget.BaseAdapter ad = new android.widget.BaseAdapter() {
            @Override
            public int getCount() { return items.length; }
            @Override
            public Object getItem(int i) { return items[i]; }
            @Override
            public long getItemId(int i) { return i; }
            @Override
            public View getView(int i, View convert, android.view.ViewGroup parent) {
                TextView tv = (TextView) (convert != null ? convert : new TextView(MainActivity.this));
                tv.setText(items[i]);
                tv.setTextSize(15f);
                tv.setPadding(48, 34, 48, 34);
                tv.setTextColor(0xFF7A8496);   // 全部灰色
                tv.setEnabled(false);
                return tv;
            }
        };
        AlertDialog dlgFast = new AlertDialog.Builder(this)
                .setTitle("⚡ 最快地区")
                .setAdapter(ad, null)
                .setPositiveButton("知道了", null)
                .create();
        dlgFast.show();
    }

    private void showItemMenuAt(final int position) {
        final long packed = list.getExpandableListPosition(position);
        ui.postDelayed(new Runnable() {
            @Override
            public void run() {
                if (uiDead()) return;
                int type = android.widget.ExpandableListView.getPackedPositionType(packed);
                int g = android.widget.ExpandableListView.getPackedPositionGroup(packed);
                int c = android.widget.ExpandableListView.getPackedPositionChild(packed);
                if (type == android.widget.ExpandableListView.PACKED_POSITION_TYPE_GROUP) {
                    if (g == 0) showFastRegionMenu();
                    else if (g >= 1 && g - 1 < countries.size()) {
                        showCountryMenu(countries.get(g - 1));
                    }
                } else if (type == android.widget.ExpandableListView.PACKED_POSITION_TYPE_CHILD
                        && g >= 1 && g <= countries.size()) {
                    Country cc0 = countries.get(g - 1);
                    if (c >= 0 && c < cc0.nodes.size()) {
                        Node n = cc0.nodes.get(c);
                        boolean vis = (NodeStore.isGood(MainActivity.this, n.uri)
                                || NodeStore.isShown(MainActivity.this, n.uri))
                                && !NodeStore.isBlacklisted(MainActivity.this, n.uri);
                        if (vis) showNodeEditMenu(n); else showHiddenNodeMenu(n);
                    }
                }
            }
        }, 60);
    }

    private void refreshAfterEdit(String msg) {
        NodeStore.reload(this);
        countries = NodeStore.countries(this, editMode && showHiddenInEdit);
        adapter.notifyDataSetChanged();
        updateStats();
        status.setText(msg);
        toast(msg);
    }

    /** 回收站：查看 / 恢复 / 永久删除 / 清空（都带确认）。 */
    /** 回收站条目是不是"隐藏类"：删除时已隐藏，或者它本来就既不实测可用也没手动显示。 */
    private boolean trashHiddenClass(String line) {
        // 只看"搬进回收站那一刻"它是不是隐藏状态。
        // 之前还按当前状态动态判断（!good && !shown），而翻新体检搬进回收站后
        // 紧跟着会把"已显示"标记清掉，于是这些条目当场就变成"隐藏类"、被过滤掉，
        // 结果回收站看着只有 1 个。
        return NodeStore.trashWasHidden(line);
    }

    private void showTrash() {
        final java.util.List<String> all = NodeStore.trashLines(this);
        final java.util.List<String> lines = new ArrayList<String>();
        final java.util.List<Boolean> dim = new ArrayList<Boolean>();
        int hiddenInTrash = 0;
        for (String l : all) {
            boolean hid = trashHiddenClass(l);
            if (hid) hiddenInTrash++;
            if (hid && !showHiddenInEdit) continue;   // 与列表一致：隐藏的要开眼睛才看
            lines.add(l);
            dim.add(hid);
        }
        final int hidden = NodeStore.blacklistSize(this);
        if (lines.isEmpty()) {
            new AlertDialog.Builder(this)
                    .setTitle("回收站")
                    .setMessage("回收站是空的。\n\n"
                            + "（编辑模式下点节点 →「删除」会把节点移到这里）"
                            + (hiddenInTrash > 0
                            ? "\n\n另有 " + hiddenInTrash + " 个隐藏条目，"
                              + (showHiddenInEdit ? "已在列表里用淡色显示。"
                              : "需要在编辑模式里点眼睛才会显示。")
                            : ""))
                    .setPositiveButton("知道了", null)
                    .show();
            return;
        }

        // 自定义列表：隐藏类条目用淡色显示
        android.widget.BaseAdapter ad = new android.widget.BaseAdapter() {
            @Override
            public int getCount() { return lines.size(); }

            @Override
            public Object getItem(int i) { return lines.get(i); }

            @Override
            public long getItemId(int i) { return i; }

            @Override
            public View getView(int i, View convert, android.view.ViewGroup parent) {
                TextView tv = (TextView) (convert != null ? convert
                        : getLayoutInflater().inflate(android.R.layout.simple_list_item_1, parent, false));
                String l = lines.get(i);
                String cc = NodeStore.ccOf(l);
                String uri = NodeStore.uriOf(l);
                boolean hid = dim.get(i);
                tv.setText((cc.length() > 0 ? Country.displayName(cc) + " · " : "") + shortName(uri)
                        + (hid ? "   （已隐藏）" : ""));
                // 回收站弹窗底色始终是深色，所以文字固定用浅色（不再跟随浅色主题变黑字）
                tv.setTextColor(hid ? 0xFF8A93A6 : 0xFFF0F3F8);
                tv.setAlpha(hid ? 0.7f : 1f);
                return tv;
            }
        };

        String trashTitle = "回收站（" + lines.size() + " 个）";
        if (hiddenInTrash > 0) {
            trashTitle = showHiddenInEdit
                    ? "回收站（" + lines.size() + " 个，其中原本隐藏的 "
                      + hiddenInTrash + " 个用淡色显示）"
                    : "回收站（" + lines.size() + " 个，另有 " + hiddenInTrash
                      + " 个隐藏的 · 开眼睛可见）";
        }
        new AlertDialog.Builder(this)
                .setTitle(trashTitle)
                .setAdapter(ad, new android.content.DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(android.content.DialogInterface d, int which) {
                        showTrashItemMenu(NodeStore.uriOf(lines.get(which)));
                    }
                })
                .setPositiveButton("全部还原", new android.content.DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(android.content.DialogInterface d, int w) {
                        new AlertDialog.Builder(MainActivity.this)
                                .setTitle("全部还原？")
                                .setMessage("把回收站里的 " + all.size() + " 个节点全部恢复到列表？")
                                .setPositiveButton("还原", new android.content.DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(android.content.DialogInterface dd, int ww) {
                                        final java.util.List<String> linesAll =
                                                new ArrayList<String>(all);
                                        runOp("正在全部还原…", new OpJob() {
                                            @Override
                                            public String run(OpProg p) {
                                                int total = linesAll.size();
                                                int restored = 0;
                                                for (int i = 0; i < total; i += 300) {
                                                    int end = Math.min(total, i + 300);
                                                    java.util.List<String> part =
                                                            new ArrayList<String>();
                                                    for (String l : linesAll.subList(i, end)) {
                                                        part.add(NodeStore.uriOf(l));
                                                    }
                                                    restored += NodeStore.trashRestoreMany(
                                                            MainActivity.this, part);
                                                    p.step(end, Math.max(1, total), "正在还原…");
                                                    try {
                                                        Thread.sleep(6);
                                                    } catch (InterruptedException ignored) {
                                                    }
                                                }
                                                return "已全部还原 " + restored + " 个节点";
                                            }
                                        });
                                    }
                                })
                                .setNegativeButton("取消", null)
                                .show();
                    }
                })
                .setNegativeButton("清空回收站", new android.content.DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(android.content.DialogInterface d, int w) {
                        confirmEmptyTrash(NodeStore.trashSize(MainActivity.this));
                    }
                })
                .setNeutralButton(hidden > 0 ? "看已隐藏(" + hidden + ")" : "关闭",
                        hidden > 0 ? new android.content.DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(android.content.DialogInterface d, int w) {
                                showHiddenByCountry();
                            }
                        } : null)
                .show();
    }

    private void showTrashItemMenu(final String uri) {
        String[] items = new String[]{"恢复到列表", "永久删除（不可恢复）"};
        new AlertDialog.Builder(this)
                .setTitle(shortName(uri))
                .setItems(items, new android.content.DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(android.content.DialogInterface d, int which) {
                        if (which == 0) {
                            NodeStore.trashRestore(MainActivity.this, uri);
                            refreshAfterEdit("已恢复到列表");
                        } else {
                            new AlertDialog.Builder(MainActivity.this)
                                    .setTitle("永久删除？")
                                    .setMessage("这个节点会从回收站彻底删掉，不再能恢复。\n\n确定吗？")
                                    .setPositiveButton("永久删除", new android.content.DialogInterface.OnClickListener() {
                                        @Override
                                        public void onClick(android.content.DialogInterface dd, int ww) {
                                            NodeStore.trashDeleteOne(MainActivity.this, uri);
                                            refreshAfterEdit("已永久删除");
                                        }
                                    })
                                    .setNegativeButton("取消", null)
                                    .show();
                        }
                    }
                })
                .show();
    }

    private void confirmEmptyTrash(final int count) {
        new AlertDialog.Builder(this)
                .setTitle("清空回收站？")
                .setMessage("回收站里的 " + count + " 个节点会被永久删除，不能再恢复。\n\n确定吗？")
                .setPositiveButton("清空", new android.content.DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(android.content.DialogInterface d, int w) {
                        runOp("正在清空回收站…", new OpJob() {
                            @Override
                            public String run(OpProg p) {
                                p.step(0, 1, "正在清空…");
                                NodeStore.trashClear(MainActivity.this);
                                p.step(1, 1, "正在整理列表…");
                                return "回收站已清空";
                            }
                        });
                    }
                })
                .setNegativeButton("取消", null)
                .show();
    }

    private String shortName(String uri) {
        int hash = uri.indexOf('#');
        if (hash >= 0 && hash + 1 < uri.length()) return uri.substring(hash + 1);
        try {
            return new Node(uri, "", "").title;
        } catch (Throwable t) {
            return uri.length() > 40 ? uri.substring(0, 40) + "…" : uri;
        }
    }

    private void confirmRemoveCountry(final Country c) {
        new AlertDialog.Builder(this)
                .setTitle("移除整个国家")
                .setMessage("把「" + c.name + "」的 " + c.nodes.size() + " 个节点全部隐藏？\n\n（不会真删，长按「体检」可恢复）")
                .setPositiveButton("全部移除", new android.content.DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(android.content.DialogInterface d, int w) {
                        int n = NodeStore.blacklistAddAll(MainActivity.this, c.nodes);
                        java.util.List<String> uris = new java.util.ArrayList<String>();
                        for (Node x : c.nodes) uris.add(x.uri);
                        NodeStore.removeShownAll(MainActivity.this, uris);   // 批量，别逐个写盘
                        NodeStore.reload(MainActivity.this);
                        countries = NodeStore.countries(MainActivity.this, editMode && showHiddenInEdit);
                        updateStats();
                        adapter.notifyDataSetChanged();
                        toast("已移除 " + n + " 个");
                    }
                })
                .setNegativeButton("取消", null)
                .show();
    }

    /** 长按国家行：置顶 / 移除该国 / 连接该国最快。 */
    private void showCountryMenu(final Country c) {
        final boolean pinned = NodeStore.isPinned(this, c.cc);
        int[] totals = NodeStore.countryTotals(this, c.cc);
        int all = totals[0];
        int visibleNow = totals[1];
        String[] items = new String[]{
                pinned ? "取消置顶" : "置顶这个国家",
                "显示这个国家的全部节点（共 " + all + " 个）",
                "隐藏这个国家的全部节点（现在显示 " + visibleNow + " 个）",
                "删除这个国家（移到回收站）",
                "连接这个国家最快的节点"
        };
        AlertDialog dlgCountry = new AlertDialog.Builder(this)
                .setTitle(c.flag() + " " + c.name)
                .setItems(items, new android.content.DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(android.content.DialogInterface d, int which) {
                        if (which == 0) {
                            boolean nowPinned = NodeStore.togglePin(MainActivity.this, c.cc);
                            NodeStore.reload(MainActivity.this);
                            countries = NodeStore.countries(MainActivity.this, editMode && showHiddenInEdit);
                        updateStats();
                            adapter.notifyDataSetChanged();
                            toast(nowPinned ? "已置顶 " + c.name : "已取消置顶 " + c.name);
                        } else if (which == 1) {
                            showAllOfCountry(c);
                        } else if (which == 2) {
                            final String cc = c.cc;
                            final String name = c.name;
                            runOp("正在隐藏 " + name + " 的全部节点…", new OpJob() {
                                @Override
                                public String run(OpProg p) {
                                    java.util.List<Node> nodes =
                                            NodeStore.countryNodesAll(MainActivity.this, cc);
                                    int total = nodes.size();
                                    p.step(0, Math.max(1, total), "正在隐藏…");
                                    NodeStore.blacklistAddAll(MainActivity.this, nodes);
                                    NodeStore.removeShownAll(MainActivity.this, urisOf(nodes));
                                    p.step(total, Math.max(1, total), "正在整理列表…");
                                    return "已隐藏 " + name + " 的 " + total + " 个节点";
                                }
                            });
                        } else if (which == 3) {
                            confirmTrashCountry(c);
                        } else {
                            connectCountry(c);
                        }
                    }
                })
                .create();
        allowBackdropDismiss(dlgCountry);
        dlgCountry.show();
    }

    /**
     * 点弹窗本身（标题、列表项、灰色按钮）不关；点弹窗外的空白才关，
     * 且弹窗窗口自带的那圈留白也算"外面"。
     */
    private void allowBackdropDismiss(final AlertDialog d) {
        if (d == null) return;
        d.setCanceledOnTouchOutside(true);
        d.setOnShowListener(new android.content.DialogInterface.OnShowListener() {
            @Override
            public void onShow(android.content.DialogInterface di) {
                try {
                    android.view.Window w = d.getWindow();
                    if (w == null) return;
                    final View decor = w.getDecorView();
                    decor.setOnTouchListener(new View.OnTouchListener() {
                        @Override
                        public boolean onTouch(View v, android.view.MotionEvent e) {
                            if (e.getActionMasked() != android.view.MotionEvent.ACTION_DOWN) {
                                return false;
                            }
                            if (insideView(d, android.R.id.list, e)
                                    || insideTitleArea(d, e)
                                    || insideView(d, android.R.id.button1, e)
                                    || insideView(d, android.R.id.button2, e)
                                    || insideView(d, android.R.id.button3, e)) {
                                return false;
                            }
                            d.dismiss();
                            return true;
                        }
                    });
                } catch (Throwable ignored) {
                }
            }
        });
    }

    /** 标题区（列表上方那一块）：点标题、点标题旁空白都不应该关闭。 */
    private boolean insideTitleArea(android.app.Dialog d, android.view.MotionEvent e) {
        try {
            View content = d.findViewById(android.R.id.content);
            View listView = d.findViewById(android.R.id.list);
            if (content == null) return false;
            int[] cl = new int[2];
            content.getLocationOnScreen(cl);
            float x = e.getRawX(), y = e.getRawY();
            if (x < cl[0] || x > cl[0] + content.getWidth()
                    || y < cl[1] || y > cl[1] + content.getHeight()) {
                return false;
            }
            if (listView == null) return true;
            int[] ll = new int[2];
            listView.getLocationOnScreen(ll);
            return y < ll[1];   // 列表顶部之前 = 标题区
        } catch (Throwable t) {
            return false;
        }
    }

    private boolean insideView(android.app.Dialog d, int id, android.view.MotionEvent e) {
        try {
            View child = d.findViewById(id);
            if (child == null || child.getVisibility() != View.VISIBLE) return false;
            int[] loc = new int[2];
            child.getLocationOnScreen(loc);
            float x = e.getRawX(), y = e.getRawY();
            return x >= loc[0] && x <= loc[0] + child.getWidth()
                    && y >= loc[1] && y <= loc[1] + child.getHeight();
        } catch (Throwable t) {
            return false;
        }
    }

    /* ---------------------------- 导入 ---------------------------- */

    private static final int REQ_IMPORT_FILE = 2;


    /* ---------------------------- 翻新节点 ---------------------------- */

    /** 翻新节点的多个来源（按更新频率排）。名字只用于日志/提示。 */
    private static final String[][] REFRESH_SOURCES = {
            // {名称, 地址, 国家提示}；国家提示非空时，这批节点直接按该国家归类
            // （这些源的节点名字都是 vless-1856237548 这种哈希，名字里没有国家信息）
            {"Au1rxx 美国", "https://raw.githubusercontent.com/Au1rxx/free-vpn-subscriptions/main/output/by-country/v2ray-base64-US.txt", "US"},
            {"Au1rxx 全量", "https://raw.githubusercontent.com/Au1rxx/free-vpn-subscriptions/main/output/v2ray-base64.txt", ""},
            {"mahdibland", "https://raw.githubusercontent.com/mahdibland/V2RayAggregator/master/sub/sub_merge_base64.txt", ""},
            {"peasoft", "https://raw.githubusercontent.com/peasoft/NoMoreWalls/master/list.txt", ""},
            {"ermaozi", "https://raw.githubusercontent.com/ermaozi/get_subscribe/main/subscribe/v2ray.txt", ""},
    };
    /** 单次翻新最多导入多少个新节点（太多会让体检很慢）。 */
    private static final int REFRESH_MAX_IMPORT = 3000;
    private boolean refreshRunning = false;
    private int refreshImported = 0;
    private volatile int refreshProgress = 0;   // 供进度文字实时显示
    private volatile boolean refreshCancel = false;
    private final StringBuilder refreshSkip = new StringBuilder();
    private boolean pendingRefreshSummary = false;
    private boolean lastScanTrashDead = false;   // 本次体检是不是"丢回收站"模式

    /** 设置页「翻新节点」：拉最新节点 → 导入缺的 → 体检 → 总结。 */
    private static final String PREF_FIRST_REFRESH = "first_refresh_done";

    /** 首次打开（没有任何节点）时，强制引导用户先翻新节点。 */
    private void maybeForceFirstRefresh() {
        try {
            android.content.SharedPreferences sp = getSharedPreferences("qv", MODE_PRIVATE);
            if (sp.getBoolean(PREF_FIRST_REFRESH, false)) return;
            int total = NodeStore.totalCount(this);
            if (total > 0) {
                sp.edit().putBoolean(PREF_FIRST_REFRESH, true).apply();
                return;
            }
            ui.postDelayed(new Runnable() {
                @Override
                public void run() {
                    if (uiDead()) return;
                    new AlertDialog.Builder(MainActivity.this)
                            .setTitle("程序里还没有节点")
                            .setMessage("两种办法：\n\n"
                                    + "① 设置 → 翻新节点：顺手把「自动翻新」打开（默认凌晨 3 点），"
                                    + "以后每天到点自动更新，你不用管；\n"
                                    + "　 不打开的话要定期手动翻新，因为节点会过期。\n\n"
                                    + "② 节点源 → 选一个源 → 连接云节点：那里的节点随时能直接用。")
                            .setCancelable(false)
                            .setPositiveButton("去设置翻新", new android.content.DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(android.content.DialogInterface d, int w) {
                                    getSharedPreferences("qv", MODE_PRIVATE).edit()
                                            .putBoolean(PREF_FIRST_REFRESH, true).apply();
                                    showTab(1);
                                    try {
                                        View sv = findViewById(R.id.viewSettings);
                                        if (sv instanceof android.widget.ScrollView) {
                                            final android.widget.ScrollView sc = (android.widget.ScrollView) sv;
                                            sc.post(new Runnable() {
                                                @Override
                                                public void run() {
                                                    sc.fullScroll(View.FOCUS_DOWN);
                                                }
                                            });
                                        }
                                    } catch (Throwable ignored) {
                                    }
                                    toast("已滚到「翻新节点」，点它开始；也可以打开上面的「自动翻新」");
                                }
                            })
                            .setNeutralButton("去节点源", new android.content.DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(android.content.DialogInterface d, int w) {
                                    getSharedPreferences("qv", MODE_PRIVATE).edit()
                                            .putBoolean(PREF_FIRST_REFRESH, true).apply();
                                    showTab(2);
                                }
                            })
                            .setNegativeButton("稍后", new android.content.DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(android.content.DialogInterface d, int w) {
                                    getSharedPreferences("qv", MODE_PRIVATE).edit()
                                            .putBoolean(PREF_FIRST_REFRESH, true).apply();
                                }
                            })
                            .show();
                }
            }, 600);
        } catch (Throwable ignored) {
        }
    }

    private static final String PREF_TIKTOK_HIDDEN = "tiktok_tip_hidden";
    private static final String TIKTOK_VIDEO_URL =
            "https://www.tiktok.com/@tkmaolaoshi555/video/7697531183562886431"
            + "?is_from_webapp=1&sender_device=mobile&sender_web_id=7699131086446708237";
    private static final String SHIZUKU_URL = "https://github.com/RikkaApps/Shizuku";
    private static final String NRFR_URL = "https://github.com/lmh-codes/Nrfr/releases";
    private boolean tiktokTipSessionClosed = false;
    private AlertDialog tiktokDialog;

    /** 设置页的 TikTok 提示卡片：可点开教程、可关闭（仅本次 / 永久）。 */
    private void bindTiktokTip() {
        try {
            View card = findViewById(R.id.cardTiktokTip);
            View close = findViewById(R.id.btnTiktokTipClose);
            if (card == null) return;
            boolean hidden = getSharedPreferences("qv", MODE_PRIVATE)
                    .getBoolean(PREF_TIKTOK_HIDDEN, false) || tiktokTipSessionClosed;
            card.setVisibility(hidden ? View.GONE : View.VISIBLE);
            card.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    showTiktokGuide();
                }
            });
            if (close != null) {
                close.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        askCloseTiktokTip();
                    }
                });
            }
        } catch (Throwable t) {
            Log2.w("TikTok 提示卡片初始化失败：" + t);
        }
    }

    private void askCloseTiktokTip() {
        // 用列表而不是三个按钮：系统按钮的排列顺序固定（否定/中立/肯定），
        // 没法保证显示成"是、是、否"，列表从上到下就一定是这个顺序
        final String[] items = {
                "是（始终关闭，永远不再出现）",
                "是（仅本次关闭）",
                "否",
        };
        new AlertDialog.Builder(this)
                .setTitle("关闭这个提示？")
                .setItems(items, new android.content.DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(android.content.DialogInterface d, int which) {
                        if (which == 0) {
                            getSharedPreferences("qv", MODE_PRIVATE).edit()
                                    .putBoolean(PREF_TIKTOK_HIDDEN, true).apply();
                            hideTiktokCard();
                            toast("已永久关闭该提示");
                        } else if (which == 1) {
                            tiktokTipSessionClosed = true;
                            hideTiktokCard();
                            toast("本次已隐藏，下次打开软件会再次出现");
                        }
                    }
                })
                .show();
    }

    private void hideTiktokCard() {
        try {
            View card = findViewById(R.id.cardTiktokTip);
            if (card != null) card.setVisibility(View.GONE);
        } catch (Throwable ignored) {
        }
    }

    /** 教程弹窗：结构化排版（分隔线用真正的横线，保证刚好一行）+ 4 个按钮。 */
    private void showTiktokGuide() {
        if (uiDead()) return;
        float dp = getResources().getDisplayMetrics().density;
        int pad = (int) (dp * 16);

        android.widget.LinearLayout box = new android.widget.LinearLayout(this);
        box.setOrientation(android.widget.LinearLayout.VERTICAL);
        box.setPadding(pad, pad, pad, pad);

        android.widget.ScrollView sv = new android.widget.ScrollView(this);
        android.widget.LinearLayout content = new android.widget.LinearLayout(this);
        content.setOrientation(android.widget.LinearLayout.VERTICAL);
        sv.addView(content);
        box.addView(sv, new android.widget.LinearLayout.LayoutParams(
                android.widget.LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f));

        addGuideText(content, "开了 VPN 还是无法正常观看 APP 版 TikTok 的原因是：", 13f, false, 0xFFF0F3F8);
        addGuideText(content, "TikTok 识别到的是你的中国大陆电话卡，所以开 VPN 也没用。", 13f, false, 0xFFF0F3F8);
        addGuideDivider(content);
        addGuideText(content, "TikTok 检测到中国电话卡的解决办法", 15f, true, 0xFF5FD08A);
        addGuideDivider(content);

        addGuideText(content, "【教程视频】", 13f, true, 0xFFF0F3F8);
        addGuideText(content, TIKTOK_VIDEO_URL, 12f, false, 0xFF8FC7FF);
        addGuideText(content, "⚠️ 注意：此视频链接需要开启 VPN 才能查看。", 12.5f, false, 0xFFE0B44A);
        addGuideDivider(content);

        addGuideText(content, "【所需软件官网链接】", 13f, true, 0xFFF0F3F8);
        addGuideText(content, "1. Shizuku（权限管理工具）\n官网 / GitHub 项目主页：", 12.5f, false, 0xFFF0F3F8);
        addGuideText(content, SHIZUKU_URL, 12f, false, 0xFF8FC7FF);
        addGuideText(content, "2. Nrfr（免 Root 修改 SIM 卡运营商/国家码工具）\n官网 / GitHub Releases 页面：", 12.5f, false, 0xFFF0F3F8);
        addGuideText(content, NRFR_URL, 12f, false, 0xFF8FC7FF);
        addGuideDivider(content);

        addGuideText(content, "【如何在 GitHub 下载 APK 安装包】", 13f, true, 0xFFF0F3F8);
        addGuideText(content, "① 打开上述 GitHub 链接。\n"
                + "② 在页面右侧（手机端在页面下方或折叠菜单中）找到 “Releases”（发布版本）。\n"
                + "③ 点击进入最新版本（通常带有 Latest 标签，如 v13.6.0）。\n"
                + "④ 往下滑动找到 “Assets”（附件资源）展开列表。\n"
                + "⑤ 点击以 “.apk” 结尾的文件链接（例如 shizuku-v13.6.0.r1086.2650830c-release.apk "
                + "或 Nrfr-v1.5.7.apk），即可直接下载。", 12.5f, false, 0xFFF0F3F8);
        addGuideDivider(content);

        final AlertDialog dlg = new AlertDialog.Builder(this)
                .setTitle("TikTok 无法使用？")
                .setView(box)
                .create();
        tiktokDialog = dlg;

        String[][] btns = {
                {"复制视频教程链接", "copy"},
                {"打开 Shizuku 官网", "shizuku"},
                {"打开 Nrfr 下载页", "nrfr"},
                {"关闭", "close"},
        };
        int h = (int) (dp * 44);
        for (final String[] b : btns) {
            Button btn = new Button(this);
            btn.setText(b[0]);
            btn.setAllCaps(false);
            btn.setTextSize(14f);
            btn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if ("copy".equals(b[1])) {
                        copy(TIKTOK_VIDEO_URL);
                        toast("视频链接已复制，请用浏览器打开此链接（需开 VPN）");
                    } else if ("shizuku".equals(b[1])) {
                        openUrl(SHIZUKU_URL);
                    } else if ("nrfr".equals(b[1])) {
                        openUrl(NRFR_URL);
                    } else {
                        try {
                            dlg.dismiss();
                        } catch (Throwable ignored) {
                        }
                    }
                }
            });
            box.addView(btn, new android.widget.LinearLayout.LayoutParams(
                    android.widget.LinearLayout.LayoutParams.MATCH_PARENT, h));
        }
        dlg.show();
    }

    private void addGuideText(android.widget.LinearLayout parent, String text, float size,
                              boolean bold, int color) {
        TextView tv = new TextView(this);
        tv.setText(text);
        tv.setTextSize(size);
        tv.setTextColor(color);
        tv.setTextIsSelectable(true);
        if (bold) tv.setTypeface(null, android.graphics.Typeface.BOLD);
        float dp = getResources().getDisplayMetrics().density;
        tv.setPadding(0, (int) (dp * 4), 0, (int) (dp * 4));
        parent.addView(tv, new android.widget.LinearLayout.LayoutParams(
                android.widget.LinearLayout.LayoutParams.MATCH_PARENT,
                android.widget.LinearLayout.LayoutParams.WRAP_CONTENT));
    }

    /** 真正的分隔线：一整行、粗细固定，不会因为字体宽度折行。 */
    private void addGuideDivider(android.widget.LinearLayout parent) {
        View v = new View(this);
        v.setBackgroundColor(0x33FFFFFF);
        float dp = getResources().getDisplayMetrics().density;
        android.widget.LinearLayout.LayoutParams lp = new android.widget.LinearLayout.LayoutParams(
                android.widget.LinearLayout.LayoutParams.MATCH_PARENT, Math.max(1, (int) dp));
        lp.topMargin = (int) (dp * 8);
        lp.bottomMargin = (int) (dp * 8);
        parent.addView(v, lp);
    }

    private static final String PREF_BG_GUIDED = "bg_permission_guided";

    /** 自动翻新 / 开机自启 / 时间点 的绑定与权限引导。 */
    private void bindAutoRefreshSettings() {
        styleSwitchTints();
        final android.widget.Switch swAuto = (android.widget.Switch) findViewById(R.id.swAutoRefresh);
        final android.widget.Switch swBoot = (android.widget.Switch) findViewById(R.id.swAutoBoot);
        final android.widget.Switch swLimitAuto = (android.widget.Switch) findViewById(R.id.swLimitAuto);
        if (swLimitAuto != null) {
            swLimitAuto.setChecked(AutoRefresh.limitAutoEnabled(this));
            swLimitAuto.setOnCheckedChangeListener(new android.widget.CompoundButton.OnCheckedChangeListener() {
                @Override
                public void onCheckedChanged(android.widget.CompoundButton b, boolean checked) {
                    AutoRefresh.setLimitAutoEnabled(MainActivity.this, checked);
                    toast(checked ? "自动翻新最多导入 3000 个节点" : "自动翻新不限数量（更耗电）");
                }
            });
        }
        final android.widget.Switch swLimitManual = (android.widget.Switch) findViewById(R.id.swLimitManual);
        if (swLimitManual != null) {
            swLimitManual.setChecked(AutoRefresh.limitManualEnabled(this));
            swLimitManual.setOnCheckedChangeListener(new android.widget.CompoundButton.OnCheckedChangeListener() {
                @Override
                public void onCheckedChanged(android.widget.CompoundButton b, boolean checked) {
                    AutoRefresh.setLimitManualEnabled(MainActivity.this, checked);
                    toast(checked ? "手动翻新最多导入 3000 个节点"
                            : "手动翻新不限数量：来源多时体检会比较漫长");
                }
            });
        }
        final android.widget.Switch swNotify = (android.widget.Switch) findViewById(R.id.swAutoNotify);
        if (swNotify != null) {
            swNotify.setChecked(AutoRefresh.notifyEnabled(this));
            swNotify.setOnCheckedChangeListener(new android.widget.CompoundButton.OnCheckedChangeListener() {
                @Override
                public void onCheckedChanged(android.widget.CompoundButton b, boolean checked) {
                    AutoRefresh.setNotifyEnabled(MainActivity.this, checked);
                    toast(checked ? "自动翻新完成后会发消息提醒" : "已关闭完成提醒");
                }
            });
        }
        final android.widget.Switch swScan = (android.widget.Switch) findViewById(R.id.swAutoScan);
        if (swScan != null) {
            swScan.setChecked(AutoRefresh.scanEnabled(this));
            swScan.setOnCheckedChangeListener(new android.widget.CompoundButton.OnCheckedChangeListener() {
                @Override
                public void onCheckedChanged(final android.widget.CompoundButton b, boolean checked) {
                    if (!checked) {
                        askSkipScanWarn("自动翻新后不体检了？",
                                "不体检的话，自动翻新只会把节点导进来，不做可用性检测。\n\n"
                                        + "结果是：列表里会混进大量连不上的节点，"
                                        + "连接某些国家时可能出现报错/连不上，"
                                        + "而且点连接时会更慢——内核会先把这些连不上的节点逐个试一遍，才轮到能用的那个。\n\n"
                                        + "之后可以在列表模式顶部点「体检」补做一次。",
                                new Runnable() {
                                    @Override
                                    public void run() {
                                        AutoRefresh.setScanEnabled(MainActivity.this, false);
                                        toast("自动翻新只导入、不体检");
                                    }
                                }, new Runnable() {
                                    @Override
                                    public void run() {
                                        b.setChecked(true);
                                    }
                                });
                        return;
                    }
                    AutoRefresh.setScanEnabled(MainActivity.this, true);
                    toast("自动翻新后会顺带体检");
                }
            });
        }
        final android.widget.Switch swScanHidden =
                (android.widget.Switch) findViewById(R.id.swScanHidden);
        TextView scanHiddenHint = (TextView) findViewById(R.id.tvScanHiddenHint);
        if (scanHiddenHint != null) scanHiddenHint.setTextColor(Palette.textFaint(this));
        if (swScanHidden != null) {
            swScanHidden.setTextColor(Palette.text(this));
            swScanHidden.setChecked(getSharedPreferences("qv", MODE_PRIVATE)
                    .getBoolean("scan_hidden_too", true));
            swScanHidden.setOnCheckedChangeListener(
                    new android.widget.CompoundButton.OnCheckedChangeListener() {
                        @Override
                        public void onCheckedChanged(android.widget.CompoundButton b, boolean on) {
                            getSharedPreferences("qv", MODE_PRIVATE).edit()
                                    .putBoolean("scan_hidden_too", on).apply();
                            toast(on ? "体检会一起测已隐藏的节点" : "体检只测当前显示的节点");
                        }
                    });
        }
        final android.widget.Switch swFastScan =
                (android.widget.Switch) findViewById(R.id.swFastScan);
        TextView fastScanHint = (TextView) findViewById(R.id.tvFastScanHint);
        if (fastScanHint != null) fastScanHint.setTextColor(Palette.textFaint(this));
        if (swFastScan != null) {
            swFastScan.setTextColor(Palette.text(this));
            swFastScan.setChecked(getSharedPreferences("qv", MODE_PRIVATE)
                    .getBoolean("fast_scan", false));
            swFastScan.setOnCheckedChangeListener(
                    new android.widget.CompoundButton.OnCheckedChangeListener() {
                        @Override
                        public void onCheckedChanged(android.widget.CompoundButton b, boolean on) {
                            getSharedPreferences("qv", MODE_PRIVATE).edit()
                                    .putBoolean("fast_scan", on).apply();
                            toast(on ? "已开启快速体检（下次体检生效）" : "已恢复默认体检速度");
                        }
                    });
        }
        final android.widget.Switch swCloudLimit = (android.widget.Switch) findViewById(R.id.swCloudLimit);
        TextView cloudHint = (TextView) findViewById(R.id.tvCloudLimitHint);
        if (cloudHint != null) cloudHint.setTextColor(Palette.textFaint(this));
        if (swCloudLimit != null) {
            swCloudLimit.setChecked(CloudTester.limit300(this));
            swCloudLimit.setOnCheckedChangeListener(new android.widget.CompoundButton.OnCheckedChangeListener() {
                @Override
                public void onCheckedChanged(final android.widget.CompoundButton b, boolean checked) {
                    if (checked) {
                        CloudTester.setLimit300(MainActivity.this, true);
                        toast("连接云节点只测前 300 个");
                        return;
                    }
                    if (getSharedPreferences("qv", MODE_PRIVATE).getBoolean("skip_cloud_limit_warn", false)) {
                        CloudTester.setLimit300(MainActivity.this, false);
                        toast("已关闭上限：连接云节点会测全部节点");
                        return;
                    }
                    float dp = getResources().getDisplayMetrics().density;
                    int pad = (int) (dp * 18);
                    final android.widget.LinearLayout box = new android.widget.LinearLayout(MainActivity.this);
                    box.setOrientation(android.widget.LinearLayout.VERTICAL);
                    box.setPadding(pad, (int) (dp * 8), pad, pad);
                    TextView tv = new TextView(MainActivity.this);
                    tv.setText("关掉后，连接云节点会把源里的节点全部测一遍。\n\n"
                            + "· 源里节点多的时候可能要等好几分钟\n"
                            + "· 建议只在源比较小的时候关掉");
                    tv.setTextSize(13.5f);
                    tv.setTextColor(0xFFF0F3F8);
                    tv.setTextIsSelectable(true);
                    box.addView(tv);
                    final android.widget.CheckBox cb = new android.widget.CheckBox(MainActivity.this);
                    cb.setText("不再提示");
                    cb.setTextColor(0xFFF0F3F8);
                    cb.setTextSize(13f);
                    cb.setPadding(0, (int) (dp * 12), 0, 0);
                    box.addView(cb);
                    final AlertDialog dlg = new AlertDialog.Builder(MainActivity.this)
                            .setTitle("关闭测试上限？")
                            .setView(box)
                            .setPositiveButton("仍然关闭", new android.content.DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(android.content.DialogInterface d, int w) {
                                    if (cb.isChecked()) {
                                        getSharedPreferences("qv", MODE_PRIVATE).edit()
                                                .putBoolean("skip_cloud_limit_warn", true).apply();
                                    }
                                    CloudTester.setLimit300(MainActivity.this, false);
                                    toast("已关闭上限：连接云节点会测全部节点");
                                }
                            })
                            .setNegativeButton("保持开启", new android.content.DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(android.content.DialogInterface d, int w) {
                                    b.setChecked(true);
                                }
                            })
                            .create();
                    dlg.show();
                }
            });
        }
        final android.widget.Switch swLogKernel = (android.widget.Switch) findViewById(R.id.swLogKernel);
        if (swLogKernel != null) {
            swLogKernel.setChecked(Log2.kernelEnabled(this));
            swLogKernel.setOnCheckedChangeListener(new android.widget.CompoundButton.OnCheckedChangeListener() {
                @Override
                public void onCheckedChanged(final android.widget.CompoundButton b, boolean checked) {
                    if (!checked) {
                        Log2.setKernelEnabled(MainActivity.this, false);
                        Log2.i("已关闭内核详细日志");
                        toast("已关闭：只记录内核的关键事件");
                        return;
                    }
                    // 打开前先询问，并写清后果与"什么情况会刷屏"
                    new AlertDialog.Builder(MainActivity.this)
                            .setTitle("开启内核详细日志？")
                            .setMessage("开启后，内核会把每一个连接、每一次 DNS 查询、每一条分流规则的命中都写进日志。\n\n"
                                    + "⚠ 会明显刷屏的情况：\n"
                                    + "· 刷视频 / 下载大文件（每个连接都写几行）\n"
                                    + "· 体检 3000 个节点（每次都写）\n"
                                    + "· 翻新导入大量节点后立刻体检\n"
                                    + "· 手机后台应用频繁联网（微信、推送、系统同步）\n\n"
                                    + "⚠ 副作用：\n"
                                    + "· 日志文件会快速变大（每天可能几 MB，只保留最近 2 份）\n"
                                    + "· 真正有用的 App 日志会被淹没，排查变慢\n\n"
                                    + "建议只在排查连不上 / 能连但没网时临时开启。")
                            .setPositiveButton("开启", new android.content.DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(android.content.DialogInterface d, int w) {
                                    Log2.setKernelEnabled(MainActivity.this, true);
                                    Log2.i("已开启内核详细日志");
                                    toast("已开启：日志会变多，排查完记得关掉");
                                }
                            })
                            .setNegativeButton("取消", new android.content.DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(android.content.DialogInterface d, int w) {
                                    suppressToggle = true;
                                    b.setChecked(false);
                                    suppressToggle = false;
                                }
                            })
                            .show();
                }
            });
        }
        Button btnGeo = (Button) findViewById(R.id.btnGeoClassify);
        if (btnGeo != null) {
            btnGeo.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (!tapAllowed()) return;
                    startGeoClassify();
                }
            });
        }
        Button btnGeoReall = (Button) findViewById(R.id.btnGeoReall);
        if (btnGeoReall != null) {
            btnGeoReall.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (!tapAllowed()) return;
                    startGeoClassify(true);
                }
            });
        }
        TextView geoReallHint = (TextView) findViewById(R.id.tvGeoReallHint);
        if (geoReallHint != null) geoReallHint.setTextColor(Palette.textFaint(this));
        TextView geoHint = (TextView) findViewById(R.id.tvGeoHint);
        if (geoHint != null) geoHint.setTextColor(Palette.textFaint(this));
        Button btnClearCache = (Button) findViewById(R.id.btnClearCache);
        if (btnClearCache != null) {
            btnClearCache.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (!tapAllowed()) return;
                    startClearCacheFlow();
                }
            });
        }
        updateCacheHint();
        Button btnClearLog = (Button) findViewById(R.id.btnClearLog);
        if (btnClearLog != null) {
            btnClearLog.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (!tapAllowed()) return;
                    startClearLogFlow();
                }
            });
        }
        TextView scanHint = (TextView) findViewById(R.id.tvAutoScanHint);
        if (scanHint != null) scanHint.setTextColor(Palette.textFaint(this));
        final Button btnHours = (Button) findViewById(R.id.btnAutoHours);
        TextView hint = (TextView) findViewById(R.id.tvAutoHint);
        if (hint != null) hint.setTextColor(Palette.textFaint(this));

        swAuto.setChecked(AutoRefresh.enabled(this));
        swBoot.setChecked(AutoRefresh.bootEnabled(this));
        updateHoursButton(btnHours);

        swAuto.setOnCheckedChangeListener(new android.widget.CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(android.widget.CompoundButton b, boolean checked) {
                AutoRefresh.setEnabled(MainActivity.this, checked);
                if (checked) {
                    startAutoRefreshGuide();
                } else {
                    cancelGuide();
                    toast("已关闭自动翻新");
                }
            }
        });
        btnHours.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!tapAllowed()) return;
                showHoursPicker();
            }
        });
        swBoot.setOnCheckedChangeListener(new android.widget.CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(android.widget.CompoundButton b, boolean checked) {
                AutoRefresh.setBootEnabled(MainActivity.this, checked);
                if (checked) showBootGuide();
                else toast("已关闭开机自启");
            }
        });
    }

    private static final int REQ_DELETE_LOGS = 3401;

    private AlertDialog geoDialog;
    private TextView geoText;

    private static final String SKIP_SCAN_WARN = "skip_scan_off_warn";

    /** "不体检"的后果提醒；带「不再提示」复选框。onConfirm = 用户确认不体检后要做的动作。 */
    private void askSkipScanWarn(String title, String msg, final Runnable onConfirm,
                                 final Runnable onKeep) {
        if (uiDead()) {
            onConfirm.run();
            return;
        }
        if (getSharedPreferences("qv", MODE_PRIVATE).getBoolean(SKIP_SCAN_WARN, false)) {
            onConfirm.run();      // 已经勾过"不再提示"，直接执行
            return;
        }
        float dp = getResources().getDisplayMetrics().density;
        int pad = (int) (dp * 18);
        final android.widget.LinearLayout box = new android.widget.LinearLayout(this);
        box.setOrientation(android.widget.LinearLayout.VERTICAL);
        box.setPadding(pad, (int) (dp * 8), pad, pad);
        TextView tv = new TextView(this);
        tv.setText(msg);
        tv.setTextSize(13.5f);
        tv.setTextColor(0xFFF0F3F8);
        tv.setTextIsSelectable(true);
        box.addView(tv);
        final android.widget.CheckBox cb = new android.widget.CheckBox(this);
        cb.setText("不再提示（以后取消体检时不再询问）");
        cb.setTextColor(0xFFF0F3F8);
        cb.setTextSize(13f);
        cb.setPadding(0, (int) (dp * 12), 0, 0);
        box.addView(cb);

        new AlertDialog.Builder(this)
                .setTitle(title)
                .setView(box)
                .setPositiveButton("仍然不体检", new android.content.DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(android.content.DialogInterface d, int w) {
                        if (cb.isChecked()) {
                            getSharedPreferences("qv", MODE_PRIVATE).edit()
                                    .putBoolean(SKIP_SCAN_WARN, true).apply();
                            Log2.i("用户勾选：以后取消体检不再提示");
                        }
                        onConfirm.run();
                    }
                })
                .setNegativeButton("保持勾选", new android.content.DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(android.content.DialogInterface d, int w) {
                        if (onKeep != null) onKeep.run();
                    }
                })
                .show();
    }

    private android.widget.SeekBar refreshBarRef;
    private android.widget.TextView refreshTitleRef;
    private android.widget.CheckBox refreshScanRef;

    /** 重算标题里的预计耗时（来源数或"是否体检"变化时调用）。 */
    private void syncRefreshEta() {
        try {
            if (refreshBarRef == null || refreshTitleRef == null || refreshScanRef == null) return;
            int k = refreshBarRef.getProgress() + 1;
            refreshTitleRef.setText("将搜寻 " + k + " 个节点来源 · 预计约 "
                    + refreshEtaText(k, refreshScanRef.isChecked()));
        } catch (Throwable ignored) {
        }
    }

    /** 翻新预计耗时：每个源约 6 秒；勾了体检再按现有节点数加上体检时间。 */
    private String refreshEtaText(int sources, boolean withScan) {
        // 下载 + 解析 + 导入：一个源大约 2 秒（不是 6 秒）
        int sec = sources * 2;
        if (withScan) {
            // 体检按"现有节点 + 预计新增（每源约 400）"估；不再设 600 的下限，
            // 否则"1 个源"和"2 个源"的估算会被下限抹平成同一个数
            int nodes = NodeStore.totalCount(this) + sources * 400;
            sec += (int) Math.max(10, Math.round(nodes / 350.0 * 60));
        }
        if (sec < 60) return sec + " 秒";
        int m = sec / 60, s2 = sec % 60;
        if (s2 == 0) return m + " 分钟";
        return m + " 分 " + s2 + " 秒";
    }

    /* ---------------------------- 节点源 ---------------------------- */

    private int srcSelected = -1;
    private int srcExpanded = -1;             // 展开查看节点的源序号
    private String cloudConnectingSource = null;   // 正在走"连接云节点"时记住源名
    private final java.util.Set<String> cloudTried = new java.util.HashSet<String>();
    private boolean cloudSwitching = false;
    private String cloudSwitchPrevUri = null;
    private String cloudSwitchPrevCc = "ZZ";
    private String cloudSwitchPrevTitle = "";
    private java.util.List<Node> cloudLastPool = new java.util.ArrayList<Node>();
    private String cloudConnectedTitle = null;     // 已连接的云节点标题
    private TextView srcConnTip = null;            // 节点源页顶部的"已连接…"行

    private void showFreezeGuide() {
        boolean colorOs = isColorOsFamily();
        String msg = colorOs
                ? "ColorOS 会周期性把后台 App「冻结」，体检/翻新会停住，点回前台才继续。\n\n"
                  + "按顺序做这几步：\n\n"
                  + "① 设置 → 电池 → 更多设置 → 关闭「睡眠待机优化」\n\n"
                  + "② 设置 → 电池 → 应用耗电管理 → 命令方块 →\n"
                  + "    允许「允许完全后台行为」和「允许后台活动」\n\n"
                  + "③ 设置 → 应用 → 应用管理 → 命令方块 → 耗电管理 →\n"
                  + "    同样打开上面两项（和 ② 是同一设置，两个入口）\n\n"
                  + "④ 从最近任务里，把「命令方块」的卡片向下拉，点「锁定」\n"
                  + "    （有锁图标表示已锁定，系统不会随手动清理）\n\n"
                  + "⑤ 如果还能找到「应用速冻」（部分版本在 设置 → 电池 → 更多设置），\n"
                  + "    把「命令方块」移出速冻名单。\n\n"
                  + "做完第 ①② 步通常就够了。"
                : "系统会在后台冻结 App，体检/翻新会停住，点回前台才继续。\n\n"
                  + "请到系统设置里：\n"
                  + "① 电池/耗电管理 → 命令方块 → 允许后台活动、允许完全后台行为；\n"
                  + "② 应用启动管理 → 命令方块 → 手动管理，允许自启动/关联启动/后台活动；\n"
                  + "③ 最近任务里把「命令方块」卡片锁定。\n\n"
                  + "不同品牌名字不同（如「应用速冻」「后台冻结」「休眠应用」），"
                  + "找不到时用系统设置里的搜索框搜「速冻 / 后台 / 耗电」。";
        new AlertDialog.Builder(this)
                .setTitle("让后台不被系统休眠")
                .setMessage(msg)
                .setPositiveButton("去电池设置", new android.content.DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(android.content.DialogInterface d, int w) {
                        try {
                            VendorSettings.openBattery(MainActivity.this);
                        } catch (Throwable t) {
                            toast("打不开设置，请手动按上面的路径操作");
                        }
                    }
                })
                .setNegativeButton("知道了", null)
                .show();
    }

    private void bindSourcePage() {
        try {
            TextView t = (TextView) findViewById(R.id.srcTitle);
            if (t != null) t.setTextColor(Palette.text(this));
            TextView h = (TextView) findViewById(R.id.srcHint);
            if (h != null) h.setTextColor(Palette.textFaint(this));
            TextView e = (TextView) findViewById(R.id.srcEmpty);
            if (e != null) e.setTextColor(Palette.textDim(this));
            Button imp = (Button) findViewById(R.id.btnSrcImport);
            if (imp != null) imp.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (!tapAllowed()) return;
                    askImportSource();
                }
            });
            Button rst = (Button) findViewById(R.id.btnSrcReset);
            if (rst != null) rst.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (!tapAllowed()) return;
                    confirmResetSources();
                }
            });
            Button sw = (Button) findViewById(R.id.btnSrcSwitch);
            if (sw != null) sw.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (!tapAllowed()) return;
                    switchCloudNode();
                }
            });
            Button conn = (Button) findViewById(R.id.btnSrcConnect);
            if (conn != null) conn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (!tapAllowed()) return;
                    if ((TunnelService.isRunning() || TunnelService.isConnecting())
                            && TunnelService.cloudSource() != null) {
                        cancelCloudRetryChain();
                        TunnelService.disconnect(MainActivity.this, "用户在节点源页断开云节点");
                        toast("已断开云节点连接");
                        ui.postDelayed(new Runnable() {
                            @Override
                            public void run() {
                                if (!uiDead()) renderSources();
                            }
                        }, 800);
                        return;
                    }
                    connectSelectedSource();
                }
            });
            renderSources();
        } catch (Throwable t) {
            Log2.w("节点源页初始化失败：" + t);
        }
    }

    private void renderSources() {
        try {
            android.widget.LinearLayout box = (android.widget.LinearLayout) findViewById(R.id.srcList);
            TextView title = (TextView) findViewById(R.id.srcTitle);
            TextView empty = (TextView) findViewById(R.id.srcEmpty);
            TextView connTip = (TextView) findViewById(R.id.srcConnected);
            srcConnTip = connTip;
            Button conn = (Button) findViewById(R.id.btnSrcConnect);
            if (box == null) return;
            java.util.List<String[]> list = SourceStore.list(this);
            if (title != null) title.setText("节点源（" + list.size() + "/" + SourceStore.MAX + "）");

            // 顶部：已连接的云节点
            Button swBtn = (Button) findViewById(R.id.btnSrcSwitch);
            if (swBtn != null) {
                boolean canSwitch = TunnelService.isRunning() && TunnelService.cloudSource() != null;
                swBtn.setEnabled(canSwitch);
            }
            String cloudSrc = TunnelService.cloudSource();
            Node curNode = TunnelService.currentNode();
            String curTitle = cloudConnectedTitle != null ? cloudConnectedTitle
                    : (curNode == null ? null : curNode.title);
            boolean runningNow = TunnelService.isRunning()
                    && TunnelService.connectedSince() > 0;
            // 只有"这次连接确实是云节点"（Activity 记住了源名）才显示云节点文案，
            // 普通节点连接时不能在这里冒充云节点
            boolean connectingNow = TunnelService.isConnecting() && !runningNow;
            boolean cloudConnecting = connectingNow && cloudConnectingSource != null;
            if (cloudConnecting && connTip != null) {
                connTip.setVisibility(View.VISIBLE);
                String name = cloudConnectingSource != null ? cloudConnectingSource
                        : (cloudSrc == null ? "" : cloudSrc);
                connTip.setText(name.length() > 0
                        ? ("正在连接 " + name + " 节点源…（正在挑可用节点）")
                        : "正在连接云节点…（正在挑可用节点）");
                connTip.setTextColor(0xFFE0A33C);
            } else if (connectingNow && connTip != null) {
                connTip.setVisibility(View.VISIBLE);
                connTip.setText("正在连接 VPN…（正在挑选可用节点）");
                connTip.setTextColor(0xFFE0A33C);
            } else if (runningNow && cloudSrc != null && curTitle != null && connTip != null) {
                connTip.setVisibility(View.VISIBLE);
                long since = TunnelService.connectedSince();
                long sec = since > 0 ? Math.max(0, (System.currentTimeMillis() - since) / 1000) : 0;
                String dur = String.format(java.util.Locale.US, "%02d:%02d:%02d",
                        sec / 3600, (sec / 60) % 60, sec % 60);
                int d = TunnelService.connectedDelay();
                connTip.setText("已连接 " + curTitle + " 节点 · " + dur
                        + (d > 0 ? " · 代理延迟 " + d + " ms" : ""));
                connTip.setTextColor(0xFF5FD08A);
            } else if (connTip != null && !cloudConnecting) {
                connTip.setVisibility(View.GONE);
            }

            box.removeAllViews();
            if (list.isEmpty()) {
                if (empty != null) empty.setVisibility(View.VISIBLE);
                if (conn != null) conn.setEnabled(false);
                return;
            }
            if (empty != null) empty.setVisibility(View.GONE);
            if (srcSelected >= list.size()) srcSelected = -1;
            if (srcExpanded >= list.size()) srcExpanded = -1;
            float dp = getResources().getDisplayMetrics().density;
            for (int i = 0; i < list.size(); i++) {
                final int idx = i;
                final String[] src = list.get(i);
                final boolean isCloudSrc = cloudSrc != null && cloudSrc.equals(src[0]);
                TextView row = new TextView(this);
                String url = src[1];
                if (url.length() > 40) url = url.substring(0, 38) + "…";
                String prefix = isCloudSrc ? "● " : (srcSelected == i ? "▶ " : "");
                row.setText(prefix + (i + 1) + ". " + src[0]
                        + "\n★优先级 " + (i + 1) + "　" + url
                        + (srcExpanded == i ? "\n（再点一下收起节点列表）" : ""));
                row.setTextSize(13.5f);
                row.setTextColor(isCloudSrc ? Palette.green(this) : Palette.text(this));
                row.setPadding((int) (dp * 12), (int) (dp * 10), (int) (dp * 12), (int) (dp * 10));
                row.setBackgroundColor(srcSelected == i ? Palette.rowSel(this) : Palette.rowBg(this));
                android.widget.LinearLayout.LayoutParams lp = new android.widget.LinearLayout.LayoutParams(
                        android.widget.LinearLayout.LayoutParams.MATCH_PARENT,
                        android.widget.LinearLayout.LayoutParams.WRAP_CONTENT);
                lp.bottomMargin = (int) (dp * 8);
                row.setLayoutParams(lp);
                row.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if (srcSelected == idx) {
                            srcExpanded = (srcExpanded == idx) ? -1 : idx;   // 再点收起/展开
                        } else {
                            srcSelected = idx;
                            srcExpanded = -1;
                        }
                        renderSources();
                    }
                });
                row.setOnLongClickListener(new View.OnLongClickListener() {
                    @Override
                    public boolean onLongClick(View v) {
                        ui.postDelayed(new Runnable() {
                            @Override
                            public void run() {
                                showSourceMenu(idx);
                            }
                        }, 160);
                        return true;
                    }
                });
                box.addView(row);
                if (srcExpanded == i) addNodeListRows(box, src[1], dp);
            }
            if (conn != null) {
                boolean busy = TunnelService.isRunning() || TunnelService.isConnecting();
                if (busy && TunnelService.cloudSource() != null) {
                    conn.setText("断开连接云节点");
                    conn.setEnabled(true);
                } else {
                    conn.setText("连接云节点");
                    conn.setEnabled(true);      // 保持可点：没选就让用户看到提示，而不是没反应
                }
            }
        } catch (Throwable t) {
            Log2.w("渲染节点源失败：" + t);
        }
    }

    /** 展开某个源时，列出它的节点与状态（未实测黄 / 不可用红 / 延迟绿或黄）。 */
    private void addNodeListRows(android.widget.LinearLayout parent, String url, float dp) {
        java.util.List<String[]> nodes = CloudTester.loadNodes(this, url);
        if (nodes.isEmpty()) {
            TextView t = new TextView(this);
            t.setText("还没有测过这个源。点下面的「连接云节点」测一次，之后就能在这里看到每个节点的状态。");
            t.setTextSize(12f);
            t.setTextColor(Palette.textFaint(this));
            t.setPadding((int) (dp * 20), (int) (dp * 6), (int) (dp * 12), (int) (dp * 10));
            parent.addView(t);
            return;
        }
        Node cur = TunnelService.currentNode();
        // 排序：已连接置顶，然后按延迟升序的可用节点，再未实测，最后不可用
        java.util.Collections.sort(nodes, new java.util.Comparator<String[]>() {
            @Override
            public int compare(String[] a, String[] b) {
                return rank(a) - rank(b) != 0 ? rank(a) - rank(b) : msOf(a) - msOf(b);
            }

            int rank(String[] p) {
                String uri = p[0];
                Node c = TunnelService.currentNode();
                if (c != null && TunnelService.isRunning() && uri.equals(c.uri)) return 0;
                String st = p.length > 3 ? p[3] : "0";
                if ("1".equals(st)) return 1;
                if ("0".equals(st)) return 2;
                return 3;
            }

            int msOf(String[] p) {
                try {
                    return p.length > 4 ? Integer.parseInt(p[4]) : 0;
                } catch (Throwable t) {
                    return 0;
                }
            }
        });
        int limit = Math.min(nodes.size(), 300);
        for (int i = 0; i < limit; i++) {
            String[] p = nodes.get(i);
            if (p.length < 4) continue;
            String uri = p[0];
            String cc = p[1];
            String title = p.length > 2 ? p[2] : uri;
            String state = p[3];
            int ms = 0;
            try {
                ms = p.length > 4 ? Integer.parseInt(p[4]) : 0;
            } catch (Throwable ignored) {
            }
            boolean connected = cur != null && TunnelService.isRunning() && uri.equals(cur.uri);
            String country = Country.displayName(cc);
            if (country == null || country.length() == 0) country = "未识别地区";
            String status;
            int color;
            if (connected) {
                int realD = TunnelService.connectedDelay();
                status = "已连接" + (realD > 0 ? " · " + realD + " ms" : (ms > 0 ? " · " + ms + " ms" : ""));
                color = Palette.green(this);
            } else if ("2".equals(state)) {
                status = "不可用";
                color = 0xFFE05454;
            } else if ("1".equals(state)) {
                status = ms + " ms";
                color = ms <= 400 ? Palette.green(this) : 0xFFE0B44A;
            } else {
                status = "未实测";
                color = 0xFFE0B44A;
            }
            TextView t = new TextView(this);
            t.setText("　" + country + " · " + title + "　" + status);
            t.setTextSize(12f);
            t.setTextColor(color);
            t.setPadding((int) (dp * 16), (int) (dp * 4), (int) (dp * 12), (int) (dp * 4));
            parent.addView(t);
        }
        int totalInSource = CloudTester.totalOf(this, url);
        StringBuilder tail = new StringBuilder();
        if (nodes.size() > limit) {
            tail.append("…还有 ").append(nodes.size() - limit).append(" 个已测节点未显示");
        }
        if (totalInSource > nodes.size()) {
            if (tail.length() > 0) tail.append("；");
            tail.append("源里共 ").append(totalInSource).append(" 个节点，其余 ")
                    .append(totalInSource - nodes.size()).append(" 个还没测");
        }
        if (tail.length() > 0) {
            TextView more = new TextView(this);
            more.setText("　" + tail);
            more.setTextSize(11f);
            more.setTextColor(Palette.textFaint(this));
            more.setPadding((int) (dp * 16), 0, (int) (dp * 12), (int) (dp * 8));
            parent.addView(more);
        }
    }

    private void showSourceMenu(final int index) {
        java.util.List<String[]> list = SourceStore.list(this);
        if (index < 0 || index >= list.size()) return;
        final String name = list.get(index)[0];
        String[] items = {
                "优先级上调一层",
                "优先级下调一层",
                "连接云节点",
                "删除此节点源"
        };
        new AlertDialog.Builder(this)
                .setTitle(name + "\n当前优先级：" + (index + 1))
                .setItems(items, new android.content.DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(android.content.DialogInterface d, int which) {
                        if (which == 0) {
                            if (!SourceStore.moveUp(MainActivity.this, index)) {
                                toast("已经在最前面了");
                            } else {
                                if (srcSelected == index) srcSelected = index - 1;
                                else if (srcSelected == index - 1) srcSelected = index;
                            }
                            renderSources();
                        } else if (which == 1) {
                            if (!SourceStore.moveDown(MainActivity.this, index)) {
                                toast("已经在最后面了");
                            } else {
                                if (srcSelected == index) srcSelected = index + 1;
                                else if (srcSelected == index + 1) srcSelected = index;
                            }
                            renderSources();
                        } else if (which == 2) {
                            srcSelected = index;
                            renderSources();
                            connectSelectedSource();
                        } else {
                            confirmRemoveSource(index);
                        }
                    }
                })
                .show();
    }

    private void confirmRemoveSource(final int index) {
        java.util.List<String[]> list = SourceStore.list(this);
        if (index < 0 || index >= list.size()) return;
        final String name = list.get(index)[0];
        new AlertDialog.Builder(this)
                .setTitle("删除节点源？")
                .setMessage("将删除「" + name + "」。\n\n"
                        + "正在进行的翻新不受影响，下次翻新开始生效。")
                .setPositiveButton("删除", new android.content.DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(android.content.DialogInterface d, int w) {
                        SourceStore.remove(MainActivity.this, index);
                        srcSelected = -1;
                        renderSources();
                        toast("已删除：" + name);
                    }
                })
                .setNegativeButton("取消", null)
                .show();
    }

    private String defaultSourceList() {
        StringBuilder sb = new StringBuilder();
        int i = 1;
        for (String[] src : SourceStore.defaults()) {
            sb.append(i++).append(". ").append(src[0]).append('\n');
        }
        return sb.toString().trim();
    }

    private void confirmResetSources() {
        new AlertDialog.Builder(this)
                .setTitle("恢复默认节点源？")
                .setMessage("当前的顺序、以及你导入的源都会被清掉，"
                        + "恢复成默认的 " + SourceStore.defaults().length + " 个源：\n\n"
                        + defaultSourceList() + "\n\n"
                        + "下次翻新开始生效。")
                .setPositiveButton("重置", new android.content.DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(android.content.DialogInterface d, int w) {
                        SourceStore.reset(MainActivity.this);
                        srcSelected = -1;
                        renderSources();
                        toast("已恢复默认 5 个节点源");
                    }
                })
                .setNegativeButton("取消", null)
                .show();
    }

    private AlertDialog cloudDialog;
    private TextView cloudText;
    /** 云节点：测通的节点按延迟排好，连不上时依次换下一个。 */
    private final java.util.ArrayDeque<Node> cloudRetry = new java.util.ArrayDeque<Node>();
    private boolean cloudRetryActive = false;
    private int cloudRetryTried = 0;          // 云节点最多试 5 个，避免一路试几百个

    /** 连接云节点：下载该源 → 测延迟 → 自动连最快的那个。 */
    private void startCloudConnect(final String name, final String url) {
        if (CloudTester.isRunning()) {
            toast("正在测试中，请稍等…");
            return;
        }
        if (cloudRetryActive) {
            warnDialog("正在逐个尝试云节点",
                    "现在正在一个接一个地试云节点，最多试 5 个。\n\n"
                            + "要么等它连上，要么先在 VPN 页点「断开」再重新来。");
            return;
        }
        if (TunnelService.isRunning() || TunnelService.isConnecting()) {
            new AlertDialog.Builder(this)
                    .setTitle("先断开当前连接")
                    .setMessage("连接云节点前需要先断开现在的 VPN。\n\n"
                            + "点「断开并继续」会先断开，然后开始测试；也可以点取消自己先断开。")
                    .setPositiveButton("断开并继续", new android.content.DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(android.content.DialogInterface d, int w) {
                            TunnelService.disconnect(MainActivity.this, "连接云节点前断开");
                            ui.postDelayed(new Runnable() {
                                @Override
                                public void run() {
                                    if (uiDead()) return;
                                    if (TunnelService.isRunning() || TunnelService.isConnecting()) {
                                        ui.postDelayed(this, 700);
                                        return;
                                    }
                                    startCloudConnect(name, url);
                                }
                            }, 1000);
                        }
                    })
                    .setNegativeButton("取消", null)
                    .show();
            return;
        }
        cloudConnectingSource = name;
        TunnelService.setCloudSource(name);
        TunnelService.cloudNotify(this, "正在连接 " + name + " 节点源");
        float dp = getResources().getDisplayMetrics().density;
        int pad = (int) (dp * 18);
        android.widget.LinearLayout box = new android.widget.LinearLayout(this);
        box.setOrientation(android.widget.LinearLayout.VERTICAL);
        box.setPadding(pad, (int) (dp * 8), pad, pad);
        cloudText = new TextView(this);
        cloudText.setText("正在下载「" + name + "」的节点…");
        cloudText.setTextSize(13.5f);
        cloudText.setTextColor(0xFFF0F3F8);
        cloudText.setTextIsSelectable(true);
        box.addView(cloudText);
        cloudDialog = new AlertDialog.Builder(this)
                .setTitle("连接云节点")
                .setView(box)
                .setCancelable(false)
                .setNegativeButton("取消", new android.content.DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(android.content.DialogInterface d, int w) {
                        CloudTester.stop();
                        cloudConnectingSource = null;
                        // 注意：不要清 TunnelService 的云节点标记。
                        // 如果此刻正连着某个云节点，清掉会让界面把它当成普通节点显示成"已连接 意大利"。
                        TunnelService.cloudNotifyCancel(MainActivity.this);
                    }
                })
                .create();
        cloudDialog.show();

        CloudTester.start(this, name, url, new CloudTester.Listener() {
            @Override
            public void onProgress(final int done, final int total, final int alive) {
                ui.post(new Runnable() {
                    @Override
                    public void run() {
                        if (cloudText != null) {
                            cloudText.setText("正在测试「" + name + "」\n\n"
                                    + "已测 " + done + " / " + total + "\n"
                                    + "可用 " + alive + " 个");
                        }
                    }
                });
            }

            @Override
            public void onDone(final int alive, final int dead, final Node fastest, final int fastestMs) {
                ui.post(new Runnable() {
                    @Override
                    public void run() {
                        if (uiDead() || isFinishing()) {
                            Log2.w("云节点测试完成时界面已销毁，丢弃回调");
                            return;
                        }
                        try {
                            if (cloudDialog != null && cloudDialog.isShowing()) cloudDialog.dismiss();
                        } catch (Throwable ignored) {
                        }
                        cloudDialog = null;
                        cloudText = null;
                        if (fastest == null) {
                            TunnelService.cloudNotifyCancel(MainActivity.this);
                            cloudConnectingSource = null;
                            TunnelService.setCloudSource(null);
                            new AlertDialog.Builder(MainActivity.this)
                                    .setTitle("这个源暂时没有可用节点")
                                    .setMessage("测了 " + (alive + dead) + " 个节点，全部连不上。\n\n"
                                            + "可以稍后再试，或者换一个节点源。")
                                    .setPositiveButton("知道了", null)
                                    .show();
                            return;
                        }
                        // 不在界面上反复"连上-断开"：把测通的节点全部交给内核一次挑通
                        java.util.List<Node> pool = new java.util.ArrayList<Node>();
                        for (Node n : CloudTester.aliveSorted) {
                            pool.add(n);
                            if (pool.size() >= 30) break;
                        }
                        if (pool.isEmpty()) pool.add(fastest);
                        cloudTried.clear();
                        cloudSwitching = false;
                        cloudRetry.clear();
                        cloudRetryActive = false;
                        cloudLastPool = new java.util.ArrayList<Node>(pool);
                        TunnelService.cloudNotify(MainActivity.this,
                                "正在连接 " + name + " 节点源");
                        toast("正在从 " + pool.size() + " 个可用节点里挑一个能用的…");
                        TunnelService.setPoolCandidates(pool);
                        requestVpn(fastest, TunnelService.MODE_POOL, false, true);
                    }
                });
            }

            @Override
            public void onError(final String msg) {
                ui.post(new Runnable() {
                    @Override
                    public void run() {
                        if (uiDead() || isFinishing()) return;
                        try {
                            if (cloudDialog != null && cloudDialog.isShowing()) cloudDialog.dismiss();
                        } catch (Throwable ignored) {
                        }
                        cloudDialog = null;
                        cloudText = null;
                        TunnelService.cloudNotifyCancel(MainActivity.this);
                        cloudConnectingSource = null;
                        TunnelService.setCloudSource(null);
                        new AlertDialog.Builder(MainActivity.this)
                                .setTitle("连接云节点失败")
                                .setMessage(msg)
                                .setPositiveButton("知道了", null)
                                .show();
                    }
                });
            }
        });
    }

    private void askImportSource() {
        if (SourceStore.size(this) >= SourceStore.MAX) {
            new AlertDialog.Builder(this)
                    .setTitle("已达到节点源数量限制（" + SourceStore.MAX + " 个）")
                    .setMessage("请删除节点源后重试。")
                    .setPositiveButton("我知道了", null)
                    .show();
            return;
        }
        float dp = getResources().getDisplayMetrics().density;
        int pad = (int) (dp * 18);
        final android.widget.LinearLayout box = new android.widget.LinearLayout(this);
        box.setOrientation(android.widget.LinearLayout.VERTICAL);
        box.setPadding(pad, (int) (dp * 8), pad, pad);
        final android.widget.EditText et = new android.widget.EditText(this);
        et.setHint("https://…（订阅或节点列表链接）");
        et.setTextSize(14f);
        box.addView(et);
        final android.widget.EditText nameEt = new android.widget.EditText(this);
        nameEt.setHint("名称（可留空）");
        nameEt.setTextSize(14f);
        android.widget.LinearLayout.LayoutParams nlp = new android.widget.LinearLayout.LayoutParams(
                android.widget.LinearLayout.LayoutParams.MATCH_PARENT,
                android.widget.LinearLayout.LayoutParams.WRAP_CONTENT);
        nlp.topMargin = (int) (dp * 8);
        box.addView(nameEt, nlp);
        new AlertDialog.Builder(this)
                .setTitle("导入节点源")
                .setView(box)
                .setPositiveButton("导入", new android.content.DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(android.content.DialogInterface d, int w) {
                        String url = et.getText() == null ? "" : et.getText().toString().trim();
                        String name = nameEt.getText() == null ? "" : nameEt.getText().toString().trim();
                        if (!url.startsWith("http://") && !url.startsWith("https://")) {
                            toast("链接必须以 http:// 或 https:// 开头");
                            return;
                        }
                        if (!SourceStore.add(MainActivity.this, name, url, "")) {
                            toast("这个链接已经存在，或已到 10 个上限");
                            return;
                        }
                        renderSources();
                        toast("已导入节点源");
                    }
                })
                .setNegativeButton("取消", null)
                .show();
    }

    /** 用户主动断开 / 取消时：把云节点"换下一个"的重试链一起停掉。 */
    private void cancelCloudRetryChain() {
        try {
            cloudRetryActive = false;
            cloudRetry.clear();
            cloudRetryTried = 0;
            cloudConnectingSource = null;
            CloudTester.stop();
        } catch (Throwable ignored) {
        }
    }

    private int msOf(String[] row) {
        try {
            return row.length > 4 ? Integer.parseInt(row[4]) : Integer.MAX_VALUE;
        } catch (Throwable t) {
            return Integer.MAX_VALUE;
        }
    }

    /** 在"当前已连接的云节点源"里换一个还没试过的可用节点。 */
    private void switchCloudNode() {
        String cloudSrc = TunnelService.cloudSource();
        if (cloudSrc == null || !TunnelService.isRunning()) {
            toast("只有已连接云节点时才能换节点");
            return;
        }
        String url = null;
        try {
            for (String[] src : SourceStore.list(this)) {
                if (src[0].equals(cloudSrc)) {
                    url = src[1];
                    break;
                }
            }
        } catch (Throwable ignored) {
        }
        if (url == null) {
            toast("找不到当前节点源，请重新连接云节点");
            return;
        }
        Node cur = TunnelService.currentNode();
        String curUri = cur == null ? "" : cur.uri;
        final java.util.List<Node> pool = new java.util.ArrayList<Node>();
        try {
            java.util.List<String[]> avail = new java.util.ArrayList<String[]>();
            for (String[] row : CloudTester.loadNodes(this, url)) {
                if (row.length >= 5 && "1".equals(row[3])) avail.add(row);
            }
            java.util.Collections.sort(avail, new java.util.Comparator<String[]>() {
                @Override
                public int compare(String[] a, String[] b) {
                    return msOf(a) - msOf(b);
                }
            });
            for (String[] row : avail) {
                String uri = row[0];
                if (uri.equals(curUri) || cloudTried.contains(uri)) continue;
                String cc = row[1] == null ? "ZZ" : row[1];
                String title = row[2] == null ? "" : row[2];
                pool.add(new Node(uri, cc, title));
                if (pool.size() >= 30) break;
            }
        } catch (Throwable t) {
            Log2.w("换节点读取缓存失败：" + t);
        }
        if (pool.isEmpty()) {
            toast("已经没有其他节点可以连了");
            return;
        }
        cloudSwitching = true;
        cloudSwitchPrevUri = curUri;
        cloudSwitchPrevCc = cur == null ? "ZZ" : cur.cc;
        cloudSwitchPrevTitle = cur == null ? "" : cur.title;
        final String srcName = cloudSrc;
        cloudLastPool = new java.util.ArrayList<Node>(pool);
        status.setText("正在换节点…（" + pool.size() + " 个候选）");
        toast("正在试 " + pool.size() + " 个节点…");
        TunnelService.disconnect(this, "换节点前断开");
        final int[] tries = {0};
        final Runnable[] poll = new Runnable[1];
        poll[0] = new Runnable() {
            @Override
            public void run() {
                if (uiDead()) return;
                if (TunnelService.isRunning() || TunnelService.isConnecting()) {
                    if (++tries[0] > 20) {
                        toast("断开太慢，请手动断开后再换节点");
                        return;
                    }
                    ui.postDelayed(this, 400);
                    return;
                }
                cloudConnectingSource = srcName;
                TunnelService.setCloudSource(srcName);
                TunnelService.setPoolCandidates(pool);
                requestVpn(pool.get(0), TunnelService.MODE_POOL, true, true);
            }
        };
        ui.postDelayed(poll[0], 500);
    }

    private void connectSelectedSource() {
        java.util.List<String[]> list = SourceStore.list(this);
        if (srcSelected < 0 || srcSelected >= list.size()) {
            new AlertDialog.Builder(this)
                    .setTitle("还没有选择节点源")
                    .setMessage("「连接云节点」要先告诉程序用哪个源。\n\n"
                            + "在上面点一下想用的节点源（那一行会显示 ▶），再点「连接云节点」就可以了。")
                    .setPositiveButton("我知道了", null)
                    .show();
            return;
        }
        if (TunnelService.isScanning()) {
            new AlertDialog.Builder(this)
                    .setTitle("正在体检节点")
                    .setMessage("体检期间不能连接 VPN（结果会失真）。\n等它结束，或先点进度窗里的「结束体检」。")
                    .setPositiveButton("知道了", null)
                    .show();
            return;
        }
        String[] src = list.get(srcSelected);
        startCloudConnect(src[0], src[1]);
    }

    /** 体检预计耗时：不满 60 秒按秒说，满 1 分钟按"X 分 Y 秒"。 */
    private String etaText(int total) {
        int sec = (int) Math.max(5, Math.round(total / 350.0 * 60));
        if (sec < 60) return sec + " 秒";
        int m = sec / 60, s2 = sec % 60;
        if (s2 == 0) return m + " 分钟";
        if (m >= 10) return m + " 分钟";
        return m + " 分 " + s2 + " 秒";
    }

    private void startGeoClassify() {
        startGeoClassify(false);
    }

    private void startGeoClassify(final boolean all) {
        if (GeoClassifier.isRunning()) {
            toast("正在识别中…");
            return;
        }
        int unknown = 0;
        int total = 0;
        try {
            for (Node n : NodeStore.allForClassify(this)) {
                total++;
                if (Country.isUnknown(n.cc)) unknown++;
            }
        } catch (Throwable ignored) {
        }
        if (!all && unknown == 0) {
            toast("没有「未识别地区」的节点，不用识别");
            return;
        }
        if (all && total == 0) {
            toast("没有可识别的节点");
            return;
        }
        final int count = all ? total : unknown;
        if (all) {
            final boolean doAll = true;
            new AlertDialog.Builder(this)
                    .setTitle("重新识别全部地区？")
                    .setMessage("会对全部 " + count + " 个节点重新查一遍地区，"
                            + "已经有国家的节点也会被覆盖。\n\n不会连接节点，需要联网。")
                    .setPositiveButton("开始", new android.content.DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(android.content.DialogInterface d, int w) {
                            runGeoClassify(doAll, count);
                        }
                    })
                    .setNegativeButton("取消", null)
                    .show();
            return;
        }
        runGeoClassify(false, count);
    }

    private void runGeoClassify(final boolean all, final int count) {
        final android.widget.LinearLayout box = new android.widget.LinearLayout(this);
        box.setOrientation(android.widget.LinearLayout.VERTICAL);
        float dp = getResources().getDisplayMetrics().density;
        int pad = (int) (dp * 20);
        box.setPadding(pad, pad, pad, pad);
        geoText = new TextView(this);
        geoText.setText((all ? "正在重新识别全部 " : "正在识别 ") + count
                + (all ? " 个节点…\n\n" : " 个未识别地区节点…\n\n")
                + "先解析域名，再按服务器 IP 归属地归类。\n不会连接节点。");
        geoText.setTextSize(14f);
        geoText.setTextColor(0xFFF0F3F8);
        box.addView(geoText);
        geoDialog = new AlertDialog.Builder(this)
                .setTitle(all ? "重新识别全部地区" : "识别未识别地区")
                .setView(box)
                .setCancelable(false)
                .setNegativeButton("取消", new android.content.DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(android.content.DialogInterface d, int w) {
                        GeoClassifier.cancel();
                        toast("正在取消…");
                    }
                })
                .create();
        geoDialog.show();

        GeoClassifier.Listener listener = new GeoClassifier.Listener() {
            @Override
            public void onProgress(final int done, final int total, final int found) {
                ui.post(new Runnable() {
                    @Override
                    public void run() {
                        if (geoText != null) {
                            geoText.setText("正在解析域名 " + done + "/" + total + "…\n\n"
                                    + "已识别 " + found + " 个\n"
                                    + "接下来按 IP 归属地归类，不会连接节点。");
                        }
                    }
                });
            }

            @Override
            public void onDone(final int found, final int remain, final boolean cancelled) {
                ui.post(new Runnable() {
                    @Override
                    public void run() {
                        try {
                            if (geoDialog != null && geoDialog.isShowing()) geoDialog.dismiss();
                        } catch (Throwable ignored) {
                        }
                        geoDialog = null;
                        geoText = null;
                        try {
                            NodeStore.reload(MainActivity.this);
                            countries = NodeStore.countries(MainActivity.this, editMode && showHiddenInEdit);
                            adapter.notifyDataSetChanged();
                            updateStats();
                        } catch (Throwable ignored) {
                        }
                        String detail = GeoClassifier.lastDetail == null ? "" : GeoClassifier.lastDetail;
                        if (cancelled) {
                            toast("已取消，已识别 " + found + " 个");
                            return;
                        }
                        if (found == 0) {
                            toast("没识别出来：" + remain + " 个节点的 IP 查不到归属地");
                            return;
                        }
                        StringBuilder m = new StringBuilder();
                        m.append("已归类 ").append(found).append(" 个节点");
                        if (remain > 0) m.append("，仍有 ").append(remain).append(" 个未识别");
                        if (detail.length() > 0) {
                            m.append("\n\n其中：\n");
                            for (String one : detail.split("、")) {
                                m.append("· ").append(one).append("\n");
                            }
                        }
                        new AlertDialog.Builder(MainActivity.this)
                                .setTitle("识别完成")
                                .setMessage(m.toString().trim())
                                .setPositiveButton("好的", null)
                                .show();
                    }
                });
            }
        };
        if (all) GeoClassifier.startAll(this, listener);
        else GeoClassifier.start(this, listener);
    }

    /** 清空全部日志：先确认权限，再确认是否清除。 */
    private void startClearLogFlow() {
        boolean hasFiles = false;
        try {
            java.io.File[] kids = logDir().listFiles();
            hasFiles = kids != null && kids.length > 0;
        } catch (Throwable ignored) {
        }
        boolean canAll = android.os.Build.VERSION.SDK_INT < 30
                || android.os.Environment.isExternalStorageManager();
        if (hasFiles && !canAll) {
            pendingClearAfterGrant = true;
            new AlertDialog.Builder(this)
                    .setTitle("需要「所有文件访问」权限")
                    .setMessage("Download/CommandVPN 里的旧日志不属于当前安装实例，"
                            + "没有这个权限就删不掉它们。\n\n"
                            + "授权后只会用来清理该目录里的日志文件，不读其它内容。")
                    .setPositiveButton("去授权", new android.content.DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(android.content.DialogInterface d, int w) {
                            try {
                                Intent i = new Intent(android.provider.Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION);
                                i.setData(android.net.Uri.parse("package:" + getPackageName()));
                                startActivity(i);
                            } catch (Throwable t) {
                                try {
                                    startActivity(new Intent(android.provider.Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION));
                                } catch (Throwable ignored) {
                                }
                            }
                        }
                    })
                    .setNegativeButton("取消", new android.content.DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(android.content.DialogInterface d, int w) {
                            pendingClearAfterGrant = false;
                        }
                    })
                    .show();
            return;
        }
        askClearLog();      // 权限没问题（或没有旧文件）：直接问是否清除
    }

    /** 清空日志前先确认，写清会删掉什么、有什么影响。 */
    private void askClearLog() {
        new AlertDialog.Builder(this)
                .setTitle("清空全部日志")
                .setMessage("要删除的内容：\n"
                        + "· Download/CommandVPN 里的全部文件（所有历史日志）\n"
                        + "· App 私有目录里的日志（quickvpn.log）\n"
                        + "· 内存里缓存的最近日志\n\n"
                        + "节点、设置、VPN 连接都不受影响。\n"
                        + "删除后无法恢复，需要留档请先复制一份。")
                .setPositiveButton("清空", new android.content.DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(android.content.DialogInterface d, int w) {
                        doClearLog();
                    }
                })
                .setNegativeButton("取消", null)
                .show();
    }

    private boolean pendingClearAfterGrant = false;

    private java.io.File logDir() {
        return new java.io.File(android.os.Environment.getExternalStoragePublicDirectory(
                android.os.Environment.DIRECTORY_DOWNLOADS), "CommandVPN");
    }

    /** 直接删目录里的文件，返回删掉几个。 */
    private int deleteLogFiles() {
        int n = 0;
        try {
            java.io.File dir = logDir();
            java.io.File[] kids = dir.listFiles();
            if (kids != null) {
                for (java.io.File k : kids) {
                    try {
                        if (k.isDirectory()) continue;
                        if (k.delete()) n++;
                    } catch (Throwable ignored) {
                    }
                }
            }
        } catch (Throwable ignored) {
        }
        return n;
    }

    private void doClearLog() {
        try {
            java.io.File dir = logDir();
            boolean hasFiles = false;
            java.io.File[] kids = dir.listFiles();
            if (kids != null) hasFiles = kids.length > 0;

            boolean canAll = android.os.Build.VERSION.SDK_INT < 30
                    || android.os.Environment.isExternalStorageManager();
            if (hasFiles && !canAll) {
                // 作用域存储下看不到/删不掉别的实例建的旧日志，需要"所有文件访问"
                pendingClearAfterGrant = true;
                new AlertDialog.Builder(this)
                        .setTitle("需要「所有文件访问」权限")
                        .setMessage("Download/CommandVPN 里的旧日志文件不属于当前安装实例，"
                                + "系统不允许直接删除。\n\n"
                                + "开启「所有文件访问」后（只用于删日志），就能一次性清空；"
                                + "授权页里把本应用的开关打开即可。")
                        .setPositiveButton("去授权", new android.content.DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(android.content.DialogInterface d, int w) {
                                try {
                                    Intent i = new Intent(android.provider.Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION);
                                    i.setData(android.net.Uri.parse("package:" + getPackageName()));
                                    startActivity(i);
                                } catch (Throwable t) {
                                    try {
                                        startActivity(new Intent(android.provider.Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION));
                                    } catch (Throwable ignored) {
                                    }
                                }
                            }
                        })
                        .setNegativeButton("取消", new android.content.DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(android.content.DialogInterface d, int w) {
                                pendingClearAfterGrant = false;
                            }
                        })
                        .show();
                return;
            }

            int deleted = deleteLogFiles();
            java.util.List<android.net.Uri> left = Log2.clear(this);
            if (left != null && !left.isEmpty() && android.os.Build.VERSION.SDK_INT >= 30) {
                try {
                    android.app.PendingIntent pi =
                            android.provider.MediaStore.createDeleteRequest(getContentResolver(), left);
                    startIntentSenderForResult(pi.getIntentSender(), REQ_DELETE_LOGS, null, 0, 0, 0);
                    return;
                } catch (Throwable t) {
                    Log2.w("系统删除确认失败：" + t);
                }
            }
            toast(deleted > 0 ? "已清空全部日志（删除 " + deleted + " 个文件）" : "日志已清空");
        } catch (Throwable t) {
            toast("清空失败：" + t);
        }
    }

    private String hoursText() {
        StringBuilder sb = new StringBuilder();
        for (Integer h : AutoRefresh.hours(this)) {
            if (sb.length() > 0) sb.append("、");
            sb.append(String.format(java.util.Locale.US, "%02d:00", h));
        }
        return sb.length() == 0 ? "03:00" : sb.toString();
    }

    private void updateHoursButton(Button b) {
        if (b == null) return;
        b.setText("翻新时间：" + hoursText() + "（点击多选）");
    }

    /** 24 个整点多选。 */
    private void showHoursPicker() {
        final java.util.TreeSet<Integer> selected = AutoRefresh.hours(this);
        final String[] items = new String[24];
        final boolean[] checked = new boolean[24];
        for (int i = 0; i < 24; i++) {
            items[i] = String.format(java.util.Locale.US, "%02d:00", i);
            checked[i] = selected.contains(i);
        }
        new AlertDialog.Builder(this)
                .setTitle("每天自动翻新的时间（可多选）")
                .setMultiChoiceItems(items, checked, new android.content.DialogInterface.OnMultiChoiceClickListener() {
                    @Override
                    public void onClick(android.content.DialogInterface d, int which, boolean isChecked) {
                        checked[which] = isChecked;
                    }
                })
                .setPositiveButton("保存", new android.content.DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(android.content.DialogInterface d, int w) {
                        java.util.TreeSet<Integer> hs = new java.util.TreeSet<Integer>();
                        for (int i = 0; i < 24; i++) if (checked[i]) hs.add(i);
                        if (hs.isEmpty()) hs.add(3);
                        AutoRefresh.setHours(MainActivity.this, hs);
                        updateHoursButton((Button) findViewById(R.id.btnAutoHours));
                        toast("每天 " + hoursText() + " 自动翻新");
                    }
                })
                .setNegativeButton("取消", null)
                .show();
    }

    /**
     * 打开自动翻新后的分步引导：通知 → 电池优化（要点"允许"）→ 自启动 → 完全后台 → App 内开机自启。
     * 一步一步来，避免用户以为点了某个"允许"就全好了。
     */
    private int guideStep = 0;              // 当前在第几步（0 = 没在引导）
    private int pendingGuideStep = 0;       // 跳到系统设置后，回来要接着显示第几步
    private boolean guideNavigating = false; // 正在跳系统设置（弹窗被系统关掉不算用户取消）
    private AlertDialog guideDialog;

    private void startAutoRefreshGuide() {
        guideStep = 1;
        showGuideStep(1);
    }

    /** 重新进入界面时，如果体检还在跑，把进度窗恢复出来并实时更新。 */
    private void showScanMonitorIfNeeded() {
        try {
            int total = TunnelService.getScanTotal();
            if (total <= 0) total = Math.max(1, NodeStore.everything(this).size());
            showScanProgress(total);
            updateScanProgress(TunnelService.getScanDone(), total, TunnelService.getScanAlive());
            ui.removeCallbacks(scanMonitorTicker);
            ui.post(scanMonitorTicker);
            Log2.i("界面恢复：体检仍在进行，" + TunnelService.getScanDone() + "/" + total);
        } catch (Throwable ignored) {
        }
    }

    /** 等服务把体检真正拉起来，再弹出体检进度窗（最多等 attempts*500ms）。 */
    private void waitForScanThenShow(final int attempts) {
        if (attempts <= 0) {
            if (pendingRefreshSummary) {
                pendingRefreshSummary = false;
                showRefreshSummaryNoScan(refreshImported);
            }
            return;
        }
        ui.postDelayed(new Runnable() {
            @Override
            public void run() {
                if (uiDead()) return;
                if (TunnelService.isScanning()) {
                    Log2.i("翻新结束：体检已开始，弹出体检进度窗");
                    showScanMonitorIfNeeded();
                } else {
                    waitForScanThenShow(attempts - 1);
                }
            }
        }, 500);
    }

    private final Runnable scanMonitorTicker = new Runnable() {
        @Override
        public void run() {
            try {
                if (!TunnelService.isScanning()) return;
                if (scanDialog == null || !scanDialog.isShowing()) return;
                int total = Math.max(1, TunnelService.getScanTotal());
                updateScanProgress(TunnelService.getScanDone(), total, TunnelService.getScanAlive());
            } catch (Throwable ignored) {
            }
            ui.postDelayed(this, 1000);
        }
    };

    /** 从系统设置回来时，把刚才那一步的弹窗重新显示出来。 */
    /** 第 2 步从系统设置回来后：让用户确认是否已经允许，避免"点了允许还被要求再去点一次"。 */
    private void showGuideStep2Confirm() {
        if (uiDead()) return;
        AlertDialog.Builder b = new AlertDialog.Builder(this)
                .setTitle("第 2/5 步：后台运行（电池优化）")
                .setMessage("刚才在系统弹窗里点「允许」了吗？\n\n"
                        + "部分系统（含 ColorOS）需要过几秒才会把状态同步过来，"
                        + "所以这里可能还显示「未允许」。\n\n"
                        + "👉 已经点过「允许」：直接点「我已允许，下一步」。\n"
                        + "👉 还没点 / 点成了不允许：点「再去设置」。")
                .setPositiveButton("我已允许，下一步", new android.content.DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(android.content.DialogInterface d, int w) {
                        Log2.i("用户确认第 2 步已允许，进入第 3 步");
                        showGuideStep(3);
                    }
                })
                .setNeutralButton("再去设置", new android.content.DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(android.content.DialogInterface d, int w) {
                        guideNavigating = true;
                        saveGuideResume(2);
                        try {
                            Intent i = new Intent(android.provider.Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS);
                            i.setData(android.net.Uri.parse("package:" + getPackageName()));
                            startActivity(i);
                        } catch (Throwable t) {
                            try {
                                startActivity(new Intent(android.provider.Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS));
                            } catch (Throwable ignored) {
                            }
                        }
                    }
                })
                .setNegativeButton("跳过", new android.content.DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(android.content.DialogInterface d, int w) {
                        showGuideStep(3);
                    }
                });
        showStep(b, 2);
    }

    private void saveGuideResume(int step) {
        try {
            getSharedPreferences("qv", MODE_PRIVATE).edit()
                    .putInt("guide_resume_step", step).apply();
        } catch (Throwable ignored) {
        }
    }

    private void resumeGuideIfNeeded() {
        try {
            int prefStep = 0;
            try {
                prefStep = getSharedPreferences("qv", MODE_PRIVATE).getInt("guide_resume_step", 0);
            } catch (Throwable ignored) {
            }
            if (prefStep >= 2 && prefStep <= 5 && pendingGuideStep != prefStep) {
                pendingGuideStep = prefStep;
            }
            guideNavigating = false;      // 回来了，弹窗被系统关掉不再算"导航中"
            if (pendingGuideStep == 2) {
                int step = pendingGuideStep;
                pendingGuideStep = 0;
                getSharedPreferences("qv", MODE_PRIVATE).edit()
                        .remove("guide_resume_step").apply();
                boolean ignoring = false;
                try {
                    android.os.PowerManager pm = (android.os.PowerManager) getSystemService(POWER_SERVICE);
                    ignoring = pm != null && pm.isIgnoringBatteryOptimizations(getPackageName());
                } catch (Throwable ignored) {
                }
                Log2.i("从电池优化设置返回：已允许=" + ignoring);
                if (ignoring) {
                    showGuideStep(3);
                } else {
                    // 有些系统刚点完"允许"，这个查询要过一会儿才变 true；
                    // 不再直接重弹"去设置"，让用户自己确认一次，避免来回点
                    showGuideStep2Confirm();
                }
                return;
            }
            if (pendingGuideStep >= 3 && pendingGuideStep <= 5) {
                int step = pendingGuideStep;
                pendingGuideStep = 0;
                getSharedPreferences("qv", MODE_PRIVATE).edit()
                        .remove("guide_resume_step").apply();
                Log2.i("从系统设置返回：继续引导第 " + step + " 步");
                showGuideStep(step);
                return;
            }
            if (guideStep >= 1 && guideStep <= 5) {
                boolean showing = guideDialog != null && guideDialog.isShowing();
                if (!showing) {
                    Log2.i("从系统设置返回：恢复引导第 " + guideStep + " 步");
                    ui.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            if (!uiDead()) showGuideStep(guideStep);
                        }
                    }, 300);
                }
            }
        } catch (Throwable ignored) {
        }
    }

    private void showGuideDialog(AlertDialog d, int step) {
        try {
            if (guideDialog != null && guideDialog.isShowing()) guideDialog.dismiss();
        } catch (Throwable ignored) {
        }
        guideStep = step;
        guideDialog = d;
        final int thisStep = step;
        d.setOnDismissListener(new android.content.DialogInterface.OnDismissListener() {
            @Override
            public void onDismiss(android.content.DialogInterface dialog) {
                if (guideNavigating) {
                    Log2.i("引导弹窗因跳转系统设置而关闭，保留进度");
                    return;
                }
                // 用户按 BACK / 点外面把它关掉：引导结束，别在 onResume 里无限重弹
                if (guideStep == thisStep) {
                    guideStep = 0;
                    guideDialog = null;
                    Log2.i("引导弹窗被关闭，结束引导");
                }
            }
        });
        d.show();
    }

    /** 关掉自动翻新开关时，把正在进行的引导也一起结束。 */
    private void cancelGuide() {
        guideStep = 0;
        try {
            if (guideDialog != null && guideDialog.isShowing()) guideDialog.dismiss();
        } catch (Throwable ignored) {
        }
        guideDialog = null;
    }

    /** 第 3/4 步的弹窗：正文 + 一个"按路径跳转"按钮 + 三个底部按钮。 */
    private void showVendorStep(final int step, String title, String message,
                                final boolean autostart, final String path) {
        if (uiDead()) return;
        float dp = getResources().getDisplayMetrics().density;
        int pad = (int) (dp * 18);
        android.widget.LinearLayout box = new android.widget.LinearLayout(this);
        box.setOrientation(android.widget.LinearLayout.VERTICAL);
        box.setPadding(pad, pad, pad, pad);

        TextView tv = new TextView(this);
        tv.setText(message);
        tv.setTextSize(13.5f);
        tv.setTextColor(0xFFF0F3F8);      // 弹窗背景是深色，文字必须浅色
        tv.setTextIsSelectable(true);
        android.widget.ScrollView sv = new android.widget.ScrollView(this);
        sv.addView(tv);
        box.addView(sv, new android.widget.LinearLayout.LayoutParams(
                android.widget.LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f));

        Button jump = new Button(this);
        jump.setText("按上面路径跳转（不保证准确）");
        jump.setAllCaps(false);
        jump.setTextSize(14f);
        jump.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                askBestEffortJump(autostart, path);
            }
        });
        android.widget.LinearLayout.LayoutParams blp = new android.widget.LinearLayout.LayoutParams(
                android.widget.LinearLayout.LayoutParams.MATCH_PARENT, (int) (dp * 46));
        blp.topMargin = (int) (dp * 10);
        box.addView(jump, blp);

        String homeLabel = VendorSettings.inPhoneManager(this) ? "打开手机管家" : "打开设置首页";
        AlertDialog d = new AlertDialog.Builder(this)
                .setTitle(title)
                .setView(box)
                .setPositiveButton(homeLabel, new android.content.DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(android.content.DialogInterface dlg, int w) {
                        guideNavigating = true;
                        saveGuideResume(step);
                        int r = autostart
                                ? VendorSettings.openAutoStart(MainActivity.this)
                                : VendorSettings.openBattery(MainActivity.this);
                        if (r == VendorSettings.OPENED_FALLBACK) {
                            toast("已打开首页，按上面的路径找到后回来点「下一步」");
                        } else {
                            showManualSettingPath(autostart ? "自启动" : "允许完全后台行为", path);
                        }
                    }
                })
                .setNeutralButton("下一步", new android.content.DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(android.content.DialogInterface dlg, int w) {
                        showGuideStep(step + 1);
                    }
                })
                .setNegativeButton("跳过", new android.content.DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(android.content.DialogInterface dlg, int w) {
                        showGuideStep(step + 1);
                    }
                })
                .create();
        showGuideDialog(d, step);
    }

    /** "按路径跳转"前的确认：说明不保证准确，三个按钮。 */
    private void askBestEffortJump(final boolean autostart, final String path) {
        if (uiDead()) return;
        float dp = getResources().getDisplayMetrics().density;
        int pad = (int) (dp * 18);
        final android.widget.LinearLayout box = new android.widget.LinearLayout(this);
        box.setOrientation(android.widget.LinearLayout.VERTICAL);
        box.setPadding(pad, (int) (dp * 8), pad, pad);

        TextView msg = new TextView(this);
        msg.setText("不保证跳到的位置一定正确，但会尽量跳到上面那条路径对应的页面。\n\n"
                + "各系统版本的菜单位置不同，跳错时请按弹窗里的路径手动找。");
        msg.setTextSize(13.5f);
        msg.setTextColor(0xFFF0F3F8);
        msg.setTextIsSelectable(true);
        box.addView(msg);

        final AlertDialog dlg = new AlertDialog.Builder(this)
                .setTitle("按路径跳转")
                .setView(box)
                .create();

        String[] labels = {"是（按路径跳转）", "否", "打开设置首页"};
        int h = (int) (dp * 44);
        for (int i = 0; i < labels.length; i++) {
            final int which = i;
            Button b = new Button(this);
            b.setText(labels[i]);
            b.setAllCaps(false);
            b.setTextSize(15f);
            b.setTextColor(0xFFF0F3F8);
            b.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    try {
                        dlg.dismiss();
                    } catch (Throwable ignored) {
                    }
                    if (which == 0) {
                        boolean inGuide = guideStep >= 3 && guideStep <= 5;
                        if (inGuide) {
                            guideNavigating = true;
                            saveGuideResume(autostart ? 3 : 4);
                        }
                        int r = VendorSettings.openBestEffort(MainActivity.this, autostart);
                        if (r == VendorSettings.OPENED_VENDOR) {
                            toast("已尽量跳到对应页面；不对的话请按上面的路径找");
                        } else if (r == VendorSettings.OPENED_DETAILS) {
                            toast("已打开应用详情页，按上面的路径继续找");
                        } else if (r == VendorSettings.OPENED_FALLBACK) {
                            toast("已打开系统设置，按上面的路径找");
                        } else {
                            showManualSettingPath(autostart ? "自启动" : "允许完全后台行为", path);
                        }
                    } else if (which == 2) {
                        boolean inGuide2 = guideStep >= 3 && guideStep <= 5;
                        if (inGuide2) {
                            guideNavigating = true;
                            saveGuideResume(autostart ? 3 : 4);
                        }
                        int r = autostart
                                ? VendorSettings.openAutoStart(MainActivity.this)
                                : VendorSettings.openBattery(MainActivity.this);
                        if (r != VendorSettings.OPENED_FALLBACK) {
                            showManualSettingPath(autostart ? "自启动" : "允许完全后台行为", path);
                        }
                    }
                }
            });
            android.widget.LinearLayout.LayoutParams lp = new android.widget.LinearLayout.LayoutParams(
                    android.widget.LinearLayout.LayoutParams.MATCH_PARENT, h);
            lp.topMargin = (int) (dp * 6);
            box.addView(b, lp);
        }
        dlg.show();
    }

    private void showGuideStep(final int step) {
        if (uiDead()) return;
        final int TOTAL = 5;
        final String prefix = "第 " + step + "/" + TOTAL + " 步：";
        guideStep = step;
        AlertDialog.Builder b;
        switch (step) {
            case 1: {
                boolean granted = android.os.Build.VERSION.SDK_INT < 33
                        || checkSelfPermission("android.permission.POST_NOTIFICATIONS")
                        == android.content.pm.PackageManager.PERMISSION_GRANTED;
                if (granted) {
                    showGuideStep(2);
                    return;
                }
                b = new AlertDialog.Builder(this)
                        .setTitle(prefix + "通知权限")
                        .setMessage("自动翻新在后台跑的时候，只能靠通知栏告诉你进度和结果。\n\n"
                                + "请点「去授权」，在系统弹窗里选允许。")
                        .setPositiveButton("去授权", new android.content.DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(android.content.DialogInterface d, int w) {
                                try {
                                    requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"}, 320);
                                } catch (Throwable ignored) {
                                }
                                showGuideStep(2);
                            }
                        })
                        .setNegativeButton("跳过", new android.content.DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(android.content.DialogInterface d, int w) {
                                showGuideStep(2);
                            }
                        });
                showStep(b, 1);
                return;
            }
            case 2: {
                boolean ignoring = false;
                try {
                    android.os.PowerManager pm = (android.os.PowerManager) getSystemService(POWER_SERVICE);
                    ignoring = pm != null && pm.isIgnoringBatteryOptimizations(getPackageName());
                } catch (Throwable ignored) {
                }
                if (ignoring) {
                    showGuideStep(3);
                    return;
                }
                b = new AlertDialog.Builder(this)
                        .setTitle(prefix + "后台运行（电池优化）")
                        .setMessage("系统会弹一个框：「要允许应用始终在后台运行吗？」\n\n"
                                + "👉 那里必须点「允许」。\n\n"
                                + "⚠ 注意：这一步只管「不被系统冻结」，不等于全部搞定，后面还有 3 步。")
                        .setPositiveButton("去设置", new android.content.DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(android.content.DialogInterface d, int w) {
                                try {
                                    Intent i = new Intent(android.provider.Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS);
                                    i.setData(android.net.Uri.parse("package:" + getPackageName()));
                                    startActivity(i);
                                } catch (Throwable t) {
                                    try {
                                        startActivity(new Intent(android.provider.Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS));
                                    } catch (Throwable ignored) {
                                    }
                                }
                                // 不在这里跳到第 3 步：等用户回来，按真实状态判断。
                                // 写进 pref：系统设置页可能把进程干掉，实例状态不一定还在
                                getSharedPreferences("qv", MODE_PRIVATE).edit()
                                        .putInt("guide_resume_step", 2).apply();
                                cancelGuide();
                                pendingGuideStep = 2;
                            }
                        })
                        .setNegativeButton("跳过", new android.content.DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(android.content.DialogInterface d, int w) {
                                showGuideStep(3);
                            }
                        });
                showStep(b, 2);
                return;
            }
            case 3: {
                showVendorStep(3,
                        prefix + (isSamsung()
                                ? "自动运行（三星 系统设置）"
                                : "自启动（" + vendorName() + " 系统设置）"),
                        "这是手机系统里的开关，不是本应用的开关。\n\n"
                                + autoStartPath() + "\n\n"
                                + (VendorSettings.inPhoneManager(this)
                                ? "点下面的「打开手机管家」会打开手机管家首页，按上面的路径找到「自启动」。"
                                : "点下面的「打开设置首页」会打开系统设置首页，按上面的路径找到「自启动」。")
                                + "\n\n不开的话：手机重启后不会自动翻新，也不容易被系统留在后台。",
                        true, autoStartPath());
                return;
            }
            case 4: {
                showVendorStep(4,
                        prefix + "允许完全后台行为（" + vendorName() + "）",
                        batteryPath() + "\n\n"
                                + (VendorSettings.inPhoneManager(this)
                                ? "点下面的「打开手机管家」会打开手机管家首页，按上面的路径设置。"
                                : "点下面的「打开设置首页」会打开系统设置首页，按上面的路径设置。")
                                + (needsBatteryOptimizeHint()
                                ? "\n\n注意：如果你进到的是「电池优化」列表（每项写着「优化 / 不优化」），"
                                  + "那属于第 2 步，不是这一步；请按上面的路径进入「命令方块」的应用设置页。"
                                : "")
                                + "\n\n不开的话：锁屏或清后台之后，进程会被系统杀掉，到点不会翻新。",
                        false, batteryPath());
                return;
            }
            default: {
                final android.widget.Switch swBoot = (android.widget.Switch) findViewById(R.id.swAutoBoot);
                b = new AlertDialog.Builder(this)
                        .setTitle(prefix + "本应用里的「开机自启」")
                        .setMessage("最后一步：设置页里的「开机自启」开关也要打开。\n\n"
                                + "⚠ 不开的话，每次开机都必须手动点一次本应用；\n"
                                + "　 不点就不会自动更新节点（直到你打开一次）。")
                        .setPositiveButton("帮我打开", new android.content.DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(android.content.DialogInterface d, int w) {
                                AutoRefresh.setBootEnabled(MainActivity.this, true);
                                if (swBoot != null) {
                                    suppressToggle = true;      // 别触发监听里的"开机自启指引"
                                    swBoot.setChecked(true);
                                    suppressToggle = false;
                                }
                                doneGuide();
                            }
                        })
                        .setNegativeButton("稍后自己开", new android.content.DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(android.content.DialogInterface d, int w) {
                                doneGuide();
                            }
                        });
                showStep(b, 5);
            }
        }
    }

    private void showStep(AlertDialog.Builder b, int step) {
        AlertDialog d = b.create();
        showGuideDialog(d, step);
    }

    /** 打不开正确页面时：明确告诉用户自己去找，并给出准确路径。 */
    private void showManualSettingPath(String what, String path) {
        new AlertDialog.Builder(this)
                .setTitle("这次没法直接跳转，请手动设置")
                .setMessage("需要你手动打开：「" + what + "」\n\n"
                        + path + "\n\n"
                        + "（不同系统版本菜单位置可能略有差异，按上面这几个字去找即可）")
                .setPositiveButton("知道了", null)
                .show();
    }

    /** 通知被系统关掉时提示用户去开（否则锁屏/切后台后看不到进度）。 */
    private Runnable preflightNext = null;
    private boolean preflightDone = false;   // 本轮前置检查是否已通过（避免递归重复检查）
    private int preflightStage = 0;
    private boolean preflightNotifDeclined = false;

    /**
     * 翻新/体检开工前的权限检查：通知 → 电池优化 → 完全后台（ColorOS 系提醒一次）。
     * 每项都说清"为什么需要"，用户可以选择"先这样"跳过；检查完再执行 next。
     */
    private void preflightThen(Runnable next) {
        preflightNext = next;
        preflightStage = 1;
        preflightNotifDeclined = false;
        runPreflight();
    }

    /** 带"不再提示"复选框的权限询问；只有勾了才写入跳过标记。 */
    private void askPermWithSkip(String title, String msg, String goLabel,
                                 final Runnable go, final String skipKey, final Runnable next) {
        askPermWithSkip(title, msg, goLabel, go, null, skipKey, next);
    }

    private void askPermWithSkip(String title, String msg, String goLabel,
                                 final Runnable go, String doneLabel,
                                 final String skipKey, final Runnable next) {
        if (uiDead()) {
            next.run();
            return;
        }
        float dp = getResources().getDisplayMetrics().density;
        int pad = (int) (dp * 18);
        final android.widget.LinearLayout box = new android.widget.LinearLayout(this);
        box.setOrientation(android.widget.LinearLayout.VERTICAL);
        box.setPadding(pad, (int) (dp * 8), pad, pad);
        TextView tv = new TextView(this);
        tv.setText(msg);
        tv.setTextSize(13.5f);
        tv.setTextColor(0xFFF0F3F8);
        tv.setTextIsSelectable(true);
        box.addView(tv);
        final android.widget.CheckBox cb = new android.widget.CheckBox(this);
        cb.setText("不再提示（以后不再问这一项）");
        cb.setTextColor(0xFFF0F3F8);
        cb.setTextSize(13f);
        cb.setPadding(0, (int) (dp * 12), 0, 0);
        box.addView(cb);

        final AlertDialog dlg = new AlertDialog.Builder(this)
                .setTitle(title)
                .setView(box)
                .setPositiveButton(goLabel, null)
                .setNegativeButton("以后再说", null)
                .create();
        dlg.setOnShowListener(new android.content.DialogInterface.OnShowListener() {
            @Override
            public void onShow(android.content.DialogInterface d) {
                ((AlertDialog) d).getButton(android.content.DialogInterface.BUTTON_POSITIVE)
                        .setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                try {
                                    go.run();       // 只去设置，弹窗留着
                                } catch (Throwable ignored) {
                                }
                            }
                        });
            }
        });


        if (doneLabel != null) {
            Button done = new Button(this);
            done.setText(doneLabel);
            done.setAllCaps(false);
            done.setTextSize(14f);
            done.setTextColor(0xFFF0F3F8);
            done.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    // 先真的查一下权限开没开，没开就别放行
                    boolean ok = false;
                    try {
                        android.os.PowerManager pm =
                                (android.os.PowerManager) getSystemService(POWER_SERVICE);
                        ok = pm != null && pm.isIgnoringBatteryOptimizations(getPackageName());
                    } catch (Throwable ignored) {
                    }
                    if (!ok) {
                        new AlertDialog.Builder(MainActivity.this)
                                .setTitle("权限还没开启成功")
                                .setMessage("系统里没检测到「电池优化已关闭」。\n\n"
                                        + "可能是刚才没点「允许」，或者系统设置页没保存成功。\n"
                                        + "请再点一次「去关掉」，在系统弹窗里选「允许」后再回来。")
                                .setPositiveButton("知道了", null)
                                .show();
                        return;
                    }
                    try {
                        dlg.dismiss();      // 校验通过 → onDismiss 里继续下一步
                    } catch (Throwable ignored) {
                    }
                }
            });
            android.widget.LinearLayout.LayoutParams dlp = new android.widget.LinearLayout.LayoutParams(
                    android.widget.LinearLayout.LayoutParams.MATCH_PARENT,
                    (int) (dp * 44));
            dlp.topMargin = (int) (dp * 8);
            box.addView(done, dlp);
        }
        dlg.setOnDismissListener(new android.content.DialogInterface.OnDismissListener() {
            @Override
            public void onDismiss(android.content.DialogInterface d) {
                if (cb.isChecked() && skipKey != null) {
                    getSharedPreferences("qv", MODE_PRIVATE).edit()
                            .putBoolean(skipKey, true).apply();
                    Log2.i("用户勾选不再提示：" + skipKey);
                }
                ui.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        if (!uiDead()) next.run();
                    }
                }, 200);
            }
        });
        dlg.show();
    }

    /** 「允许完全后台行为」提醒：带不再提示复选框 + 按路径跳转（与五步引导同款）。 */
    private void showFullBgPermDialog(final Runnable next) {
        if (uiDead()) {
            next.run();
            return;
        }
        float dp = getResources().getDisplayMetrics().density;
        int pad = (int) (dp * 18);
        final android.widget.LinearLayout box = new android.widget.LinearLayout(this);
        box.setOrientation(android.widget.LinearLayout.VERTICAL);
        box.setPadding(pad, (int) (dp * 8), pad, pad);
        TextView tv = new TextView(this);
        tv.setText("ColorOS / vivo 这类系统除了电池优化，还有一个「完全后台行为」开关。\n\n"
                + "不开的话：锁屏几分钟或清掉最近任务后，进程会被系统冻结/杀掉，"
                + "体检会中途停住。\n\n"
                + "路径：设置 → 应用管理 → 命令方块 → 耗电管理 → 允许完全后台行为\n"
                + "（不同版本可能叫「电池」「应用耗电管理」「后台活动」）");
        tv.setTextSize(13.5f);
        tv.setTextColor(0xFFF0F3F8);
        tv.setTextIsSelectable(true);
        box.addView(tv);

        final android.widget.CheckBox cb = new android.widget.CheckBox(this);
        cb.setText("不再提示（以后不再问这一项）");
        cb.setTextColor(0xFFF0F3F8);
        cb.setTextSize(13f);
        cb.setPadding(0, (int) (dp * 12), 0, 0);
        box.addView(cb);

        Button doneBtn = new Button(this);
        doneBtn.setText("我已在设置里开好，继续");
        doneBtn.setAllCaps(false);
        doneBtn.setTextSize(14f);
        doneBtn.setTextColor(0xFFF0F3F8);
        android.widget.LinearLayout.LayoutParams dlp2 = new android.widget.LinearLayout.LayoutParams(
                android.widget.LinearLayout.LayoutParams.MATCH_PARENT, (int) (dp * 44));
        dlp2.topMargin = (int) (dp * 8);
        box.addView(doneBtn, dlp2);

        Button jump = new Button(this);
        jump.setText("按上面路径跳转（不保证准确）");
        jump.setAllCaps(false);
        jump.setTextSize(14f);
        jump.setTextColor(0xFFF0F3F8);
        jump.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                askBestEffortJump(false, batteryPath());
            }
        });
        android.widget.LinearLayout.LayoutParams blp = new android.widget.LinearLayout.LayoutParams(
                android.widget.LinearLayout.LayoutParams.MATCH_PARENT, (int) (dp * 46));
        blp.topMargin = (int) (dp * 8);
        box.addView(jump, blp);

        final AlertDialog dlg = new AlertDialog.Builder(this)
                .setTitle("还要给「允许完全后台行为」")
                .setView(box)
                .setPositiveButton("去设置首页", null)
                .setNegativeButton("以后再说", null)
                .create();
        dlg.setOnShowListener(new android.content.DialogInterface.OnShowListener() {
            @Override
            public void onShow(android.content.DialogInterface d) {
                ((AlertDialog) d).getButton(android.content.DialogInterface.BUTTON_POSITIVE)
                        .setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                try {
                                    startActivity(new Intent(android.provider.Settings.ACTION_SETTINGS));
                                } catch (Throwable ignored) {
                                }
                            }
                        });
            }
        });

        doneBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // 这一项系统没有提供查询接口，只能让用户再确认一次
                new AlertDialog.Builder(MainActivity.this)
                        .setTitle("确认已经开启？")
                        .setMessage("请确认系统设置里「允许完全后台行为」已经打开。\n\n"
                                + "（这一项系统不提供查询接口，只能靠你确认）\n\n"
                                + "路径：设置 → 应用管理 → 命令方块 → 耗电管理 → 允许完全后台行为")
                        .setPositiveButton("已开启，继续", new android.content.DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(android.content.DialogInterface d, int w) {
                                // 用户确认已开启：记住，不再每次开工都问
                                getSharedPreferences("qv", MODE_PRIVATE).edit()
                                        .putBoolean("fullbg_ok", true).apply();
                                Log2.i("用户确认「允许完全后台行为」已开启，以后不再提醒");
                                try {
                                    dlg.dismiss();      // 关掉 → onDismiss 继续
                                } catch (Throwable ignored) {
                                }
                            }
                        })
                        .setNegativeButton("还没开", null)
                        .show();
            }
        });
        dlg.setOnDismissListener(new android.content.DialogInterface.OnDismissListener() {
            @Override
            public void onDismiss(android.content.DialogInterface d) {
                if (cb.isChecked()) {
                    getSharedPreferences("qv", MODE_PRIVATE).edit()
                            .putBoolean("skip_fullbg_perm", true).apply();
                    Log2.i("用户勾选不再提示：skip_fullbg_perm");
                }
                ui.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        if (!uiDead()) next.run();
                    }
                }, 200);
            }
        });
        dlg.show();
    }

    /** 通知权限弹窗：上面是"我已开启，下一步"（会校验），下面是"去开启 / 以后再说"。 */
    private void showNotifPermDialog() {
        if (uiDead()) {
            preflightStage = 2;
            runPreflight();
            return;
        }
        float dp = getResources().getDisplayMetrics().density;
        int pad = (int) (dp * 18);
        final android.widget.LinearLayout box = new android.widget.LinearLayout(this);
        box.setOrientation(android.widget.LinearLayout.VERTICAL);
        box.setPadding(pad, (int) (dp * 8), pad, pad);
        TextView tv = new TextView(this);
        tv.setText("体检和翻新可能要跑几分钟。\n\n"
                + "开启通知后，通知栏会一直显示「进度 / 已测多少 / 还剩多少」，"
                + "锁屏或切到别的应用也能知道它还在跑。\n\n"
                + "不开通知：锁屏或切到别的应用之后就看不到进度了，"
                + "只能回到软件里看；部分系统也更容易把这个后台任务杀掉。");
        tv.setTextSize(13.5f);
        tv.setTextColor(0xFFF0F3F8);
        tv.setTextIsSelectable(true);
        box.addView(tv);

        final android.widget.CheckBox cb = new android.widget.CheckBox(this);
        cb.setText("不再提示（以后不再问这一项）");
        cb.setTextColor(0xFFF0F3F8);
        cb.setTextSize(13f);
        cb.setPadding(0, (int) (dp * 12), 0, 0);
        box.addView(cb);

        final AlertDialog dlg = new AlertDialog.Builder(this)
                .setTitle("先开通知权限")
                .setView(box)
                .setPositiveButton("去开启", null)
                .setNegativeButton("以后再说", null)
                .create();
        // 覆盖默认点击：点"去开启"只去设置，弹窗不关闭
        dlg.setOnShowListener(new android.content.DialogInterface.OnShowListener() {
            @Override
            public void onShow(android.content.DialogInterface d) {
                ((AlertDialog) d).getButton(android.content.DialogInterface.BUTTON_POSITIVE)
                        .setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                openNotificationSettings();
                            }
                        });
            }
        });

        // 上面那个大按钮：先校验，真开了才放行
        Button done = new Button(this);
        done.setText("我已开启，下一步");
        done.setAllCaps(false);
        done.setTextSize(14f);
        done.setTextColor(0xFFF0F3F8);
        done.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!TunnelService.notificationsAllowed(MainActivity.this)) {
                    new AlertDialog.Builder(MainActivity.this)
                            .setTitle("权限还没开启成功")
                            .setMessage("系统里还是没检测到本应用的通知权限。\n\n"
                                    + "请点下面的「去开启」，在系统设置里把「允许通知」打开后再回来。")
                            .setPositiveButton("知道了", null)
                            .show();
                    return;
                }
                try {
                    dlg.dismiss();      // 校验通过 → onDismiss 继续
                } catch (Throwable ignored) {
                }
            }
        });
        android.widget.LinearLayout.LayoutParams dlp = new android.widget.LinearLayout.LayoutParams(
                android.widget.LinearLayout.LayoutParams.MATCH_PARENT, (int) (dp * 44));
        dlp.topMargin = (int) (dp * 10);
        box.addView(done, dlp);

        dlg.setOnDismissListener(new android.content.DialogInterface.OnDismissListener() {
            @Override
            public void onDismiss(android.content.DialogInterface d) {
                if (cb.isChecked()) {
                    getSharedPreferences("qv", MODE_PRIVATE).edit()
                            .putBoolean("skip_notif_perm", true).apply();
                    Log2.i("用户勾选不再提示：skip_notif_perm");
                }
                preflightStage = 2;
                ui.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        if (!uiDead()) runPreflight();
                    }
                }, 200);
            }
        });
        dlg.show();
    }

    private int permGoPendingStage = 0;   // 从系统设置返回后要重新检查的阶段（1通知/2电池/3完全后台）

    private void openNotificationSettings() {
        try {
            if (android.os.Build.VERSION.SDK_INT >= 33) {
                requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"}, 320);
            } else {
                Intent i = new Intent(android.provider.Settings.ACTION_APP_NOTIFICATION_SETTINGS);
                i.putExtra("android.provider.extra.APP_PACKAGE", getPackageName());
                startActivity(i);
            }
        } catch (Throwable t) {
            try {
                Intent i2 = new Intent(android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
                i2.setData(android.net.Uri.parse("package:" + getPackageName()));
                startActivity(i2);
            } catch (Throwable ignored) {
            }
        }
    }

    private boolean skipOnce(String key) {
        return getSharedPreferences("qv", MODE_PRIVATE).getBoolean(key, false);
    }

    private void runPreflight() {
        try {
            if (preflightStage == 1) {
                boolean ok = TunnelService.notificationsAllowed(this) || preflightNotifDeclined
                        || skipOnce("skip_notif_perm");
                if (ok) {
                    preflightStage = 2;
                    runPreflight();
                    return;
                }
                showNotifPermDialog();
                return;
            }
            if (preflightStage == 2) {
                boolean ignoring = false;
                try {
                    android.os.PowerManager pm = (android.os.PowerManager) getSystemService(POWER_SERVICE);
                    ignoring = pm != null && pm.isIgnoringBatteryOptimizations(getPackageName());
                } catch (Throwable ignored) {
                }
                if (ignoring || skipOnce("skip_battery_perm")) {
                    preflightStage = 3;
                    runPreflight();
                    return;
                }
                askPermWithSkip("先把电池优化关掉",
                        "系统的「电池优化」会限制后台运行。\n\n"
                                + "不关的话：锁屏或切到别的应用后，体检可能被冻结/杀掉，"
                                + "进度卡住不动，看起来像「没在体检」。\n\n"
                                + "关掉它只是让系统别限制本应用，不影响续航设置本身。",
                        "去关掉", new Runnable() {
                            @Override
                            public void run() {
                                try {
                                    Intent i = new Intent(android.provider.Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS);
                                    i.setData(android.net.Uri.parse("package:" + getPackageName()));
                                    startActivity(i);
                                } catch (Throwable t) {
                                    try {
                                        startActivity(new Intent(android.provider.Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS));
                                    } catch (Throwable ignored) {
                                    }
                                }
                            }
                        }, "我已在设置里关掉，继续",
                        "skip_battery_perm", new Runnable() {
                            @Override
                            public void run() {
                                preflightStage = 3;
                                runPreflight();
                            }
                        });
                return;
            }
            if (preflightStage == 3) {
                boolean need = isColorOsFamily() && !skipOnce("skip_fullbg_perm")
                        && !skipOnce("fullbg_ok");      // 已确认开过的就不再问
                if (need) {
                    showFullBgPermDialog(new Runnable() {
                        @Override
                        public void run() {
                            preflightStage = 4;
                            runPreflight();
                        }
                    });
                    return;
                }
            }
            Runnable r = preflightNext;
            preflightNext = null;
            if (r != null) r.run();
        } catch (Throwable t) {
            Runnable r = preflightNext;
            preflightNext = null;
            if (r != null) r.run();
        }
    }

    private boolean isColorOsFamily() {
        String b = (android.os.Build.BRAND + " " + android.os.Build.MANUFACTURER).toLowerCase();
        return b.contains("oppo") || b.contains("oneplus") || b.contains("realme") || b.contains("oplus")
                || b.contains("vivo") || b.contains("iqoo");
    }

    /** 通知被关时：先把提醒弹出来，用户看完关掉后再执行 next（否则会被进度窗盖住）。 */
    private void ensureNotificationsThen(final Runnable next) {
        try {
            if (TunnelService.notificationsAllowed(this)) {
                next.run();
                return;
            }
            if (isFinishing()) {
                next.run();
                return;
            }
            final boolean[] ran = {false};
            AlertDialog d = new AlertDialog.Builder(this)
                    .setTitle("通知被关闭了")
                    .setMessage("翻新和体检的进度是靠通知栏显示的。\n\n"
                            + "现在系统不允许本应用发通知，所以锁屏或切到别的应用后看不到进度，"
                            + "只能回到软件里看。\n\n点「去开启」把通知打开；"
                            + "不想开就点「先这样」，继续翻新/体检。")
                    .setPositiveButton("去开启", new android.content.DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(android.content.DialogInterface dlg, int w) {
                            try {
                                Intent i = new Intent(android.provider.Settings.ACTION_APP_NOTIFICATION_SETTINGS);
                                i.putExtra("android.provider.extra.APP_PACKAGE", getPackageName());
                                startActivity(i);
                            } catch (Throwable t) {
                                try {
                                    Intent i2 = new Intent(android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
                                    i2.setData(android.net.Uri.parse("package:" + getPackageName()));
                                    startActivity(i2);
                                } catch (Throwable ignored) {
                                }
                            }
                        }
                    })
                    .setNegativeButton("先这样", null)
                    .create();
            d.setOnDismissListener(new android.content.DialogInterface.OnDismissListener() {
                @Override
                public void onDismiss(android.content.DialogInterface dlg) {
                    if (ran[0]) return;
                    ran[0] = true;
                    ui.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            if (!uiDead()) next.run();
                        }
                    }, 150);
                }
            });
            d.show();
        } catch (Throwable t) {
            try {
                next.run();
            } catch (Throwable ignored) {
            }
        }
    }

    private void ensureNotificationsForBackground() {
        try {
            if (TunnelService.notificationsAllowed(this)) return;
            if (isFinishing()) return;
            new AlertDialog.Builder(this)
                    .setTitle("通知被关闭了")
                    .setMessage("翻新和体检的进度是靠通知栏显示的。\n\n"
                            + "现在系统不允许本应用发通知，所以你看不到进度，"
                            + "也可能以为它在后台没跑。\n\n请点「去开启」，把通知打开。")
                    .setPositiveButton("去开启", new android.content.DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(android.content.DialogInterface d, int w) {
                            try {
                                Intent i = new Intent(android.provider.Settings.ACTION_APP_NOTIFICATION_SETTINGS);
                                i.putExtra("android.provider.extra.APP_PACKAGE", getPackageName());
                                startActivity(i);
                            } catch (Throwable t) {
                                try {
                                    Intent i2 = new Intent(android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
                                    i2.setData(android.net.Uri.parse("package:" + getPackageName()));
                                    startActivity(i2);
                                } catch (Throwable ignored) {
                                }
                            }
                        }
                    })
                    .setNegativeButton("先这样", null)
                    .show();
        } catch (Throwable ignored) {
        }
    }

    private void doneGuide() {
        guideStep = 0;
        try {
            if (guideDialog != null && guideDialog.isShowing()) guideDialog.dismiss();
        } catch (Throwable ignored) {
        }
        guideDialog = null;
        getSharedPreferences("qv", MODE_PRIVATE).edit().putBoolean(PREF_BG_GUIDED, true).apply();
        toast("设置完成：每天 " + hoursText() + " 自动翻新，到点后不需要打开 App");
    }

    /** 当前手机品牌（用于引导文案）。 */
    private boolean isSamsung() {
        String b = (android.os.Build.BRAND + " " + android.os.Build.MANUFACTURER).toLowerCase();
        return b.contains("samsung");
    }

    /** 第 4 步那句"别走进电池优化列表"的提醒，只在路径会经过"电池"页的品牌才显示。 */
    private boolean needsBatteryOptimizeHint() {
        String b = (android.os.Build.BRAND + " " + android.os.Build.MANUFACTURER).toLowerCase();
        if (b.contains("xiaomi") || b.contains("redmi") || b.contains("poco")) return false;   // 走「省电策略」
        if (b.contains("meizu")) return false;                                                  // 走手机管家
        return true;   // OPPO/华为/vivo/三星/其它：路径会经过「电池」，容易误入优化列表
    }

    private String vendorName() {
        String brand = (android.os.Build.BRAND + " " + android.os.Build.MANUFACTURER).toLowerCase();
        if (brand.contains("oppo") || brand.contains("oneplus") || brand.contains("realme") || brand.contains("oplus")) return "OPPO / ColorOS";
        if (brand.contains("xiaomi") || brand.contains("redmi") || brand.contains("poco")) return "小米 / 红米";
        if (brand.contains("huawei") || brand.contains("honor")) return "华为 / 荣耀";
        if (brand.contains("vivo") || brand.contains("iqoo")) return "vivo / iQOO";
        if (brand.contains("samsung")) return "三星";
        if (brand.contains("meizu")) return "魅族";
        if (brand.contains("asus")) return "华硕";
        return "Android";
    }

    /** 这个品牌的自启动开关是否通常在"应用详情页"里。 */
    private String batteryPath() {
        String brand = (android.os.Build.BRAND + " " + android.os.Build.MANUFACTURER).toLowerCase();
        if (brand.contains("oppo") || brand.contains("oneplus") || brand.contains("realme") || brand.contains("oplus")) {
            return "设置 → 应用管理 → 命令方块 → 耗电管理 → 允许完全后台行为\n"
                    + "（ColorOS 12 以前这一项可能叫「电池」「应用耗电管理」或「后台活动」，"
                    + "选「允许完全后台 / 不受限制」即可）";
        }
        if (brand.contains("xiaomi") || brand.contains("redmi") || brand.contains("poco")) {
            return "设置 → 应用设置 → 应用管理 → 命令方块 → 省电策略 → 无限制\n"
                    + "（也可在 手机管家 → 电池 → 应用智能省电 → 命令方块 → 无限制）";
        }
        if (brand.contains("huawei") || brand.contains("honor")) {
            return "设置 → 应用和服务 → 应用启动管理 → 命令方块 → 手动管理\n"
                    + "（把「自启动」「关联启动」「后台活动」三个开关都打开）\n"
                    + "（EMUI 及部分版本：设置 → 电池 → 应用启动管理）";
        }
        if (brand.contains("vivo") || brand.contains("iqoo")) {
            return "设置 → 电池 → 后台耗电管理 → 命令方块 → 允许后台高耗电\n"
                    + "（部分 Funtouch 版本叫「后台高耗电」，也可能在 i 管家 → 应用管理 → 后台高耗电）";
        }
        if (brand.contains("samsung")) {
            return "设置 → 应用 → 命令方块 → 电池 → 不受限制\n"
                    + "（One UI 4 及以前：设置 → 电池和设备维护 → 电池 → 后台使用限制 → "
                    + "把命令方块从「休眠应用 / 深度休眠应用」里移除）";
        }
        if (brand.contains("meizu")) {
            return "手机管家 → 权限管理 → 后台管理 → 命令方块 → 允许后台运行";
        }
        return "设置 → 应用 → 命令方块 → 电池 → 不受限制";
    }

    private String autoStartPath() {
        String brand = (android.os.Build.BRAND + " " + android.os.Build.MANUFACTURER).toLowerCase();
        if (brand.contains("oppo") || brand.contains("oneplus") || brand.contains("realme") || brand.contains("oplus")) {
            return "OPPO / 一加 / 真我（ColorOS）：\n"
                    + "设置 → 应用管理 → 命令方块 → 允许自启动\n"
                    + "（部分 ColorOS 版本这一项在应用详情页的子目录里：命令方块 → 耗电管理 → 允许自启动；"
                    + "也可以在 手机管家 → 权限隐私 → 自启动管理 里开）";
        }
        if (brand.contains("xiaomi") || brand.contains("redmi") || brand.contains("poco")) {
            return "小米 / 红米（MIUI / HyperOS）：\n"
                    + "设置 → 应用设置 → 应用管理 → 命令方块 → 权限 → 后台自启动\n"
                    + "（较早版本：应用详情页里直接有「自启动」；"
                    + "也可以走 手机管家 → 应用管理 → 权限 → 自启动）";
        }
        if (brand.contains("huawei") || brand.contains("honor")) {
            return "华为 / 荣耀：\n"
                    + "设置 → 应用和服务 → 应用启动管理 → 命令方块 → 手动管理\n"
                    + "（把「自启动」「关联启动」「后台活动」三个开关都打开；"
                    + "EMUI 及部分版本：设置 → 电池 → 应用启动管理）";
        }
        if (brand.contains("vivo") || brand.contains("iqoo")) {
            return "vivo / iQOO：\n"
                    + "设置 → 应用与权限 → 权限管理 → 自启动 → 命令方块\n"
                    + "（部分 Funtouch 版本：设置 → 更多设置 → 应用 → 自启动；"
                    + "也可能在 i 管家 → 应用管理 → 自启动管理）";
        }
        if (brand.contains("samsung")) {
            return "三星（One UI）：\n"
                    + "设置 → 电池和设备维护 → 电池 → 后台使用限制 → 自动运行应用程序 → 命令方块\n"
                    + "（三星没有叫「自启动」的开关，就是这个；"
                    + "新版 One UI 在「后台使用限制」的休眠应用列表里把命令方块移除）";
        }
        if (brand.contains("meizu")) {
            return "魅族（Flyme）：\n"
                    + "手机管家 → 权限管理 → 自启动管理 → 命令方块";
        }
        return "设置 → 应用 → 命令方块 → 电池 / 权限里允许后台运行";
    }

    private void showBootGuide() {
        String brand = (android.os.Build.BRAND + " " + android.os.Build.MANUFACTURER).toLowerCase();
        String path;
        if (brand.contains("oppo") || brand.contains("oplus") || brand.contains("oneplus") || brand.contains("realme")) {
            path = "OPPO / 一加 / 真我（ColorOS）：\n"
                    + "① 设置 → 应用管理 → 命令方块 → 耗电管理\n"
                    + "　→ 打开「允许自启动」\n"
                    + "　→ 同时打开「允许完全后台行为」\n"
                    + "\n② 不同 ColorOS 版本位置不同：有的机型在「应用详情页」里\n"
                    + "　就能直接看到「允许自启动」，不用进耗电管理；\n"
                    + "　有的机型这一项叫「电池」「应用耗电管理」或「后台活动」，\n"
                    + "　选项叫「不受限制」也选它。\n"
                    + "　两处都按上面名字找，找到哪一处就开哪一处。";
        } else if (brand.contains("xiaomi") || brand.contains("redmi") || brand.contains("poco")) {
            path = "小米 / 红米（MIUI / HyperOS）：\n"
                    + "设置 → 应用设置 → 应用管理 → 命令方块 → 自启动（打开）\n"
                    + "设置 → 应用设置 → 应用管理 → 命令方块 → 省电策略 → 无限制";
        } else if (brand.contains("huawei") || brand.contains("honor")) {
            path = "华为 / 荣耀（EMUI / MagicOS）：\n"
                    + "设置 → 应用 → 应用启动管理 → 命令方块 → 手动管理（自启动、关联启动、后台活动全开）\n"
                    + "手机管家 → 应用启动管理";
        } else if (brand.contains("vivo") || brand.contains("iqoo")) {
            path = "vivo / iQOO（OriginOS）：\n"
                    + "设置 → 应用与权限 → 权限管理 → 自启动（打开）\n"
                    + "设置 → 电池 → 后台耗电管理 → 命令方块 → 允许后台高耗电";
        } else if (brand.contains("samsung")) {
            path = "三星（One UI）：\n"
                    + "设置 → 应用程序 → 命令方块 → 电池 → 不受限制\n"
                    + "设置 → 电池和设备维护 → 电池 → 后台使用限制 → 从休眠列表中移除";
        } else {
            path = "原生 / 其它 Android：\n"
                    + "设置 → 应用 → 命令方块 → 电池 → 不受限制（Unrestricted）\n"
                    + "部分机型还需在「自启动管理」里允许本应用";
        }
        new AlertDialog.Builder(this)
                .setTitle("开机自启需要你手动设置")
                .setMessage("系统默认会拦截第三方应用的开机和后台自启。\n\n"
                        + path + "\n\n"
                        + "⚠ 必须打开开机自启，否则每次开机都要手动点一次本应用；\n"
                        + "　 不手动启动的话，开机后就不会自动更新节点（直到你打开一次）。\n"
                        + "设置完回到这里即可，不需要额外操作。")
                .setPositiveButton("知道了", null)
                .show();
    }

    /** 点「翻新节点」：先问要搜寻几个来源（1~5）。 */
    private void askRefreshSourceCount() {
        // 不管是点按钮还是首启引导进来的，都先过一遍权限检查
        if (!preflightDone) {
            preflightThen(new Runnable() {
                @Override
                public void run() {
                    preflightDone = true;
                    askRefreshSourceCount();
                }
            });
            return;
        }
        preflightDone = false;
        if (refreshRunning) {
            toast("正在翻新中，请稍等…");
            return;
        }
        if (TunnelService.isScanning()) {
            toast("正在体检中，请等体检结束（或点「结束体检」）再翻新");
            return;
        }
        final boolean vpnOn = TunnelService.isRunning() || TunnelService.isConnecting();
        final java.util.List<String[]> srcList = SourceStore.list(this);
        if (srcList.isEmpty()) {
            toast("还没有节点源，先去「节点源」页添加或重置");
            return;
        }
        final int max = srcList.size();
        android.widget.LinearLayout box = new android.widget.LinearLayout(this);
        box.setOrientation(android.widget.LinearLayout.VERTICAL);
        int pad = (int) (getResources().getDisplayMetrics().density * 18);
        box.setPadding(pad, pad, pad, pad);

        final TextView title = new TextView(this);
        title.setText("将搜寻 " + max + " 个节点来源");
        title.setTextSize(16f);
        title.setTextColor(0xFFF0F3F8);
        box.addView(title);

        final boolean firstTime = NodeStore.totalCount(this) <= 0;
        final android.widget.SeekBar bar = new android.widget.SeekBar(this);
        bar.setMax(max - 1);
        bar.setProgress(max - 1);   // 默认全部
        android.widget.LinearLayout.LayoutParams lp = new android.widget.LinearLayout.LayoutParams(
                android.widget.LinearLayout.LayoutParams.MATCH_PARENT, android.widget.LinearLayout.LayoutParams.WRAP_CONTENT);
        lp.topMargin = pad;
        box.addView(bar, lp);

        final TextView list = new TextView(this);
        list.setTextSize(12f);
        list.setTextColor(0xFF8A93A6);
        list.setPadding(0, pad / 2, 0, 0);
        box.addView(list);

        final android.widget.CheckBox doScan = new android.widget.CheckBox(this);
        doScan.setText("翻新后立即体检并识别 IP");
        doScan.setChecked(true);


        doScan.setTextSize(14f);
        doScan.setTextColor(0xFFF0F3F8);
        doScan.setPadding(0, pad / 2, 0, 0);
        box.addView(doScan);

        final TextView warn = new TextView(this);
        warn.setTextColor(0xFFE0B44A);
        final Runnable updateWarn = new Runnable() {
            @Override
            public void run() {
                int k = bar.getProgress() + 1;
                String base = "⚠ 搜寻的来源越多，花的时间就越久。";
                if (doScan.isChecked()) {
                    warn.setText(base + "\n勾选了「翻新后立即体检并识别 IP」，这一步最慢"
                            + "（节点越多越久），不勾选会快很多。"
                            + "\n\n到体检这一步会自动断开本应用内的 VPN；"
                            + "请确保没有开启「外部应用的 VPN」，否则会影响体检结果。");
                } else {
                    warn.setText(base + "\n未勾选体检：只下载导入，速度很快，"
                            + "但新节点能不能用/在哪个地区都不知道，之后要自己到 VPN 页点体检。");
                }
            }
        };
        warn.setTextSize(12f);
        warn.setPadding(0, pad / 2, 0, 0);
        box.addView(warn);
        doScan.setOnCheckedChangeListener(new android.widget.CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(final android.widget.CompoundButton b, boolean checked) {
                if (!checked) {
                    askSkipScanWarn("不体检了？",
                            "取消体检后，翻新导入的节点不会做可用性检测，也不会识别地区。\n\n"
                                    + "结果是：列表里会混进大量连不上的节点，"
                                    + "连接某些国家时可能出现报错/连不上，"
                                    + "而且点连接时会更慢——内核会先把这些连不上的节点逐个试一遍，才轮到能用的那个。\n\n"
                                    + "之后可以在列表模式顶部点「体检」补做一次。",
                            new Runnable() {
                                @Override
                                public void run() {
                                    updateWarn.run();
                                    syncRefreshEta();
                                }
                            }, new Runnable() {
                                @Override
                                public void run() {
                                    b.setChecked(true);
                                    updateWarn.run();
                                    syncRefreshEta();
                                }
                            });
                    return;
                }
                updateWarn.run();
                syncRefreshEta();
            }
        });

        refreshBarRef = bar;
        refreshTitleRef = title;
        refreshScanRef = doScan;
        final Runnable refreshHint = new Runnable() {
            @Override
            public void run() {
                int k = bar.getProgress() + 1;
                syncRefreshEta();
                StringBuilder sb = new StringBuilder();
                for (int i = 0; i < k && i < srcList.size(); i++) {
                    sb.append(i + 1).append(". ").append(srcList.get(i)[0]).append('\n');
                }
                list.setText(sb.toString().trim());
                updateWarn.run();
            }
        };
        bar.setOnSeekBarChangeListener(new android.widget.SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(android.widget.SeekBar sb, int p, boolean fromUser) {
                refreshHint.run();
            }

            @Override
            public void onStartTrackingTouch(android.widget.SeekBar sb) {
                listTouching = true;      // 拖动时暂停列表重绘
            }

            @Override
            public void onStopTrackingTouch(android.widget.SeekBar sb) {
                listTouching = false;
            }
        });
        refreshHint.run();



        new AlertDialog.Builder(this)
                .setTitle("翻新节点")
                .setView(box)
                .setPositiveButton("开始翻新", new android.content.DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(android.content.DialogInterface d, int w) {
                        doRefreshNodes(bar.getProgress() + 1, doScan.isChecked());
                    }
                })
                .setNegativeButton("取消", null)
                .show();
    }

    private boolean refreshDoScan = true;

    private void doRefreshNodes(final int sourceCount) {
        doRefreshNodes(sourceCount, true);
    }

    private void doRefreshNodes(final int sourceCount, final boolean doScan) {
        refreshDoScan = doScan;
        if (RefreshRunner.isRunning()) {
            toast("已经在翻新中，显示当前进度");
            showRefreshMonitor();
            return;
        }
        refreshRunning = true;
        refreshCancel = false;
        refreshImported = 0;
        reallyStartRefresh(sourceCount, doScan);
    }

    /** 真正发起翻新（通知提醒处理完之后才走到这里）。 */
    private void reallyStartRefresh(final int sourceCount, final boolean doScan) {
        pendingRefreshSummary = doScan;      // 体检结果弹窗关掉后给"翻新完成"总结
        if (!TunnelService.startRefresh(this, sourceCount, doScan)) {
            refreshRunning = false;
            pendingRefreshSummary = false;
            toast("启动翻新失败");
            return;
        }
        refreshFinishHandled = false;
        refreshCancelRequested = false;
        showRefreshMonitor();
    }

    private String pendingReconnectCc = "";
    private boolean pendingReconnectFastest = false;

    /** 点"VPN 已断开"通知回来时，自动重连该国（相当于点该国闪电）。 */
    private void tryReconnectFromNotification() {
        if (pendingReconnectFastest) {
            pendingReconnectFastest = false;
            pendingReconnectCc = "";
            try {
                getSharedPreferences("qv", MODE_PRIVATE).edit()
                        .remove("reconnect_cc").remove("reconnect_fastest").apply();
            } catch (Throwable ignored) {
            }
            ui.postDelayed(new Runnable() {
                @Override
                public void run() {
                    Log2.i("通知点击返回：自动重连「最快地区」");
                    toast("正在重新连接「最快地区」…");
                    autoConnectFastest();
                }
            }, 800);
            return;
        }
        if (pendingReconnectCc == null || pendingReconnectCc.length() != 2) return;
        final String cc = pendingReconnectCc;
        pendingReconnectCc = "";
        try {
            getSharedPreferences("qv", MODE_PRIVATE).edit()
                    .remove("reconnect_cc").remove("reconnect_fastest").apply();
        } catch (Throwable ignored) {
        }
        ui.postDelayed(new Runnable() {
            @Override
            public void run() {
                for (Country c : countries) {
                    if (c.cc.equalsIgnoreCase(cc) && !c.nodes.isEmpty()) {
                        Log2.i("通知点击返回：自动重连「" + c.name + "」");
                        toast("正在重新连接「" + c.name + "」…");
                        connectCountryNow(c);
                        return;
                    }
                }
                toast("原来的国家节点已不在列表里，请重新选一个");
            }
        }, 800);
    }

    private AlertDialog refreshMon;
    private boolean refreshFinishHandled = false;    // 收尾只做一次（广播与 ticker 都会调）
    private boolean refreshCancelRequested = false;  // 用户点了取消

    private void dismissRefreshMonitorHard() {
        try {
            if (refreshMon != null && refreshMon.isShowing()) refreshMon.dismiss();
        } catch (Throwable ignored) {
        }
        dismissRefreshMonitor();
    }
    private TextView refreshMonText;
    private android.widget.ProgressBar refreshMonBar1;
    private android.widget.ProgressBar refreshMonBar2;
    private TextView refreshMonLabel1;
    private TextView refreshMonLabel2;

    private final Runnable refreshMonTicker = new Runnable() {
        @Override
        public void run() {
            try {
                if (refreshMon == null || !refreshMon.isShowing()) return;
                int total = Math.max(1, RefreshRunner.totalSources);
                int src = Math.min(RefreshRunner.curSource + 1, total);
                int pct = RefreshRunner.curPct;
                if (refreshMonText != null) {
                    refreshMonText.setText("正在获取第 " + src + "/" + total + " 个来源："
                            + (RefreshRunner.stage == null ? "" : RefreshRunner.stage) + "…\n"
                            + "已导入 " + RefreshRunner.imported + " 个新节点");
                }
                if (refreshMonLabel1 != null) refreshMonLabel1.setText("来源进度 " + src + " / " + total);
                if (refreshMonBar1 != null) {
                    refreshMonBar1.setMax(total * 1000);
                    refreshMonBar1.setProgress(Math.min(total * 1000, (src - 1) * 1000 + pct * 10));
                }
                if (refreshMonLabel2 != null) {
                    String d = RefreshRunner.stageDetail;
                    refreshMonLabel2.setText(pct > 0
                            ? ("本来源节点解析 " + pct + "%")
                            : (d != null && d.length() > 0 ? ("本来源：" + d) : "本来源：下载中…"));
                }
                if (refreshMonBar2 != null) refreshMonBar2.setProgress(Math.min(1000, pct * 10));
                if (!RefreshRunner.isRunning()) {
                    onRefreshMonitorFinished();
                    return;
                }
            } catch (Throwable ignored) {
            }
            ui.postDelayed(this, 500);
        }
    };

    /** 显示/复用"翻新进行中"的进度窗（前台手动与后台自动共用同一份状态）。 */
    private void showRefreshMonitor() {
        if (uiDead()) return;
        // 如果是"打开 App 时接管后台任务"（自动翻新），体检意图以服务端为准
        if (!refreshRunning) refreshDoScan = TunnelService.refreshWantsScan(this);
        refreshFinishHandled = false;
        if (refreshMon != null && refreshMon.isShowing()) {
            ui.removeCallbacks(refreshMonTicker);
            ui.post(refreshMonTicker);
            return;
        }
        float dp = getResources().getDisplayMetrics().density;
        android.widget.LinearLayout box = new android.widget.LinearLayout(this);
        box.setOrientation(android.widget.LinearLayout.VERTICAL);
        int pad = (int) (dp * 18);
        box.setPadding(pad, pad, pad, pad);

        refreshMonText = new TextView(this);
        refreshMonText.setText("正在翻新节点…");
        refreshMonText.setTextSize(14f);
        refreshMonText.setTextColor(0xFFF0F3F8);
        box.addView(refreshMonText);

        refreshMonLabel1 = new TextView(this);
        refreshMonLabel1.setText("来源进度 1 / 1");
        refreshMonLabel1.setTextSize(12f);
        refreshMonLabel1.setTextColor(0xFFB7BFCF);
        refreshMonLabel1.setPadding(0, (int) (dp * 12), 0, (int) (dp * 4));
        box.addView(refreshMonLabel1);

        refreshMonBar1 = new android.widget.ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        refreshMonBar1.setMax(1000);
        box.addView(refreshMonBar1, new android.widget.LinearLayout.LayoutParams(
                android.widget.LinearLayout.LayoutParams.MATCH_PARENT, (int) (dp * 10)));

        refreshMonLabel2 = new TextView(this);
        refreshMonLabel2.setText("本来源节点解析 0%");
        refreshMonLabel2.setTextSize(12f);
        refreshMonLabel2.setTextColor(0xFFB7BFCF);
        refreshMonLabel2.setPadding(0, (int) (dp * 12), 0, (int) (dp * 4));
        box.addView(refreshMonLabel2);

        refreshMonBar2 = new android.widget.ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        refreshMonBar2.setMax(1000);
        box.addView(refreshMonBar2, new android.widget.LinearLayout.LayoutParams(
                android.widget.LinearLayout.LayoutParams.MATCH_PARENT, (int) (dp * 10)));

        refreshMon = new AlertDialog.Builder(this)
                .setTitle("翻新节点")
                .setView(box)
                .setCancelable(false)
                .setNegativeButton("取消", new android.content.DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(android.content.DialogInterface d, int w) {
                        RefreshRunner.cancel();
                        refreshCancelRequested = true;
                        status.setText("正在取消翻新…");
                        dismissRefreshMonitorHard();
                        toast("正在取消翻新…");
                    }
                })
                .create();
        refreshMon.show();
        ui.removeCallbacks(refreshMonTicker);
        ui.post(refreshMonTicker);
    }

    private void dismissRefreshMonitor() {
        try {
            ui.removeCallbacks(refreshMonTicker);
        } catch (Throwable ignored) {
        }
        try {
            if (refreshMon != null && refreshMon.isShowing()) refreshMon.dismiss();
        } catch (Throwable ignored) {
        }
        refreshMon = null;
        refreshMonText = null;
        refreshMonBar1 = null;
        refreshMonBar2 = null;
        refreshMonLabel1 = null;
        refreshMonLabel2 = null;
    }

    /** 翻新结束：刷新列表，按需体检或弹总结。 */
    private void onRefreshMonitorFinished() {
        if (uiDead()) return;
        if (refreshFinishHandled) return;      // ticker 与广播都会调，别收尾两次
        refreshFinishHandled = true;
        refreshCancelRequested = false;
        boolean cancelled = RefreshRunner.cancelled;
        int n = RefreshRunner.imported;
        refreshImported = n;
        refreshRunning = false;
        dismissRefreshMonitor();
        try {
            NodeStore.reload(this);
            countries = NodeStore.countries(this, editMode && showHiddenInEdit);
            adapter.notifyDataSetChanged();
            updateStats();
        } catch (Throwable ignored) {
        }
        if (n > 0) status.setText("已导入 " + n + " 个新节点");
        else status.setText("翻新结束：没有新节点");
        if (n == 0 && RefreshRunner.okSources == 0 && !cancelled) {
            // 一个源都没下载成功：这基本是网络问题，别让用户对着"没有新节点"猜
            new AlertDialog.Builder(this)
                    .setTitle("所有来源都没下载成功")
                    .setMessage("5 个节点源里，成功下载的有 0 个。\n\n"
                            + "常见原因：\n"
                            + "· 当前网络访问 GitHub 被拦（国内宽带/移动网络常见）\n"
                            + "· 学校/公司网络限制\n\n"
                            + "可以试：\n"
                            + "· 先连上 VPN 再翻新\n"
                            + "· 换一个网络（Wi-Fi ↔ 移动数据）\n"
                            + "· 稍后再试（源站偶尔也会抽风）")
                    .setPositiveButton("知道了", null)
                    .show();
            pendingRefreshSummary = false;
            return;
        }
        if (refreshDoScan && !cancelled) {
            // 体检由前台服务接力；这里轮询等待它真正开始，然后把体检进度窗弹出来
            status.setText("翻新完成，正在体检…");
            Toast.makeText(this, "翻新完成，接着体检", Toast.LENGTH_SHORT).show();
            waitForScanThenShow(24);      // 最多等 12 秒
        } else {
            pendingRefreshSummary = false;
            showRefreshSummaryNoScan(n);
        }
    }

    /** 旧版活动内翻新线程：已由前台服务 + RefreshRunner 取代，保留方法不再调用。 */
    private void doRefreshNodesLegacy(final int sourceCount, final boolean doScan) {
        refreshDoScan = doScan;
        if (refreshRunning) {
            toast("正在翻新中，请稍等…");
            return;
        }
        refreshRunning = true;
        refreshCancel = false;
        refreshImported = 0;
        refreshSkip.setLength(0);
        showRefreshProgress("正在获取节点列表…");
        new Thread(new Runnable() {
            @Override
            public void run() {
                int imported = 0;
                int okSources = 0;
                StringBuilder errs = new StringBuilder();
                java.util.Set<String> seen = new java.util.HashSet<String>();
                final int useCount = Math.max(1, Math.min(sourceCount, REFRESH_SOURCES.length));
                for (int si = 0; si < useCount; si++) {
                    if (refreshCancel) break;
                    final int idx = si + 1;
                    final String label = REFRESH_SOURCES[si][0];
                    refreshBase = "正在获取第 " + idx + "/" + useCount + " 个来源：" + label + "…";
                    refreshPct = 0;
                    refreshDoneSources = si;
                    refreshTotalSources = useCount;
                    long srcStart = System.currentTimeMillis();
                    String body = httpGet(REFRESH_SOURCES[si][1], 12000);   // 12 秒拿不到就跳过
                    if (body == null || body.length() == 0) {
                        errs.append(label).append(" 超时; ");
                        Log2.w("翻新源失败（已跳过）：" + label
                                + " 耗时 " + (System.currentTimeMillis() - srcStart) + "ms");
                        refreshSkip.append(label).append(' ');
                        continue;
                    }
                    okSources++;
                    final java.util.Map<String, String> ccBatch = new java.util.HashMap<String, String>();
                    String text = body;
                    try {
                        String clean = body.replaceAll("\\s", "");
                        String dec = new String(android.util.Base64.decode(clean, android.util.Base64.DEFAULT), "UTF-8");
                        if (dec.contains("://")) text = dec;
                    } catch (Throwable ignored) {
                        // 不是 base64 就用原文
                    }
                    String[] lineArr = text.split("\\r?\\n");
                    final int lineTotal = Math.max(1, lineArr.length);
                    // 先收集候选行，最后一次性写盘（逐个写会 O(n²)，几千个会直接闪退）
                    java.util.LinkedHashSet<String> candidates = new java.util.LinkedHashSet<String>();
                    String hint = REFRESH_SOURCES[si].length > 2 ? REFRESH_SOURCES[si][2] : "";
                    int lineIdx = 0;
                    for (String raw : lineArr) {
                        lineIdx++;
                        if ((lineIdx % 200) == 0) {
                            refreshPct = (int) (100L * lineIdx / lineTotal);
                            refreshDoneSources = si;
                            refreshTotalSources = useCount;
                        }
                        if (refreshCancel) break;
                        String line = raw.trim();
                        if (line.length() < 10 || !line.contains("://")) continue;
                        if (!seen.add(line)) continue;
                        candidates.add(line);
                    }
                    java.util.Set<String> existing = NodeStore.allUris(MainActivity.this);
                    java.util.Set<String> purgedNow = NodeStore.purgedUris(MainActivity.this);
                    java.util.Set<String> trashedNow = NodeStore.trashedUris(MainActivity.this);
                    java.util.List<String> toAdd = new java.util.ArrayList<String>();
                    for (String line : candidates) {
                        if (imported >= REFRESH_MAX_IMPORT) break;
                        if (existing.contains(line)) continue;
                        try {
                            // 回收站 / 隐藏 里的节点：跳过；
                            // 永久删除的不算"列表里有"，允许重新导入（导回来即恢复）
                            if (trashedNow.contains(line)) continue;
                            if (NodeStore.isBlacklisted(MainActivity.this, line)) continue;
                            if (purgedNow.contains(line)) NodeStore.unpurge(MainActivity.this, line);
                            String dcc = (hint != null && hint.length() == 2) ? hint : guessCc(line);
                            Node nd = new Node(line, dcc.length() == 2 ? dcc : "ZZ", "");
                            if (!nd.supported) continue;
                            toAdd.add(line);
                            if (hint != null && hint.length() == 2) ccBatch.put(line, hint);
                            imported++;
                        } catch (Throwable ignored) {
                        }
                    }
                    int addedNow = NodeStore.addImportedBatch(MainActivity.this, toAdd);
                    NodeStore.addShownBatch(MainActivity.this, toAdd);
                    refreshProgress = imported;
                    refreshPct = 100;
                    Log2.i("来源 " + REFRESH_SOURCES[si][0] + " 批量导入 " + addedNow + " 个（累计 " + imported + "）");
                    NodeStore.setImportedCcBatch(MainActivity.this, ccBatch);
                    refreshProgress = imported;
                    Log2.i("翻新源 " + label + " 处理完，累计新节点 " + imported);
                }
                final int n = imported;
                final int ok = okSources;
                final String err = errs.toString();
                ui.post(new Runnable() {
                    @Override
                    public void run() {
                        refreshRunning = false;
                        refreshImported = n;
                        dismissRefreshProgress();
                        try {
                            NodeStore.reload(MainActivity.this);
                            countries = NodeStore.countries(MainActivity.this, editMode && showHiddenInEdit);
                            adapter.notifyDataSetChanged();
                            updateStats();
                        } catch (Throwable ignored) {
                        }
                        String skipped = refreshSkip.toString().trim();
                        if (ok == 0) {
                            toast("所有来源都获取失败：" + err);
                        } else if (n > 0) {
                            toast("已从 " + ok + " 个来源导入 " + n + " 个新节点"
                                    + (skipped.length() > 0 ? "（跳过：" + skipped + "）" : ""));
                            status.setText("已导入 " + n + " 个新节点，开始体检…");
                        } else {
                            toast("目前还没有新节点哦~");
                            status.setText("目前还没有新节点，开始体检…");
                        }
                        if (refreshDoScan && !refreshCancel) {
                            startScanForRefresh();
                        } else {
                            pendingRefreshSummary = false;
                            status.setText("已导入 " + n + " 个新节点（未体检）");
                            showRefreshSummaryNoScan(n);
                        }
                    }
                });
            }
        }, "refresh-nodes").start();
    }

    private String httpGet(String url, int timeoutMs) {
        java.net.HttpURLConnection c = null;
        try {
            c = (java.net.HttpURLConnection) new java.net.URL(url).openConnection();
            c.setConnectTimeout(timeoutMs / 2);
            c.setReadTimeout(timeoutMs);
            c.setRequestProperty("User-Agent", "Mozilla/5.0");
            c.setInstanceFollowRedirects(true);
            int code = c.getResponseCode();
            if (code != 200) return null;
            java.io.InputStream in = c.getInputStream();
            java.io.ByteArrayOutputStream bos = new java.io.ByteArrayOutputStream();
            byte[] buf = new byte[8192];
            int len;
            while ((len = in.read(buf)) > 0) bos.write(buf, 0, len);
            in.close();
            return new String(bos.toByteArray(), "UTF-8");
        } catch (Throwable t) {
            Log2.w("HTTP 失败：" + t);
            return null;
        } finally {
            if (c != null) c.disconnect();
        }
    }

    private AlertDialog refreshDialog;
    private TextView refreshText;
    private android.widget.ProgressBar refreshBar;    // 来源数量进度
    private android.widget.ProgressBar refreshBar2;   // 当前来源的节点解析进度
    private TextView refreshLabel1;
    private TextView refreshLabel2;
    private volatile String refreshBase = "";
    private int refreshPct = 0;
    private int refreshDoneSources = 0;
    private int refreshTotalSources = 1;

    /** 每 600ms 刷新一次文字和进度条。 */
    private final Runnable refreshTicker = new Runnable() {
        @Override
        public void run() {
            try {
                if (refreshDialog == null || !refreshDialog.isShowing()) return;
                if (refreshText != null) {
                    String detail = RefreshRunner.stageDetail;
                    refreshText.setText((refreshBase == null ? "" : refreshBase)
                            + "\n" + (detail == null || detail.length() == 0
                            ? ("本来源解析 " + refreshPct + "%") : detail)
                            + "\n已导入 " + RefreshRunner.imported + " 个新节点");
                }
                updateRefreshBar(refreshTotalSources, refreshDoneSources, refreshPct);
            } catch (Throwable ignored) {
            }
            ui.postDelayed(this, 600);
        }
    };

    /** 总进度 = (已完成源数 + 当前源内百分比) / 总源数。 */
    private void updateRefreshBar(int totalSources, int doneSources, int curPct) {
        try {
            if (totalSources <= 0) return;
            // 第一个条：来源数量进度（第 1 个源 = 1/total）
            if (refreshBar != null) {
                refreshBar.setMax(totalSources * 1000);
                refreshBar.setProgress((int) Math.min(totalSources * 1000,
                        doneSources * 1000L + curPct * 10L));
            }
            if (refreshLabel1 != null) {
                refreshLabel1.setText("来源进度 " + Math.min(doneSources + 1, totalSources)
                        + " / " + totalSources);
            }
            // 第二个条：解析进度 / 写入节点进度
            boolean writing = RefreshRunner.writeTotal > 0
                    && RefreshRunner.writeDone < RefreshRunner.writeTotal;
            if (writing) {
                if (refreshBar2 != null) {
                    refreshBar2.setProgress((int) Math.min(1000,
                            1000L * RefreshRunner.writeDone / Math.max(1, RefreshRunner.writeTotal)));
                }
                if (refreshLabel2 != null) {
                    refreshLabel2.setText("写入节点 " + RefreshRunner.writeDone
                            + " / " + RefreshRunner.writeTotal);
                }
            } else {
                if (refreshBar2 != null) {
                    refreshBar2.setProgress(Math.max(0, Math.min(1000, curPct * 10)));
                }
                if (refreshLabel2 != null) {
                    refreshLabel2.setText("本来源节点解析 " + curPct + "%");
                }
            }
        } catch (Throwable ignored) {
        }
    }

    private void showRefreshProgress(String msg) {
        dismissRefreshProgress();
        android.widget.LinearLayout box = new android.widget.LinearLayout(this);
        box.setOrientation(android.widget.LinearLayout.VERTICAL);
        int pad = (int) (getResources().getDisplayMetrics().density * 20);
        box.setPadding(pad, pad, pad, pad);
        refreshText = new TextView(this);
        refreshText.setText(msg);
        refreshText.setTextSize(15f);
        refreshText.setTextColor(0xFFF0F3F8);
        box.addView(refreshText);

        float dp = getResources().getDisplayMetrics().density;

        refreshLabel1 = new TextView(this);
        refreshLabel1.setText("来源进度 0 / 1");
        refreshLabel1.setTextSize(12f);
        refreshLabel1.setTextColor(0xFFB7BFCF);
        refreshLabel1.setPadding(0, (int) (dp * 12), 0, (int) (dp * 4));
        box.addView(refreshLabel1);

        refreshBar = new android.widget.ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        refreshBar.setMax(1000);
        refreshBar.setProgress(0);
        try {
            refreshBar.setProgressTintList(android.content.res.ColorStateList.valueOf(Palette.green(this)));
        } catch (Throwable ignored) {
        }
        box.addView(refreshBar, new android.widget.LinearLayout.LayoutParams(
                android.widget.LinearLayout.LayoutParams.MATCH_PARENT, (int) (dp * 10)));

        refreshLabel2 = new TextView(this);
        refreshLabel2.setText("本来源节点解析 0%");
        refreshLabel2.setTextSize(12f);
        refreshLabel2.setTextColor(0xFFB7BFCF);
        refreshLabel2.setPadding(0, (int) (dp * 12), 0, (int) (dp * 4));
        box.addView(refreshLabel2);

        refreshBar2 = new android.widget.ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        refreshBar2.setMax(1000);
        refreshBar2.setProgress(0);
        try {
            refreshBar2.setProgressTintList(android.content.res.ColorStateList.valueOf(0xFF2F6FED));
        } catch (Throwable ignored) {
        }
        box.addView(refreshBar2, new android.widget.LinearLayout.LayoutParams(
                android.widget.LinearLayout.LayoutParams.MATCH_PARENT, (int) (dp * 10)));
        refreshDialog = new AlertDialog.Builder(this)
                .setTitle("翻新节点")
                .setView(box)
                .setCancelable(false)
                .setNegativeButton("取消", new android.content.DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(android.content.DialogInterface d, int w) {
                        refreshCancel = true;
                        status.setText("正在取消翻新…");
                    }
                })
                .create();
        refreshDialog.show();
        refreshBase = msg;
        refreshPct = 0;
        refreshDoneSources = 0;
        refreshProgress = 0;
        ui.removeCallbacks(refreshTicker);
        ui.post(refreshTicker);
    }

    private void dismissRefreshProgress() {
        try {
            ui.removeCallbacks(refreshTicker);
        } catch (Throwable ignored) {
        }
        try {
            if (refreshDialog != null && refreshDialog.isShowing()) refreshDialog.dismiss();
        } catch (Throwable ignored) {
        }
        refreshDialog = null;
        refreshText = null;
        refreshBar = null;
        refreshBar2 = null;
        refreshLabel1 = null;
        refreshLabel2 = null;
    }

    /** 翻新流程里的体检（与 VPN 页的体检完全一致）。 */
    private int scanForRefreshDisconnectTries = 0;

    private void startScanForRefresh() {
        if (TunnelService.isRunning() || TunnelService.isConnecting()) {
            if (scanForRefreshDisconnectTries >= 5) {
                // 断开一直没完成：别无限重试，直接按"未体检"收尾
                Log2.w("翻新：断开 VPN 超时，跳过体检");
                scanForRefreshDisconnectTries = 0;
                toast("断开 VPN 超时，本次没有做体检");
                pendingRefreshSummary = false;
                showRefreshSummaryNoScan(refreshImported);
                return;
            }
            scanForRefreshDisconnectTries++;
            status.setText("体检前先断开 VPN…");
            TunnelService.disconnect(this);
            ui.postDelayed(new Runnable() {
                @Override
                public void run() {
                    startScanForRefresh();
                }
            }, 1800);
            return;
        }
        scanForRefreshDisconnectTries = 0;
        int total = NodeStore.everything(this).size();
        if (total <= 0) {
            toast("没有可体检的节点");
            return;
        }
        if (TunnelService.isScanning()) {
            Log2.w("体检已在运行，本次翻新跳过体检环节");
            pendingRefreshSummary = false;
            showRefreshSummaryNoScan(refreshImported);
            return;
        }
        pendingRefreshSummary = true;
        showScanProgress(total);
        TunnelService.startScanTrashDead(this);   // 翻新体检：测不通的丢回收站
    }

    /** 没勾选体检时的总结。 */
    private void showRefreshSummaryNoScan(int imported) {
        StringBuilder m = new StringBuilder();
        m.append("本次翻新结果：\n\n");
        m.append("· 新增节点：").append(imported).append(" 个\n");
        m.append("· 未体检\n\n");
        if (imported > 0) {
            m.append("新节点已经加进列表了。\n\n");
            m.append("需要知道哪些能用、并把不能用的清掉，\n");
            m.append("可以稍后在 VPN 页面点「体检」。");
        } else {
            m.append("这次没有新节点。");
        }
        new AlertDialog.Builder(this)
                .setTitle("翻新完成")
                .setMessage(m.toString())
                .setPositiveButton("好的", null)
                .show();
    }

    /** 体检结果弹窗关闭后，翻新流程的总结。 */
    private void showRefreshSummary(int alive, int dead, String reportPath) {
        pendingRefreshSummary = false;
        StringBuilder m = new StringBuilder();
        m.append("本次翻新结果：\n\n");
        m.append("· 新增节点：").append(refreshImported).append(" 个\n");
        m.append("· 体检后可用：").append(alive).append(" 个");
        if (dead > 0) m.append("（不通 ").append(dead).append(" 个已丢进回收站）");
        m.append("\n\n");
        m.append(refreshImported > 0 ? "新节点已经加进列表，可以开始连接了。"
                : "这次没有新节点，但已经把现有节点重新体检了一遍。");
        if (reportPath != null && reportPath.length() > 0) {
            m.append("\n\n报告：").append(reportPath);
        }
        m.append("\n\n下次如果连不上，记得再来点一次「翻新节点」。");
        new AlertDialog.Builder(this)
                .setTitle("翻新完成")
                .setMessage(m.toString())
                .setPositiveButton("好的", null)
                .show();
    }

    private void showImportDialog() {
        new AlertDialog.Builder(this)
                .setTitle("节点文件")
                .setItems(new String[]{"从 txt 文件导入", "粘贴链接导入",
                        "导出节点到 txt（带国家备注）",
                        "导出纯节点链接（无备注，可直接导入 v2rayNG）",
                        "清空导入的节点（" + NodeStore.clearableCount(MainActivity.this) + " 个）"},
                        new android.content.DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(android.content.DialogInterface d, int which) {
                        if (which == 0) pickImportFile();
                        else if (which == 1) showPasteImportDialog();
                        else if (which == 2) exportNodesBg();
                        else if (which == 3) exportPlainLinksBg();
                        else confirmClearImported();
                    }
                })
                .setNegativeButton("取消", null)
                .show();
    }

    /** 打开系统文件选择器，挑一个 txt 导入。 */
    private void pickImportFile() {
        try {
            Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
            i.addCategory(Intent.CATEGORY_OPENABLE);
            i.setType("text/plain");
            i.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{"text/plain", "application/octet-stream", "*/*"});
            startActivityForResult(i, REQ_IMPORT_FILE);
        } catch (Throwable t) {
            toast("打不开文件选择器：" + t);
        }
    }

    /** 导出当前列表里的节点到 Download/CommandVPN/*.txt。 */
    private void exportNodesBg() {
        toast("正在导出…");
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    exportNodes();
                } catch (Throwable t) {
                    Log2.w("导出失败：" + t);
                }
            }
        }, "export").start();
    }

    private void exportPlainLinksBg() {
        toast("正在导出纯节点链接…");
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    java.util.List<String> links = new java.util.ArrayList<String>();
                    java.util.Set<String> seen = new java.util.HashSet<String>();
                    for (Node n : NodeStore.everything(MainActivity.this)) {
                        if (n.uri == null || n.uri.length() < 8) continue;
                        if (seen.add(n.uri)) links.add(n.uri);
                    }
                    if (links.isEmpty()) {
                        toast("没有可导出的节点");
                        return;
                    }
                    final String path = NodeStore.exportPlainLinksFile(MainActivity.this, links);
                    if (path == null) {
                        toast("导出失败");
                        return;
                    }
                    final int count = links.size();
                    ui.post(new Runnable() {
                        @Override
                        public void run() {
                            new AlertDialog.Builder(MainActivity.this)
                                    .setTitle("已导出纯节点链接")
                                    .setMessage("共 " + count + " 条链接，每行一条，没有任何注释。\n\n"
                                            + path + "\n\n"
                                            + "在 v2rayNG 里用「从剪贴板导入」或「从文件导入」都可以直接识别。")
                                    .setPositiveButton("好的", null)
                                    .show();
                        }
                    });
                } catch (Throwable t) {
                    Log2.w("导出纯节点失败：" + t);
                    toast("导出失败：" + t);
                }
            }
        }, "export-links").start();
    }

    private void exportNodes() {
        try {
            java.util.List<Node> all = new ArrayList<Node>(NodeStore.all(this));
            if (all.isEmpty()) {
                toast("没有可导出的节点");
                return;
            }
            StringBuilder sb = new StringBuilder();
            sb.append("# Command VPN 节点导出 ").append(new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm", java.util.Locale.US)
                    .format(new java.util.Date())).append('\n');
            sb.append("# 共 ").append(all.size()).append(" 个节点，每行：国家码<TAB>分享链接\n");
            for (Node n : all) {
                sb.append(n.cc == null || n.cc.length() != 2 ? "??" : n.cc).append('\t').append(n.uri).append('\n');
            }
            String path = NodeStore.exportNodesFile(this, sb.toString());
            toast(path != null ? ("已导出 " + all.size() + " 个节点：\n" + path) : "导出失败");
            final String fp = path;
            ui.post(new Runnable() {
                @Override
                public void run() {
                    try {
                        status.setText("已导出节点到 " + fp);
                    } catch (Throwable ignored) {
                    }
                }
            });
        } catch (Throwable t) {
            toast("导出失败：" + t);
        }
    }

    /** 把选中的 txt 读出来导入。 */
    private void importFromUri(final android.net.Uri uri) {
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    java.io.InputStream in = getContentResolver().openInputStream(uri);
                    if (in == null) {
                        toast("读不到这个文件");
                        return;
                    }
                    java.io.BufferedReader r = new java.io.BufferedReader(new java.io.InputStreamReader(in, "UTF-8"));
                    StringBuilder sb = new StringBuilder();
                    String line;
                    while ((line = r.readLine()) != null) sb.append(line).append('\n');
                    r.close();
                    final String content = sb.toString();
                    // doImport 现在要弹进度窗（创建 Handler/对话框），必须在界面线程调用
                    MainActivity.this.runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            doImport(content);
                        }
                    });
                } catch (Throwable t) {
                    Log2.w("读取导入文件失败：" + t);
                    toast("导入失败：" + t);
                }
            }
        }, "read-import").start();
    }

    private void showPasteImportDialog() {
        final android.widget.EditText input = new android.widget.EditText(this);
        input.setTextSize(12f);
        input.setMinLines(3);
        input.setMaxLines(8);
        input.setTextColor(0xFFF0F3F8);
        input.setHintTextColor(0xFF8A93A6);
        input.setHint("粘贴分享链接，一行一个：\nvless://…  trojan://…  vmess://…\nss://…  h2://…");
        String clip = clipboardText();
        if (clip != null && clip.contains("://")) input.setText(clip);
        new AlertDialog.Builder(this)
                .setTitle("导入节点")
                .setView(input)
                .setPositiveButton("导入", new android.content.DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(android.content.DialogInterface dialog, int which) {
                        doImport(input.getText().toString());
                    }
                })
                .setNegativeButton("取消", null)
                .show();
    }

    private String clipboardText() {
        try {
            ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
            if (cm == null || cm.getPrimaryClip() == null || cm.getPrimaryClip().getItemCount() == 0) return null;
            CharSequence cs = cm.getPrimaryClip().getItemAt(0).coerceToText(this);
            return cs == null ? null : cs.toString();
        } catch (Throwable t) {
            return null;
        }
    }

    /** 导入单条链接；返回 1=成功，0=失败（原因写进 why）。 */
    private static String guessCc(String uri) {
        return Country.detectFromUri(uri);
    }

    private int importOne(String uri, String cc, StringBuilder why) {
        try {
            String detected = guessCc(uri);
            if (detected.length() == 2) cc = detected;      // 能识别国家就自动归类
            Node n = new Node(uri, cc == null || cc.length() != 2 ? "ZZ" : cc, "");
            if (!n.supported) {
                why.append(n.protocol).append("(不支持) ");
                return 0;
            }
            ConfigBuilder.build(n);
            if (NodeStore.containsUri(this, uri)) {
                // 已经拥有（内置或之前导入过）：什么都不改，连回收站也不碰
                return 2;
            }
            // 回收站 / 隐藏里的节点跳过；永久删除的允许重新导入（导回来即可用）
            if (NodeStore.isTrashed(this, uri)) {
                why.append("在回收站 ");
                return 0;
            }
            if (NodeStore.isBlacklisted(this, uri)) {
                why.append("已隐藏 ");
                return 0;
            }
            if (NodeStore.isPurged(this, uri)) {
                NodeStore.unpurge(this, uri);
            }
            boolean added = NodeStore.addImported(this, uri);
            if (added) NodeStore.addShown(this, uri);   // 标记"已显示"，导入后立刻出现在列表里
            return added ? 1 : 0;
        } catch (Throwable t) {
            why.append(t).append(" ");
            return 0;
        }
    }

    /** 导入（粘贴/文件）：全部放到后台线程，先解析去重、最后批量写一次盘。 */
    private void doImport(String text) {
        if (text == null || text.trim().length() == 0) {
            toast("没有内容");
            return;
        }
        final String content = text;
        runOp("正在导入节点…", new OpJob() {
            @Override
            public String run(OpProg p) {
                int ok = 0, exist = 0, fail = 0;
                StringBuilder why = new StringBuilder();
                java.util.Set<String> existing = NodeStore.allUris(MainActivity.this);
                java.util.Set<String> purgedNow = NodeStore.purgedUris(MainActivity.this);
                java.util.Set<String> trashedNow = NodeStore.trashedUris(MainActivity.this);
                java.util.LinkedHashSet<String> toAdd = new java.util.LinkedHashSet<String>();
                java.util.List<String> toUnpurge = new java.util.ArrayList<String>();
                String[] rawLines = content.split("\n");
                int total = Math.max(1, rawLines.length);
                int idx = 0;
                for (String raw : rawLines) {
                    idx++;
                    if (idx % 500 == 0) p.step(idx, total, "正在解析节点…");
                    String line = raw.trim();
                    if (line.length() == 0 || line.startsWith("#")) continue;
                    String cc = "ZZ";
                    int tab = line.indexOf('\t');
                    if (tab > 0 && tab <= 3) {
                        cc = line.substring(0, tab).trim().toUpperCase(java.util.Locale.ROOT);
                        line = line.substring(tab + 1).trim();
                    }
                    java.util.List<String> pieces = new java.util.ArrayList<String>();
                    if (line.length() >= 10 && line.contains("://")) {
                        pieces.add(line);
                    } else {
                        for (String piece : line.split("[\\s,;]+")) {
                            piece = piece.trim();
                            if (piece.length() >= 10 && piece.contains("://")) pieces.add(piece);
                        }
                    }
                    for (String uri : pieces) {
                        String detected = Country.detectFromUri(uri);
                        String useCc = detected.length() == 2 ? detected : cc;
                        try {
                            Node n = new Node(uri, useCc.length() == 2 ? useCc : "ZZ", "");
                            if (!n.supported) {
                                fail++;
                                why.append(n.protocol).append("(不支持) ");
                                continue;
                            }
                        } catch (Throwable t) {
                            fail++;
                            why.append("解析失败 ");
                            continue;
                        }
                        if (existing.contains(uri)) { exist++; continue; }
                        if (trashedNow.contains(uri)) { fail++; why.append("在回收站 "); continue; }
                        if (NodeStore.isBlacklisted(MainActivity.this, uri)) {
                            fail++;
                            why.append("已隐藏 ");
                            continue;
                        }
                        if (purgedNow.contains(uri)) toUnpurge.add(uri);
                        if (toAdd.add(uri)) ok++;
                    }
                }
                for (String u : toUnpurge) {
                    try {
                        NodeStore.unpurge(MainActivity.this, u);
                    } catch (Throwable ignored) {
                    }
                }
                // 立刻把提示切到写入阶段，避免停在"正在解析节点 99%"
                p.step(1, Math.max(1, toAdd.size()), "正在写入节点…");
                // 分块写入：每 300 个一批，写完让出锁，界面不卡
                java.util.List<String> all = new java.util.ArrayList<String>(toAdd);
                int n = all.size();
                for (int i = 0; i < n; i += 300) {
                    int end = Math.min(n, i + 300);
                    java.util.List<String> chunk = new java.util.ArrayList<String>(all.subList(i, end));
                    NodeStore.addImportedBatch(MainActivity.this, chunk);
                    NodeStore.addShownBatch(MainActivity.this, chunk);
                    p.step(end, Math.max(1, n), "正在写入节点…");
                    try {
                        Thread.sleep(6);
                    } catch (InterruptedException ignored) {
                    }
                }
                Log2.i("导入完成：新增 " + ok + "，已存在 " + exist + "，跳过 " + fail);
                String msg = "已导入 " + ok + " 个节点（已按国家自动归类）";
                if (exist > 0) msg += "，已存在 " + exist + " 个";
                if (fail > 0) msg += "，跳过 " + fail + " 个";
                return msg;
            }
        });
    }

    /* ---------------------------- 其它 ---------------------------- */

    private void openUrl(String url) {
        try {
            Intent i = new Intent(Intent.ACTION_VIEW, android.net.Uri.parse(url));
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(i);
        } catch (Exception e) {
            toast("打不开浏览器：" + e);
        }
    }

    private void updateConnLine() {
        if (conn == null) return;
        long since = TunnelService.connectedSince();
        if (!TunnelService.isRunning() || since <= 0) {
            if (TunnelService.isConnecting()) {
                Node cn = TunnelService.connectingNode();
                String name = "";
                if (cn != null) {
                    String country = Country.displayName(cn.cc);
                    name = (country.length() > 0 ? country + " · " : "") + cn.title;
                }
                conn.setTextColor(0xFFE0A33C);
                conn.setText("● 正在连接 " + name + " …（正在逐个试节点，最多十几秒）");
            } else {
                conn.setText("");
            }
            return;
        }
        if (TunnelService.cloudSource() != null) {
            // 云节点：列表模式顶部只写一句话，不带国家
            conn.setTextColor(0xFFE0B44A);
            conn.setText("● 已连接云节点");
            return;
        }
        conn.setTextColor(0xFF5FD08A);
        long sec = (System.currentTimeMillis() - since) / 1000;
        String up = String.format(java.util.Locale.US, "%02d:%02d:%02d", sec / 3600, (sec / 60) % 60, sec % 60);
        int d = TunnelService.connectedDelay();
        Node cur = TunnelService.currentNode();
        String country = cur == null ? "" : Country.displayName(cur.cc);
        StringBuilder sb = new StringBuilder("● 已连接");
        if (country.length() > 0) sb.append(" · ").append(country);
        sb.append(" ").append(up);
        if (d > 0) sb.append(" · 代理延迟 ").append(d).append(" ms");
        conn.setText(sb.toString());
    }

    private void refreshState(String msg) {
        boolean running = TunnelService.isRunning();
        try {
            if (running && !wasRunningForTip) {
                wasRunningForTip = true;
                // 同一次连接只提示一次：切换深浅色会重建界面，不能因此再弹
                long sess = TunnelService.connectedSince();
                long shown = getSharedPreferences("qv", MODE_PRIVATE)
                        .getLong("google_tip_session", 0L);
                if (sess > 0 && sess != shown) {
                    getSharedPreferences("qv", MODE_PRIVATE).edit()
                            .putLong("google_tip_session", sess).apply();
                    maybeShowGoogleTip();
                }
            } else if (!running) {
                wasRunningForTip = false;
            }
        } catch (Throwable ignored) {
        }
        if (running && cloudRetryActive) {
            // 云节点已经连上了：清空"换下一个"的重试队列
            cloudRetryActive = false;
            cloudRetry.clear();
        }
        if (running && TunnelService.cloudSource() == null) {
            String saved = getSharedPreferences("qv", MODE_PRIVATE)
                    .getString("cloud_active_source", null);
            if (saved != null && saved.length() > 0) {
                TunnelService.setCloudSource(saved);
                Log2.i("云节点标记兜底恢复：" + saved);
            }
        }
        String cloudSrcNow = TunnelService.cloudSource();
        if (running && cloudSrcNow == null && cloudConnectingSource != null) {
            cloudSrcNow = cloudConnectingSource;
            TunnelService.setCloudSource(cloudSrcNow);
            Log2.i("云节点标记兜底恢复（连接成功）：" + cloudSrcNow);
        }
        if (running && cloudSrcNow != null) {
            cloudSwitching = false;
            Node curCloud = TunnelService.currentNode();
            if (curCloud != null) cloudConnectedTitle = curCloud.title;
            try {
                if (curCloud != null) {
                    int idx = -1;
                    for (int i = 0; i < cloudLastPool.size(); i++) {
                        if (cloudLastPool.get(i).uri.equals(curCloud.uri)) {
                            idx = i;
                            break;
                        }
                    }
                    if (idx >= 0) {
                        for (int i = 0; i <= idx; i++) cloudTried.add(cloudLastPool.get(i).uri);
                    } else {
                        cloudTried.add(curCloud.uri);
                    }
                }
            } catch (Throwable ignored) {
            }
            cloudConnectingSource = null;
        } else if (!running) {
            cloudConnectedTitle = null;
            if (!cloudRetryActive) cloudConnectingSource = null;
        }
        boolean connecting = TunnelService.isConnecting();
        lastStateFp = "";
        if (msg != null && msg.length() > 0) {
            // 云节点连接时，广播里带的是"已连接 · 国家 · 节点"，这里统一换成一句话，
            // 否则状态栏会闪一下"已连接 · 未识别地区"
            if (running && TunnelService.cloudSource() != null && msg.contains("已连接")) {
                status.setText("已连接云节点");
                status.setTextColor(0xFFE0B44A);
            } else {
                status.setText(msg);
            }
        }
        adapter.notifyDataSetChanged();
        updateConnectButton();
    }

    private void showLogs() {
        StringBuilder sb = new StringBuilder();
        String extPath = Log2.externalPath();
        if (extPath != null) {
            sb.append("外部日志文件（可直接查看/发送）：\n").append(extPath).append("\n\n");
        }
        String core = Crashes.coreCrash(this);
        if (!TextUtils.isEmpty(core)) {
            sb.append("── 内核报告（sing-box）──\n").append(tail(core, 5000)).append("\n\n");
        }
        String ours = Crashes.ourLog(this);
        if (!TextUtils.isEmpty(ours)) {
            sb.append("── 运行日志 ──\n").append(tail(ours, 3500));
        }
        if (sb.length() == 0) sb.append("还没有日志，连接一次就有了。");
        final String all = sb.toString();
        final AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("运行日志")
                .setMessage(all)
                .setPositiveButton("关闭", null)
                .setNeutralButton("复制", null)
                .create();
        dialog.show();
        activeDialog = dialog;
        setSelectable(dialog);
        dialog.getButton(AlertDialog.BUTTON_NEUTRAL).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                copy(all);
                toast("已复制");
            }
        });
    }

    private void showError(String msg) {
        Log2.i("showError 开始，长度=" + (msg == null ? 0 : msg.length())
                + " finishing=" + isFinishing());
        if (uiDead()) {
            Log2.w("界面已销毁，跳过错误弹窗");
            return;
        }
        StringBuilder sb = new StringBuilder();
        sb.append(msg).append("\n\n");
        String ours = Crashes.ourLog(this);
        if (!TextUtils.isEmpty(ours)) sb.append("── 最近日志 ──\n").append(tail(ours, 2500));
        final String all = sb.toString();
        final AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("连接失败")
                .setMessage(all)
                .setPositiveButton("换个地区", new android.content.DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(android.content.DialogInterface d, int w) {
                        showRegionPicker();
                    }
                })
                .setNeutralButton("复制", null)
                .setNegativeButton("关闭", null)
                .create();
        dialog.show();
        activeDialog = dialog;
        setSelectable(dialog);
        try {
            dialog.getButton(AlertDialog.BUTTON_NEUTRAL).setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    copy(all);
                    toast("已复制");
                }
            });
        } catch (Throwable ignored) {
        }
        Log2.i("showError 弹窗已显示");
    }

    private void showCrashReport() {
        StringBuilder sb = new StringBuilder();
        String core = Crashes.coreCrash(this);
        if (!TextUtils.isEmpty(core)) sb.append("── 内核报告 ──\n").append(tail(core, 5000)).append("\n\n");
        String ours = Crashes.ourLog(this);
        if (!TextUtils.isEmpty(ours)) sb.append("── 运行日志 ──\n").append(tail(ours, 2500));
        final AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("上次连接闪退了 —— 把这段发给我")
                .setMessage(sb.toString())
                .setPositiveButton("关闭", null)
                .setNeutralButton("复制", null)
                .setNegativeButton("清除", null)
                .create();
        dialog.show();
        setSelectable(dialog);
        dialog.getButton(AlertDialog.BUTTON_NEUTRAL).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                copy(tail(Crashes.coreCrash(MainActivity.this), 12000) + "\n"
                        + tail(Crashes.ourLog(MainActivity.this), 4000));
                toast("已复制");
            }
        });
        dialog.getButton(AlertDialog.BUTTON_NEGATIVE).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Crashes.clear(MainActivity.this);
                dialog.dismiss();
            }
        });
    }

    private void setSelectable(AlertDialog dialog) {
        try {
            TextView tv = (TextView) dialog.findViewById(android.R.id.message);
            if (tv != null) {
                tv.setTextIsSelectable(true);
                tv.setTextSize(11f);
            }
        } catch (Throwable ignored) {
        }
    }

    private void copy(String text) {
        try {
            ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
            cm.setPrimaryClip(ClipData.newPlainText("Command VPN", text == null ? "" : text));
        } catch (Throwable ignored) {
        }
    }

    private static String tail(String text, int max) {
        if (text == null) return "";
        if (text.length() <= max) return text;
        return "…\n" + text.substring(text.length() - max);
    }

    private void toast(final String s) {
        // 关键：导入/导出等工作线程也会调这个，必须切回主线程，
        // 否则在无 Looper 的线程上 show() 会抛"Can't toast on a thread that has not called Looper.prepare()"
        if (android.os.Looper.myLooper() == android.os.Looper.getMainLooper()) {
            try {
                Toast.makeText(this, s, Toast.LENGTH_SHORT).show();
            } catch (Throwable ignored) {
            }
        } else {
            ui.post(new Runnable() {
                @Override
                public void run() {
                    try {
                        Toast.makeText(MainActivity.this, s, Toast.LENGTH_SHORT).show();
                    } catch (Throwable ignored) {
                    }
                }
            });
        }
    }

    /** 连不上时给个"换地区"的快捷入口（不再偷偷换国家，要用户自己选）。 */
    /** 等旧连接断干净（最多 tries 次×600ms），再连用户选的国家。 */
    private void waitDisconnectedThen(final int tries, final Country picked) {
        if (tries <= 0) {
            Log2.w("换地区：旧连接一直没断开，放弃本次切换");
            status.setText("切换失败：旧连接还没断开，请手动断开后重试");
            toast("切换失败：旧连接还没断开");
            return;
        }
        ui.postDelayed(new Runnable() {
            @Override
            public void run() {
                if (uiDead()) return;
                if (TunnelService.isRunning() || TunnelService.isConnecting()) {
                    Log2.w("换地区：旧连接还没断干净，再等一会（剩余 " + tries + " 次）");
                    waitDisconnectedThen(tries - 1, picked);
                    return;
                }
                Log2.i("换地区：连接「" + picked.name + "」");
                connectCountryNow(picked);
            }
        }, 600);
    }

    private void showRegionPicker() {
        final List<Country> list = new ArrayList<Country>();
        for (Country c : countries) if (c.nodes.size() > 0) list.add(c);
        if (list.isEmpty()) {
            toast("没有可选地区");
            return;
        }
        String[] items = new String[list.size()];
        for (int i = 0; i < list.size(); i++) {
            Country c = list.get(i);
            int best = c.bestLatency();
            items[i] = c.flag() + " " + c.name + "   （" + c.nodes.size() + " 个"
                    + (best > 0 ? "，最快 " + best + " ms" : "") + "）";
        }
        new AlertDialog.Builder(this)
                .setTitle("换一个地区试试")
                .setItems(items, new android.content.DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(android.content.DialogInterface d, int which) {
                        final Country picked = list.get(which);
                        // 连接失败后 sConnecting 可能还没复位，直接 connectCountry 会被"请先断开"拦住
                        // 这里先复位/断开，再直接连用户选的这个国家
                        status.setText("正在切换到「" + picked.name + "」…");
                        try {
                            TunnelService.disconnect(MainActivity.this, "切换到新地区前断开");
                        } catch (Throwable ignored) {
                        }
                        waitDisconnectedThen(8, picked);
                    }
                })
                .show();
    }

    private class CountryAdapter extends BaseExpandableListAdapter {

        @Override
        public int getGroupCount() {
            return countries.size() + 1;      // 第 0 行固定是"最快地区"
        }

        @Override
        public int getChildrenCount(int groupPosition) {
            return groupPosition == 0 ? 0 : countries.get(groupPosition - 1).nodes.size();
        }

        @Override
        public Object getGroup(int groupPosition) {
            return groupPosition == 0 ? fastCountry : countries.get(groupPosition - 1);
        }

        @Override
        public Object getChild(int groupPosition, int childPosition) {
            return countries.get(groupPosition - 1).nodes.get(childPosition);
        }

        @Override
        public long getGroupId(int groupPosition) {
            return groupPosition;
        }

        @Override
        public long getChildId(int groupPosition, int childPosition) {
            return childPosition;
        }

        @Override
        public boolean hasStableIds() {
            return false;
        }

        @Override
        public View getGroupView(final int groupPosition, boolean isExpanded, View convertView, ViewGroup parent) {
            View v = convertView;
            if (v == null) {
                v = LayoutInflater.from(MainActivity.this).inflate(R.layout.item_country, parent, false);
            }
            if (groupPosition == 0) {
                renderFastRow(v);
            } else {
                renderCountryRow(v, countries.get(groupPosition - 1), groupPosition, isExpanded);
            }
            return v;
        }

        private void renderFastRow(View v) {
            ((TextView) v.findViewById(R.id.flag)).setText("\u26A1");
            TextView fname = (TextView) v.findViewById(R.id.cname);
            fname.setText("最快地区");
            fname.setTextColor(selectedKind == SEL_FAST ? Palette.green(MainActivity.this)
                    : Palette.text(MainActivity.this));
            String fastSub;
            boolean fastMode = TunnelService.connectMode() == TunnelService.MODE_AUTO;
            if (TunnelService.isConnecting() && fastMode) fastSub = "\u23F3 正在连接…（自动挑最快的那个）";
            else if (TunnelService.isRunning() && fastMode) fastSub = "\u25CF 已连接";
            else if (selectedKind == SEL_FAST) fastSub = "\u2714 已选中 · 点下面「连接」";
            else fastSub = "自动挑全部节点里最快的那个";
            ((TextView) v.findViewById(R.id.csub)).setText(fastSub);
            ((TextView) v.findViewById(R.id.arrow)).setText("");
            v.setBackgroundColor(selectedKind == SEL_FAST ? Palette.rowSel(MainActivity.this)
                    : Palette.rowBg(MainActivity.this));

            Button fbtn = (Button) v.findViewById(R.id.auto);
            boolean fastConnected = TunnelService.isRunning() && fastMode;
            fbtn.setText(fastConnected ? "\u2713" : "\u26A1");
            fbtn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if (!tapAllowed()) return;
                    boolean busy = TunnelService.isRunning() || TunnelService.isConnecting();
                    if (busy) {
                        // 最快地区自己在连/已连 → 再点就是断开；别的模式连的 → 提示先断开
                        boolean autoMode = TunnelService.connectMode() == TunnelService.MODE_AUTO;
                        Log2.i("最快地区闪电：busy=true autoMode=" + autoMode);
                        if (autoMode) {
                            TunnelService.disconnect(MainActivity.this);
                        } else {
                            blockIfBusy();
                        }
                        return;
                    }
                    selectFast();
                    autoConnectFastest();
                }
            });
            View arrow0 = v.findViewById(R.id.arrow);
            if (arrow0 != null) {                 // 复用到国家行的箭头监听器必须清掉
                arrow0.setOnClickListener(null);
                arrow0.setClickable(false);
            }
            v.setOnLongClickListener(null);
            v.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    selectFast();
                }
            });
        }

        private void renderCountryRow(View v, final Country c, int groupPosition, boolean isExpanded) {
            ((TextView) v.findViewById(R.id.flag)).setText(c.flag());
            TextView name = (TextView) v.findViewById(R.id.cname);
            boolean pinned = NodeStore.isPinned(MainActivity.this, c.cc);
            boolean selectedCountry = selectedKind == SEL_COUNTRY && c.cc.equals(selectedCc);
            Node connNode = TunnelService.isConnecting() ? TunnelService.connectingNode() : null;
            boolean connectingHere = connNode != null && c.cc.equals(connNode.cc);

            name.setText(pinned ? ("\u2605 " + c.name) : c.name);
            name.setTextColor(connectingHere ? Palette.orange(MainActivity.this)
                    : c.isCurrent() ? Palette.green(MainActivity.this)
                    : selectedCountry ? Palette.blue(MainActivity.this)
                    : Palette.text(MainActivity.this));
            name.setAlpha(1f);
            v.setBackgroundColor(selectedCountry ? Palette.rowSel(MainActivity.this)
                    : Palette.rowBg(MainActivity.this));

            int best = c.bestLatency();
            StringBuilder sub = new StringBuilder();
            if (connectingHere) sub.append("\u23F3 正在连接 · ");
            else if (c.isCurrent() && TunnelService.cloudSource() == null) sub.append("\u25CF 已连接 · ");
            else if (selectedCountry) sub.append("\u2714 已选中 · ");
            if (NodeStore.isRecommendedCountry(MainActivity.this, c.cc)) sub.append("★推荐 · ");
            int visCount = 0, hidCount = 0;
            for (Node n : c.nodes) {
                if (n.hidden) hidCount++; else visCount++;
            }
            sub.append(visCount).append(" 个节点");
            if (best > 0) sub.append(" · 最快 ").append(best).append(" ms");
            if (hidCount > 0) {
                // 眼睛打开时会带出隐藏节点：分开显示"可见 N · 隐藏 M"，不再合并成一个数
                sub.append(" · 隐藏 ").append(hidCount).append(" 个");
            } else {
                Integer allCount = NodeStore.totalByCountry(MainActivity.this).get(c.cc);
                if (!NodeStore.showAll(MainActivity.this) && allCount != null && allCount > c.nodes.size()) {
                    sub.append(" · 隐藏 ").append(allCount - c.nodes.size()).append(" 个");
                }
            }
            TextView subTv = (TextView) v.findViewById(R.id.csub);
            subTv.setText(sub.toString());
            subTv.setAlpha(1f);

            TextView arrow = (TextView) v.findViewById(R.id.arrow);
            arrow.setText(isExpanded ? "\u25BE" : "\u25B8");
            final int gp = groupPosition;
            arrow.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if (list.isGroupExpanded(gp)) list.collapseGroup(gp);
                    else list.expandGroup(gp);
                }
            });

            v.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    selectCountry(c);
                }
            });

            Button auto = (Button) v.findViewById(R.id.auto);
            auto.setText(TunnelService.isRunning() && c.isCurrent() ? "\u2713" : "\u26A1");
            auto.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if (!tapAllowed()) return;
                    if (TunnelService.isRunning() || TunnelService.isConnecting()) {
                        Node busyNode = TunnelService.isRunning()
                                ? TunnelService.currentNode() : TunnelService.connectingNode();
                        // 同国家 或 当前节点就在这个国家列表里 → 都算"点的是它自己"
                        boolean sameCountry = busyNode != null
                                && (c.cc.equalsIgnoreCase(busyNode.cc) || containsUri(c, busyNode.uri));
                        if (sameCountry) {
                            Log2.i("再点同一国家的闪电 → 断开");
                            TunnelService.disconnect(MainActivity.this);
                            return;
                        }
                        blockIfBusy();
                        return;
                    }
                    selectCountry(c);
                    connectCountry(c);
                }
            });
        }

        @Override
        public View getChildView(int groupPosition, int childPosition, boolean isLastChild, View convertView, ViewGroup parent) {
            View v = convertView;
            if (v == null) {
                v = LayoutInflater.from(MainActivity.this).inflate(R.layout.item_node, parent, false);
            }
            renderNodeRow(v, countries.get(groupPosition - 1).nodes.get(childPosition));
            return v;
        }

        private void renderNodeRow(View v, final Node n) {
            boolean isGood = NodeStore.isGood(MainActivity.this, n.uri);
            boolean visibleNow = (isGood || NodeStore.isShown(MainActivity.this, n.uri))
                    && !NodeStore.isBlacklisted(MainActivity.this, n.uri);

            TextView nameTv = (TextView) v.findViewById(R.id.name);
            TextView subTv = (TextView) v.findViewById(R.id.sub);
            TextView lat = (TextView) v.findViewById(R.id.lat);
            TextView flagTv = (TextView) v.findViewById(R.id.flag);

            flagTv.setText(n.flag());
            nameTv.setText(n.title);

            String base = n.subtitle();
            String stateTag = visibleNow ? "已显示" : "已隐藏";

            StringBuilder sb = new StringBuilder();
            int goodStart = -1, goodEnd = -1;
            if (isGood) {
                goodStart = 0;
                sb.append("实测可用");
                goodEnd = sb.length();
                sb.append(" · ");
            }
            int stateStart = sb.length();
            sb.append(stateTag);
            int stateEnd = sb.length();
            sb.append(" · ");
            int baseStart = sb.length();
            sb.append(base);
            int baseEnd = sb.length();

            android.text.SpannableString ss = new android.text.SpannableString(sb.toString());
            ss.setSpan(new android.text.style.ForegroundColorSpan(Palette.textDim(MainActivity.this)),
                    stateStart, stateEnd, android.text.Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
            ss.setSpan(new android.text.style.ForegroundColorSpan(Palette.subOnRow(MainActivity.this)),
                    baseStart, baseEnd, android.text.Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
            if (goodStart >= 0) {
                ss.setSpan(new android.text.style.ForegroundColorSpan(Palette.green(MainActivity.this)),
                        goodStart, goodEnd, android.text.Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
                ss.setSpan(new android.text.style.StyleSpan(android.graphics.Typeface.BOLD),
                        goodStart, goodEnd, android.text.Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
            }
            subTv.setText(ss);

            lat.setText(n.latencyText());
            lat.setTextColor(n.latency > 0
                    ? (n.latency < 400 ? Palette.blue(MainActivity.this) : Palette.orange(MainActivity.this))
                    : Palette.textFaint(MainActivity.this));
            lat.setAlpha(visibleNow ? 1f : 0.55f);

            if (visibleNow) {
                nameTv.setTextColor(Palette.text(MainActivity.this));
                flagTv.setAlpha(1f);
                v.setAlpha(1f);
            } else {
                // 已隐藏：整行再淡一点（0.38），旗帜跟着变淡但仍看得见；
                // 名字用正常亮度色，这样乘上整行 alpha 后文字仍然清楚
                nameTv.setTextColor(Palette.text(MainActivity.this));
                flagTv.setAlpha(0.45f);
                v.setAlpha(0.38f);
            }

            int bg = Palette.rowBg(MainActivity.this);
            Node cur = TunnelService.currentNode();
            if (cur != null && TunnelService.isRunning() && n.uri.equals(cur.uri)) bg = Palette.rowActive(MainActivity.this);
            else if (selectedKind == SEL_NODE && n.uri.equals(selectedUri)) bg = Palette.rowSel(MainActivity.this);
            v.setBackgroundColor(bg);

            v.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if (!editMode) { selectNode(n); return; }
                    boolean vis = (NodeStore.isGood(MainActivity.this, n.uri)
                            || NodeStore.isShown(MainActivity.this, n.uri))
                            && !NodeStore.isBlacklisted(MainActivity.this, n.uri);
                    if (vis) showNodeEditMenu(n); else showHiddenNodeMenu(n);
                }
            });
        }

        @Override
        public boolean isChildSelectable(int groupPosition, int childPosition) {
            return true;
        }
    }
}