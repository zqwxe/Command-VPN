package com.dsh.quickvpn;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.os.Build;
import android.view.View;
import android.view.Window;

/** 外观设置：深色 / 浅色 / 跟随系统，默认跟随系统。 */
public class Theme {

    public static final int DARK = 0;
    public static final int LIGHT = 1;
    public static final int SYSTEM = 2;

    public static int pref(Context ctx) {
        try {
            return ctx.getSharedPreferences("qv", Context.MODE_PRIVATE).getInt("theme", SYSTEM);
        } catch (Throwable t) {
            return DARK;
        }
    }

    public static void setPref(Context ctx, int value) {
        try {
            ctx.getSharedPreferences("qv", Context.MODE_PRIVATE).edit().putInt("theme", value).apply();
        } catch (Throwable ignored) {
        }
    }

    /** 当前实际是不是深色。 */
    public static boolean isDark(Context ctx) {
        int p = pref(ctx);
        if (p == LIGHT) return false;
        if (p == SYSTEM) {
            int mode = ctx.getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK;
            return mode != Configuration.UI_MODE_NIGHT_NO;
        }
        return true;
    }

    /** 应用窗口背景 + 状态栏/导航栏配色（浅色主题用深色图标，深色主题用浅色图标）。 */
    public static void applyWindow(Activity a) {
        try {
            boolean dark = isDark(a);
            Window w = a.getWindow();
            int barColor = Palette.bg(a);
            // 状态栏/导航栏跟着主题背景走，否则浅色主题下状态栏是黑的、时间和图标看不见
            w.setStatusBarColor(barColor);
            w.setNavigationBarColor(barColor);
            w.setBackgroundDrawableResource(android.R.color.transparent);
            View decor = w.getDecorView();
            decor.setBackgroundColor(barColor);

            if (Build.VERSION.SDK_INT >= 30) {
                android.view.WindowInsetsController c = w.getInsetsController();
                if (c != null) {
                    int mask = android.view.WindowInsetsController.APPEARANCE_LIGHT_STATUS_BARS
                            | android.view.WindowInsetsController.APPEARANCE_LIGHT_NAVIGATION_BARS;
                    int value = dark ? 0 : mask;
                    c.setSystemBarsAppearance(value, mask);
                }
            }
            int flags = decor.getSystemUiVisibility();
            if (Build.VERSION.SDK_INT >= 23) {
                if (dark) flags &= ~View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;
                else flags |= View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;
            }
            if (Build.VERSION.SDK_INT >= 26) {
                if (dark) flags &= ~View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR;
                else flags |= View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR;
            }
            decor.setSystemUiVisibility(flags);
        } catch (Throwable ignored) {
        }
    }
}
