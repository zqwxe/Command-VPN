package com.dsh.quickvpn;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.util.AttributeSet;
import android.view.View;

/**
 * 胶囊型开关：轨道 + 白色圆点。
 * 只负责"画"，状态由外部每次 setOn() 决定，不参与 View 状态保存，
 * 所以切换主题（recreate）不会像 CheckBox 那样被恢复成旧值。
 */
public class PillSwitch extends View {

    private boolean on = false;
    private int colorOn = 0xFF5FD08A;
    private int colorOff = 0xFF6B7280;

    private final Paint trackPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint thumbPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF rect = new RectF();

    public PillSwitch(Context c) {
        super(c);
        init();
    }

    public PillSwitch(Context c, AttributeSet a) {
        super(c, a);
        init();
    }

    public PillSwitch(Context c, AttributeSet a, int s) {
        super(c, a, s);
        init();
    }

    private void init() {
        thumbPaint.setColor(0xFFFFFFFF);
        thumbPaint.setShadowLayer(2f, 0f, 1f, 0x40000000);
        setLayerType(LAYER_TYPE_SOFTWARE, null);   // 阴影需要软件层
    }

    public void setOn(boolean value) {
        if (on != value) {
            on = value;
            invalidate();
        }
    }

    public boolean isOn() {
        return on;
    }

    public void setColors(int onColor, int offColor) {
        colorOn = onColor;
        colorOff = offColor;
        invalidate();
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        float w = getWidth();
        float h = getHeight();
        float r = h / 2f;

        trackPaint.setColor(on ? colorOn : colorOff);
        rect.set(0, 0, w, h);
        canvas.drawRoundRect(rect, r, r, trackPaint);

        float pad = Math.max(2f, h * 0.12f);
        float d = h - pad * 2f;
        float cx = on ? (w - pad - d / 2f) : (pad + d / 2f);
        float cy = h / 2f;
        canvas.drawCircle(cx, cy, d / 2f, thumbPaint);
    }
}
