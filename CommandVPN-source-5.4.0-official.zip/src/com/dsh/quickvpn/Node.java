package com.dsh.quickvpn;

import java.util.Locale;

import org.json.JSONObject;

/** 一个节点。 */
public class Node {
    public final String uri;
    public final String protocol;   // vless / vmess / trojan / shadowsocks / hysteria2
    public final String host;
    public final int port;
    public String cc;         // 国家/地区两位码，可能为空（云节点测完可能被补上）
    public final String title;      // 展示名
    public final boolean supported; // 内核是否支持
    public final Link link;

    /**
     * 服务器域名解析出来的 IP。**必须**在生成配置前解析好：
     * 内核的 DNS 是走代理的，而"解析节点自己域名"又要先连上节点 —— 死循环，
     * 结果就是所有用域名当服务器的节点永远连不上（日志里表现为
     * "dns: lookup failed for xxx: context deadline exceeded"）。
     */
    public volatile String resolvedHost;
    /** 域名解析出来的所有 IP（轮着用：某个 IP 被封时下次换一个）。 */
    private volatile java.util.List<String> resolvedIps;
    private volatile int resolvedIndex = -1;

    /** 把服务器域名在本地（直连）解析成 IP；失败就保持域名不动。 */
    public synchronized void resolveHost() {
        resolveHost(false);
    }

    /** 指定超时的解析（识别地区时用，比体检时给的余量更大）。 */
    public synchronized void resolveHost(long timeoutMs) {
        String h = host;
        if (h == null || h.length() == 0) return;
        if (isIpLiteral(h)) {
            resolvedHost = h;
            return;
        }
        if (resolvedIps == null) {
            try {
                java.net.InetAddress[] all = resolveWithTimeout(h, timeoutMs);
                java.util.List<String> v4 = new java.util.ArrayList<String>();
                java.util.List<String> other = new java.util.ArrayList<String>();
                if (all != null) {
                    for (java.net.InetAddress a : all) {
                        String ip = a.getHostAddress();
                        if (ip == null) continue;
                        if (a instanceof java.net.Inet4Address) v4.add(ip);
                        else other.add(ip);
                    }
                }
                v4.addAll(other);
                if (!v4.isEmpty()) resolvedIps = v4;
            } catch (Throwable ignored) {
            }
        }
        if (resolvedIps == null || resolvedIps.isEmpty()) return;
        if (resolvedIndex < 0) resolvedIndex = 0;
        resolvedHost = resolvedIps.get(resolvedIndex);
    }

    /**
     * @param rotate true = 换一个 IP（同一个域名可能有多个 A 记录，
     *               某个 IP 被墙时换一个说不定就通了）
     */
    public synchronized void resolveHost(boolean rotate) {
        String h = host;
        if (h == null || h.length() == 0) return;
        if (isIpLiteral(h)) {
            resolvedHost = h;
            return;
        }
        if (resolvedIps == null) {
            try {
                java.net.InetAddress[] all = resolveWithTimeout(h, 1500);
                java.util.List<String> v4 = new java.util.ArrayList<String>();
                java.util.List<String> other = new java.util.ArrayList<String>();
                for (java.net.InetAddress a : all) {
                    String ip = a.getHostAddress();
                    if (ip == null) continue;
                    if (a instanceof java.net.Inet4Address) v4.add(ip);
                    else other.add(ip);
                }
                v4.addAll(other);
                if (!v4.isEmpty()) resolvedIps = v4;
            } catch (Throwable ignored) {
            }
        }
        if (resolvedIps == null || resolvedIps.isEmpty()) return;
        if (resolvedIndex < 0) resolvedIndex = 0;
        else if (rotate) resolvedIndex = (resolvedIndex + 1) % resolvedIps.size();
        resolvedHost = resolvedIps.get(resolvedIndex);
    }

    private static final java.util.concurrent.ExecutorService DNS_POOL =
            java.util.concurrent.Executors.newCachedThreadPool(new java.util.concurrent.ThreadFactory() {
                @Override
                public Thread newThread(Runnable r) {
                    Thread t = new Thread(r, "dns-resolve");
                    t.setDaemon(true);
                    return t;
                }
            });

    /**
     * 带超时的域名解析。系统 DNS 在没有网络/移动网络切换时会挂很久，
     * 体检时一批 100 个域名挨个解析，就会出现"体检卡住几十分钟"。
     * 这里每个域名最多等 1.5 秒，解析不到就用原域名，绝不阻塞整批。
     */
    private static java.net.InetAddress[] resolveWithTimeout(final String host, long timeoutMs) {
        java.util.concurrent.Future<java.net.InetAddress[]> f =
                DNS_POOL.submit(new java.util.concurrent.Callable<java.net.InetAddress[]>() {
                    @Override
                    public java.net.InetAddress[] call() throws Exception {
                        return java.net.InetAddress.getAllByName(host);
                    }
                });
        try {
            return f.get(timeoutMs, java.util.concurrent.TimeUnit.MILLISECONDS);
        } catch (java.util.concurrent.TimeoutException te) {
            f.cancel(true);
            Log2.w("域名解析超时，跳过解析：" + host);
            return null;
        } catch (Throwable t) {
            return null;
        }
    }

    public static boolean isIpLiteral(String h) {
        if (h == null || h.length() == 0) return false;
        if (h.indexOf(':') >= 0) return true;                 // IPv6
        return h.matches("\\d{1,3}(\\.\\d{1,3}){3}");        // IPv4
    }

    /** 是否处于"已隐藏"状态（编辑模式下会一起显示出来，方便恢复）。 */
    public boolean hidden = false;

    /** 是否被实测验证过能用（打包时按历史体检结果标记）。 */
    public boolean verified = false;

    /** 是否是 Cloudflare 前置节点（按解析后的 IP 判断，构建时算好）。 */
    public boolean cf = false;

    public volatile int latency = -1; // -1 未测；>=0 毫秒；-2 测试中；-3 不通

    public Node(String uri, String cc, String title) {
        this.uri = uri;
        this.cc = cc == null ? "" : cc.trim().toUpperCase(Locale.ROOT);
        this.link = Link.parse(uri);
        this.protocol = normalize(this.link.scheme);
        String h = this.link.host;
        int p = this.link.port;
        String ps = "";
        if ("vmess".equals(this.link.scheme)) {
            // vmess 是 base64(JSON)，主机端口在 JSON 里
            String[] info = parseVmess(uri);
            if (info != null) {
                if (info[0].length() > 0) h = info[0];
                try {
                    int pp = Integer.parseInt(info[1]);
                    if (pp > 0) p = pp;
                } catch (Exception ignored) {
                }
                ps = info[2];
            }
        }
        this.host = h;
        this.port = p;
        String t = title == null ? "" : title.trim();
        if (t.length() == 0) {
            if (this.link.fragment.length() > 0) t = this.link.fragment;
            else if (ps.length() > 0) t = ps;
            else t = protocol + "-" + host;
        }
        this.title = cleanTitle(t);
        this.supported = checkSupported();
    }

    /** 修掉两种常见的标题乱码：百分号编码、以及 UTF-8 被当成 Latin-1 读出来。 */
    static String cleanTitle(String raw) {
        if (raw == null || raw.length() == 0) return "";
        String t = raw;
        if (t.indexOf('%') >= 0) {
            try {
                t = java.net.URLDecoder.decode(t, "UTF-8");
            } catch (Throwable ignored) {
            }
        }
        int latin = 0;
        for (int i = 0; i < t.length(); i++) {
            char c = t.charAt(i);
            if (c >= 0xC0 && c <= 0xFF) latin++;
        }
        if (latin >= 2) {
            try {
                String fixed = new String(t.getBytes("ISO-8859-1"), "UTF-8");
                if (fixed.indexOf('\uFFFD') < 0) t = fixed;
            } catch (Throwable ignored) {
            }
        }
        return t.trim();
    }

    /** 解析 vmess://base64(json) → {add, port, ps}。 */
    private static String[] parseVmess(String uri) {
        try {
            String body = uri.substring(uri.indexOf("://") + 3).trim();
            int cut = body.indexOf('#');
            if (cut >= 0) body = body.substring(0, cut);
            JSONObject o = new JSONObject(SsAuth.b64(body));
            return new String[]{o.optString("add", ""), o.optString("port", "0"), o.optString("ps", "")};
        } catch (Throwable t) {
            return null;
        }
    }

    private static String normalize(String scheme) {
        if ("hy2".equals(scheme) || "hysteria2".equals(scheme)) return "hysteria2";
        if ("ss".equals(scheme)) return "shadowsocks";
        if ("trojan-go".equals(scheme)) return "trojan";
        return scheme;
    }

    private boolean checkSupported() {
        if (host.length() == 0 || port <= 0 || port > 65535) return false;
        if ("vless".equals(protocol)) {
            if (link.userInfo.length() == 0) return false;
            // reality 的 pbk 不合法时内核会直接报 invalid public_key，
            // 这种节点测不了也连不上，直接当成不支持，省得体检时反复拆批重试
            if ("reality".equals(link.q("security"))) {
                String pbk = link.q("pbk", "publicKey");
                if (pbk.length() < 40) return false;
            }
            return true;
        }
        if ("vmess".equals(protocol)) return true;
        if ("trojan".equals(protocol)) return true;
        if ("hysteria2".equals(protocol)) return true;
        if ("shadowsocks".equals(protocol)) return SsAuth.isSupported(SsAuth.method(link));
        return false;
    }

    /** 国旗 emoji。 */
    public String flag() {
        if (cc.length() != 2) return "\uD83C\uDF10";
        char a = cc.charAt(0), b = cc.charAt(1);
        if (a < 'A' || a > 'Z' || b < 'A' || b > 'Z') return "\uD83C\uDF10";
        return new String(Character.toChars(0x1F1E6 + (a - 'A'))) + new String(Character.toChars(0x1F1E6 + (b - 'A')));
    }

    public String protoShort() {
        if ("shadowsocks".equals(protocol)) return "SS";
        return protocol.toUpperCase(Locale.ROOT);
    }

    public String subtitle() {
        String extra = "";
        if ("vless".equals(protocol)) {
            String sec = link.q("security");
            if ("reality".equals(sec)) extra = "·reality";
            else if ("tls".equals(sec)) extra = "·tls";
            else if ("none".equals(sec)) extra = "·none";
        } else if ("hysteria2".equals(protocol)) {
            extra = "·quic";
        } else if ("shadowsocks".equals(protocol)) {
            extra = "·" + SsAuth.method(link);
        }
        return protoShort() + extra + " · " + host + ":" + port;
    }

    public String latencyText() {
        if (latency == -1) return "—";
        if (latency == -2) return "…";
        if (latency == -3) return "不通";
        return latency + " ms";
    }
}
