package com.dsh.quickvpn;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.provider.Settings;

/**
 * 尽量把用户直接送到"正确的那一页"：
 * 先试厂商私有的自启动/耗电页面（组件名各 ROM 不同，逐个探测），
 * 全都不存在时回退到标准的「应用详情页」或电池优化列表。
 */
public class VendorSettings {

    /** 厂商的自启动管理页候选组件。 */
    private static final String[][] AUTOSTART = {
            // 小米 / 红米
            {"com.miui.securitycenter", "com.miui.permcenter.autostart.AutoStartManagementActivity"},
            // 华为 / 荣耀
            {"com.huawei.systemmanager", "com.huawei.systemmanager.startupmgr.ui.StartupNormalAppListActivity"},
            {"com.huawei.systemmanager", "com.huawei.systemmanager.appcontrol.activity.StartupAppControlActivity"},
            // OPPO / 一加 / 真我（ColorOS / 新老包名都试）
            {"com.coloros.safecenter", "com.coloros.safecenter.permission.startup.StartupAppListActivity"},
            {"com.coloros.safecenter", "com.coloros.safecenter.startupapp.StartupAppListActivity"},
            {"com.oplus.safecenter", "com.oplus.safecenter.permission.startup.StartupAppListActivity"},
            {"com.oplus.safecenter", "com.oplus.safecenter.startupapp.StartupAppListActivity"},
            // vivo / iQOO
            {"com.vivo.permissionmanager", "com.vivo.permissionmanager.activity.BgStartUpManagerActivity"},
            {"com.iqoo.secure", "com.iqoo.secure.ui.phoneoptimize.BgStartUpManager"},
            // 魅族
            {"com.meizu.safe", "com.meizu.safe.permission.SuperPermissionActivity"},
            // 三星没有独立"自启动"页，不猜组件（避免打开电池总览这种找不到设置的地方）
    };

    /**
     * 耗电管理页候选。
     * 标准：打开的这一页**或其子页面**能找到「允许完全后台行为 / 不受限制」就算合格
     * （比如先进"耗电排行"，从应用列表点进去就是耗电管理）。
     */
    private static final String[][] BATTERY = {
            // OPPO / 一加 / 真我：新旧包名的"应用耗电管理 / 耗电保护"
            {"com.coloros.oppoguardelf", "com.coloros.powermanager.fuelgaue.PowerUsageModelActivity"},
            {"com.oplus.battery", "com.oplus.powermanager.fuelgaue.PowerUsageModelActivity"},
            {"com.coloros.oppoguardelf", "com.coloros.powermanager.fuelgaue.PowerConsumptionActivity"},
            {"com.oplus.battery", "com.oplus.powermanager.fuelgaue.PowerConsumptionActivity"},
            {"com.coloros.safecenter", "com.coloros.safecenter.permission.power.PowerManagementActivity"},
            {"com.oplus.safecenter", "com.oplus.safecenter.permission.power.PowerManagementActivity"},
            {"com.miui.powerkeeper", "com.miui.powerkeeper.ui.HiddenAppsConfigActivity"},
            {"com.huawei.systemmanager", "com.huawei.systemmanager.power.ui.HwPowerManagerActivity"},
            // vivo 没有稳定的"后台耗电管理"组件：
            // com.vivo.permissionmanager/...PurviewTabActivity 实际是"权限管理"页，
            // 跳过去找不到"允许后台高耗电"，所以这条删掉，改由界面提示手动按路径设置。
            {"com.samsung.android.lool", "com.samsung.android.sm.ui.battery.BatteryActivity"},
            {"com.meizu.safe", "com.meizu.safe.security.SecurePrimaryActivity"},
    };



    /** 打开结果：打开了厂商专属页面 / 打开了应用详情页 / 打不开（需要手动） */
    public static final int OPENED_VENDOR = 1;      // 打开了厂商专属页
    public static final int OPENED_DETAILS = 2;     // 打开了应用详情页
    public static final int OPENED_FALLBACK = 3;    // 退到了系统设置首页 / 电池列表
    public static final int FAILED = 0;             // 一个都打不开，只能手动

    /**
     * 打开「自启动」页面。
     * 只有在"该品牌的这项确实在应用详情页里"时才会回退到详情页；
     * 否则一律返回 FAILED，让界面提示用户手动去系统设置找——
     * 绝不再乱开一个不对的页面。
     */
    /**
     * 自启动：统一只打开"系统设置首页"。
     * 各品牌到底在哪一页、不同版本有什么区别，全部写在弹窗文案里，
     * 不再猜厂商组件（猜错会把人带到不相干的页面）。
     */
    /** 该品牌的这些设置是不是在"手机管家"里（魅族：自启动与后台管理都在手机管家）。 */
    public static boolean inPhoneManager(Context ctx) {
        return kind(ctx) == 5;
    }

    /** 打开手机管家首页（魅族等）。 */
    private static boolean openPhoneManager(Context ctx) {
        String[] pkgs = {"com.meizu.safe", "com.meizu.safecenter"};
        for (String pkg : pkgs) {
            try {
                Intent i = ctx.getPackageManager().getLaunchIntentForPackage(pkg);
                if (i == null) continue;
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                if (ctx.getPackageManager().resolveActivity(i, 0) != null && start(ctx, i)) {
                    Log2.i("跳转：手机管家首页（" + pkg + "）");
                    return true;
                }
            } catch (Throwable ignored) {
            }
        }
        return false;
    }

    public static int openAutoStart(Context ctx) {
        if (inPhoneManager(ctx) && openPhoneManager(ctx)) return OPENED_FALLBACK;
        if (openSettingsRoot(ctx)) {
            Log2.i("跳转：系统设置首页（自启动请按弹窗里的路径找）");
            return OPENED_FALLBACK;
        }
        Log2.w("连系统设置首页都打不开，交给用户手动");
        return FAILED;
    }

    /** 打开「耗电 / 完全后台」页面，规则同上。 */
    /** 允许完全后台：同样只打开"设置首页"（魅族打开手机管家首页）。 */
    public static int openBattery(Context ctx) {
        if (inPhoneManager(ctx) && openPhoneManager(ctx)) return OPENED_FALLBACK;
        if (openSettingsRoot(ctx)) {
            Log2.i("跳转：系统设置首页（完全后台请按弹窗里的路径找）");
            return OPENED_FALLBACK;
        }
        Log2.w("连系统设置首页都打不开，交给用户手动");
        return FAILED;
    }

    /** 打开系统设置首页（从这里按路径能走到任何设置）。 */

    /** 尽力跳转到"路径上那一页"（不保证准确，跳不到会退到详情页/首页）。 */
    public static int openBestEffort(Context ctx, boolean autostart) {
        int k = kind(ctx);
        String[][] list = autostart ? AUTOSTART_CANDIDATES : BATTERY_CANDIDATES;
        for (String[] c : list) {
            if (kindOf(c[0]) != k) continue;
            try {
                Intent i = new Intent();
                i.setComponent(new ComponentName(c[0], c[1]));
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                if (ctx.getPackageManager().resolveActivity(i, 0) != null && start(ctx, i)) {
                    Log2.i("尽力跳转（" + (autostart ? "自启动" : "耗电管理") + "）：" + c[0] + "/" + c[1]);
                    return OPENED_VENDOR;
                }
            } catch (Throwable ignored) {
            }
        }
        if (openAppDetails(ctx)) {
            Log2.w("没有可用组件，退到应用详情页");
            return OPENED_DETAILS;
        }
        if (!autostart) {
            try {
                Intent b = new Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS);
                b.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                if (start(ctx, b)) {
                    Log2.w("详情页打不开，退到电池优化列表");
                    return OPENED_FALLBACK;
                }
            } catch (Throwable ignored) {
            }
        }
        return openSettingsRoot(ctx) ? OPENED_FALLBACK : FAILED;
    }

    /** 尽力跳转用的候选组件（不保证页面正确，只用于"按路径跳转"按钮）。 */
    private static final String[][] AUTOSTART_CANDIDATES = {
            {"com.miui.securitycenter", "com.miui.permcenter.autostart.AutoStartManagementActivity"},
            {"com.huawei.systemmanager", "com.huawei.systemmanager.startupmgr.ui.StartupNormalAppListActivity"},
            {"com.coloros.safecenter", "com.coloros.safecenter.permission.startup.StartupAppListActivity"},
            {"com.oplus.safecenter", "com.oplus.safecenter.permission.startup.StartupAppListActivity"},
            {"com.vivo.permissionmanager", "com.vivo.permissionmanager.activity.BgStartUpManagerActivity"},
            {"com.meizu.safe", "com.meizu.safe.permission.SuperPermissionActivity"},
    };

    private static final String[][] BATTERY_CANDIDATES = {
            {"com.coloros.oppoguardelf", "com.coloros.powermanager.fuelgaue.PowerUsageModelActivity"},
            {"com.oplus.battery", "com.oplus.powermanager.fuelgaue.PowerUsageModelActivity"},
            {"com.miui.powerkeeper", "com.miui.powerkeeper.ui.HiddenAppsConfigActivity"},
            {"com.huawei.systemmanager", "com.huawei.systemmanager.power.ui.HwPowerManagerActivity"},
            {"com.samsung.android.lool", "com.samsung.android.sm.ui.battery.BatteryActivity"},
            {"com.meizu.safe", "com.meizu.safe.security.SecurePrimaryActivity"},
    };

    private static int kindOf(String pkg) {
        if (pkg.contains("coloros") || pkg.contains("oplus") || pkg.contains("oneplus") || pkg.contains("realme")) return 0;
        if (pkg.contains("miui") || pkg.contains("xiaomi")) return 1;
        if (pkg.contains("huawei") || pkg.contains("honor")) return 2;
        if (pkg.contains("vivo") || pkg.contains("iqoo")) return 3;
        if (pkg.contains("samsung")) return 4;
        if (pkg.contains("meizu")) return 5;
        return 6;
    }

    private static boolean openSettingsRoot(Context ctx) {
        try {
            Intent i = new Intent(Settings.ACTION_SETTINGS);
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            return start(ctx, i);
        } catch (Throwable t) {
            return false;
        }
    }

    /** 该品牌的自启动开关是否在"应用详情页"里。 */
    public static boolean autoStartInDetails(Context ctx) {
        String b = brand(ctx);
        // 三星没有"自启动"这一项（只有后台使用限制），详情页里找不到 → 不跳
        return b.contains("oppo") || b.contains("oplus") || b.contains("oneplus") || b.contains("realme")
                || b.contains("xiaomi") || b.contains("redmi") || b.contains("poco");
    }

    /** 该品牌的"完全后台/不受限制"是否在"应用详情页"里。 */
    public static boolean batteryInDetails(Context ctx) {
        String b = brand(ctx);
        // 魅族的后台管理在「手机管家」，应用详情页里没有 → 不跳
        return b.contains("oppo") || b.contains("oplus") || b.contains("oneplus") || b.contains("realme")
                || b.contains("xiaomi") || b.contains("redmi") || b.contains("poco")
                || b.contains("samsung");
    }

    /** 品牌分类：0=OPPO系 1=小米系 2=华为系 3=vivo系 4=三星 5=魅族 6=其它 */
    public static int kind(Context ctx) {
        String b = brand(ctx);
        if (b.contains("oppo") || b.contains("oplus") || b.contains("oneplus") || b.contains("realme")) return 0;
        if (b.contains("xiaomi") || b.contains("redmi") || b.contains("poco")) return 1;
        if (b.contains("huawei") || b.contains("honor")) return 2;
        if (b.contains("vivo") || b.contains("iqoo")) return 3;
        if (b.contains("samsung")) return 4;
        if (b.contains("meizu")) return 5;
        return 6;
    }

    /** 只在本品牌自己的候选里探测，避免撞上"存在但页面不对"的组件。 */
    private static Intent resolveFor(Context ctx, int kind, String[][] all, String tag) {
        for (String[] c : all) {
            if (kindOf(c[0]) != kind) continue;
            try {
                Intent i = new Intent();
                i.setComponent(new ComponentName(c[0], c[1]));
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                if (ctx.getPackageManager().resolveActivity(i, 0) != null) {
                    Log2.i("跳转" + tag + "：" + c[0] + "/" + c[1]);
                    return i;
                }
            } catch (Throwable ignored) {
            }
        }
        return null;
    }


    private static String brand(Context ctx) {
        return (android.os.Build.BRAND + " " + android.os.Build.MANUFACTURER).toLowerCase();
    }

    public static boolean openAppDetails(Context ctx) {
        try {
            Intent i = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
            i.setData(android.net.Uri.parse("package:" + ctx.getPackageName()));
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            return start(ctx, i);
        } catch (Throwable t) {
            return false;
        }
    }

    private static boolean start(Context ctx, Intent i) {
        try {
            if (ctx.getPackageManager().resolveActivity(i, 0) == null) return false;
            ctx.startActivity(i);
            return true;
        } catch (Throwable t) {
            return false;
        }
    }
}
