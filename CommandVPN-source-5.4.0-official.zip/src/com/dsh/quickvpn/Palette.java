package com.dsh.quickvpn;

import android.content.Context;

/** 深浅色共用的调色板。所有界面颜色都从这里取。 */
public class Palette {

    private static boolean dark(Context ctx) {
        return Theme.isDark(ctx);
    }

    public static int bg(Context c)       { return dark(c) ? 0xFF0F1115 : 0xFFF4F6F9; }
    public static int panel(Context c)    { return dark(c) ? 0xFF151922 : 0xFFFFFFFF; }
    public static int rowBg(Context c)    { return dark(c) ? 0xFF121620 : 0xFFFFFFFF; }
    public static int rowSel(Context c)   { return dark(c) ? 0xFF1B2436 : 0xFFDCE8FA; }
    public static int rowActive(Context c){ return dark(c) ? 0xFF12321F : 0xFFDCF3E3; }
    public static int text(Context c)     { return dark(c) ? 0xFFF0F3F8 : 0xFF1A1D23; }
    public static int textDim(Context c)  { return dark(c) ? 0xFF8A93A6 : 0xFF5B6472; }
    public static int textFaint(Context c){ return dark(c) ? 0xFF5E6678 : 0xFF8A93A6; }
    public static int hiddenTx(Context c) { return dark(c) ? 0xFF4C5261 : 0xFFB3BAC6; }
    public static int divider(Context c)  { return dark(c) ? 0xFF1C2029 : 0xFFE3E7EE; }
    public static int green(Context c)    { return dark(c) ? 0xFF5FD08A : 0xFF1F9D57; }
    public static int blue(Context c)     { return dark(c) ? 0xFF7FB2FF : 0xFF2F6FE0; }
    public static int orange(Context c)   { return dark(c) ? 0xFFE0A33C : 0xFFB8761A; }
    public static int red(Context c)      { return dark(c) ? 0xFFE06C75 : 0xFFC0392B; }
    public static int subOnRow(Context c) { return dark(c) ? 0xFF9AA3B5 : 0xFF6E7787; }
}
