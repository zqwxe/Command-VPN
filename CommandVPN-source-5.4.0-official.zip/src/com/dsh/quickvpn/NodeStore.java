package com.dsh.quickvpn;

import android.content.Context;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/** 从 assets/nodes.tsv 载入内置节点。每行： 国家码 \t 分享链接 */
public class NodeStore {

    /** URI 名单（shown/good/purged）在 prefs 里的最大长度，防止长期使用无限膨胀。 */
    private static final int URI_LIST_MAX_CHARS = 200 * 1024;

    /** 超长就按行裁掉最前面的部分，保留最近的记录。 */
    private static String capList(StringBuilder sb) {
        if (sb.length() <= URI_LIST_MAX_CHARS) return sb.toString();
        String all = sb.toString();
        int cut = all.length() - URI_LIST_MAX_CHARS;
        int nl = all.indexOf('\n', cut);
        return nl > 0 ? all.substring(nl + 1) : all.substring(cut);
    }

    private static List<Node> cached;
    private static List<Node> importedCache;
    private static java.util.Map<String, Integer> latencyCache;

    /* -------- 上次体检结果（写进 Download，卸载重装也能读回来） -------- */

    public static final String STATE_NAME = "CommandVPN-last-scan.txt";

    /** 把上次体检的可用节点写进 Download/CommandVPN/，卸载重装后能恢复。 */
    public static void saveStateFile(Context ctx, java.util.List<String> uris, String header) {
        try {
            StringBuilder sb = new StringBuilder(uris.size() * 90);
            sb.append("# ").append(header).append('\n');
            for (String u : uris) sb.append(u).append('\n');
            String text = sb.toString();
            if (android.os.Build.VERSION.SDK_INT >= 29) {
                android.net.Uri col = android.provider.MediaStore.Downloads.EXTERNAL_CONTENT_URI;
                // 先删掉同名的旧文件，保证只有一个
                try {
                    android.database.Cursor c = ctx.getContentResolver().query(col,
                            new String[]{android.provider.MediaStore.MediaColumns._ID},
                            android.provider.MediaStore.MediaColumns.DISPLAY_NAME + "=?",
                            new String[]{STATE_NAME}, null);
                    if (c != null) {
                        while (c.moveToNext()) {
                            ctx.getContentResolver().delete(
                                    android.content.ContentUris.withAppendedId(col, c.getLong(0)), null, null);
                        }
                        c.close();
                    }
                } catch (Throwable ignored) {
                }
                android.content.ContentValues v = new android.content.ContentValues();
                v.put(android.provider.MediaStore.MediaColumns.DISPLAY_NAME, STATE_NAME);
                v.put(android.provider.MediaStore.MediaColumns.MIME_TYPE, "text/plain");
                v.put(android.provider.MediaStore.MediaColumns.RELATIVE_PATH,
                        android.os.Environment.DIRECTORY_DOWNLOADS + "/CommandVPN");
                android.net.Uri uri = ctx.getContentResolver().insert(col, v);
                if (uri != null) {
                    java.io.OutputStream os = ctx.getContentResolver().openOutputStream(uri);
                    if (os != null) {
                        os.write(text.getBytes("UTF-8"));
                        os.close();
                    }
                }
            }
        } catch (Throwable ignored) {
        }
    }

    /** 读上次体检结果（没有就返回空）。 */
    public static java.util.List<String> readStateFile(Context ctx) {
        java.util.List<String> out = new java.util.ArrayList<String>();
        try {
            if (android.os.Build.VERSION.SDK_INT < 29) return out;
            android.net.Uri col = android.provider.MediaStore.Downloads.EXTERNAL_CONTENT_URI;
            android.database.Cursor c = ctx.getContentResolver().query(col,
                    new String[]{android.provider.MediaStore.MediaColumns._ID},
                    android.provider.MediaStore.MediaColumns.DISPLAY_NAME + "=?",
                    new String[]{STATE_NAME},
                    android.provider.MediaStore.MediaColumns.DATE_ADDED + " DESC");
            if (c == null) return out;
            long id = -1;
            try {
                if (c.moveToFirst()) id = c.getLong(0);
            } finally {
                c.close();
            }
            if (id < 0) return out;
            java.io.InputStream in = ctx.getContentResolver()
                    .openInputStream(android.content.ContentUris.withAppendedId(col, id));
            if (in == null) return out;
            java.io.BufferedReader r = new java.io.BufferedReader(new java.io.InputStreamReader(in, "UTF-8"));
            String line;
            while ((line = r.readLine()) != null) {
                line = line.trim();
                if (line.length() < 10 || line.startsWith("#")) continue;
                out.add(line);
            }
            r.close();
        } catch (Throwable ignored) {
        }
        return out;
    }

    /* -------- 用户手动"显示"的节点（不等于实测可用） -------- */

    private static java.util.Set<String> shownUris;

    private static synchronized java.util.Set<String> shown(Context ctx) {
        if (shownUris != null) return shownUris;
        shownUris = new java.util.HashSet<String>();
        try {
            String raw = ctx.getSharedPreferences("qv", Context.MODE_PRIVATE).getString("shown_uris", "");
            if (raw != null) {
                for (String line : raw.split("\n")) {
                    line = line.trim();
                    if (line.length() > 10) shownUris.add(line);
                }
            }
        } catch (Throwable ignored) {
        }
        return shownUris;
    }

    private static void saveShown(Context ctx) {
        try {
            java.util.Set<String> set = shown(ctx);
            StringBuilder sb = new StringBuilder(set.size() * 90);
            for (String u : set) sb.append(u).append('\n');
            ctx.getSharedPreferences("qv", Context.MODE_PRIVATE).edit()
                    .putString("shown_uris", capList(sb)).apply();
            cached = null;   // shown 只影响 all() 的过滤，跟解析缓存无关
        } catch (Throwable ignored) {
        }
    }

    /** 批量"显示"：一次改集合、一次写盘。 */
    public static synchronized int addShownAll(Context ctx, java.util.Collection<String> uris) {
        int added = 0;
        try {
            java.util.Set<String> set = shown(ctx);
            for (String u : uris) if (u != null && set.add(u)) added++;
            if (added > 0) saveShown(ctx);
        } catch (Throwable t) {
            Log2.w("批量显示失败：" + t);
        }
        return added;
    }

    public static synchronized void addShown(Context ctx, String uri) {
        try {
            if (uri != null && shown(ctx).add(uri)) saveShown(ctx);
        } catch (Throwable ignored) {
        }
    }

    public static synchronized void removeShown(Context ctx, String uri) {
        try {
            if (uri != null && shown(ctx).remove(uri)) saveShown(ctx);
        } catch (Throwable ignored) {
        }
    }

    /** 批量取消"已显示"（一次写盘）。 */
    public static synchronized int removeShownAll(Context ctx, java.util.Collection<String> uris) {
        int n = 0;
        try {
            java.util.Set<String> set = shown(ctx);
            for (String u : uris) if (u != null && set.remove(u)) n++;
            if (n > 0) saveShown(ctx);
        } catch (Throwable t) {
            Log2.w("批量取消显示失败：" + t);
        }
        return n;
    }

    public static boolean isShown(Context ctx, String uri) {
        try {
            return shown(ctx).contains(uri);
        } catch (Throwable t) {
            return false;
        }
    }

    /* -------- 实测可用名单（体检/连接测通的，默认视图靠它） -------- */

    private static java.util.Set<String> goodUris;

    private static synchronized java.util.Set<String> good(Context ctx) {
        if (goodUris != null) return goodUris;
        goodUris = new java.util.HashSet<String>();
        try {
            boolean seeded = ctx.getSharedPreferences("qv", Context.MODE_PRIVATE)
                    .getBoolean("good_seeded", false);
            String raw = ctx.getSharedPreferences("qv", Context.MODE_PRIVATE).getString("good_uris", null);
            if (raw != null && seeded) {
                // 已经初始化过：**无条件信任**，哪怕它是空的（体检全不通就是这个状态）
                for (String line : raw.split("\n")) {
                    line = line.trim();
                    if (line.length() > 10) goodUris.add(line);
                }
                return goodUris;
            }
            if (raw == null) {
                // 第一次运行（比如刚重装）：
                //   1) 先读 Download 里上次体检的结果（卸载重装也能恢复）
                //   2) 没有就用包里标的"实测可用"
                java.util.List<String> last = readStateFile(ctx);
                if (!last.isEmpty()) {
                    goodUris.addAll(last);
                } else {
                    for (Node n : parseAll(ctx)) {
                        if (n.verified) goodUris.add(n.uri);
                    }
                }
                StringBuilder sb = new StringBuilder(goodUris.size() * 90);
                for (String u : goodUris) sb.append(u).append('\n');
                ctx.getSharedPreferences("qv", Context.MODE_PRIVATE).edit()
                        .putString("good_uris", capList(sb))
                        .putBoolean("good_seeded", true).apply();
            } else {
                // 旧版本留下的数据（没有 seeded 标记）：读一次，写回标记
                for (String line : raw.split("\n")) {
                    line = line.trim();
                    if (line.length() > 10) goodUris.add(line);
                }
                ctx.getSharedPreferences("qv", Context.MODE_PRIVATE).edit()
                        .putBoolean("good_seeded", true).apply();
            }
        } catch (Throwable ignored) {
        }
        return goodUris;
    }

    /** 把测通的节点记进"实测可用"名单，默认视图就能看到它们。 */
    public static synchronized void addGoodUris(Context ctx, List<Node> nodes) {
        try {
            if (nodes == null || nodes.isEmpty()) return;
            java.util.Set<String> set = good(ctx);
            int before = set.size();
            for (Node n : nodes) if (n != null && n.uri != null) set.add(n.uri);
            if (set.size() == before) return;
            StringBuilder sb = new StringBuilder(set.size() * 90);
            for (String u : set) sb.append(u).append('\n');
            ctx.getSharedPreferences("qv", Context.MODE_PRIVATE).edit()
                    .putString("good_uris", capList(sb))
                    .putBoolean("good_seeded", true).apply();
            cached = null;
        } catch (Throwable ignored) {
        }
    }

    /**
     * 体检结束后更新"实测可用"名单，规则：
     *  · 这次测通的 → 一定在名单里
     *  · 上次在名单里、这次没测通的 → 还留一次（节点会抖，别一次失败就踢掉）
     *  · 连续两次没测通的 → 移出名单
     */
    public static synchronized int updateGoodAfterScan(Context ctx, List<Node> alive) {
        try {
            java.util.Set<String> prev = new java.util.HashSet<String>(good(ctx));
            java.util.Map<String, Integer> fails = loadGoodFails(ctx);
            java.util.Set<String> next = new java.util.HashSet<String>();
            if (alive != null) {
                for (Node n : alive) {
                    if (n == null || n.uri == null) continue;
                    next.add(n.uri);
                    fails.remove(n.uri);
                }
            }
            int kept = 0;
            for (String uri : prev) {
                if (next.contains(uri)) continue;
                int c = fails.containsKey(uri) ? fails.get(uri) : 0;
                if (c < 1) {              // 只失败过一次 → 再给它一次机会
                    next.add(uri);
                    fails.put(uri, c + 1);
                    kept++;
                } else {
                    fails.remove(uri);    // 连续两次失败 → 移出
                }
            }
            StringBuilder sb = new StringBuilder(next.size() * 90);
            for (String u : next) sb.append(u).append('\n');
            ctx.getSharedPreferences("qv", Context.MODE_PRIVATE).edit()
                    .putString("good_uris", capList(sb))
                    .putBoolean("good_seeded", true).apply();
            saveGoodFails(ctx, fails);
            goodUris = next;
            cached = null;
            return kept;
        } catch (Throwable t) {
            return 0;
        }
    }

    private static java.util.Map<String, Integer> loadGoodFails(Context ctx) {
        java.util.Map<String, Integer> map = new java.util.HashMap<String, Integer>();
        try {
            String raw = ctx.getSharedPreferences("qv", Context.MODE_PRIVATE).getString("good_fails", "");
            if (raw != null) {
                for (String line : raw.split("\n")) {
                    int bar = line.lastIndexOf('|');
                    if (bar <= 0) continue;
                    try {
                        map.put(line.substring(0, bar), Integer.parseInt(line.substring(bar + 1)));
                    } catch (Throwable ignored) {
                    }
                }
            }
        } catch (Throwable ignored) {
        }
        return map;
    }

    private static void saveGoodFails(Context ctx, java.util.Map<String, Integer> map) {
        try {
            StringBuilder sb = new StringBuilder(map.size() * 90);
            for (java.util.Map.Entry<String, Integer> e : map.entrySet()) {
                sb.append(e.getKey()).append('|').append(e.getValue()).append('\n');
            }
            ctx.getSharedPreferences("qv", Context.MODE_PRIVATE).edit()
                    .putString("good_fails", sb.toString()).apply();
        } catch (Throwable ignored) {
        }
    }

    /** 用这次体检的结果整体替换"实测可用"名单。 */
    public static synchronized void setGoodUris(Context ctx, List<Node> nodes) {
        try {
            java.util.Set<String> set = good(ctx);
            set.clear();
            if (nodes != null) {
                for (Node n : nodes) if (n != null && n.uri != null) set.add(n.uri);
            }
            StringBuilder sb = new StringBuilder(set.size() * 90);
            for (String u : set) sb.append(u).append('\n');
            ctx.getSharedPreferences("qv", Context.MODE_PRIVATE).edit()
                    .putString("good_uris", capList(sb))
                    .putBoolean("good_seeded", true).apply();
            cached = null;
        } catch (Throwable ignored) {
        }
    }

    /** 批量移除"实测可用"标记（体检中断时给没测到的节点用）。 */
    public static synchronized void removeGoodUris(Context ctx, java.util.Collection<String> uris) {
        try {
            if (uris == null || uris.isEmpty()) return;
            java.util.Set<String> set = good(ctx);
            int before = set.size();
            set.removeAll(uris);
            if (set.size() == before) return;
            StringBuilder sb = new StringBuilder(set.size() * 90);
            for (String u : set) sb.append(u).append('\n');
            ctx.getSharedPreferences("qv", Context.MODE_PRIVATE).edit()
                    .putString("good_uris", capList(sb)).apply();
            cached = null;
        } catch (Throwable ignored) {
        }
    }

    public static boolean isGood(Context ctx, String uri) {
        try {
            return good(ctx).contains(uri);
        } catch (Throwable t) {
            return false;
        }
    }

    public static synchronized void addGoodUri(Context ctx, String uri) {
        if (uri == null) return;
        java.util.Set<String> set = good(ctx);
        if (set.contains(uri)) return;
        set.add(uri);
        try {
            StringBuilder sb = new StringBuilder(set.size() * 90);
            for (String u : set) sb.append(u).append('\n');
            ctx.getSharedPreferences("qv", Context.MODE_PRIVATE).edit()
                    .putString("good_uris", capList(sb)).apply();
            cached = null;
        } catch (Throwable ignored) {
        }
    }

    /** true = 显示全部节点；false（默认）= 只显示实测可用的。 */
    public static boolean showAll(Context ctx) {
        try {
            return ctx.getSharedPreferences("qv", Context.MODE_PRIVATE).getBoolean("show_all", false);
        } catch (Throwable t) {
            return false;
        }
    }

    public static void setShowAll(Context ctx, boolean all) {
        try {
            ctx.getSharedPreferences("qv", Context.MODE_PRIVATE).edit().putBoolean("show_all", all).apply();
            cached = null;
        } catch (Throwable ignored) {
        }
    }

    /** 资产里一共有多少节点（不受"只显示可用"影响）。 */
    public static synchronized int totalCount(Context ctx) {
        java.util.Set<String> uris = new java.util.HashSet<String>();
        try {
            // 用"原始导入清单"，这样被隐藏的导入节点也算在内
            for (String u : importedRaw(ctx)) {
                if (!isPurged(ctx, u) && !isTrashed(ctx, u)) uris.add(u);
            }
            for (Node x : parseAll(ctx)) uris.add(x.uri);
        } catch (Throwable t) {
            return 0;
        }
        return uris.size();
    }

    private static List<Node> parsedCache;

    private static List<Node> parseAll(Context ctx) {
        if (parsedCache != null) return parsedCache;
        List<Node> built = parseAllUncached(ctx);
        parsedCache = built;
        return built;
    }

    private static List<Node> parseAllUncached(Context ctx) {
        // 不套"只看可用"过滤的完整列表（给体检/统计用）
        boolean prev = false;
        List<Node> list = new ArrayList<Node>();
        try {
            BufferedReader r = new BufferedReader(new InputStreamReader(ctx.getAssets().open("nodes.tsv"), "UTF-8"));
            String line;
            while ((line = r.readLine()) != null) {
                line = line.trim();
                if (line.length() == 0 || line.startsWith("#")) continue;
                String[] parts = line.split("\t", 4);
                String cc = "", flag = "", vflag = "", uri = line;
                if (parts.length >= 2) {
                    cc = parts[0].trim();
                    if (parts.length == 4) {
                        flag = parts[1].trim();
                        vflag = parts[2].trim();
                        uri = parts[3].trim();
                    } else if (parts.length == 3) {
                        flag = parts[1].trim();
                        uri = parts[2].trim();
                    } else {
                        uri = parts[1].trim();
                    }
                }
                try {
                    // 内置节点也允许被"识别地区"覆盖：否则给内置节点识别出来的国家存不下来，
                    // 表现就是"识别完成后列表里还是未识别地区"
                    String hint = importedCcMap(ctx).get(uri);
                    if (hint != null && hint.length() == 2) cc = hint;
                    Node n = new Node(uri, cc, "");
                    n.cf = "cf".equals(flag);
                    n.verified = "1".equals(vflag);
                    if (!n.supported || !ConfigBuilder.canBuild(n)) continue;
                    if (isPurged(ctx, uri)) continue;
                    if (isTrashed(ctx, uri)) continue;
                    list.add(n);
                } catch (Throwable ignored) {
                }
            }
            r.close();
        } catch (Throwable ignored) {
        }
        return list;
    }

    private static java.util.Map<String, Integer> totalByCc;

    /** 每个国家在资产里一共有多少节点（用来提示"另有 N 个未验证"）。 */
    public static synchronized java.util.Map<String, Integer> totalByCountry(Context ctx) {
        if (totalByCc != null) return totalByCc;
        java.util.Map<String, Integer> map = new java.util.HashMap<String, Integer>();
        try {
            for (Node n : parseAll(ctx)) {
                String cc = n.cc == null || n.cc.length() == 0 ? "ZZ" : n.cc;
                Integer c = map.get(cc);
                map.put(cc, c == null ? 1 : c + 1);
            }
        } catch (Throwable ignored) {
        }
        totalByCc = map;
        return map;
    }

    /** 体检用：全部节点（不管"只看可用"开关），但排除已隐藏的。 */
    public static synchronized List<Node> everything(Context ctx) {
        List<Node> out = new ArrayList<Node>();
        // 导入的节点也要参与体检（之前只遍历内置节点，导致"未识别地区"那批从不被体检）
        java.util.Set<String> seen = new java.util.HashSet<String>();
        for (Node imp : imported(ctx)) {
            if (isBlacklisted(ctx, imp.uri)) continue;
            if (!seen.add(imp.uri)) continue;
            out.add(imp);
        }
        for (Node n : parseAll(ctx)) {
            if (isBlacklisted(ctx, n.uri)) continue;
            if (!seen.add(n.uri)) continue;
            out.add(n);
        }
        applyLatencyCache(ctx, out);
        return out;
    }

    /** 体检用的候选节点；includeHidden=false 时排除已隐藏的。 */
    public static synchronized List<Node> scanCandidates(Context ctx, boolean includeHidden) {
        List<Node> out = new ArrayList<Node>();
        java.util.Set<String> seen = new java.util.HashSet<String>();
        for (Node n : allWithHidden(ctx)) {
            if (n == null || n.uri == null) continue;
            if (!includeHidden && n.hidden) continue;
            if (!seen.add(n.uri)) continue;
            out.add(n);
        }
        for (Node n : parseAll(ctx)) {
            if (n == null || n.uri == null) continue;
            if (isTrashed(ctx, n.uri) || isPurged(ctx, n.uri)) continue;
            boolean hidden = isBlacklisted(ctx, n.uri);
            if (!includeHidden && hidden) continue;
            if (!seen.add(n.uri)) continue;
            n.hidden = hidden;
            out.add(n);
        }
        applyLatencyCache(ctx, out);
        return out;
    }

    /** 每个国家"当前被隐藏"的节点数（含黑名单和未标记显示的），一次算好给界面用。 */
    public static synchronized java.util.Map<String, Integer> hiddenCountsByCountry(Context ctx) {
        java.util.Map<String, Integer> out = new java.util.HashMap<String, Integer>();
        try {
            java.util.Set<String> seen = new java.util.HashSet<String>();
            for (Node n : allWithHidden(ctx)) {
                if (n == null || n.cc == null) continue;
                if (!seen.add(n.uri)) continue;
                if (n.hidden) {
                    Integer c = out.get(n.cc);
                    out.put(n.cc, c == null ? 1 : c + 1);
                }
            }
            for (Node n : parseAll(ctx)) {
                if (n == null || n.cc == null) continue;
                if (isTrashed(ctx, n.uri) || isPurged(ctx, n.uri)) continue;
                if (!seen.add(n.uri)) continue;
                boolean hidden = isBlacklisted(ctx, n.uri)
                        || (!good(ctx).contains(n.uri) && !shown(ctx).contains(n.uri));
                if (hidden) {
                    Integer c = out.get(n.cc);
                    out.put(n.cc, c == null ? 1 : c + 1);
                }
            }
        } catch (Throwable ignored) {
        }
        return out;
    }

    /** 某个国家的全部节点（含隐藏，排除回收站/永久删除）。 */
    public static synchronized List<Node> countryNodesAll(Context ctx, String cc) {
        List<Node> out = new ArrayList<Node>();
        java.util.Set<String> seen = new java.util.HashSet<String>();
        try {
            for (Node n : allWithHidden(ctx)) {
                if (n == null || n.cc == null || !n.cc.equalsIgnoreCase(cc)) continue;
                if (!seen.add(n.uri)) continue;
                out.add(n);
            }
            for (Node n : parseAll(ctx)) {
                if (n == null || n.cc == null || !n.cc.equalsIgnoreCase(cc)) continue;
                if (isTrashed(ctx, n.uri) || isPurged(ctx, n.uri)) continue;
                if (!seen.add(n.uri)) continue;
                n.hidden = isBlacklisted(ctx, n.uri);
                out.add(n);
            }
        } catch (Throwable ignored) {
        }
        return out;
    }

    /** 这个国家一共多少节点（含隐藏）、当前可见多少。返回 {总数, 可见数}。 */
    public static synchronized int[] countryTotals(Context ctx, String cc) {
        int total = 0, visible = 0;
        try {
            java.util.Set<String> seen = new java.util.HashSet<String>();
            for (Node n : allWithHidden(ctx)) {
                if (n == null || n.cc == null || !n.cc.equalsIgnoreCase(cc)) continue;
                if (!seen.add(n.uri)) continue;
                total++;
                if (!n.hidden) visible++;
            }
            for (Node n : parseAll(ctx)) {
                if (n == null || n.cc == null || !n.cc.equalsIgnoreCase(cc)) continue;
                if (isTrashed(ctx, n.uri) || isPurged(ctx, n.uri)) continue;
                if (!seen.add(n.uri)) continue;
                total++;
                if (!isBlacklisted(ctx, n.uri)) visible++;
            }
        } catch (Throwable ignored) {
        }
        return new int[]{total, visible};
    }

    /* ---------------------------- 推荐地区 ---------------------------- */

    private static java.util.Set<String> recommendedCcs;

    /** 打包时标记的"推荐地区"（assets/recommended_countries.txt，一行一个国家码）。 */
    public static synchronized java.util.Set<String> recommendedCountries(Context ctx) {
        if (recommendedCcs != null) return recommendedCcs;
        recommendedCcs = new java.util.HashSet<String>();
        try {
            java.io.BufferedReader r = new java.io.BufferedReader(
                    new java.io.InputStreamReader(ctx.getAssets().open("recommended_countries.txt"), "UTF-8"));
            String line;
            while ((line = r.readLine()) != null) {
                line = line.trim().toUpperCase();
                if (line.length() >= 2 && !line.startsWith("#")) recommendedCcs.add(line);
            }
            r.close();
        } catch (Throwable ignored) {
        }
        return recommendedCcs;
    }

    public static boolean isRecommendedCountry(Context ctx, String cc) {
        try {
            return cc != null && recommendedCountries(ctx).contains(cc.toUpperCase());
        } catch (Throwable t) {
            return false;
        }
    }

    /** 某个国家的全部节点（含未验证的，但排除回收站里的）。 */
    public static synchronized List<Node> allOfCountry(Context ctx, String cc) {
        List<Node> out = new ArrayList<Node>();
        for (Node n : parseAll(ctx)) {
            if (n.cc != null && n.cc.equalsIgnoreCase(cc)) out.add(n);
        }
        for (Node n : imported(ctx)) {
            if (isTrashed(ctx, n.uri)) continue;
            if (n.cc != null && n.cc.equalsIgnoreCase(cc)) out.add(n);
        }
        return out;
    }

    /** 全部节点（含未验证的、被隐藏的、自己导入的），并标出 hidden —— 编辑模式不划线时用。 */
    /**
     * 用于"按 IP 识别地区"的全集：可见 + 隐藏的导入节点，再加上内置节点。
     * （之前只用 allWithHidden，内置节点里的"未识别地区"会被漏掉——
     *   表现就是列表里有 3 个未识别地区，点识别却说"没有"。）
     */
    public static synchronized List<Node> allForClassify(Context ctx) {
        List<Node> out = new ArrayList<Node>();
        java.util.Set<String> seen = new java.util.HashSet<String>();
        for (Node n : allWithHidden(ctx)) {
            if (n == null || n.uri == null) continue;
            if (!seen.add(n.uri)) continue;
            out.add(n);
        }
        for (Node n : parseAll(ctx)) {
            if (n == null || n.uri == null) continue;
            if (isTrashed(ctx, n.uri) || isPurged(ctx, n.uri)) continue;
            if (!seen.add(n.uri)) continue;
            out.add(n);
        }
        applyLatencyCache(ctx, out);
        return out;
    }

    public static synchronized List<Node> allWithHidden(Context ctx) {
        List<Node> out = new ArrayList<Node>();
        java.util.Set<String> goodSet = good(ctx);
        java.util.Set<String> seen = new java.util.HashSet<String>();   // 按 uri 去重
        // 这里必须用"原始导入清单"：imported() 会把已隐藏/拉黑的节点过滤掉，
        // 用它的话"眼睛打开"也永远不会出现隐藏节点
        java.util.Map<String, String> ccMap = importedCcMap(ctx);
        for (String uri : importedRaw(ctx)) {
            if (isTrashed(ctx, uri) || isPurged(ctx, uri)) continue;
            if (!seen.add(uri)) continue;
            try {
                String cc = ccMap.get(uri);
                if (cc == null || cc.length() != 2) cc = "ZZ";
                Node n = new Node(uri, cc != null && cc.length() == 2 ? cc : "ZZ", "");
                if (!n.supported || !ConfigBuilder.canBuild(n)) continue;
                n.hidden = isBlacklisted(ctx, uri)
                        || (!goodSet.contains(uri) && !shown(ctx).contains(uri));
                out.add(n);
            } catch (Throwable ignored) {
            }
        }
        for (Node n : parseAll(ctx)) {
            if (!seen.add(n.uri)) continue;      // 与导入的重复时只留一份
            n.hidden = isBlacklisted(ctx, n.uri)
                    || (!goodSet.contains(n.uri) && !shown(ctx).contains(n.uri));
            out.add(n);
        }
        applyLatencyCache(ctx, out);
        return out;
    }

    public static synchronized List<Node> all(Context ctx) {
        if (cached != null) return cached;
        List<Node> list = new ArrayList<Node>();
        java.util.Set<String> seen = new java.util.HashSet<String>();
        for (Node imp : imported(ctx)) {            // 自己导入的也遵守隐藏/回收站
            if (isBlacklisted(ctx, imp.uri) || isTrashed(ctx, imp.uri)) continue;
            if (!seen.add(imp.uri)) continue;
            list.add(imp);
        }
        for (Node n : parseAll(ctx)) {              // 复用缓存解析结果
            if (isBlacklisted(ctx, n.uri)) continue;
            if (!seen.add(n.uri)) continue;         // 与导入的重复时只留一份
            list.add(n);
        }
        applyLatencyCache(ctx, list);
        if (!showAll(ctx)) {
            java.util.Set<String> goodSet = good(ctx);
            java.util.Set<String> shownSet = shown(ctx);
            List<Node> only = new ArrayList<Node>();
            for (Node n : list) {
                if (goodSet.contains(n.uri) || shownSet.contains(n.uri)) only.add(n);
            }
            cached = only;
            return only;
        }
        cached = list;
        return list;
    }
    /** 从节点链接里猜国家码（优先看 # 后面的名字）。 */
    /** 导入节点的国家提示表（uri -> cc），名字里没有国家信息时用它。 */
    private static java.util.Map<String, String> importedCcCache;

    public static synchronized java.util.Map<String, String> importedCcMap(Context ctx) {
        if (importedCcCache != null) return importedCcCache;
        java.util.Map<String, String> m = new java.util.HashMap<String, String>();
        try {
            String raw = ctx.getSharedPreferences("qv", Context.MODE_PRIVATE).getString("imported_cc", "");
            if (raw != null && raw.length() > 0) {
                for (String line : raw.split("\n")) {
                    int tab = line.indexOf('\t');
                    if (tab > 0) m.put(line.substring(tab + 1), line.substring(0, tab));
                }
            }
        } catch (Throwable ignored) {
        }
        importedCcCache = m;
        return m;
    }

    /** 批量写入导入节点的国家。 */
    /** 记录"这个链接的国家是 Google 出口判定的"，手动三源识别不要覆盖它。 */
    private static final String PREF_GOOGLE_CC = "cc_from_google";

    public static synchronized void markCcFromGoogle(Context ctx, String uri, String cc) {
        try {
            if (uri == null || cc == null || cc.length() != 2) return;
            java.util.Set<String> set = googleCcSet(ctx);
            set.add(uri + "\t" + cc);
            saveGoogleCc(ctx, set);
        } catch (Throwable ignored) {
        }
    }

    public static synchronized boolean isCcFromGoogle(Context ctx, String uri) {
        try {
            for (String line : googleCcSet(ctx)) {
                int tab = line.indexOf('\t');
                if (tab > 0 && uri.equals(line.substring(0, tab))) return true;
            }
        } catch (Throwable ignored) {
        }
        return false;
    }

    private static java.util.Set<String> googleCcCache;

    private static java.util.Set<String> googleCcSet(Context ctx) {
        if (googleCcCache != null) return googleCcCache;
        googleCcCache = new java.util.HashSet<String>();
        try {
            String raw = ctx.getSharedPreferences("qv", Context.MODE_PRIVATE).getString(PREF_GOOGLE_CC, "");
            if (raw != null) {
                for (String line : raw.split("\n")) {
                    if (line.trim().length() > 8) googleCcCache.add(line.trim());
                }
            }
        } catch (Throwable ignored) {
        }
        return googleCcCache;
    }

    private static void saveGoogleCc(Context ctx, java.util.Set<String> set) {
        try {
            StringBuilder sb = new StringBuilder();
            for (String line : set) sb.append(line).append('\n');
            ctx.getSharedPreferences("qv", Context.MODE_PRIVATE).edit()
                    .putString(PREF_GOOGLE_CC, sb.toString()).apply();
        } catch (Throwable ignored) {
        }
    }

    public static synchronized void setImportedCcBatch(Context ctx, java.util.Map<String, String> add) {
        try {
            if (add == null || add.isEmpty()) return;
            java.util.Map<String, String> m = importedCcMap(ctx);
            m.putAll(add);
            StringBuilder sb = new StringBuilder(m.size() * 40);
            for (java.util.Map.Entry<String, String> e : m.entrySet()) {
                sb.append(e.getValue()).append('\t').append(e.getKey()).append('\n');
            }
            ctx.getSharedPreferences("qv", Context.MODE_PRIVATE).edit()
                    .putString("imported_cc", sb.toString()).apply();
            importedCache = null;
            cached = null;
            parsedCache = null;
        } catch (Throwable t) {
            Log2.w("写导入国家失败：" + t);
        }
    }

    /** 清掉这些链接的历史地区缓存，让它们重新从"未识别地区"开始（新导入时用）。 */
    public static synchronized void clearCcHints(Context ctx, java.util.Collection<String> uris) {
        try {
            if (uris == null || uris.isEmpty()) return;
            java.util.Map<String, String> m = importedCcMap(ctx);
            int before = m.size();
            m.keySet().removeAll(uris);
            if (m.size() == before) return;
            StringBuilder sb = new StringBuilder(m.size() * 40);
            for (java.util.Map.Entry<String, String> e : m.entrySet()) {
                sb.append(e.getValue()).append('\t').append(e.getKey()).append('\n');
            }
            ctx.getSharedPreferences("qv", Context.MODE_PRIVATE).edit()
                    .putString("imported_cc", sb.toString()).apply();
            importedCache = null;
            cached = null;
            parsedCache = null;
        } catch (Throwable t) {
            Log2.w("清理地区缓存失败：" + t);
        }
    }

    private static boolean isCacheKey(String k) {
        return k.startsWith("cloud_nodes_") || k.startsWith("cloud_state_")
                || k.startsWith("cloud_total_") || k.startsWith("cloud_cache_")
                || k.equals("imported_cc") || k.equals("geo_ip_cache_v1")
                || k.equals("cc_from_google") || k.equals("snap_good")
                || k.equals("snap_shown") || k.equals("snap_black");
    }

    /** 各类缓存占用的字节数（含延迟表和地区结果；不含回收站/隐藏/永久删除这些用户数据）。 */
    public static synchronized long cacheBytes(Context ctx) {
        long bytes = 0;
        try {
            for (java.util.Map.Entry<String, ?> e : ctx.getSharedPreferences("qv", Context.MODE_PRIVATE)
                    .getAll().entrySet()) {
                if (!isCacheKey(e.getKey())) continue;
                Object v = e.getValue();
                if (v instanceof String) bytes += ((String) v).length() * 2L;
            }
            java.io.File lat = new java.io.File(ctx.getFilesDir(), "latency.tsv");
            if (lat.exists()) bytes += lat.length();
        } catch (Throwable ignored) {
        }
        return bytes;
    }

    public static String formatBytes(long b) {
        if (b < 1024) return b + " B";
        if (b < 1024 * 1024) return String.format(java.util.Locale.US, "%.1f KB", b / 1024.0);
        return String.format(java.util.Locale.US, "%.1f MB", b / 1024.0 / 1024.0);
    }

    /**
     * 清空全部缓存：云节点缓存/延迟表/地区识别结果。
     * 回收站、已隐藏、永久删除名单属于用户数据，不清。
     */
    public static synchronized long clearAllCaches(Context ctx) {
        long bytes = cacheBytes(ctx);
        try {
            android.content.SharedPreferences sp = ctx.getSharedPreferences("qv", Context.MODE_PRIVATE);
            android.content.SharedPreferences.Editor ed = sp.edit();
            int n = 0;
            for (String k : new java.util.ArrayList<String>(sp.getAll().keySet())) {
                if (isCacheKey(k)) {
                    ed.remove(k);
                    n++;
                }
            }
            ed.apply();
            try {
                java.io.File lat = new java.io.File(ctx.getFilesDir(), "latency.tsv");
                if (lat.exists()) lat.delete();
            } catch (Throwable ignored) {
            }
            importedCcCache = null;
            importedCache = null;
            cached = null;
            parsedCache = null;
            latencyCache = null;
            googleCcCache = null;
            GeoClassifier.clearIpCache();
            Log2.i("已清除全部缓存：" + n + " 项，" + formatBytes(bytes));
        } catch (Throwable t) {
            Log2.w("清除缓存失败：" + t);
        }
        return bytes;
    }

    /**
     * 一次性去重：同一台服务器（协议+主机+端口）只保留一条。
     * 优先保留：最近连通过的 > 有延迟记录的（延迟低）> 先出现的。
     */
    public static synchronized void dedupeByServer(Context ctx) {
        try {
            android.content.SharedPreferences sp = ctx.getSharedPreferences("qv", Context.MODE_PRIVATE);
            if (sp.getBoolean("dedupe_hostport_v1", false)) return;
            String raw = sp.getString("imported", "");
            java.util.LinkedHashSet<String> keep = new java.util.LinkedHashSet<String>();
            java.util.Map<String, String> byKey = new java.util.HashMap<String, String>();
            java.util.Map<String, Integer> lat = latencyCache(ctx);
            String lastGood = sp.getString("last_good", "");
            java.util.List<String> removed = new java.util.ArrayList<String>();
            if (raw != null) {
                for (String line : raw.split("\n")) {
                    line = line.trim();
                    if (line.length() < 8) continue;
                    String key;
                    try {
                        Node n = new Node(line, "ZZ", "");
                        key = n.protocol + "|" + n.host + "|" + n.port;
                    } catch (Throwable t) {
                        keep.add(line);
                        continue;
                    }
                    String prev = byKey.get(key);
                    if (prev == null) {
                        byKey.put(key, line);
                        keep.add(line);
                    } else {
                        // 已有同服务器的一条：比较谁更值得留
                        boolean better = line.equals(lastGood) && !prev.equals(lastGood);
                        if (!better) {
                            Integer a = lat.get(prev), b = lat.get(line);
                            better = b != null && b > 0 && (a == null || a <= 0 || b < a);
                        }
                        if (better) {
                            keep.remove(prev);
                            keep.add(line);
                            byKey.put(key, line);
                            removed.add(prev);
                        } else {
                            removed.add(line);
                        }
                    }
                }
            }
            sp.edit().putString("imported", join(keep))
                    .putBoolean("dedupe_hostport_v1", true).apply();
            if (!removed.isEmpty()) Log2.i("节点去重：同一服务器的重复项移除 " + removed.size() + " 条");
        } catch (Throwable t) {
            Log2.w("节点去重失败：" + t);
        }
    }

    private static String join(java.util.Collection<String> c) {
        StringBuilder sb = new StringBuilder();
        for (String s : c) sb.append(s).append('\n');
        return sb.toString();
    }

    /** 一次性清理：旧版把 base64 里的 "it" 误判成意大利，去掉这些错误的 cc 缓存。 */
    public static synchronized void fixWrongItCache(Context ctx) {
        try {
            android.content.SharedPreferences sp = ctx.getSharedPreferences("qv", Context.MODE_PRIVATE);
            if (sp.getBoolean("fix_cc_it_v1", false)) return;
            String raw = sp.getString("imported_cc", "");
            if (raw != null && raw.length() > 0) {
                StringBuilder sb = new StringBuilder();
                int dropped = 0;
                for (String line : raw.split("\n")) {
                    int tab = line.lastIndexOf('\t');
                    if (tab <= 0) continue;
                    String uri = line.substring(0, tab);
                    String cc = line.substring(tab + 1);
                    if ("IT".equalsIgnoreCase(cc) && Country.detectFromUri(uri).length() != 2) {
                        dropped++;
                        continue;
                    }
                    sb.append(line).append('\n');
                }
                sp.edit().putString("imported_cc", sb.toString())
                        .putBoolean("fix_cc_it_v1", true).apply();
                if (dropped > 0) Log2.i("清理误判为意大利的地区缓存：" + dropped + " 条（会变成未识别地区）");
            } else {
                sp.edit().putBoolean("fix_cc_it_v1", true).apply();
            }
        } catch (Throwable t) {
            Log2.w("清理地区缓存失败：" + t);
        }
    }

    /**
     * 一次性迁移：以前节点的国家来自"名字/国旗"（源经常乱标），
     * 现在改为只信 IP 识别结果。清空旧缓存，让所有导入节点回到未识别地区，
     * 等下一次"体检并识别 IP"重新判定。
     */
    public static synchronized void resetNameDerivedCountries(Context ctx) {
        try {
            android.content.SharedPreferences sp = ctx.getSharedPreferences("qv", Context.MODE_PRIVATE);
            if (sp.getBoolean("cc_name_reset_v1", false)) return;
            sp.edit().remove("imported_cc").putBoolean("cc_name_reset_v1", true).apply();
            importedCcCache = null;
            importedCache = null;
            cached = null;
            parsedCache = null;
            Log2.i("地区归类迁移：清空按名字/国旗推断的旧结果，统一改为按 IP 识别");
        } catch (Throwable t) {
            Log2.w("地区归类迁移失败：" + t);
        }
    }

    public static String detectCcOf(String uri) {
        try {
            return Country.detectFromUri(uri);   // 统一走带乱码修复 + 中转出口判断的逻辑
        } catch (Throwable t) {
            return "";
        }
    }

    public static synchronized List<Node> imported(Context ctx) {
        if (importedCache != null) return importedCache;
        List<Node> out = new ArrayList<>();
        int skippedUnsupported = 0;
        try {
            String raw = ctx.getSharedPreferences("qv", Context.MODE_PRIVATE).getString("imported", "");
            if (raw != null && raw.length() > 0) {
                for (String line : raw.split("\n")) {
                    line = line.trim();
                    if (line.length() < 8 || !line.contains("://")) continue;
                    try {
                        // 不再从节点名/国旗猜国家（源经常乱标）。
                        // 只认"按 IP 识别"的结果；没有就保持未识别地区。
                        String cc = importedCcMap(ctx).get(line);
                        if (cc == null || cc.length() != 2) cc = "ZZ";
                        Node n = new Node(line, cc.length() == 2 ? cc : "ZZ", "");
                        // 永久删除 / 回收站里的导入节点不能再冒出来
                        if (isPurged(ctx, line) || isTrashed(ctx, line)) continue;
                        if (n.supported && ConfigBuilder.canBuild(n) && !isBlacklisted(ctx, line)) out.add(n);
                        else if (!n.supported || !ConfigBuilder.canBuild(n)) skippedUnsupported++;
                    } catch (Throwable ignored) {
                    }
                }
            }
        } catch (Throwable ignored) {
        }
        if (skippedUnsupported > 0) {
            Log2.i("加载节点：跳过 " + skippedUnsupported + " 个参数不合法/不支持的节点（如 reality 公钥错误）");
        }
        importedCache = out;
        return out;
    }

    /** 这个链接是否已经存在（内置节点或已导入的都算）。 */
    public static synchronized boolean containsUri(Context ctx, String uri) {
        if (uri == null) return false;
        try {
            for (Node n : parseAll(ctx)) if (uri.equals(n.uri)) return true;
            for (Node n : imported(ctx)) if (uri.equals(n.uri)) return true;
        } catch (Throwable ignored) {
        }
        return false;
    }

    /** 清空全部导入的节点（内置的不受影响）。返回清掉的数量。 */
    public static synchronized int clearImported(Context ctx) {
        int n = 0;
        try {
            // 与界面上的"清空导入的节点（N 个）"用同一个口径：
            // 已显示 + 已隐藏 + 回收站（含隐藏），不含永久删除的
            n = clearableCount(ctx);
            android.content.SharedPreferences sp = ctx.getSharedPreferences("qv", Context.MODE_PRIVATE);
            android.content.SharedPreferences.Editor ed = sp.edit()
                    .remove("imported").remove("imported_cc")
                    .remove("trash").remove("purged_uris")
                    .remove("good_uris").remove("shown_uris")
                    .remove("snap_good").remove("snap_shown").remove("snap_black");
            // 各网络各自的"已隐藏"名单也要一起清掉
            for (String k : sp.getAll().keySet()) {
                if (k.startsWith("blacklist_")) ed.remove(k);
            }
            ed.apply();
            try {
                java.io.File lat = new java.io.File(ctx.getFilesDir(), "latency.tsv");
                if (lat.exists()) lat.delete();
            } catch (Throwable ignored) {
            }
            importedCcCache = null;
            importedCache = null;
            cached = null;
            parsedCache = null;
            totalByCc = null;
            // 关键：回收站/显示/可用/隐藏名单都有内存缓存，不失效的话
            // 清空后界面（尤其回收站）看起来完全没变
            trashSet = null;
            trashUriSet = null;
            goodUris = null;
            shownUris = null;
            blacklists.clear();
            blacklistUriIndex.clear();
            latencyCache = null;
            Log2.i("已清空导入节点：" + n + " 个");
        } catch (Throwable t) {
            Log2.w("清空导入节点失败：" + t);
        }
        return n;
    }

    /**
     * "当前确实存在的节点"链接集合（内置 + 导入），用于批量去重。
     * 注意：必须用过滤后的 imported()——回收站/永久删除/已隐藏的都不算"存在"，
     * 否则清空回收站后这些节点会永远导不进来。
     */
    public static synchronized java.util.Set<String> allUris(Context ctx) {
        java.util.Set<String> set = new java.util.HashSet<String>();
        try {
            for (Node n : parseAll(ctx)) set.add(n.uri);
            for (Node n : imported(ctx)) set.add(n.uri);
        } catch (Throwable ignored) {
        }
        return set;
    }

    /** 批量导入（一次写盘）。返回真正新增的数量。 */
    /** 数据变动后统一失效所有缓存（避免"改了数据但列表还是旧的"）。 */
    private static void invalidateAll(Context ctx) {
        try {
            importedCache = null;
            importedCcCache = null;
            cached = null;
            parsedCache = null;
            totalByCc = null;
            blacklists.clear();
            blacklistUriIndex.clear();
        } catch (Throwable ignored) {
        }
    }

    /** 已永久删除的链接集合。 */
    public static synchronized java.util.Set<String> purgedUris(Context ctx) {
        try {
            return new java.util.HashSet<String>(purged(ctx));
        } catch (Throwable t) {
            return new java.util.HashSet<String>();
        }
    }

    /** 回收站里的链接集合。 */
    public static synchronized java.util.Set<String> trashedUris(Context ctx) {
        java.util.Set<String> out = new java.util.HashSet<String>();
        try {
            for (String l : trash(ctx)) {
                String u = uriOf(l);
                if (u != null && u.length() > 8) out.add(u);
            }
        } catch (Throwable ignored) {
        }
        return out;
    }

    public static synchronized int addImportedBatch(Context ctx, java.util.Collection<String> uris) {
        int added = 0;
        try {
            if (uris == null || uris.isEmpty()) return 0;
            android.content.SharedPreferences sp = ctx.getSharedPreferences("qv", Context.MODE_PRIVATE);
            String raw = sp.getString("imported", "");
            if (raw == null) raw = "";
            java.util.LinkedHashSet<String> all = new java.util.LinkedHashSet<String>();
            for (String line : raw.split("\n")) {
                line = line.trim();
                if (line.length() > 8) all.add(line);
            }
            for (String u : uris) {
                if (u == null) continue;
                u = u.trim();
                if (u.length() < 10) continue;
                if (all.add(u)) added++;
            }
            if (added > 0) {
                StringBuilder sb = new StringBuilder(all.size() * 110);
                for (String u : all) sb.append(u).append('\n');
                sp.edit().putString("imported", sb.toString()).apply();
                importedCache = null;
                cached = null;
                parsedCache = null;
            }
        } catch (Throwable t) {
            Log2.w("批量导入失败：" + t);
        }
        return added;
    }

    /** 批量加入"已显示"（一次写盘）。 */
    public static synchronized void addShownBatch(Context ctx, java.util.Collection<String> uris) {
        try {
            if (uris == null || uris.isEmpty()) return;
            java.util.Set<String> set = shown(ctx);
            if (set.addAll(uris)) saveShown(ctx);
        } catch (Throwable ignored) {
        }
    }

    public static synchronized boolean addImported(Context ctx, String uri) {
        try {
            String raw = ctx.getSharedPreferences("qv", Context.MODE_PRIVATE).getString("imported", "");
            if (raw == null) raw = "";
            for (String line : raw.split("\n")) {
                if (line.trim().equals(uri.trim())) return false;
            }
            String next = raw.length() == 0 ? uri.trim() : (raw.trim() + "\n" + uri.trim());
            ctx.getSharedPreferences("qv", Context.MODE_PRIVATE).edit().putString("imported", next).apply();
            importedCache = null;
            cached = null;
            return true;
        } catch (Throwable t) {
            return false;
        }
    }

    public static synchronized void reload(Context ctx) {
        cached = null;
        importedCache = null;
        netKeyCache = null;          // 切网/重载后重新判定网络类型
    }

    private static java.io.File latencyFile(Context ctx) {
        return new java.io.File(ctx.getFilesDir(), "latency.tsv");
    }

    private static synchronized java.util.Map<String, Integer> latencyCache(Context ctx) {
        if (latencyCache != null) return latencyCache;
        latencyCache = new java.util.HashMap<String, Integer>();
        try {
            java.io.File f = latencyFile(ctx);
            if (f.isFile()) {
                BufferedReader r = new BufferedReader(new InputStreamReader(new java.io.FileInputStream(f), "UTF-8"));
                String line;
                while ((line = r.readLine()) != null) {
                    int tab = line.indexOf('\t');
                    if (tab <= 0) continue;
                    try {
                        latencyCache.put(line.substring(tab + 1), Integer.parseInt(line.substring(0, tab)));
                    } catch (Exception ignored) {
                    }
                }
                r.close();
            }
        } catch (Throwable ignored) {
        }
        return latencyCache;
    }

    private static void applyLatencyCache(Context ctx, List<Node> list) {
        try {
            java.util.Map<String, Integer> cache = latencyCache(ctx);
            if (cache.isEmpty()) return;
            for (Node n : list) {
                Integer ms = cache.get(n.uri);
                if (ms != null) n.latency = ms;
            }
        } catch (Throwable ignored) {
        }
    }

    /** 把测到的延迟写盘，下次打开就不用重测。 */
    public static synchronized void saveLatencies(Context ctx, List<Node> list) {
        try {
            java.util.Map<String, Integer> cache = latencyCache(ctx);
            for (Node n : list) {
                if (n.latency > 0) cache.put(n.uri, n.latency);
            }
            StringBuilder sb = new StringBuilder(cache.size() * 80);
            for (java.util.Map.Entry<String, Integer> e : cache.entrySet()) {
                sb.append(e.getValue()).append('\t').append(e.getKey()).append('\n');
            }
            java.io.FileOutputStream out = new java.io.FileOutputStream(latencyFile(ctx));
            out.write(sb.toString().getBytes("UTF-8"));
            out.close();
        } catch (Throwable ignored) {
        }
    }

    /** 按国家/地区分组；组按节点数从多到少排，组内按延迟升序。 */
    public static synchronized List<Country> countries(Context ctx) {
        return countries(ctx, false);
    }

    public static synchronized List<Country> countries(Context ctx, boolean withHidden) {
        List<Node> list = withHidden ? allWithHidden(ctx) : all(ctx);
        Map<String, List<Node>> grouped = new LinkedHashMap<String, List<Node>>();
        for (Node n : list) {
            String cc = n.cc == null || n.cc.length() != 2 ? "ZZ" : n.cc.toUpperCase(Locale.ROOT);
            if ("**".equals(cc)) cc = "ZZ";   // 不再单独搞「我导入的」，归到未识别地区
            List<Node> bucket = grouped.get(cc);
            if (bucket == null) {
                bucket = new ArrayList<Node>();
                grouped.put(cc, bucket);
            }
            bucket.add(n);
        }
        List<Country> out = new ArrayList<Country>();
        for (Map.Entry<String, List<Node>> e : grouped.entrySet()) {
            out.add(new Country(e.getKey(), e.getValue()));
        }
        // 先把排序要用的东西取出来，别在比较器里反复读 SharedPreferences
        final java.util.Set<String> goodCcs = new java.util.HashSet<String>();
        final java.util.List<String> pins = pinnedList(ctx);
        for (Country c : out) {
            if (countryGoodUri(ctx, c.cc).length() > 0) goodCcs.add(c.cc);
        }
        Collections.sort(out, new Comparator<Country>() {
            @Override
            public int compare(Country a, Country b) {
                // 上次连通过的国家排前面（US/JP 这种能用的会浮到顶部）
                boolean ga = goodCcs.contains(a.cc);
                boolean gb = goodCcs.contains(b.cc);
                if (ga != gb) return ga ? -1 : 1;
                int ra = pins.indexOf(a.cc), rb = pins.indexOf(b.cc);
                if ((ra >= 0) != (rb >= 0)) return ra >= 0 ? -1 : 1;
                if (ra >= 0 && rb >= 0 && ra != rb) return ra - rb;
                if (a.nodes.size() != b.nodes.size()) return b.nodes.size() - a.nodes.size();
                return a.name.compareTo(b.name);
            }
        });
        return out;
    }

    public static Node selected(Context ctx) {
        List<Node> l = all(ctx);
        if (l.isEmpty()) return null;
        return l.get(selectedIndex(ctx));
    }

    public static int selectedIndex(Context ctx) {
        List<Node> l = all(ctx);
        if (l.isEmpty()) return 0;
        int idx = ctx.getSharedPreferences("qv", Context.MODE_PRIVATE).getInt("node", 0);
        return (idx < 0 || idx >= l.size()) ? 0 : idx;
    }

    public static int measuredCount(Context ctx) {
        int c = 0;
        for (Node n : all(ctx)) if (n.latency > 0) c++;
        return c;
    }


    /* ---------------------- 体检前的状态快照（可一键还原） ---------------------- */

    /** 体检开始前拍一张快照：实测可用 / 隐藏 / 手动显示 三份名单。 */
    public static synchronized void snapshotBeforeScan(Context ctx) {
        try {
            android.content.SharedPreferences sp = ctx.getSharedPreferences("qv", Context.MODE_PRIVATE);
            String net = netKey(ctx);
            sp.edit()
                    .putString("snap_good", sp.getString("good_uris", ""))
                    .putString("snap_shown", sp.getString("shown_uris", ""))
                    .putString("snap_black", sp.getString("blacklist_" + net, ""))
                    .putString("snap_net", net)
                    .putBoolean("snap_valid", true)
                    .putLong("snap_at", System.currentTimeMillis())
                    .apply();
            Log2.i("体检前已保存状态快照（可用 " + good(ctx).size()
                    + " · 隐藏 " + blacklist(ctx).size() + " · 手动显示 " + shown(ctx).size() + "）");
        } catch (Throwable t) {
            Log2.w("保存体检快照失败：" + t);
        }
    }

    public static boolean hasSnapshot(Context ctx) {
        try {
            return ctx.getSharedPreferences("qv", Context.MODE_PRIVATE).getBoolean("snap_valid", false);
        } catch (Throwable t) {
            return false;
        }
    }

    /** 恢复到体检之前的状态（实测可用 / 隐藏 / 手动显示 全部还原）。 */
    public static synchronized boolean restoreSnapshot(Context ctx) {
        try {
            android.content.SharedPreferences sp = ctx.getSharedPreferences("qv", Context.MODE_PRIVATE);
            if (!sp.getBoolean("snap_valid", false)) return false;
            String snapNet = sp.getString("snap_net", netKey(ctx));
            String curNet = netKey(ctx);
            android.content.SharedPreferences.Editor e = sp.edit()
                    .putString("good_uris", sp.getString("snap_good", ""))
                    .putString("shown_uris", sp.getString("snap_shown", ""))
                    .putString("blacklist_" + snapNet, sp.getString("snap_black", ""))
                    .putBoolean("good_seeded", true)
                    .putBoolean("snap_valid", false);
            if (!snapNet.equals(curNet)) {
                // 体检期间可能切过网：当前网络也写回同一份，否则"恢复"看起来没生效
                e.putString("blacklist_" + curNet, sp.getString("snap_black", ""));
            }
            e.apply();
            // 快照里的节点如果是在体检过程中被丢进回收站的，恢复时要一并撤出回收站，
            // 否则界面上说"已恢复"，列表里却仍然没有它们
            try {
                java.util.Set<String> snapUris = new java.util.HashSet<String>();
                for (String line : sp.getString("snap_good", "").split("\n")) {
                    line = line.trim();
                    if (line.length() > 8) snapUris.add(line);
                }
                for (String line : sp.getString("snap_shown", "").split("\n")) {
                    line = line.trim();
                    if (line.length() > 8) snapUris.add(line);
                }
                if (!snapUris.isEmpty()) {
                    java.util.Set<String> tset = trash(ctx);
                    java.util.List<String> drop = new java.util.ArrayList<String>();
                    for (String l : tset) {
                        String u = uriOf(l);
                        if (u != null && snapUris.contains(u)) drop.add(l);
                    }
                    if (!drop.isEmpty()) {
                        tset.removeAll(drop);
                        saveTrash(ctx);
                        Log2.i("恢复快照：同时把 " + drop.size() + " 个节点从回收站撤出");
                    }
                }
            } catch (Throwable ignored) {
            }
            // 让所有内存缓存失效
            goodUris = null;
            shownUris = null;
            blacklists.remove(snapNet);
            blacklists.remove(curNet);
            blacklistUriIndex.clear();
            importedCache = null;
            cached = null;
            totalByCc = null;
            Log2.i("已恢复到体检前的状态");
            return true;
        } catch (Throwable t) {
            Log2.w("恢复体检前状态失败：" + t);
            return false;
        }
    }

    public static synchronized void clearSnapshot(Context ctx) {
        try {
            ctx.getSharedPreferences("qv", Context.MODE_PRIVATE).edit()
                    .putBoolean("snap_valid", false).apply();
        } catch (Throwable ignored) {
        }
    }

    /** 把节点清单写成 txt，存到 Download/CommandVPN/，返回相对路径。 */
    /** 导出"纯节点链接"：每行一条，没有任何注释/前缀，可直接导入 v2rayNG 等客户端。 */
    public static String exportPlainLinksFile(Context ctx, java.util.List<String> uris) {
        try {
            if (android.os.Build.VERSION.SDK_INT < 29) return null;
            StringBuilder sb = new StringBuilder();
            for (String u : uris) {
                if (u == null || u.length() < 8) continue;
                sb.append(u).append('\n');
            }
            String name = "CommandVPN-links-"
                    + new java.text.SimpleDateFormat("yyyyMMdd-HHmm", java.util.Locale.US)
                    .format(new java.util.Date()) + ".txt";
            android.net.Uri col = android.provider.MediaStore.Downloads.EXTERNAL_CONTENT_URI;
            android.content.ContentValues v = new android.content.ContentValues();
            v.put(android.provider.MediaStore.MediaColumns.DISPLAY_NAME, name);
            v.put(android.provider.MediaStore.MediaColumns.MIME_TYPE, "text/plain");
            v.put(android.provider.MediaStore.MediaColumns.RELATIVE_PATH,
                    android.os.Environment.DIRECTORY_DOWNLOADS + "/命令方块节点资源");
            android.net.Uri uri = ctx.getContentResolver().insert(col, v);
            if (uri == null) return null;
            java.io.OutputStream os = ctx.getContentResolver().openOutputStream(uri);
            if (os == null) return null;
            os.write(sb.toString().getBytes("UTF-8"));
            os.close();
            Log2.i("纯节点链接已导出：Download/命令方块节点资源/" + name + "（" + uris.size() + " 条）");
            return "Download/命令方块节点资源/" + name;
        } catch (Throwable t) {
            Log2.w("导出纯节点链接失败：" + t);
            return null;
        }
    }

    public static String exportNodesFile(Context ctx, String content) {
        try {
            if (android.os.Build.VERSION.SDK_INT < 29) return null;
            String name = "CommandVPN-nodes-"
                    + new java.text.SimpleDateFormat("yyyyMMdd-HHmm", java.util.Locale.US)
                    .format(new java.util.Date()) + ".txt";
            android.net.Uri col = android.provider.MediaStore.Downloads.EXTERNAL_CONTENT_URI;
            android.content.ContentValues v = new android.content.ContentValues();
            v.put(android.provider.MediaStore.MediaColumns.DISPLAY_NAME, name);
            v.put(android.provider.MediaStore.MediaColumns.MIME_TYPE, "text/plain");
            // 导出文件单独放一个目录：清空日志不会把导出的节点一起删掉
            v.put(android.provider.MediaStore.MediaColumns.RELATIVE_PATH,
                    android.os.Environment.DIRECTORY_DOWNLOADS + "/命令方块节点资源");
            android.net.Uri uri = ctx.getContentResolver().insert(col, v);
            if (uri == null) return null;
            java.io.OutputStream os = ctx.getContentResolver().openOutputStream(uri);
            if (os == null) return null;
            os.write(content.getBytes("UTF-8"));
            os.close();
            Log2.i("节点已导出：Download/命令方块节点资源/" + name);
            return "Download/命令方块节点资源/" + name;
        } catch (Throwable t) {
            Log2.w("导出节点失败：" + t);
            return null;
        }
    }

    /* ---------------------- 下载优化模式 ---------------------- */

    /** 下载优化模式：更小的 MTU、拒绝 UDP，专门对付"大文件传到一半卡住"。 */
    public static boolean isDownloadBoost(Context ctx) {
        try {
            return ctx.getSharedPreferences("qv", Context.MODE_PRIVATE)
                    .getBoolean("dl_boost", false);
        } catch (Throwable t) {
            return false;
        }
    }

    public static void setDownloadBoost(Context ctx, boolean on) {
        try {
            ctx.getSharedPreferences("qv", Context.MODE_PRIVATE).edit()
                    .putBoolean("dl_boost", on).apply();
        } catch (Throwable ignored) {
        }
    }

    /* ---------------------------- 回收站 ---------------------------- */

    private static java.util.Set<String> trashSet;

    /** 回收站 uri 索引：parseAll 里每行都要判断一次，必须 O(1)。 */
    private static java.util.Set<String> trashUriSet;

    private static java.util.Set<String> trashUriIndex(Context ctx) {
        java.util.Set<String> idx = trashUriSet;
        if (idx != null) return idx;
        idx = new java.util.HashSet<String>();
        for (String l : trash(ctx)) idx.add(uriOf(l));
        trashUriSet = idx;
        return idx;
    }

    private static synchronized java.util.Set<String> trash(Context ctx) {
        if (trashSet != null) return trashSet;
        trashSet = new java.util.HashSet<String>();
        try {
            String raw = ctx.getSharedPreferences("qv", Context.MODE_PRIVATE).getString("trash", "");
            if (raw != null) {
                for (String line : raw.split("\n")) {
                    line = line.trim();
                    if (line.length() > 10) trashSet.add(line);
                }
            }
        } catch (Throwable ignored) {
        }
        return trashSet;
    }

    private static void saveTrash(Context ctx) {
        trashUriSet = null;
        try {
            java.util.Set<String> set = trash(ctx);
            StringBuilder sb = new StringBuilder(set.size() * 90);
            for (String u : set) sb.append(u).append('\n');
            ctx.getSharedPreferences("qv", Context.MODE_PRIVATE).edit()
                    .putString("trash", sb.toString()).apply();
            cached = null;
            totalByCc = null;
            parsedCache = null;
        } catch (Throwable ignored) {
        }
    }

    /* -------- 永久删除名单（清空回收站 / 永久删除时写入） -------- */

    private static java.util.Set<String> purgedSet;

    private static synchronized java.util.Set<String> purged(Context ctx) {
        if (purgedSet != null) return purgedSet;
        purgedSet = new java.util.HashSet<String>();
        try {
            String raw = ctx.getSharedPreferences("qv", Context.MODE_PRIVATE).getString("purged_uris", "");
            if (raw != null) {
                for (String line : raw.split("\n")) {
                    line = line.trim();
                    if (line.length() > 10) purgedSet.add(line);
                }
            }
        } catch (Throwable ignored) {
        }
        return purgedSet;
    }

    public static boolean isPurged(Context ctx, String uri) {
        try {
            return uri != null && purged(ctx).contains(uri);
        } catch (Throwable t) {
            return false;
        }
    }

    /** 永久删除：加入 purged 名单，并从各名单里清干净（不可恢复、不显示为"隐藏"）。 */
    public static synchronized void purge(Context ctx, String cc, String uri) {
        try {
            if (uri == null) return;
            if (purged(ctx).add(uri)) {
                StringBuilder sb = new StringBuilder();
                for (String u : purged(ctx)) sb.append(u).append('\n');
                ctx.getSharedPreferences("qv", Context.MODE_PRIVATE).edit()
                        .putString("purged_uris", capList(sb)).apply();
            }
            blacklistRemove(ctx, uri);
            removeShown(ctx, uri);
            try {
                java.util.Set<String> g = good(ctx);
                if (g.remove(uri)) {
                    StringBuilder sb2 = new StringBuilder();
                    for (String u : g) sb2.append(u).append('\n');
                    ctx.getSharedPreferences("qv", Context.MODE_PRIVATE).edit()
                            .putString("good_uris", sb2.toString()).apply();
                }
            } catch (Throwable ignored) {
            }
            cached = null;
            parsedCache = null;
            totalByCc = null;
        } catch (Throwable t) {
            Log2.w("永久删除失败：" + t);
        }
    }

    /** 撤销"永久删除"（比如用户又手动导入了同一个节点）。 */
    public static synchronized void unpurge(Context ctx, String uri) {
        try {
            if (uri != null && purged(ctx).remove(uri)) {
                StringBuilder sb = new StringBuilder();
                for (String u : purged(ctx)) sb.append(u).append('\n');
                ctx.getSharedPreferences("qv", Context.MODE_PRIVATE).edit()
                        .putString("purged_uris", capList(sb)).apply();
                cached = null;
                parsedCache = null;
            }
        } catch (Throwable ignored) {
        }
    }

    /** 删除全部已隐藏的节点（永久删除，进 purged 名单）。返回删除数量。 */
    public static synchronized int purgeAllHidden(Context ctx) {
        int n = 0;
        try {
            // 隐藏名单是按网络分开存的，这里要**跨所有网络**清掉
            android.content.SharedPreferences sp = ctx.getSharedPreferences("qv", Context.MODE_PRIVATE);
            java.util.Set<String> all = new java.util.HashSet<String>();
            for (String k : sp.getAll().keySet()) {
                if (!k.startsWith("blacklist_")) continue;
                Object v = sp.getAll().get(k);
                if (!(v instanceof String)) continue;
                for (String line : ((String) v).split("\n")) {
                    line = line.trim();
                    if (line.length() > 10) all.add(line);
                }
            }
            for (String line : all) {
                try {
                    purge(ctx, ccOf(line), uriOf(line));
                    n++;
                } catch (Throwable ignored) {
                }
            }
            // 把所有网络的隐藏名单一起清空
            android.content.SharedPreferences.Editor e = sp.edit();
            for (String k : sp.getAll().keySet()) {
                if (k.startsWith("blacklist_")) e.putString(k, "");
            }
            e.apply();
            blacklists.clear();
            blacklistUriIndex.clear();
            Log2.i("已永久删除全部隐藏节点：" + n + " 个");
        } catch (Throwable t) {
            Log2.w("删除隐藏节点失败：" + t);
        }
        return n;
    }

    /** 判断某个节点在界面上算不算"已隐藏"（与 allWithHidden 的口径一致）。 */
    public static boolean isHiddenNode(Context ctx, String uri) {
        try {
            return isBlacklisted(ctx, uri) || (!isGood(ctx, uri) && !isShown(ctx, uri));
        } catch (Throwable t) {
            return false;
        }
    }

    /** 界面口径下"已隐藏"的节点总数（内置 + 导入，跨网络）。 */
    public static synchronized int hiddenNodeCount(Context ctx) {
        int n = 0;
        try {
            java.util.Set<String> seen = new java.util.HashSet<String>();
            java.util.Set<String> goodSet = good(ctx);
            java.util.Set<String> shownSet = shown(ctx);
            // 隐藏 = 在黑名单里，或（不是实测可用且没手动显示）
            for (String l : blacklist(ctx)) {
                String u = uriOf(l);
                if (u != null && u.length() > 8 && !isTrashed(ctx, u) && !isPurged(ctx, u)) seen.add(u);
            }
            for (Node x : parseAll(ctx)) {
                if (!isTrashed(ctx, x.uri) && !isPurged(ctx, x.uri)
                        && !goodSet.contains(x.uri) && !shownSet.contains(x.uri)) seen.add(x.uri);
            }
            for (String raw : importedRaw(ctx)) {
                if (raw.length() > 8 && !isTrashed(ctx, raw) && !isPurged(ctx, raw)
                        && !goodSet.contains(raw) && !shownSet.contains(raw)) seen.add(raw);
            }
            n = seen.size();
        } catch (Throwable ignored) {
        }
        return n;
    }

    /** 导入的原始条数（含被隐藏/在回收站的），用于"清空导入"的确认提示。 */
    /**
     * "清空导入的节点"会删掉多少：已显示 + 已隐藏 + 回收站（含隐藏条目），
     * 也就是 导入原始清单里除"永久删除"之外的全部。
     */
    public static synchronized int clearableCount(Context ctx) {
        int n = 0;
        try {
            java.util.Set<String> seen = new java.util.HashSet<String>();
            for (String u : importedRaw(ctx)) {
                if (u == null || u.length() <= 8 || isPurged(ctx, u)) continue;
                seen.add(u);
                n++;
            }
            // 回收站里的条目不算在 imported 里，但"清空导入的节点"会一起清掉，
            // 所以数量必须算上，否则会出现"回收站 11000 个，这里只显示 9000 个"
            for (String line : trash(ctx)) {
                String u = uriOf(line);
                if (u == null || u.length() <= 8) continue;
                if (seen.add(u)) n++;
            }
        } catch (Throwable ignored) {
        }
        return n;
    }

    public static synchronized int importedRawCount(Context ctx) {
        return importedRaw(ctx).size();
    }

    /** 导入的原始链接（不过滤），用于统计"到底导入过什么"。 */
    private static java.util.List<String> importedRaw(Context ctx) {
        java.util.List<String> out = new java.util.ArrayList<String>();
        try {
            String raw = ctx.getSharedPreferences("qv", Context.MODE_PRIVATE).getString("imported", "");
            if (raw != null) {
                for (String line : raw.split("\n")) {
                    line = line.trim();
                    if (line.length() > 8 && line.contains("://")) out.add(line);
                }
            }
        } catch (Throwable ignored) {
        }
        return out;
    }

    /** 把全部"已隐藏"的节点移到回收站（可恢复）。返回数量。 */
    public static synchronized int trashAllHiddenNodes(Context ctx) {
        int n = 0;
        try {
            java.util.List<Node> all = new java.util.ArrayList<Node>();
            all.addAll(parseAll(ctx));
            all.addAll(imported(ctx));
            java.util.Set<String> set = trash(ctx);
            // 隐藏节点可能不在 imported()/parseAll() 的可见结果里，直接把黑名单条目也算上
            java.util.LinkedHashMap<String, String> targets = new java.util.LinkedHashMap<String, String>();
            for (Node x : all) {
                if (isHiddenNode(ctx, x.uri)) targets.put(x.uri, x.cc == null ? "ZZ" : x.cc);
            }
            for (String l : blacklist(ctx)) {
                String u = uriOf(l);
                if (u != null && u.length() > 8 && !targets.containsKey(u)) {
                    targets.put(u, ccOf(l));     // 补上"在黑名单里但列表看不到"的那些
                }
            }
            for (java.util.Map.Entry<String, String> e : targets.entrySet()) {
                try {
                    set.add(trashLine(e.getValue(), e.getKey(), isBlacklisted(ctx, e.getKey())));
                    n++;
                } catch (Throwable ignored) {
                }
            }
            if (n > 0) {
                saveTrash(ctx);
                blacklistClearAll(ctx);      // 落盘清空所有网络的隐藏名单
                cached = null;
                parsedCache = null;
                importedCache = null;
                totalByCc = null;
            }
            Log2.i("已把 " + n + " 个隐藏节点移入回收站");
        } catch (Throwable t) {
            Log2.w("移入回收站失败：" + t);
        }
        return n;
    }

    /** 永久删除全部"已隐藏"的节点（界面口径）。返回删除数量。 */
    public static synchronized int purgeAllHiddenNodes(Context ctx) {
        int n = 0;
        try {
            java.util.List<Node> all = new java.util.ArrayList<Node>();
            all.addAll(parseAll(ctx));
            all.addAll(imported(ctx));
            java.util.LinkedHashMap<String, String> targets = new java.util.LinkedHashMap<String, String>();
            for (Node x : all) {
                if (isHiddenNode(ctx, x.uri)) targets.put(x.uri, x.cc == null ? "ZZ" : x.cc);
            }
            for (String l : blacklist(ctx)) {
                String u = uriOf(l);
                if (u != null && u.length() > 8 && !targets.containsKey(u)) targets.put(u, ccOf(l));
            }
            if (targets.isEmpty()) return 0;
            // 一次性写 purged（不再逐条 O(n²)）
            java.util.Set<String> purgedNow = purged(ctx);
            purgedNow.addAll(targets.keySet());
            StringBuilder pb = new StringBuilder(purgedNow.size() * 90);
            for (String u : purgedNow) pb.append(u).append('\n');
            ctx.getSharedPreferences("qv", Context.MODE_PRIVATE).edit()
                    .putString("purged_uris", pb.toString()).apply();
            blacklistClearAll(ctx);
            java.util.List<String> uris = new java.util.ArrayList<String>(targets.keySet());
            java.util.Set<String> goodSet = good(ctx);
            if (goodSet.removeAll(targets.keySet())) {
                StringBuilder sb = new StringBuilder(goodSet.size() * 90);
                for (String u : goodSet) sb.append(u).append('\n');
                ctx.getSharedPreferences("qv", Context.MODE_PRIVATE).edit()
                        .putString("good_uris", capList(sb)).apply();
            }
            removeShownAll(ctx, uris);
            n = targets.size();
            invalidateAll(ctx);
            Log2.i("已永久删除全部隐藏节点：" + n + " 个");
        } catch (Throwable t) {
            Log2.w("删除隐藏节点失败：" + t);
        }
        return n;
    }

    /** 所有网络（wifi/cell/other）下隐藏名单的条目总数（兼容旧逻辑）。 */
    public static synchronized int blacklistAllCount(Context ctx) {
        int n = 0;
        try {
            android.content.SharedPreferences sp = ctx.getSharedPreferences("qv", Context.MODE_PRIVATE);
            java.util.Map<String, ?> all = sp.getAll();
            java.util.Set<String> seen = new java.util.HashSet<String>();
            for (String k : all.keySet()) {
                if (!k.startsWith("blacklist_")) continue;
                Object v = all.get(k);
                if (!(v instanceof String)) continue;
                for (String line : ((String) v).split("\n")) {
                    line = line.trim();
                    if (line.length() > 10) seen.add(uriOf(line));
                }
            }
            n = seen.size();
        } catch (Throwable ignored) {
        }
        return n;
    }

    public static int purgedCount(Context ctx) {
        try {
            return purged(ctx).size();
        } catch (Throwable t) {
            return 0;
        }
    }

    public static boolean isTrashed(Context ctx, String uri) {
        try {
            return uri != null && trashUriIndex(ctx).contains(uri);
        } catch (Throwable ignored) {
        }
        return false;
    }

    /** 回收站里"眼睛关闭时"应该看到的数量（只算删除时是已显示的）。 */
    public static synchronized int trashVisibleSize(Context ctx) {
        int n = 0;
        try {
            for (String l : trash(ctx)) if (!trashWasHidden(l)) n++;
        } catch (Throwable ignored) {
        }
        return n;
    }

    public static synchronized int trashSize(Context ctx) {
        return trash(ctx).size();
    }

    public static synchronized java.util.List<String> trashLines(Context ctx) {
        java.util.List<String> out = new java.util.ArrayList<String>(trash(ctx));
        java.util.Collections.sort(out, new java.util.Comparator<String>() {
            @Override
            public int compare(String a, String b) {
                return ccOf(a).compareTo(ccOf(b));
            }
        });
        return out;
    }

    public static synchronized void trashAdd(Context ctx, String cc, String uri) {
        try {
            java.util.Set<String> set = trash(ctx);
            boolean wasHidden = isBlacklisted(ctx, uri);
            removeTrashUri(set, uri);                 // 同一链接只留一条，避免数量翻倍
            set.add(trashLine(cc, uri, wasHidden));
            blacklistRemove(ctx, uri);
            saveTrash(ctx);
        } catch (Throwable t) {
            Log2.w("回收站写入失败：" + t);
        }
    }

    private static synchronized void trashAddLegacy(Context ctx, String cc, String uri) {
        try {
            if (uri == null || uri.length() < 10) return;
            trash(ctx).add(line(cc, uri));
            saveTrash(ctx);
            blacklistRemove(ctx, uri);          // 删了就不该再算"已隐藏"
        } catch (Throwable ignored) {
        }
    }

    public interface BulkProgress {
        void onProgress(int done, int total);
    }

    /**
     * 一次性把大批节点移进回收站：只在最后写一次盘、只失效一次缓存。
     * 分小块调用 trashAddAll 会反复失效缓存，界面反复重建列表 → 很容易 ANR。
     */
    public static synchronized int trashAddAllBulk(Context ctx, List<Node> nodes, BulkProgress cb) {
        int added = 0;
        try {
            if (nodes == null || nodes.isEmpty()) return 0;
            java.util.Set<String> set = trash(ctx);
            java.util.Set<String> uris = new java.util.HashSet<String>();
            int before = set.size();
            int i = 0;
            for (Node n : nodes) {
                i++;
                if (n == null || n.uri == null) continue;
                removeTrashUri(set, n.uri);
                // n.hidden 已包含"当前网络黑名单 + 未标记显示"两种情况；
                // 只看 isBlacklisted 会把"被隐藏但记录在其它网络下"的节点记成可见
                set.add(trashLine(n.cc, n.uri, n.hidden || isBlacklisted(ctx, n.uri)));
                uris.add(n.uri);
                if (cb != null && i % 1000 == 0) cb.onProgress(i, nodes.size());
            }
            added = Math.max(0, set.size() - before);
            saveTrash(ctx);
            blacklistRemoveManyUris(ctx, uris);
            cached = null;
            parsedCache = null;
            if (cb != null) cb.onProgress(nodes.size(), nodes.size());
            Log2.i("批量移入回收站：" + nodes.size() + " 个（新增 " + added + " 条）");
        } catch (Throwable t) {
            Log2.w("批量移入回收站失败：" + t);
        }
        return added;
    }

    /** 分块移入回收站：每块单独加锁，界面不会被一次锁住十几秒。 */
    public static synchronized int trashAddChunk(Context ctx, List<Node> nodes) {
        int added = 0;
        try {
            if (nodes == null || nodes.isEmpty()) return 0;
            java.util.Set<String> set = trash(ctx);
            for (Node n : nodes) {
                if (n == null || n.uri == null) continue;
                removeTrashUri(set, n.uri);
                set.add(trashLine(n.cc, n.uri, n.hidden || isBlacklisted(ctx, n.uri)));
                added++;
            }
        } catch (Throwable ignored) {
        }
        return added;
    }

    /** 分块把回收站条目移除（还原用）。 */
    public static synchronized int trashRestoreChunk(Context ctx, java.util.Collection<String> uris) {
        int n = 0;
        try {
            java.util.Set<String> set = trash(ctx);
            java.util.Set<String> target = new java.util.HashSet<String>(uris);
            java.util.List<String> drop = new java.util.ArrayList<String>();
            for (String l : set) if (target.contains(uriOf(l))) drop.add(l);
            for (String l : drop) {
                set.remove(l);
                n++;
            }
        } catch (Throwable ignored) {
        }
        return n;
    }

    /** 批量操作结束后统一落盘一次。 */
    public static synchronized void trashSaveNow(Context ctx) {
        try {
            saveTrash(ctx);
        } catch (Throwable ignored) {
        }
    }

    public static synchronized int trashAddAll(Context ctx, List<Node> nodes) {
        try {
            if (nodes == null || nodes.isEmpty()) return 0;
            java.util.Set<String> set = trash(ctx);
            int before = set.size();
            for (Node n : nodes) {
                if (n == null || n.uri == null) continue;
                removeTrashUri(set, n.uri);           // 同一链接只留一条
                set.add(trashLine(n.cc, n.uri, isBlacklisted(ctx, n.uri)));
            }
            int added = Math.max(0, set.size() - before);
            if (added > 0) {
                saveTrash(ctx);
                // 一次写盘把它们从隐藏名单里摘掉
                blacklistRemoveMany(ctx, nodes);
            }
            cached = null;
            parsedCache = null;
            return added;
        } catch (Throwable t) {
            return 0;
        }
    }

    /** 批量还原：一次扫描 + 一次写盘，避免"全部还原"变成 O(n²)。 */
    public static synchronized int trashRestoreMany(Context ctx, java.util.Collection<String> uris) {
        int n = 0;
        try {
            java.util.Set<String> set = trash(ctx);
            java.util.Set<String> target = new java.util.HashSet<String>(uris);
            java.util.List<String> drop = new java.util.ArrayList<String>();
            for (String l : set) {
                if (target.contains(uriOf(l))) drop.add(l);
            }
            if (!drop.isEmpty()) {
                java.util.List<String> wasHidden = new java.util.ArrayList<String>();
                java.util.List<String> wasVisible = new java.util.ArrayList<String>();
                for (String l : drop) {
                    String u = uriOf(l);
                    if (u == null || u.length() <= 8) continue;
                    if (trashWasHidden(l)) wasHidden.add(u); else wasVisible.add(u);
                }
                set.removeAll(drop);
                saveTrash(ctx);
                if (!wasVisible.isEmpty()) {
                    blacklistRemoveManyUris(ctx, wasVisible);   // 原本可见的：还原成可见
                    addShownBatch(ctx, wasVisible);
                }
                if (!wasHidden.isEmpty()) {
                    // 原本就是隐藏的：还原后仍然隐藏（不进"已显示"名单）
                    for (String u : wasHidden) {
                        try {
                            blacklistAdd(ctx, u);
                        } catch (Throwable ignored) {
                        }
                    }
                }
                n = drop.size();
            }
            cached = null;
            parsedCache = null;
            importedCache = null;
            totalByCc = null;
        } catch (Throwable t) {
            Log2.w("批量还原失败：" + t);
        }
        return n;
    }

    public static synchronized void trashRestore(Context ctx, String uri) {
        try {
            java.util.Set<String> set = trash(ctx);
            java.util.Iterator<String> it = set.iterator();
            boolean changed = false;
            boolean wasHidden = false;
            while (it.hasNext()) {
                String l = it.next();
                if (uriOf(l).equals(uri)) {
                    wasHidden = trashWasHidden(l);
                    it.remove();
                    changed = true;
                }
            }
            if (changed) {
                saveTrash(ctx);
                if (wasHidden) {
                    blacklistAdd(ctx, uri);         // 原本隐藏：还原后继续隐藏
                } else {
                    blacklistRemove(ctx, uri);      // 原本可见：还原后可见
                }
            }
        } catch (Throwable ignored) {
        }
    }

    public static synchronized void trashDeleteOne(Context ctx, String uri) {
        try {
            java.util.Set<String> set = trash(ctx);
            java.util.List<String> drop = new java.util.ArrayList<String>();
            String cc = null;
            for (String l : set) if (uriOf(l).equals(uri)) { drop.add(l); cc = ccOf(l); }
            set.removeAll(drop);
            if (!drop.isEmpty()) {
                try {
                    purge(ctx, cc, uri);   // 永久删除：进 purged 名单
                } catch (Throwable ignored) {
                }
                saveTrash(ctx);
            }
            cached = null;
            parsedCache = null;
        } catch (Throwable t) {
            Log2.w("回收站永久删除失败：" + t);
        }
    }

    private static synchronized void trashDeleteOneLegacy(Context ctx, String uri) {
        trashRestore(ctx, uri);
    }

    /** 清空回收站：永久删除（批量写盘，避免几千条时卡死/闪退）。 */
    public static synchronized void trashClear(Context ctx) {
        try {
            java.util.Set<String> set = trash(ctx);
            java.util.List<String> snapshot = new java.util.ArrayList<String>(set);
            if (snapshot.isEmpty()) {
                return;
            }
            // ① 一次性把 uri 全部加进 purged 名单
            java.util.Set<String> purgedNow = purged(ctx);
            java.util.Set<String> uris = new java.util.HashSet<String>();
            for (String l : snapshot) {
                String u = uriOf(l);
                if (u != null && u.length() > 10) {
                    purgedNow.add(u);
                    uris.add(u);
                }
            }
            StringBuilder pb = new StringBuilder(purgedNow.size() * 90);
            for (String u : purgedNow) pb.append(u).append('\n');
            android.content.SharedPreferences.Editor ed =
                    ctx.getSharedPreferences("qv", Context.MODE_PRIVATE).edit();
            ed.putString("purged_uris", pb.toString());

            // ② 从 实测可用 / 已显示 / 隐藏 三个名单里一次性剔除
            try {
                java.util.Set<String> g = good(ctx);
                boolean gChanged = g.removeAll(uris);
                if (gChanged) {
                    StringBuilder sb = new StringBuilder(g.size() * 90);
                    for (String u : g) sb.append(u).append('\n');
                    ed.putString("good_uris", capList(sb));
                }
            } catch (Throwable ignored) {
            }
            try {
                java.util.Set<String> sh = shown(ctx);
                boolean shChanged = sh.removeAll(uris);
                if (shChanged) {
                    StringBuilder sb = new StringBuilder(sh.size() * 90);
                    for (String u : sh) sb.append(u).append('\n');
                    ed.putString("shown_uris", sb.toString());
                }
            } catch (Throwable ignored) {
            }
            try {
                String key = netKey(ctx);
                java.util.Set<String> bl = blacklist(ctx, key);
                java.util.Iterator<String> it = bl.iterator();
                boolean blChanged = false;
                while (it.hasNext()) {
                    if (uris.contains(uriOf(it.next()))) { it.remove(); blChanged = true; }
                }
                if (blChanged) {
                    StringBuilder sb = new StringBuilder(bl.size() * 90);
                    for (String u : bl) sb.append(u).append('\n');
                    ed.putString("blacklist_" + key, sb.toString());
                }
            } catch (Throwable ignored) {
            }
            ed.apply();

            // ③ 清空回收站
            set.clear();
            saveTrash(ctx);
            blacklistUriIndex.clear();
            cached = null;
            parsedCache = null;
            totalByCc = null;
            Log2.i("回收站已清空（永久删除 " + snapshot.size() + " 个）");
        } catch (Throwable t) {
            Log2.w("清空回收站失败：" + t);
        }
    }

    /* ------------------------- 置顶（收藏） ------------------------- */

    private static final String DEFAULT_PINS = "HK,SG,US";
    /** 老版本的默认置顶（含台湾），升级时自动替换掉。 */
    private static final String OLD_DEFAULT_PINS = "HK,TW,SG,US";

    /** 用户置顶的国家列表（有序）。 */
    public static java.util.List<String> pinnedList(Context ctx) {
        java.util.List<String> out = new java.util.ArrayList<String>();
        try {
            String raw = ctx.getSharedPreferences("qv", Context.MODE_PRIVATE)
                    .getString("pins", DEFAULT_PINS);
            if (raw == null) raw = DEFAULT_PINS;
            if (OLD_DEFAULT_PINS.equals(raw.trim())) {
                // 用户没动过置顶设置 → 去掉台湾，其它保持
                raw = DEFAULT_PINS;
                ctx.getSharedPreferences("qv", Context.MODE_PRIVATE).edit().putString("pins", raw).apply();
            }
            for (String p : raw.split(",")) {
                p = p.trim().toUpperCase(java.util.Locale.ROOT);
                if (p.length() == 2 && !out.contains(p)) out.add(p);
            }
        } catch (Throwable ignored) {
        }
        return out;
    }

    public static int pinRank(Context ctx, String cc) {
        if (cc == null) return -1;
        return pinnedList(ctx).indexOf(cc.toUpperCase(java.util.Locale.ROOT));
    }

    public static boolean isPinned(Context ctx, String cc) {
        return pinRank(ctx, cc) >= 0;
    }

    public static boolean togglePin(Context ctx, String cc) {
        if (cc == null || cc.length() != 2) return false;
        String c = cc.toUpperCase(java.util.Locale.ROOT);
        java.util.List<String> pins = pinnedList(ctx);
        boolean added;
        if (pins.contains(c)) {
            pins.remove(c);
            added = false;
        } else {
            pins.add(c);
            added = true;
        }
        StringBuilder sb = new StringBuilder();
        for (String p : pins) {
            if (sb.length() > 0) sb.append(',');
            sb.append(p);
        }
        ctx.getSharedPreferences("qv", Context.MODE_PRIVATE).edit().putString("pins", sb.toString()).apply();
        return added;
    }

    /* ---------------- 体检后隐藏不可用节点 ---------------- */

    /** netKey → 隐藏节点的纯 uri 集合（O(1) 查询，避免每次遍历几千条）。 */
    private static final java.util.Map<String, java.util.Set<String>> blacklistUriIndex =
            new java.util.HashMap<String, java.util.Set<String>>();

    private static void invalidateBlacklistIndex(Context ctx) {
        try {
            blacklistUriIndex.remove(netKey(ctx));
            importedCache = null;   // imported() 缓存里烘焙过黑名单状态，必须一起失效
        } catch (Throwable ignored) {
        }
    }

    private static synchronized java.util.Set<String> blacklistUriSet(Context ctx) {
        String key = netKey(ctx);
        java.util.Set<String> idx = blacklistUriIndex.get(key);
        if (idx != null) return idx;
        idx = new java.util.HashSet<String>();
        for (String l : blacklist(ctx)) idx.add(uriOf(l));
        blacklistUriIndex.put(key, idx);
        return idx;
    }

    private static final java.util.Map<String, java.util.Set<String>> blacklists =
            new java.util.HashMap<String, java.util.Set<String>>();

    /** 当前网络类型：wifi / cell / eth / other —— 隐藏名单按网络分别记。 */
    private static String netKeyCache;
    private static long netKeyAt;

    /** 供网络切换时主动失效。 */
    public static void invalidateNetKey() {
        netKeyCache = null;
    }

    public static String netKey(Context ctx) {
        long now = System.currentTimeMillis();
        if (netKeyCache != null && now - netKeyAt < 3000L) return netKeyCache;
        String result = "other";
        try {
            android.net.ConnectivityManager cm = (android.net.ConnectivityManager)
                    ctx.getSystemService(Context.CONNECTIVITY_SERVICE);
            android.net.Network n = cm.getActiveNetwork();
            android.net.NetworkCapabilities c = cm.getNetworkCapabilities(n);
            if (c != null) {
                if (c.hasTransport(android.net.NetworkCapabilities.TRANSPORT_WIFI)) result = "wifi";
                else if (c.hasTransport(android.net.NetworkCapabilities.TRANSPORT_CELLULAR)) result = "cell";
                else if (c.hasTransport(android.net.NetworkCapabilities.TRANSPORT_ETHERNET)) result = "eth";
            }
        } catch (Throwable ignored) {
        }
        netKeyCache = result;
        netKeyAt = now;
        return result;
    }

    public static String netLabel(Context ctx) {
        String k = netKey(ctx);
        if ("wifi".equals(k)) return "Wi-Fi";
        if ("cell".equals(k)) return "移动数据";
        if ("eth".equals(k)) return "有线";
        return "其它网络";
    }

    private static synchronized java.util.Set<String> blacklist(Context ctx, String key) {
        java.util.Set<String> cachedSet = blacklists.get(key);
        if (cachedSet != null) return cachedSet;
        java.util.Set<String> set = new java.util.HashSet<String>();
        try {
            String raw = ctx.getSharedPreferences("qv", Context.MODE_PRIVATE)
                    .getString("blacklist_" + key, "");
            if (raw != null) {
                for (String line : raw.split("\n")) {
                    line = line.trim();
                    if (line.length() > 10) set.add(line);
                }
            }
        } catch (Throwable ignored) {
        }
        blacklists.put(key, set);
        return set;
    }

    private static synchronized java.util.Set<String> blacklist(Context ctx) {
        String key = netKey(ctx);
        java.util.Set<String> cachedSet = blacklists.get(key);
        if (cachedSet != null) return cachedSet;
        java.util.Set<String> set = new java.util.HashSet<String>();
        blacklists.put(key, set);
        try {
            String raw = ctx.getSharedPreferences("qv", Context.MODE_PRIVATE).getString("blacklist_" + key, "");
            if (raw != null) {
                for (String line : raw.split("\n")) {
                    line = line.trim();
                    if (line.length() > 10) set.add(line);
                }
            }
        } catch (Throwable ignored) {
        }
        return set;
    }

    /** 存进黑名单的一行：cc \t uri */
    private static String line(String cc, String uri) {
        String c = (cc == null || cc.length() == 0) ? "??" : cc.toUpperCase(java.util.Locale.ROOT);
        return c + "\t" + uri;
    }

    /** 回收站专用：多带一个"删除时是否已隐藏"的标记（1=隐藏）。 */
    private static String trashLine(String cc, String uri, boolean wasHidden) {
        return line(cc, uri) + "\t" + (wasHidden ? "1" : "0");
    }

    private static void removeTrashUri(java.util.Set<String> set, String uri) {
        if (uri == null || set == null || set.isEmpty()) return;
        java.util.Iterator<String> it = set.iterator();
        while (it.hasNext()) {
            String l = it.next();
            if (uri.equals(uriOf(l))) it.remove();
        }
    }

    /** 一次性清理：老版本可能给同一个链接存了"显示/隐藏"两条回收站记录，按 uri 合并。 */
    public static synchronized void dedupeTrash(Context ctx) {
        try {
            android.content.SharedPreferences sp = ctx.getSharedPreferences("qv", Context.MODE_PRIVATE);
            if (sp.getBoolean("trash_dedupe_v1", false)) return;
            java.util.Set<String> set = trash(ctx);
            java.util.LinkedHashMap<String, String> byUri = new java.util.LinkedHashMap<String, String>();
            for (String l : set) {
                byUri.put(uriOf(l), l);   // 同一 uri 保留最后一条
            }
            int removed = set.size() - byUri.size();
            set.clear();
            set.addAll(byUri.values());
            saveTrash(ctx);
            sp.edit().putBoolean("trash_dedupe_v1", true).apply();
            if (removed > 0) Log2.i("回收站去重：合并了 " + removed + " 条重复记录");
        } catch (Throwable t) {
            Log2.w("回收站去重失败：" + t);
        }
    }

    /** 回收站条目在删除时是不是隐藏状态（老数据没有标记，按"已显示"算）。 */
    public static boolean trashWasHidden(String line) {
        int first = line.indexOf('\t');
        if (first < 0) return false;
        int second = line.indexOf('\t', first + 1);
        if (second < 0) return false;
        return "1".equals(line.substring(second + 1).trim());
    }

    /** 从黑名单行里取出 uri。 */
    public static String uriOf(String line) {
        int tab = line.indexOf('\t');
        if (tab < 0) return line;
        int tab2 = line.indexOf('\t', tab + 1);
        return tab2 < 0 ? line.substring(tab + 1) : line.substring(tab + 1, tab2);
    }

    /** 从黑名单行里取出国家码。 */
    public static String ccOfSafe(String line) {
        return ccOf(line);
    }

    public static String ccOf(String line) {
        int tab = line.indexOf('\t');
        return tab < 0 ? "??" : line.substring(0, tab);
    }

    public static boolean isBlacklisted(Context ctx, String uri) {
        try {
            return uri != null && blacklistUriSet(ctx).contains(uri);
        } catch (Throwable t) {
            return false;
        }
    }

    public static synchronized int blacklistSize(Context ctx) {
        return blacklist(ctx).size();
    }

    /** 把单个节点加进隐藏名单。 */
    public static synchronized boolean blacklistAdd(Context ctx, String uri) {
        return blacklistAdd(ctx, null, uri);
    }

    public static synchronized boolean blacklistAdd(Context ctx, String cc, String uri) {
        try {
            if (uri == null || uri.length() < 10) return false;
            String key = netKey(ctx);
            java.util.Set<String> bl = blacklist(ctx, key);
            if (!bl.add(line(cc, uri))) return false;
            StringBuilder sb = new StringBuilder(bl.size() * 90);
            for (String u : bl) sb.append(u).append('\n');
            ctx.getSharedPreferences("qv", Context.MODE_PRIVATE).edit()
                    .putString("blacklist_" + key, sb.toString()).apply();
            cached = null;
            invalidateBlacklistIndex(ctx);
            return true;
        } catch (Throwable t) {
            return false;
        }
    }

    /** 把一批节点加进隐藏名单（体检判定不可用的）。 */
    public static synchronized int blacklistAddAll(Context ctx, List<Node> nodes) {
        try {
            String key = netKey(ctx);
            java.util.Set<String> bl = blacklist(ctx, key);
            int before = bl.size();
            for (Node n : nodes) {
                if (n != null && n.uri != null) bl.add(line(n.cc, n.uri));
            }
            StringBuilder sb = new StringBuilder(bl.size() * 90);
            for (String u : bl) sb.append(u).append('\n');
            ctx.getSharedPreferences("qv", Context.MODE_PRIVATE).edit()
                    .putString("blacklist_" + key, sb.toString()).apply();
            cached = null;
            invalidateBlacklistIndex(ctx);
            return bl.size() - before;
        } catch (Throwable t) {
            return 0;
        }
    }

    public static synchronized void blacklistClear(Context ctx) {
        try {
            blacklist(ctx).clear();
            ctx.getSharedPreferences("qv", Context.MODE_PRIVATE).edit()
                    .remove("blacklist_" + netKey(ctx)).apply();
            cached = null;
            invalidateBlacklistIndex(ctx);
        } catch (Throwable ignored) {
        }
    }

    /**
     * 把体检报告写进手机的 Download 目录（通过 MediaStore，不需要存储权限）。
     * 这样用户能直接把文件发出去，或者让工具脚本读到。
     */
    /** 用指定文件名导出报告（异步调用时先算好文件名）。 */
    public static String exportReportNamed(Context ctx, String name, String text) {
        if (text == null) return null;
        try {
            if (android.os.Build.VERSION.SDK_INT >= 29) {
                android.content.ContentValues v = new android.content.ContentValues();
                v.put(android.provider.MediaStore.MediaColumns.DISPLAY_NAME, name);
                v.put(android.provider.MediaStore.MediaColumns.MIME_TYPE, "text/plain");
                v.put(android.provider.MediaStore.MediaColumns.RELATIVE_PATH,
                        android.os.Environment.DIRECTORY_DOWNLOADS + "/CommandVPN");
                android.net.Uri uri = ctx.getContentResolver()
                        .insert(android.provider.MediaStore.Downloads.EXTERNAL_CONTENT_URI, v);
                if (uri != null) {
                    java.io.OutputStream os = ctx.getContentResolver().openOutputStream(uri);
                    if (os != null) {
                        os.write(text.getBytes("UTF-8"));
                        os.close();
                        Log2.i("体检报告已写入：" + name);
                        return "Download/CommandVPN/" + name;
                    }
                }
            }
        } catch (Throwable t) {
            Log2.w("导出报告失败：" + t);
        }
        return null;
    }

    public static String exportReport(Context ctx, String text) {
        if (text == null) return null;
        String name = "CommandVPN-scan-" + new java.text.SimpleDateFormat("yyyyMMdd-HHmm", java.util.Locale.US)
                .format(new java.util.Date()) + ".txt";
        try {
            if (android.os.Build.VERSION.SDK_INT >= 29) {
                android.content.ContentValues v = new android.content.ContentValues();
                v.put(android.provider.MediaStore.MediaColumns.DISPLAY_NAME, name);
                v.put(android.provider.MediaStore.MediaColumns.MIME_TYPE, "text/plain");
                v.put(android.provider.MediaStore.MediaColumns.RELATIVE_PATH,
                        android.os.Environment.DIRECTORY_DOWNLOADS + "/CommandVPN");
                android.net.Uri uri = ctx.getContentResolver()
                        .insert(android.provider.MediaStore.Downloads.EXTERNAL_CONTENT_URI, v);
                if (uri != null) {
                    java.io.OutputStream os = ctx.getContentResolver().openOutputStream(uri);
                    if (os != null) {
                        os.write(text.getBytes("UTF-8"));
                        os.close();
                        return "Download/CommandVPN/" + name;
                    }
                }
            }
            java.io.File dir = ctx.getExternalFilesDir(null);
            if (dir != null) {
                dir.mkdirs();
                java.io.File f = new java.io.File(dir, name);
                java.io.FileOutputStream out = new java.io.FileOutputStream(f);
                out.write(text.getBytes("UTF-8"));
                out.close();
                return f.getAbsolutePath();
            }
        } catch (Throwable t) {
            return null;
        }
        return null;
    }

    /* -------- 疑似不通（失败一次）名单：失败两次才真正隐藏 -------- */

    private static final java.util.Map<String, java.util.Set<String>> pendings =
            new java.util.HashMap<String, java.util.Set<String>>();

    private static synchronized java.util.Set<String> pending(Context ctx) {
        String key = netKey(ctx);
        java.util.Set<String> set = pendings.get(key);
        if (set != null) return set;
        set = new java.util.HashSet<String>();
        pendings.put(key, set);
        try {
            String raw = ctx.getSharedPreferences("qv", Context.MODE_PRIVATE).getString("pending_" + key, "");
            if (raw != null) {
                for (String line : raw.split("\n")) {
                    line = line.trim();
                    if (line.length() > 10) set.add(line);
                }
            }
        } catch (Throwable ignored) {
        }
        return set;
    }

    private static void savePending(Context ctx) {
        try {
            java.util.Set<String> set = pending(ctx);
            StringBuilder sb = new StringBuilder(set.size() * 90);
            for (String u : set) sb.append(u).append('\n');
            ctx.getSharedPreferences("qv", Context.MODE_PRIVATE).edit()
                    .putString("pending_" + netKey(ctx), sb.toString()).apply();
        } catch (Throwable ignored) {
        }
    }

    public static synchronized boolean pendingContains(Context ctx, String uri) {
        for (String l : pending(ctx)) if (uriOf(l).equals(uri)) return true;
        return false;
    }

    public static synchronized void pendingAdd(Context ctx, String cc, String uri) {
        try {
            pending(ctx).add(line(cc, uri));
            savePending(ctx);
        } catch (Throwable ignored) {
        }
    }

    public static synchronized void pendingRemove(Context ctx, String uri) {
        try {
            java.util.Set<String> set = pending(ctx);
            java.util.Iterator<String> it = set.iterator();
            boolean changed = false;
            while (it.hasNext()) {
                if (uriOf(it.next()).equals(uri)) {
                    it.remove();
                    changed = true;
                }
            }
            if (changed) savePending(ctx);
        } catch (Throwable ignored) {
        }
    }

    /** 从隐藏名单里恢复单个节点。 */
    public static synchronized void blacklistRemove(Context ctx, String uri) {
        try {
            String key = netKey(ctx);
            java.util.Set<String> bl = blacklist(ctx, key);
            java.util.Iterator<String> it = bl.iterator();
            boolean changed = false;
            while (it.hasNext()) {
                if (uriOf(it.next()).equals(uri)) {
                    it.remove();
                    changed = true;
                }
            }
            if (changed) {
                StringBuilder sb = new StringBuilder(bl.size() * 90);
                for (String u : bl) sb.append(u).append('\n');
                ctx.getSharedPreferences("qv", Context.MODE_PRIVATE).edit()
                        .putString("blacklist_" + key, sb.toString()).apply();
                cached = null;
                invalidateBlacklistIndex(ctx);
            }
        } catch (Throwable ignored) {
        }
    }

    public static synchronized void pendingAddAll(Context ctx, List<Node> nodes) {
        try {
            java.util.Set<String> set = pending(ctx);
            for (Node n : nodes) if (n != null && n.uri != null) set.add(line(n.cc, n.uri));
            savePending(ctx);
        } catch (Throwable ignored) {
        }
    }

    public static synchronized void pendingRemoveAll(Context ctx, List<Node> nodes) {
        try {
            java.util.Set<String> set = pending(ctx);
            java.util.Set<String> uris = new java.util.HashSet<String>();
            for (Node n : nodes) if (n != null && n.uri != null) uris.add(n.uri);
            if (uris.isEmpty()) return;
            boolean changed = false;
            java.util.Iterator<String> it = set.iterator();
            while (it.hasNext()) {
                if (uris.contains(uriOf(it.next()))) {
                    it.remove();
                    changed = true;
                }
            }
            if (changed) savePending(ctx);
        } catch (Throwable ignored) {
        }
    }

    /** 批量从隐藏名单恢复（复检发现能用时调用）。 */
    /** 按 uri 批量移出隐藏名单（一次写盘）。 */
    public static synchronized int blacklistRemoveManyUris(Context ctx, java.util.Collection<String> uris) {
        int removed = 0;
        try {
            if (uris == null || uris.isEmpty()) return 0;
            java.util.Set<String> target = new java.util.HashSet<String>(uris);
            String key = netKey(ctx);
            java.util.Set<String> bl = blacklist(ctx, key);
            java.util.Iterator<String> it = bl.iterator();
            while (it.hasNext()) {
                if (target.contains(uriOf(it.next()))) { it.remove(); removed++; }
            }
            if (removed > 0) {
                StringBuilder sb = new StringBuilder(bl.size() * 90);
                for (String u : bl) sb.append(u).append('\n');
                ctx.getSharedPreferences("qv", Context.MODE_PRIVATE).edit()
                        .putString("blacklist_" + key, sb.toString()).apply();
                cached = null;
                invalidateBlacklistIndex(ctx);
            }
        } catch (Throwable t) {
            Log2.w("批量移出隐藏失败：" + t);
        }
        return removed;
    }

    /** 从所有网络的隐藏名单里移除这些链接（"显示全部"用：不区分当前是 Wi-Fi 还是移动数据）。 */
    public static synchronized int blacklistRemoveUrisAllNets(Context ctx, java.util.Collection<String> uris) {
        int removed = 0;
        try {
            if (uris == null || uris.isEmpty()) return 0;
            java.util.Set<String> target = new java.util.HashSet<String>(uris);
            android.content.SharedPreferences sp = ctx.getSharedPreferences("qv", Context.MODE_PRIVATE);
            android.content.SharedPreferences.Editor ed = sp.edit();
            for (String k : new java.util.ArrayList<String>(sp.getAll().keySet())) {
                if (!k.startsWith("blacklist_")) continue;
                Object v = sp.getAll().get(k);
                if (!(v instanceof String)) continue;
                java.util.List<String> keep = new java.util.ArrayList<String>();
                boolean changed = false;
                for (String line : ((String) v).split("\n")) {
                    line = line.trim();
                    if (line.length() == 0) continue;
                    if (target.contains(uriOf(line))) {
                        removed++;
                        changed = true;
                    } else {
                        keep.add(line);
                    }
                }
                if (changed) {
                    StringBuilder sb = new StringBuilder();
                    for (String line : keep) sb.append(line).append('\n');
                    ed.putString(k, sb.toString());
                }
            }
            ed.apply();
            if (removed > 0) {
                cached = null;
                blacklists.clear();
                blacklistUriIndex.clear();
            }
        } catch (Throwable t) {
            Log2.w("跨网络取消隐藏失败：" + t);
        }
        return removed;
    }

    public static synchronized int blacklistRemoveMany(Context ctx, List<Node> nodes) {
        try {
            if (nodes == null || nodes.isEmpty()) return 0;
            java.util.Set<String> uris = new java.util.HashSet<String>();
            for (Node n : nodes) if (n != null && n.uri != null) uris.add(n.uri);
            String key = netKey(ctx);
            java.util.Set<String> bl = blacklist(ctx, key);
            int removed = 0;
            java.util.Iterator<String> it = bl.iterator();
            while (it.hasNext()) {
                if (uris.contains(uriOf(it.next()))) {
                    it.remove();
                    removed++;
                }
            }
            if (removed > 0) {
                StringBuilder sb = new StringBuilder(bl.size() * 90);
                for (String u : bl) sb.append(u).append('\n');
                ctx.getSharedPreferences("qv", Context.MODE_PRIVATE).edit()
                        .putString("blacklist_" + key, sb.toString()).apply();
                cached = null;
                invalidateBlacklistIndex(ctx);
            }
            return removed;
        } catch (Throwable t) {
            return 0;
        }
    }

    /** 取一批被隐藏的节点（用来复检，命中了就恢复）。 */
    public static synchronized List<Node> hiddenSample(Context ctx, int limit) {
        List<Node> out = new ArrayList<Node>();
        try {
            List<String> all = new ArrayList<String>(blacklist(ctx));
            java.util.Collections.shuffle(all, new java.util.Random(System.currentTimeMillis()));
            for (String l : all) {
                if (out.size() >= limit) break;
                String uri = uriOf(l);
                String cc = ccOf(l);
                try {
                    Node n = new Node(uri, cc, "");
                    if (n.supported && ConfigBuilder.canBuild(n)) out.add(n);
                } catch (Throwable ignored) {
                }
            }
        } catch (Throwable ignored) {
        }
        return out;
    }

    /** 当前网络隐藏的节点，按国家分组。 */
    public static synchronized java.util.Map<String, java.util.List<String>> blacklistByCountry(Context ctx) {
        java.util.Map<String, java.util.List<String>> out =
                new java.util.LinkedHashMap<String, java.util.List<String>>();
        for (String l : blacklist(ctx)) {
            String cc = ccOf(l);
            java.util.List<String> list = out.get(cc);
            if (list == null) {
                list = new java.util.ArrayList<String>();
                out.put(cc, list);
            }
            list.add(uriOf(l));
        }
        return out;
    }

    /** 只恢复某个国家被隐藏的节点。 */
    public static synchronized int blacklistRemoveCountry(Context ctx, String cc) {
        try {
            String key = netKey(ctx);
            java.util.Set<String> bl = blacklist(ctx, key);
            int removed = 0;
            java.util.List<String> oldLines = new java.util.ArrayList<String>();
            java.util.Iterator<String> it = bl.iterator();
            while (it.hasNext()) {
                String line = it.next();
                if (ccOf(line).equalsIgnoreCase(cc)) {
                    oldLines.add(line);
                    it.remove();
                    removed++;
                }
            }
            StringBuilder sb = new StringBuilder(bl.size() * 90);
            for (String u : bl) sb.append(u).append('\n');
            ctx.getSharedPreferences("qv", Context.MODE_PRIVATE).edit()
                    .putString("blacklist_" + key, sb.toString()).apply();
            if (removed > 0) {
                // 恢复出来的节点要能被看见：加入"已显示"
                java.util.List<String> back = new java.util.ArrayList<String>();
                for (String l : oldLines) {
                    String u = uriOf(l);
                    if (u != null && u.length() > 8) back.add(u);
                }
                addShownBatch(ctx, back);
            }
            cached = null;
            invalidateBlacklistIndex(ctx);
            return removed;
        } catch (Throwable t) {
            return 0;
        }
    }

    /** 清掉所有网络类型下的隐藏名单。 */
    public static synchronized void blacklistClearAll(Context ctx) {
        try {
            for (String k : new String[]{"wifi", "cell", "eth", "other"}) {
                java.util.Set<String> set = blacklists.get(k);
                if (set != null) set.clear();
                ctx.getSharedPreferences("qv", Context.MODE_PRIVATE).edit().remove("blacklist_" + k).apply();
            }
            blacklists.clear();
            blacklistUriIndex.clear();
            cached = null;
        } catch (Throwable ignored) {
        }
    }

    /** 上次真正连通的节点（用于"秒连"）。 */
    public static String lastGoodUri(Context ctx) {
        return ctx.getSharedPreferences("qv", Context.MODE_PRIVATE).getString("last_good", "");
    }

    public static int lastGoodDelay(Context ctx) {
        return ctx.getSharedPreferences("qv", Context.MODE_PRIVATE).getInt("last_good_delay", 0);
    }

    public static void setLastGood(Context ctx, String uri, int delay) {
        ctx.getSharedPreferences("qv", Context.MODE_PRIVATE).edit()
                .putString("last_good", uri == null ? "" : uri)
                .putInt("last_good_delay", delay)
                .apply();
    }

    /** 某个国家/地区上次连通的节点。 */
    public static String countryGoodUri(Context ctx, String cc) {
        if (cc == null || cc.length() == 0) return "";
        return ctx.getSharedPreferences("qv", Context.MODE_PRIVATE).getString("good_" + cc.toUpperCase(Locale.ROOT), "");
    }

    public static void setCountryGoodUri(Context ctx, String cc, String uri) {
        if (cc == null || cc.length() == 0 || uri == null) return;
        ctx.getSharedPreferences("qv", Context.MODE_PRIVATE).edit()
                .putString("good_" + cc.toUpperCase(Locale.ROOT), uri).apply();
    }

    public static String selectedUri(Context ctx) {
        return ctx.getSharedPreferences("qv", Context.MODE_PRIVATE).getString("node_uri", "");
    }

    public static void setSelectedUri(Context ctx, String uri) {
        ctx.getSharedPreferences("qv", Context.MODE_PRIVATE).edit().putString("node_uri", uri).apply();
    }

    public static void setSelected(Context ctx, int idx) {
        ctx.getSharedPreferences("qv", Context.MODE_PRIVATE).edit().putInt("node", idx).apply();
    }
}
