package com.dsh.quickvpn;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.ConnectivityManager;
import android.net.LinkProperties;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.net.NetworkRequest;
import android.net.VpnService;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.os.ParcelFileDescriptor;
import android.system.OsConstants;

import java.net.Inet4Address;
import java.net.Inet6Address;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.InterfaceAddress;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import io.nekohasekai.libbox.BridgeOptions;
import io.nekohasekai.libbox.BridgeSession;
import io.nekohasekai.libbox.CommandServer;
import io.nekohasekai.libbox.CommandServerHandler;
import io.nekohasekai.libbox.ConnectionOwner;
import io.nekohasekai.libbox.InterfaceUpdateListener;
import io.nekohasekai.libbox.Libbox;
import io.nekohasekai.libbox.LocalDNSTransport;
import io.nekohasekai.libbox.NeighborUpdateListener;
import io.nekohasekai.libbox.NetworkInterface;
import io.nekohasekai.libbox.NetworkInterfaceIterator;
import io.nekohasekai.libbox.OverrideOptions;
import io.nekohasekai.libbox.PlatformInterface;
import io.nekohasekai.libbox.PlatformUser;
import io.nekohasekai.libbox.RoutePrefix;
import io.nekohasekai.libbox.RoutePrefixIterator;
import io.nekohasekai.libbox.SetupOptions;
import io.nekohasekai.libbox.ShellSession;
import io.nekohasekai.libbox.StringIterator;
import io.nekohasekai.libbox.SystemProxyStatus;
import io.nekohasekai.libbox.TunOptions;
import io.nekohasekai.libbox.WIFIState;

/**
 * 真正的 VPN 服务：把自己建立的 tun 交给 sing-box 内核，由内核做分流与加密。
 *
 * 注意：这里是 Go 内核（libbox.so）回调进来的地方。任何在这里抛出的 Java 异常，
 * 在 gobind 里都可能变成 Go 端的 panic 直接把进程干掉（闪退），
 * 所以每个回调都必须自己兜住异常、返回安全默认值。
 */
public class TunnelService extends VpnService implements PlatformInterface, CommandServerHandler {

    private static final int NOTIF_ID = 0x51;
    // 用新渠道 id：老渠道如果是"低重要性"被系统折叠，改 id 才能让老用户也看到
    private static final String CHANNEL = "vpn_progress";

    public static final String ACTION_STATE = "com.dsh.quickvpn.STATE";
    public static final String ACTION_CONNECT = "com.dsh.quickvpn.CONNECT";
    public static final String ACTION_DISCONNECT = "com.dsh.quickvpn.DISCONNECT";
    public static final String EXTRA_ERROR = "error";
    public static final String EXTRA_SCAN_DONE = "scan_done";
    public static final String EXTRA_SCAN_ALIVE = "scan_alive";
    public static final String EXTRA_SCAN_DEAD = "scan_dead";
    public static final String EXTRA_SCAN_SUMMARY = "scan_summary";
    public static final String ACTION_SCAN = "com.dsh.quickvpn.SCAN";
    public static final String ACTION_SCAN_STOP = "com.dsh.quickvpn.SCAN_STOP";
    public static final String ACTION_KEEPALIVE = "com.dsh.quickvpn.KEEPALIVE";
    public static final String ACTION_REFRESH = "com.dsh.quickvpn.REFRESH";

    private static volatile boolean sScanning = false;
    /** 已连接时每秒刷新通知（保证通知里的节点就是实际节点）。 */
    private static volatile boolean notifHeartbeatOn = false;

    private void startConnectedHeartbeat() {
        synchronized (TunnelService.class) {
            if (notifHeartbeatOn) return;      // 已经有一个在跑，别重复起
            notifHeartbeatOn = true;
        }
        new Thread(new Runnable() {
            @Override
            public void run() {
                int ticks = 0;
                int bad = 0;
                while (notifHeartbeatOn) {
                    try {
                        Thread.sleep(1000);
                    } catch (InterruptedException ignored) {
                    }
                    if (!notifHeartbeatOn) break;
                    if (!sRunning) break;
                    updateConnectedNotification();
                    // 每 45 秒验一次外网：连上之后节点挂掉时能自己发现并断开，
                    // 而不是等用户打开网页才发现、切回 App 才弹错
                    if (++ticks % 45 == 0) {
                        int d = proxyDelayWith("proxy", "https://www.gstatic.com/generate_204", 5000);
                        if (d <= 0) d = proxyDelayWith("proxy", "https://www.google.com/generate_204", 5000);
                        if (d <= 0) d = proxyDelayWith("proxy", "http://cp.cloudflare.com/generate_204", 5000);
                        if (d > 0) {
                            bad = 0;
                        } else if (++bad >= 2) {
                            Log2.w("健康检查连续失败，判定连接已失效，主动断开");
                            reportError("连接已失效（外网不通），已自动断开。\n\n"
                                    + "节点可能刚刚挂掉，请换一个节点或重新连接。");
                            disconnect(TunnelService.this, "健康检查失败（外网不通），自动断开");
                            break;
                        }
                    }
                }
            }
        }, "conn-notify").start();
    }

    private static final String P_TASK = "pending_task";      // "" / "refresh" / "scan"
    private static final String P_TASK_SRC = "pending_task_sources";
    private static final String P_TASK_SCAN_TRASH = "pending_task_scan_trash";

    private static void savePendingTask(Context ctx, String task, int sources, boolean scanTrash,
                                        boolean alsoScan, boolean fromAuto) {
        try {
            ctx.getSharedPreferences("qv", Context.MODE_PRIVATE).edit()
                    .putString(P_TASK, task)
                    .putInt(P_TASK_SRC, sources)
                    .putBoolean(P_TASK_SCAN_TRASH, scanTrash)
                    .putBoolean("pending_task_also_scan", alsoScan)
                    .putBoolean("pending_task_from_auto", fromAuto)
                    .apply();
        } catch (Throwable ignored) {
        }
    }

    private static void clearPendingTask(Context ctx) {
        try {
            ctx.getSharedPreferences("qv", Context.MODE_PRIVATE).edit()
                    .putString(P_TASK, "").apply();
        } catch (Throwable ignored) {
        }
    }

    /** 体检进度（供界面重新进入时恢复进度窗）。 */
    public static volatile int scanDone = 0;
    /** 体检最近一次有进展的时间（0=没体检），界面用它判断后台是否被冻结过。 */
    public static volatile long scanLastProgressAt = 0;
    /** 本次体检开始的时间（用于判断"冻结了多久"，避免沿用上一次的旧时间）。 */
    public static volatile long scanStartedAt = 0;
    /** 翻新链体检时开一个本地 http 入口，用于逐个节点问 Google 地区；0=不开。 */
    private volatile int scanHttpPort = 0;
    public static volatile int scanTotal = 0;
    public static volatile int scanAlive = 0;

    public static int getScanDone() { return scanDone; }

    public static long getScanLastProgress() { return scanLastProgressAt; }

    public static long getScanStartedAt() { return scanStartedAt; }
    public static int getScanTotal() { return scanTotal; }
    public static int getScanAlive() { return scanAlive; }

    public static boolean isScanning() {
        return sScanning;
    }

    /** 本次体检对"测不通"的节点怎么处理：false=隐藏（VPN 页），true=丢回收站（翻新用）。 */
    private static volatile boolean sScanTrashDead = false;
    /** 本次体检是不是用户点「结束体检」停的（停掉后不再弹"体检完成"结果窗）。 */
    private static volatile boolean sScanStoppedByUser = false;
    /** 本次翻新是不是"到点自动"触发的（只有自动触发的才在服务里接力体检，手动由界面负责）。 */
    private static volatile boolean refreshFromAuto = false;
    /** 手动翻新时是否勾了"翻新后立即体检"（勾了就由服务接力，通知不断）。 */
    private static volatile boolean refreshAlsoScan = false;

    @Override
    public void onTaskRemoved(Intent rootIntent) {
        // 从最近任务里划掉应用时，别把正在跑的翻新/体检一起带走
        try {
            boolean busy = RefreshRunner.isRunning() || sScanning || sRunning || sConnecting;
            Log2.i("应用从最近任务移除，当前" + (busy ? "仍在工作" : "空闲"));
            if ((sRunning || sConnecting) && !RefreshRunner.isRunning() && !sScanning) {
                // VPN 已连接时从最近任务划掉：连接实际上会被系统断掉，
                // 于是主动断开并把状态复位，发一条"意外退出"提醒（点它可自动重连该国）
                if (!sRunning) {
                    // 只是"正在连接"时被划掉：直接取消，不发"点我重连"（那时还没连上）
                    Log2.i("划掉后台：正在连接，取消本次连接");
                    disconnect(this, "应用被划出最近任务（连接被取消）");
                    try {
                        postMessage(this, NOTIF_MSG_ID + 1, "连接已取消",
                                "应用被划出最近任务，正在进行的连接已取消",
                                "由于应用意外退出，这次连接没有完成。点这条通知回到应用重新连接。",
                                openAppIntent(this));
                        stopForeground(true);
                    } catch (Throwable ignored) {
                    }
                    super.onTaskRemoved(rootIntent);
                    return;
                }
                Node cur = sNode;
                String cc = cur == null ? "" : cur.cc;
                boolean fastestMode = sConnectMode == MODE_AUTO;
                String countryName = fastestMode ? "最快地区" : Country.displayName(cc);
                String flag = fastestMode ? "⚡️" : (cur == null ? "" : cur.flag());
                getSharedPreferences("qv", MODE_PRIVATE).edit()
                        .putString("reconnect_cc", cc)
                        .putBoolean("reconnect_fastest", fastestMode).apply();
                Log2.i("划掉后台：主动断开 VPN（" + countryName + " " + cc + "），等待用户决定是否重连");
                disconnect(this, "应用被划出最近任务（意外退出）");
                sRunning = false;
                if (cloudSourceName != null) {
                    // 云节点：通知里用"节点源名称"代替国家/国旗
                    String nodeTitle = cur == null ? "云节点" : cur.title;
                    String shortText = "与" + nodeTitle + "的连接已断开，点我重连";
                    String fullText = "由于应用意外退出，与" + nodeTitle + "的节点已断开连接。\n"
                            + "该节点来自「" + cloudSourceName + "」节点源。\n"
                            + "点这条通知返回应用，会重新连接「" + cloudSourceName + "」里最快的节点。";
                    Intent reopen = openAppIntent(this);
                    postMessage(this, NOTIF_MSG_ID + 1, "VPN 已断开", shortText, fullText, reopen);
                    try {
                        stopForeground(true);
                    } catch (Throwable ignored) {
                    }
                    super.onTaskRemoved(rootIntent);
                    return;
                }
                String shortText = fastestMode
                        ? "与最快地区⚡️的连接已断开，点我重连"
                        : "与" + countryName + flag + "的节点已断开，点我重连";
                String fullText = fastestMode
                        ? "由于应用意外退出，与最快地区⚡️的连接已断开。\n点这条通知返回应用，会自动重新连接最快地区⚡️（全部节点里挑最快）。"
                        : "由于应用意外退出，与" + countryName + flag + "的节点已断开连接。\n"
                          + "点这条通知返回应用，会自动重新连接" + countryName + flag + "（挑该国最快节点）。";
                Intent reopen = openAppIntent(this);
                reopen.putExtra("reconnect_cc", cc);
                postMessage(this, NOTIF_MSG_ID + 1, "VPN 已断开", shortText, fullText, reopen);
                try {
                    stopForeground(true);
                } catch (Throwable ignored) {
                }
                super.onTaskRemoved(rootIntent);
                return;
            }
            if (busy) {
                // 通知文字要按"当前到底在干什么"来写，否则连着 VPN 也会被写成"正在体检节点"
                String text;
                if (RefreshRunner.isRunning()) text = "正在翻新节点";
                else if (sScanning) text = "正在体检节点";
                else text = "正在连接 VPN…";
                startForegroundCompat(text);
            }
        } catch (Throwable ignored) {
        }
        super.onTaskRemoved(rootIntent);
    }

    /** 翻新没能开始：通知界面复位并提示。 */
    private void broadcastRefreshError(String msg) {
        try {
            Intent i = new Intent(RefreshRunner.ACTION_REFRESH_STATE);
            i.setPackage(getPackageName());
            i.putExtra("state", 3);          // 3 = 启动失败
            i.putExtra("error", msg);
            sendBroadcast(i);
        } catch (Throwable ignored) {
        }
    }

    /** 当前这次翻新结束后会不会接力体检（供界面判断文案与弹窗顺序）。 */
    public static boolean refreshWantsScan(Context ctx) {
        try {
            return refreshAlsoScan || (refreshFromAuto && AutoRefresh.scanEnabled(ctx));
        } catch (Throwable t) {
            return false;
        }
    }

    /** 启动一次翻新（前台服务 + 进度通知 + 结束后按需接力体检）。 */
    private int launchRefreshWork(final int sources, final boolean alsoScan, final boolean fromAuto) {
        refreshAlsoScan = alsoScan;
        refreshFromAuto = fromAuto;
        boolean limitOn = fromAuto ? AutoRefresh.limitAutoEnabled(this) : AutoRefresh.limitManualEnabled(this);
        int cap = limitOn ? RefreshRunner.MAX_IMPORT : Integer.MAX_VALUE;
        Log2.i((fromAuto ? "自动" : "手动") + "翻新开始：来源 " + sources
                + " 个，导入上限 " + (limitOn ? "3000 个" : "不限"));
        startForegroundCompat("正在翻新节点");
        savePendingTask(this, "refresh", sources, false, alsoScan, fromAuto);
        boolean started = RefreshRunner.start(this, sources, alsoScan, cap);
        if (!started) {
            Log2.w("翻新启动失败（已有翻新在跑？）");
            broadcastRefreshError("翻新启动失败，请稍后重试");
            clearPendingTask(this);
            stopSelf();
            return START_NOT_STICKY;
        }
            // 轮询等待结束（前台服务保活），结束即退出
            new Thread(new Runnable() {
                @Override
                public void run() {
                    final boolean[] chained = {false};   // 是否已接力体检（接力后由体检线程收尾）
                    try {
                        while (RefreshRunner.isRunning()) {
                            try {
                                Thread.sleep(500);
                            } catch (InterruptedException ignored) {
                            }
                            // 通知跟着进度实时更新，而不是一直停在"正在翻新节点"
                            updateForegroundText("翻新节点 " + (RefreshRunner.curSource + 1) + "/"
                                    + Math.max(1, RefreshRunner.totalSources)
                                    + " · 已导入 " + RefreshRunner.imported + " 个");
                        }
                        // 通知栏更新一下结果
                        try {
                            broadcast("翻新完成：新增 " + lastRefreshImported() + " 个节点");
                        } catch (Throwable ignored) {
                        }
                        // 自动翻新后按设置顺带体检一次（体检必须断开 VPN）
                        boolean chainedScan = false;
                        try {
                            boolean wantScan = refreshAlsoScan
                                    || (refreshFromAuto && AutoRefresh.scanEnabled(TunnelService.this));
                            if (wantScan && !RefreshRunner.cancelled) {
                                if (sRunning || sConnecting) {
                                    Log2.i("翻新结束：体检前先断开 VPN");
                                    if (sRunning) disconnect(TunnelService.this, "翻新结束，体检前自动断开");
                                }
                                // 等 VPN 真正断开（最多 6 秒），否则体检会因"正在连接/已连接"被拒
                                for (int i = 0; i < 12 && (sRunning || sConnecting); i++) {
                                    try {
                                        Thread.sleep(500);
                                    } catch (InterruptedException ignored) {
                                    }
                                }
                                Log2.i("翻新结束：开始体检并识别 IP（通知保持）");
                                pendingNotifyAfterScan = refreshFromAuto;   // 自动翻新才发"完成提醒"
                                startScanTrashDead(TunnelService.this);
                                // 等体检真的开始（最多 4 秒）；没接上就别假装接力
                                for (int i = 0; i < 8 && !sScanning; i++) {
                                    try {
                                        Thread.sleep(500);
                                    } catch (InterruptedException ignored) {
                                    }
                                }
                                chainedScan = sScanning;
                                if (!chainedScan) {
                                    Log2.w("翻新结束：体检没能启动，按普通结束收尾");
                                    pendingNotifyAfterScan = false;
                                }
                            }
                        } catch (Throwable t) {
                            Log2.w("翻新后自动体检失败：" + t);
                        }
                        if (!chainedScan) {
                            clearPendingTask(TunnelService.this);
                            if (refreshFromAuto) finishAutoRefreshSummary(TunnelService.this, -1);
                        }
                        if (chainedScan) {
                            chained[0] = true;
                            Log2.i("翻新服务：已接力体检，保持前台服务与通知");
                            return;               // 由体检线程自己收尾
                        }
                    } finally {
                        if (!chained[0]) {
                            try {
                                stopForeground(true);
                            } catch (Throwable ignored) {
                            }
                            stopSelf();
                            Log2.i("翻新服务退出");
                        }
                    }
                }
            }, "refresh-wait").start();
        return START_STICKY;      // 被系统杀掉时希望能重启（重启后会检查未完成任务）
    }

    public static void startScan(Context ctx) {
        sScanTrashDead = false;
        Intent i = new Intent(ctx, TunnelService.class);
        i.setAction(ACTION_SCAN);
        ctx.startService(i);
    }

    /** 翻新节点专用：测不通的直接丢回收站（而不是隐藏）。 */
    public static void startScanTrashDead(Context ctx) {
        sScanTrashDead = true;
        Intent i = new Intent(ctx, TunnelService.class);
        i.setAction(ACTION_SCAN);
        ctx.startService(i);
    }

    /** 手动/自动翻新节点的统一入口（跑在前台服务里，切到后台也不会被系统随手杀）。 */
    public static boolean startRefresh(Context ctx, int sources) {
        return startRefresh(ctx, sources, false);
    }

    public static boolean startRefresh(Context ctx, int sources, boolean alsoScan) {
        try {
            Intent i = new Intent(ctx, TunnelService.class);
            i.setAction(ACTION_REFRESH);
            i.putExtra("sources", sources);
            i.putExtra("alsoScan", alsoScan);
            if (android.os.Build.VERSION.SDK_INT >= 26) ctx.startForegroundService(i);
            else ctx.startService(i);
            return true;
        } catch (Throwable t) {
            Log2.w("启动翻新服务失败：" + t);
            return false;
        }
    }

    public static void stopScan(Context ctx) {
        Intent i = new Intent(ctx, TunnelService.class);
        i.setAction(ACTION_SCAN_STOP);
        ctx.startService(i);
    }

    /** 连接模式：0=自动（全局最快） 1=指定国家/地区内最快 2=只用这一个节点 */
    public static final int MODE_AUTO = 0;
    /** 4：使用外部给定的候选池（云节点用），一次内核内挑通再连，避免反复开关 VPN。 */
    public static final int MODE_POOL = 4;

    private static volatile java.util.List<Node> sPoolCandidates = null;

    public static void setPoolCandidates(java.util.List<Node> list) {
        sPoolCandidates = list == null ? null : new java.util.ArrayList<Node>(list);
    }

    /** 本次连接用的模式（0=自动/最快地区 1=按国家 2=指定节点）。 */
    private static volatile int sConnectMode = MODE_AUTO;

    public static int connectMode() {
        return sConnectMode;
    }
    public static final int MODE_COUNTRY = 1;
    public static final int MODE_NODE = 2;

    private static volatile boolean sRunning = false;
    private static volatile Node sNode = null;
    private static volatile boolean sSetupDone = false;
    private static volatile long sConnectedAt = 0;
    private static volatile boolean sConnecting = false;

    // —— 上传/下载速度（走本地 clash_api 的累计流量做差分）——
    private static volatile long sSpeedUp = 0, sSpeedDown = 0;
    private static volatile long sTrafficUpTotal = 0, sTrafficDownTotal = 0;
    private static volatile boolean sTrafficPolling = false;
    /** 轮询"代次"：每次重新连接端口都会变，代号不匹配的旧线程自动退出。 */
    private static volatile int sTrafficGen = 0;

    public static long speedUp() { return sSpeedUp; }
    public static long speedDown() { return sSpeedDown; }
    public static long trafficUpTotal() { return sTrafficUpTotal; }
    public static long trafficDownTotal() { return sTrafficDownTotal; }

    /** 每秒读一次 clash_api /connections 的累计流量，差值即实时速度。 */
    private void startTrafficPoll() {
        if (clashPort <= 0) return;
        // 每次连接都换一个代号：上一轮线程看到代号变了就自己退出，
        // 避免它带着旧端口继续跑（会导致速度一直是 0）
        final int myGen = ++sTrafficGen;
        sTrafficPolling = true;
        sSpeedUp = 0; sSpeedDown = 0;
        sTrafficUpTotal = 0; sTrafficDownTotal = 0;
        final int port = clashPort;
        final String secret = clashSecret;
        Thread t = new Thread(new Runnable() {
            @Override
            public void run() {
                long lastUp = -1, lastDown = -1, lastAt = 0;
                while (sTrafficPolling && sRunning && myGen == sTrafficGen) {
                    java.net.HttpURLConnection conn = null;
                    try {
                        conn = (java.net.HttpURLConnection) new java.net.URL(
                                "http://127.0.0.1:" + port + "/connections").openConnection();
                        conn.setConnectTimeout(1500);
                        conn.setReadTimeout(1500);
                        if (secret != null) {
                            conn.setRequestProperty("Authorization", "Bearer " + secret);
                        }
                        if (conn.getResponseCode() == 200) {
                            String body = readAll(conn.getInputStream());
                            org.json.JSONObject o = new org.json.JSONObject(body);
                            long up = o.optLong("uploadTotal", 0);
                            long down = o.optLong("downloadTotal", 0);
                            long now = System.currentTimeMillis();
                            if (lastUp >= 0 && now > lastAt) {
                                double dt = (now - lastAt) / 1000.0;
                                sSpeedUp = Math.max(0, Math.round((up - lastUp) / dt));
                                sSpeedDown = Math.max(0, Math.round((down - lastDown) / dt));
                            }
                            sTrafficUpTotal = up;
                            sTrafficDownTotal = down;
                            lastUp = up; lastDown = down; lastAt = now;
                        }
                    } catch (Throwable ignored) {
                    } finally {
                        if (conn != null) conn.disconnect();
                    }
                    try {
                        Thread.sleep(1000);
                    } catch (InterruptedException e) {
                        break;
                    }
                }
                if (myGen == sTrafficGen) {   // 只有"当前这一轮"才清速度和标志
                    sSpeedUp = 0; sSpeedDown = 0;
                    sTrafficPolling = false;
                }
            }
        }, "traffic-poll");
        t.setDaemon(true);
        t.start();
    }

    private static void stopTrafficPoll() {
        sTrafficPolling = false;
        sTrafficGen++;          // 让还在 sleep 的旧线程立刻作废
        sSpeedUp = 0; sSpeedDown = 0;
    }
    /** 开始连接的时刻，用来给"正在连接"加 90 秒有效期，防止状态卡死。 */
    private static volatile long sConnectingAt = 0;
    /** 每次"连接/断开"都 +1，正在跑的后台流程发现代次变了就作废自己。 */
    private static volatile int sGen = 0;

    /** 原子地开新会话：返回新的代次。 */
    private static synchronized int nextGen() {
        sGen = sGen + 1;
        return sGen;
    }
    private static volatile Node sConnectingNode = null;
    private static volatile int sConnectedDelay = 0;

    public static boolean isRunning() {
        return sRunning;
    }

    /** 连接流程最坏可能十几分钟（全量探测 + 多个复核），超时放宽到 10 分钟。 */
    private static final long CONNECTING_STALE_MS = 600_000L;

    public static boolean isConnecting() {
        if (!sConnecting) return false;
        // 只在"确实很久没有进展"时才判定失效，避免把还在探测的连接误杀
        if (sConnectingAt > 0 && System.currentTimeMillis() - sConnectingAt > CONNECTING_STALE_MS) {
            sConnecting = false;
            sConnectingNode = null;
            Log2.w("正在连接状态超过 10 分钟，自动失效");
            return false;
        }
        return true;
    }

    public static Node connectingNode() {
        return sConnectingNode;
    }

    public static Node currentNode() {
        return sNode;
    }

    /** 连上时内核实测的代理延迟（毫秒）。 */
    public static int connectedDelay() {
        return sRunning ? sConnectedDelay : 0;
    }

    /** 连接建立的时间戳（毫秒），0 = 未连接。 */
    public static long connectedSince() {
        return sRunning ? sConnectedAt : 0;
    }

    private static long lastConnectAt = 0;
    /** 连接配置的本地 http 入口端口（0=没开），连上后用它问 Google 出口地区。 */
    private volatile int connectHttpPort = 0;

    public static void connect(Context ctx, Node node, int mode) {
        connect(ctx, node, mode, false);
    }

    /** force=true 时跳过"2 秒连点保护"（云节点失败后自动换下一个要用）。 */
    public static void connect(Context ctx, Node node, int mode, boolean force) {
        connect(ctx, node, mode, force, null);
    }

    /** cloudSource 非空表示这次是"连接云节点"，随请求带过去，不会残留到下一次连接。 */
    public static void connect(Context ctx, Node node, int mode, boolean force, String cloudSource) {
        if (node == null) {
            Log2.e("connect: 没有可用节点", null);
            return;
        }
        // 连点保护：2 秒内重复发起连接直接忽略（否则会同时跑多个 startPool，内核直接崩）
        long now = System.currentTimeMillis();
        if (!force && now - lastConnectAt < 2000L) {
            Log2.w("忽略重复连接请求（间隔 " + (now - lastConnectAt) + "ms）");
            return;
        }
        lastConnectAt = now;
        nextGen();
        sScanning = false;               // 正在体检就先停掉
        String modeName = mode == MODE_NODE ? "指定节点" : (mode == MODE_COUNTRY ? "国家内最快" : "自动最快");
        Log2.i("连接请求[" + modeName + "]：" + node.title + " (" + node.protocol + " " + node.host + ":" + node.port + ")");
        sNode = node;
        Intent i = new Intent(ctx, TunnelService.class);
        i.setAction(ACTION_CONNECT);
        i.putExtra("uri", node.uri);
        i.putExtra("cc", node.cc);
        i.putExtra("title", node.title);
        i.putExtra("mode", mode);
        i.putExtra("gen", sGen);
        if (cloudSource != null) i.putExtra("cloud_source", cloudSource);
        ctx.startService(i);
    }

    public static void reconnect(Context ctx, Node node, int mode) {
        connect(ctx, node, mode);
    }

    /** 本次断开的原因（写日志用）。 */
    private static volatile String sDisconnectReason = "";
    /** 最近一次"主动断开"的时间；界面用它判断是否还要继续尝试下一个云节点。 */
    public static volatile long lastDisconnectAt = 0;
    /** 云节点会话的源名称（非空表示这次连接来自"连接云节点"）。 */
    private static volatile String cloudSourceName = null;

    public static void setCloudSource(String name) {
        cloudSourceName = name;
    }

    public static String cloudSource() {
        return cloudSourceName;
    }

    /** 记录"VPN 是怎么断的 + 这次连了多久"。 */
    private static void logDisconnect(Context ctx, String reason) {
        try {
            String dur = "未知";
            if (sConnectedAt > 0) {
                long sec = Math.max(0, (System.currentTimeMillis() - sConnectedAt) / 1000);
                dur = String.format(java.util.Locale.US, "%02d:%02d:%02d",
                        sec / 3600, (sec / 60) % 60, sec % 60);
            }
            Log2.i("VPN 断开：原因=" + (reason == null || reason.length() == 0 ? "未说明" : reason)
                    + " · 本次连接时长=" + dur);
        } catch (Throwable ignored) {
        }
    }

    public static void disconnect(Context ctx) {
        disconnect(ctx, "用户在界面点断开");
    }

    public static void disconnect(Context ctx, String reason) {
        sDisconnectReason = reason;
        lastDisconnectAt = System.currentTimeMillis();
        notifHeartbeatOn = false;
        nextGen();                       // 让正在进行的连接立刻作废
        sConnecting = false;
        sConnectingNode = null;
        Intent i = new Intent(ctx, TunnelService.class);
        i.setAction(ACTION_DISCONNECT);
        i.putExtra("reason", reason);
        ctx.startService(i);
    }

    private CommandServer commandServer;
    private ParcelFileDescriptor tunFd;
    private int clashPort;
    private String clashSecret;
    private String lastHealthError;
    private volatile String myTunName = "";
    private volatile boolean poolMode = false;
    /** 实测连不通的主机，下一次组候选池时避开（进程重启后清空）。 */
    private static final java.util.Map<String, Long> BAD_HOSTS =
            java.util.Collections.synchronizedMap(new java.util.HashMap<String, Long>());
    private static final long BAD_HOST_TTL = 5 * 60 * 1000L;   // 5 分钟后重新给它机会

    private static boolean isBadHost(String host) {
        Long at = BAD_HOSTS.get(host);
        if (at == null) return false;
        if (System.currentTimeMillis() - at > BAD_HOST_TTL) {
            BAD_HOSTS.remove(host);
            return false;
        }
        return true;
    }
    private volatile List<NetworkInterface> lastInterfaces = new ArrayList<NetworkInterface>();
    private String lastE2eError;
    private InterfaceUpdateListener interfaceListener;
    private ConnectivityManager.NetworkCallback networkCallback;
    private final Handler main = new Handler(Looper.getMainLooper());
    private ConnectivityManager connectivity;

    /* ------------------------------------------------------------------ */

    @Override
    public void onCreate() {
        super.onCreate();
        Log2.init(this);
        connectivity = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        String action = intent == null ? null : intent.getAction();
        // 系统把服务重启了（intent 可能为空）：看看有没有没做完的任务，接着做
        if (action == null || intent == null
                || !(ACTION_REFRESH.equals(action) || ACTION_SCAN.equals(action)
                || ACTION_SCAN_STOP.equals(action) || ACTION_CONNECT.equals(action)
                || ACTION_DISCONNECT.equals(action))) {
            String pending = getSharedPreferences("qv", MODE_PRIVATE).getString(P_TASK, "");
            if ("refresh".equals(pending) && !RefreshRunner.isRunning()
                    && !sScanning && !sRunning && !sConnecting) {
                int src = getSharedPreferences("qv", MODE_PRIVATE).getInt(P_TASK_SRC, 5);
                boolean alsoScan = getSharedPreferences("qv", MODE_PRIVATE)
                        .getBoolean("pending_task_also_scan", false);
                boolean fromAuto = getSharedPreferences("qv", MODE_PRIVATE)
                        .getBoolean("pending_task_from_auto", false);
                Log2.w("服务被重启：检测到未完成的翻新，自动续做（体检=" + alsoScan + "）");
                return launchRefreshWork(src, alsoScan, fromAuto);
            }
            if ("scan".equals(pending) && !sScanning && !sRunning && !sConnecting) {
                boolean trash = getSharedPreferences("qv", MODE_PRIVATE).getBoolean(P_TASK_SCAN_TRASH, true);
                Log2.w("服务被重启：检测到未完成的体检，自动续做");
                startForegroundCompat("正在体检节点");
                sScanTrashDead = trash;
                sScanning = true;
                scanDone = 0;
                scanTotal = 0;
                scanAlive = 0;
                new Thread(new Runnable() {
                    @Override
                    public void run() {
                        runScan();
                    }
                }, "scan").start();
                return START_STICKY;
            }
            return START_STICKY;
        }
        if (ACTION_REFRESH.equals(action)) {
            // 允许"连着 VPN"时翻新：下载走现有 VPN，到体检那一步会自动断开（见接力体检处）
            if (sScanning || sConnecting) {
                Log2.w("自动/手动翻新：当前正忙（体检或连接中），跳过本次");
                startForegroundCompat("翻新已跳过（正在体检/连接）");
                broadcastRefreshError("当前正忙（体检或连接中），请稍后再翻新");
                boolean fromAuto = intent.getBooleanExtra("fromAuto", false);
                if (fromAuto) {
                    // 被体检/连接占住时照旧每 10 分钟重试一次；
                    // 连着 VPN 已经不算"占用"（下载走现有 VPN，到体检才断开），
                    // 所以不会再出现"整夜重试、早上一关 VPN 就开跑"的情况
                    AutoRefresh.retrySoon(this, 10 * 60 * 1000L);
                    Log2.i("自动翻新被占用挡住（体检/连接中），10 分钟后重试");
                }
                return START_NOT_STICKY;      // 注意：不能 stopSelf，会连带掐掉 VPN/体检
            }
            final int sources = intent.getIntExtra("sources", RefreshRunner.SOURCES.length);
            final boolean reqAlsoScan = intent.getBooleanExtra("alsoScan", false);
            final boolean reqFromAuto = intent.getBooleanExtra("fromAuto", false);
            if (RefreshRunner.isRunning()) {
                Log2.w("翻新已在运行，忽略重复请求");
                startForegroundCompat("正在翻新节点");   // 必须先进前台，否则系统会判超时
                return START_NOT_STICKY;
            }
            return launchRefreshWork(sources, reqAlsoScan, reqFromAuto);
        }
        if (ACTION_KEEPALIVE.equals(action)) {
            // 闹钟把我叫醒：只要保持前台通知，体检/翻新的线程就会继续跑
            if (sScanning) {
                startForegroundCompat("正在体检节点 " + scanDone + " 个 · 后台保活中");
                scheduleKeepAlive(this, 4 * 60 * 1000L);
            } else if (RefreshRunner.isRunning()) {
                startForegroundCompat("正在翻新节点 · 后台保活中");
                scheduleKeepAlive(this, 4 * 60 * 1000L);
            } else {
                // 已连接 VPN / 空闲：不唤醒、不续期
                cancelKeepAlive(this);
                stopSelf();
                return START_NOT_STICKY;
            }
            return START_NOT_STICKY;
        }
        if (ACTION_SCAN_STOP.equals(action)) {
            releaseWifiLock();
            Log2.i("收到停止体检请求");
            sScanning = false;
            sScanStoppedByUser = true;      // 让收尾阶段知道是用户主动停的
            return START_NOT_STICKY;
        }
        if (ACTION_SCAN.equals(action)) {
            if (sScanning) return START_NOT_STICKY;
            if (sRunning || sConnecting) {
                reportError("正在连接中，先断开（或等连接完成）再做节点体检。");
                return START_NOT_STICKY;
            }
            startForegroundCompat("正在体检节点");
            savePendingTask(this, "scan", 0, sScanTrashDead, false, false);
            sScanning = true;
            scanDone = 0;
            scanTotal = 0;
            scanAlive = 0;
            sScanStoppedByUser = false;
            new Thread(new Runnable() {
                @Override
                public void run() {
                    runScan();
                }
            }, "scan").start();
            return START_STICKY;
        }
        if (ACTION_DISCONNECT.equals(action)) {
            String reason = intent.getStringExtra("reason");
            if (reason == null || reason.length() == 0) reason = sDisconnectReason;
            Log2.i("收到断开请求：" + (reason == null ? "" : reason));
            lastDisconnectAt = System.currentTimeMillis();
            CloudTester.stop();          // 断开时顺带取消云节点测试，别在后台继续试
            logDisconnect(this, reason);
            cloudSourceName = null;
            stopBox();
            stopSelf();
            return START_NOT_STICKY;
        }
        if (ACTION_CONNECT.equals(action)) {
            if (sScanning) {
                Log2.w("体检进行中，拒绝连接请求（兜底）");
                reportError("正在体检节点，不能连接 VPN。\n\n请等体检结束，或先在进度窗点「结束体检」。");
                return START_NOT_STICKY;
            }
            if (false) {
                // 体检中要连接：直接把体检作废（新代次会让旧体检线程自行退出，且不再拆新内核）
                Log2.w("连接请求打断体检");
                sScanning = false;
            }
            if (sConnecting) {
                // 旧连接流程还在跑：接管（它看到代次不匹配会自行退出），
                // 不能直接丢弃请求，否则界面会卡在"正在连接"直到超时
                Log2.w("已有连接流程在跑，接管本次连接请求");
                sConnecting = false;
                sConnectingNode = null;
            }
            String extraSrc = intent.getStringExtra("cloud_source");
            if (extraSrc == null) {
                // Activity 在 startService 之前已经 setCloudSource()（同一进程的静态字段），
                // 这里补上，避免"云节点被当成普通节点"
                extraSrc = cloudSourceName;
            }
            cloudSourceName = extraSrc;
            if (cloudSourceName == null) {
                // 兜底：界面在发起连接前把"这次是云节点"写进了 prefs，
                // 某些路径（如断开后重试）会丢掉 intent 里的标记
                cloudSourceName = getSharedPreferences("qv", MODE_PRIVATE)
                        .getString("cloud_active_source", null);
            }
            String uri = intent.getStringExtra("uri");
            String cc = intent.getStringExtra("cc");
            String title = intent.getStringExtra("title");
            final int mode = intent.getIntExtra("mode", MODE_AUTO);
            sConnectMode = mode;
            final int gen = intent.getIntExtra("gen", sGen);
            if (cloudSourceName != null) {
                startForegroundCompat("正在连接 " + cloudSourceName + " 节点源");
            } else {
                startForegroundCompat("正在连接 VPN…（正在挑节点）");
            }
            final Node node;
            final List<Node> candidates;
            try {
                node = new Node(uri, cc, title);
                clashPort = pickFreePort();
                clashSecret = java.util.UUID.randomUUID().toString().replace("-", "").substring(0, 16);
                connectHttpPort = pickFreePort();
                if (mode == MODE_POOL && sPoolCandidates != null && !sPoolCandidates.isEmpty()) {
                    candidates = new java.util.ArrayList<Node>(sPoolCandidates);
                    sPoolCandidates = null;
                } else {
                    candidates = buildCandidates(node, 24, mode);
                }
            } catch (Throwable t) {
                Log2.e("准备节点失败", t);
                reportError("准备节点失败：" + shortError(t));
                stopBox(true);
                stopSelf();
                return START_NOT_STICKY;
            }
            if (sNode == null) sNode = node;
            new Thread(new Runnable() {
                @Override
                public void run() {
                    startPool(candidates, mode, gen);
                }
            }, "start-box").start();
            return START_NOT_STICKY;
        }
        return START_NOT_STICKY;
    }

    @Override
    public void onRevoke() {
        Log2.w("VPN 被系统收回（多半是另一个 VPN 接管，或授权被撤销）");
        reportError("VPN 被系统收回了。\n\n最常见的原因：手机里还有另一个 VPN 正在运行"
                + "（比如 v2rayNG / Clash 之类，尤其是开了「始终开启 VPN」或「锁定」），"
                + "系统会立刻把 VPN 抢回去，表现就是连上瞬间断开。\n\n"
                + "先把其它 VPN 断开（或在系统设置里取消它的始终开启），再回来连。");
        stopBox(true);
        stopSelf();
        super.onRevoke();
    }

    @Override
    public void onDestroy() {
        releaseScanLocks();
        try {
            GeoClassifier.flushCache(this);   // 把 IP→国家 缓存落盘，下次直接复用
        } catch (Throwable ignored) {
        }
        if (sRunning) {
            logDisconnect(this, "服务被系统销毁（可能被清理/回收）");
        }
        Log2.i("服务销毁");
        stopBox();
        super.onDestroy();
    }

    private static String shortError(Throwable t) {
        String msg = t.getMessage();
        if (msg == null || msg.length() == 0) msg = t.getClass().getSimpleName();
        return msg.length() > 160 ? msg.substring(0, 160) : msg;
    }

    /* --------------------------- 内核启停 --------------------------- */

    private synchronized void ensureSetup() {
        if (sSetupDone) return;
        SetupOptions options = new SetupOptions();
        options.setBasePath(getFilesDir().getAbsolutePath());
        java.io.File cache = getCacheDir();
        options.setWorkingPath(cache.getAbsolutePath());
        options.setTempPath(cache.getAbsolutePath());
        options.setAppVersion("1");
        options.setAppMarketingVersion("Command VPN 4.6");
        options.setCrashReportSource("Command VPN");
        options.setDebug(true);   // 关键：让内核把日志回调给我们，出问题时能在 App 里看到
        options.setFixAndroidStack(true);
        options.setLogMaxLines(500);
        options.setPlatformMetadata("{\"os\":\"Android " + Build.VERSION.RELEASE + "\",\"sdk\":" + Build.VERSION.SDK_INT
                + ",\"model\":\"" + Build.MODEL + "\",\"manufacturer\":\"" + Build.MANUFACTURER + "\"}");
        Log2.i("Libbox.setup basePath=" + options.getBasePath() + " work=" + options.getWorkingPath());
        Libbox.setup(options);
        sSetupDone = true;
        try {
            Log2.i("内核版本 " + Libbox.version() + " / " + Libbox.goVersion());
        } catch (Throwable t) {
            Log2.w("读取内核版本失败：" + t);
        }
    }

    private synchronized void startOrReload(String config) {
        ensureSetup();
        OverrideOptions override = new OverrideOptions();
        override.setAutoRedirect(false);
        if (commandServer == null) {
            Log2.i("创建 CommandServer");
            CommandServer server = new CommandServer(this, this);
            server.start();
            commandServer = server;
            Log2.i("CommandServer 已启动");
        }
        Log2.i("startOrReloadService …");
        try {
            commandServer.startOrReloadService(config, override);
            Log2.i("内核 startOrReloadService 返回成功");
        } catch (Throwable t) {
            String msg = String.valueOf(t.getMessage());
            if (msg.contains("cache-file") || msg.contains("timeout")) {
                // 上一次内核没完全退出，cache 文件还锁着：彻底关掉、等它释放，再重试一次
                Log2.w("内核启动失败（" + msg + "），清理旧内核后重试一次");
                closeServer();
                try { Thread.sleep(700); } catch (InterruptedException ignored) { }
                if (commandServer == null) {
                    CommandServer server2 = new CommandServer(this, this);
                    server2.start();
                    commandServer = server2;
                }
                commandServer.startOrReloadService(config, override);
                Log2.i("重试后内核启动成功");
            } else {
                throw t;
            }
        }
    }

    private void stopBox() {
        stopBox(false);
    }

    /** quiet=true 时不广播"未连接"，避免把错误信息冲掉。 */
    private synchronized void stopBox(boolean quiet) {
        cloudSourceName = null;      // 断开就清掉，避免节点源页一直是绿的
        try {
            getSharedPreferences("qv", MODE_PRIVATE).edit()
                    .remove("cloud_active_source").apply();
        } catch (Throwable ignored) {
        }
        sRunning = false;
        sConnecting = false;
        stopTrafficPoll();
        // sConnectedAt 用在断开日志里，别在这里提前清空
        sConnectedAt = 0;
        sConnectedDelay = 0;
        stopNetworkMonitor();
        closeServer();
        closeTunQuietly();
        try {
            stopForeground(true);
        } catch (Throwable ignored) {
        }
        if (!quiet) broadcast("未连接");
    }

    private synchronized void closeTunQuietly() {
        ParcelFileDescriptor fd = tunFd;
        tunFd = null;
        if (fd != null) {
            try {
                fd.close();
                Log2.i("tun 已关闭（VPN 界面拆除）");
            } catch (Throwable t) {
                Log2.w("关闭 tun 失败：" + t);
            }
        }
    }

    private android.net.wifi.WifiManager.WifiLock wifiLock = null;

    /** 体检/翻新期间保持无线不休眠：夜里系统会把 WiFi 降到极低功耗，探测会被拖慢十几倍。 */
    /** 体检/翻新期间每 4 分钟用闹钟唤醒自己一次（防系统速冻）。 */
    public static void scheduleKeepAlive(Context ctx, long delayMs) {
        try {
            android.app.AlarmManager am =
                    (android.app.AlarmManager) ctx.getSystemService(Context.ALARM_SERVICE);
            if (am == null) return;
            Intent i = new Intent(ctx, KeepAliveReceiver.class);
            i.setAction(KeepAliveReceiver.ACTION_KEEPALIVE);
            int flags = android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.M
                    ? PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
                    : PendingIntent.FLAG_UPDATE_CURRENT;
            PendingIntent pi = PendingIntent.getBroadcast(ctx, 0x77, i, flags);
            am.setAndAllowWhileIdle(android.app.AlarmManager.RTC_WAKEUP,
                    System.currentTimeMillis() + delayMs, pi);
            Log2.i("保活心跳已安排：" + (delayMs / 1000) + " 秒后");
        } catch (Throwable t) {
            Log2.w("安排保活心跳失败：" + t);
        }
    }

    public static void cancelKeepAlive(Context ctx) {
        try {
            android.app.AlarmManager am =
                    (android.app.AlarmManager) ctx.getSystemService(Context.ALARM_SERVICE);
            if (am == null) return;
            Intent i = new Intent(ctx, KeepAliveReceiver.class);
            i.setAction(KeepAliveReceiver.ACTION_KEEPALIVE);
            int flags = android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.M
                    ? PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
                    : PendingIntent.FLAG_UPDATE_CURRENT;
            PendingIntent pi = PendingIntent.getBroadcast(ctx, 0x77, i, flags);
            am.cancel(pi);
            Log2.i("保活心跳已取消");
        } catch (Throwable ignored) {
        }
    }

    private android.os.PowerManager.WakeLock scanWakeLock = null;

    /** 体检期间保活：CPU 不休眠 + WiFi 不降功耗，否则后台体检会大面积超时（假死）。 */
    private void acquireScanLocks() {
        try {
            android.os.PowerManager pm = (android.os.PowerManager) getSystemService(POWER_SERVICE);
            if (pm != null) {
                releaseScanWakeLock();
                scanWakeLock = pm.newWakeLock(android.os.PowerManager.PARTIAL_WAKE_LOCK,
                        "CommandVPN:scan");
                scanWakeLock.setReferenceCounted(false);
                scanWakeLock.acquire(60 * 60 * 1000L);   // 最长 1 小时，体检结束会主动释放
                Log2.i("体检：已持有 CPU 唤醒锁（防止后台被冻结）");
            }
        } catch (Throwable t) {
            Log2.w("获取体检唤醒锁失败：" + t);
        }
        acquireWifiLock();
    }

    private void releaseScanLocks() {
        releaseScanWakeLock();
        releaseWifiLock();
    }

    private void releaseScanWakeLock() {
        try {
            if (scanWakeLock != null && scanWakeLock.isHeld()) scanWakeLock.release();
        } catch (Throwable ignored) {
        }
        scanWakeLock = null;
    }

    private void acquireWifiLock() {
        try {
            android.net.wifi.WifiManager wm =
                    (android.net.wifi.WifiManager) getApplicationContext().getSystemService(WIFI_SERVICE);
            if (wm == null) return;
            releaseWifiLock();
            int mode = android.net.wifi.WifiManager.WIFI_MODE_FULL_HIGH_PERF;
            wifiLock = wm.createWifiLock(mode, "CommandVPN:scan");
            wifiLock.setReferenceCounted(false);
            wifiLock.acquire();
            Log2.i("体检：已持有 WiFi 锁（防止夜里无线休眠）");
        } catch (Throwable t) {
            Log2.w("获取 WiFi 锁失败：" + t);
        }
    }

    private void releaseWifiLock() {
        try {
            if (wifiLock != null && wifiLock.isHeld()) wifiLock.release();
        } catch (Throwable ignored) {
        }
        wifiLock = null;
    }

    private synchronized void closeServer() {
        CommandServer server = commandServer;
        commandServer = null;
        if (server != null) {
            try {
                server.closeService();
                Thread.sleep(250);      // 给内核释放缓存文件的时间，避免下次启动 timeout
            } catch (Throwable t) {
                Log2.w("closeService：" + t);
            }
            try {
                server.close();
                Log2.i("内核已关闭");
            } catch (Throwable t) {
                Log2.e("关闭内核出错", t);
            }
        }
    }

    /** 把新建立的 tun fd 发布出去；如果期间已经断开，就地关掉并抛错让内核启动失败。 */
    private synchronized void publishTun(ParcelFileDescriptor fd, int genAtOpen) {
        if (genAtOpen != sGen) {
            try {
                fd.close();
            } catch (Throwable ignored) {
            }
            throw new IllegalStateException("VPN 已断开，放弃本次 TUN");
        }
        try {
            if (tunFd != null) tunFd.close();
        } catch (Throwable ignored) {
        }
        tunFd = fd;
    }

    /**
     * 启动流程（1.6）：
     * 1) 把多个候选节点放进同一份配置（每个一个出站 + 一个 selector + 本地 clash_api）
     * 2) 起内核
     * 3) 并发让内核用每个候选"真的连一次外网"（clash_api 的 delay 接口，走的是代理本身）
     * 4) 选中能通的最快的那个，切换 selector
     * 好处：不再赌单个节点，一次尝试就能在几个节点里挑到活的；切节点也不用重启内核。
     */
    /** 连接流程被作废：把这次留下的内核/TUN 关掉，并把"正在连接"复位。 */
    private synchronized void abortPool(int gen) {
        if (gen != sGen) {
            // 已经有新的会话在跑：只关自己能看到的资源，不动全局状态
            Log2.w("旧连接流程结束（已有新会话），清理残留");
            closeTunQuietly();
            return;
        }
        sConnecting = false;
        sConnectingNode = null;
        closeServer();
        closeTunQuietly();
    }


    /**
     * 先选后连：用扫描配置（无 tun）探测所有候选 → 挑出真能上外网的 → 再用单节点配置连。
     * 这样 DNS 天然走"选中的那个节点"，与 4.9.7 实际生效的行为一致。
     */
    private boolean scanSelectAndConnect(List<Node> candidates, int mode, int gen) {
        try {
            if (clashPort <= 0) return false;
            String scanCfg = ConfigBuilder.buildScanner(candidates, clashPort, clashSecret);
            startOrReload(scanCfg);
            poolMode = true;
            int n = candidates.size();
            final int[] delays = new int[n];
            for (int i = 0; i < n; i++) delays[i] = -1;
            int conc = Math.min(n, 32);
            final java.util.concurrent.ExecutorService pool =
                    java.util.concurrent.Executors.newFixedThreadPool(conc);
            final java.util.concurrent.CountDownLatch latch =
                    new java.util.concurrent.CountDownLatch(n);
            for (int i = 0; i < n; i++) {
                final int idx = i;
                try {
                    pool.execute(new Runnable() {
                        @Override
                        public void run() {
                            try {
                                delays[idx] = proxyDelay("node-" + idx, 5000);
                            } catch (Throwable ignored) {
                            } finally {
                                latch.countDown();
                            }
                        }
                    });
                } catch (Throwable t) {
                    latch.countDown();
                }
            }
            long waves = (n + conc - 1L) / conc;
            try {
                latch.await(waves * 7000L + 3000L, java.util.concurrent.TimeUnit.MILLISECONDS);
            } catch (InterruptedException ignored) {
            }
            try {
                pool.shutdownNow();
            } catch (Throwable ignored) {
            }
            if (gen != sGen) return false;

            java.util.List<int[]> ranked = new java.util.ArrayList<int[]>();
            for (int i = 0; i < n; i++) {
                if (delays[i] > 0) ranked.add(new int[]{i, delays[i]});
            }
            java.util.Collections.sort(ranked, new java.util.Comparator<int[]>() {
                @Override
                public int compare(int[] a, int[] b) { return Integer.compare(a[1], b[1]); }
            });
            Log2.i("扫描完成：可连 " + ranked.size() + "/" + n + " 个，开始复核能否上外网");
            Node chosen = null;
            int checked = 0;
            for (int[] r : ranked) {
                if (checked >= 6) break;
                checked++;
                int g = proxyDelayWith("node-" + r[0], "https://www.gstatic.com/generate_204", 5000);
                int g2 = -1;
                if (g > 0) {
                    g2 = proxyDelayWith("node-" + r[0], "https://www.google.com/generate_204", 5000);
                }
                Log2.i("复核 node-" + r[0] + "（" + candidates.get(r[0]).title + "）：1.1.1.1="
                        + r[1] + "ms，gstatic=" + g + "ms，google=" + g2 + "ms");
                if (g > 0 && g2 > 0) {
                    chosen = candidates.get(r[0]);
                    break;
                }
                if (g > 0 && g2 <= 0) {
                    Log2.w("node-" + r[0] + " 能通 gstatic 但打不开 Google，跳过（这种节点连上也上不了网）");
                }
            }
            closeServer();
            if (chosen == null) {
                Log2.w("没有节点能访问 gstatic（全部只能连通 1.1.1.1）");
                return false;
            }
            if (gen != sGen) return false;
            // 用单节点配置连接
            String cfg = ConfigBuilder.buildMinimal(chosen, clashPort, clashSecret, NodeStore.isDownloadBoost(this), connectHttpPort);
            startOrReload(cfg);
            poolMode = false;
            sNode = chosen;
            // 内核起来了但还没验证外网：这时不能显示"已连接"，
            // 否则会出现"显示已连接、打开网页却打不开"的情况
            updateForegroundText("正在验证外网连通性…");
            Log2.i("单节点内核已启动，正在验证外网连通性");
            int d = proxyDelay("proxy", 6000);
            if (gen != sGen) return false;
            if (d <= 0) {
                // 再换两个地址确认一次：不同节点能通的站点不一样，只认 gstatic 太严格
                d = proxyDelayWith("proxy", "https://www.gstatic.com/generate_204", 5000);
            }
            if (d <= 0) d = proxyDelayWith("proxy", "https://www.google.com/generate_204", 5000);
            if (d <= 0) d = proxyDelayWith("proxy", "http://cp.cloudflare.com/generate_204", 5000);
            boolean unverified = false;
            if (d <= 0) {
                // 三个都不通但节点本身 TCP 是通的：照样连，交给健康检查去处理，
                // 不能因为外网探测失败就把所有节点都判死
                unverified = true;
                d = ranked.isEmpty() ? 0 : Math.max(1, ranked.get(0)[1]);
                Log2.w("外网探测失败，但节点 TCP 可用，按未验证方式连接：" + chosen.title);
            }
            if (d >= 0) {
                sRunning = true;
                startTrafficPoll();
                sConnecting = false;
                sConnectedAt = System.currentTimeMillis();
                sConnectedDelay = d;
                NodeStore.setLastGood(this, chosen.uri, d);
                NodeStore.setCountryGoodUri(this, chosen.cc, chosen.uri);
                NodeStore.addGoodUri(this, chosen.uri);
                startConnectedHeartbeat();
                updateConnectedNotification();
                correctRegionWithGoogle(chosen);
                broadcast("已连接 · " + Country.displayName(chosen.cc) + " · " + chosen.title
                        + (d > 0 ? " · " + d + " ms" : "") + (unverified ? "（外网未验证）" : "") + " ✅");
                Log2.i("先选后连成功：" + chosen.title + " " + d + " ms（单节点模式，DNS 走该节点）");
                return true;
            }
            Log2.w("单节点配置起来后仍连不上外网：" + chosen.title);
            closeServer();
            return false;
        } catch (Throwable t) {
            Log2.w("先选后连失败：" + shortError(t));
            try {
                closeServer();
            } catch (Throwable ignored) {
            }
            return false;
        }
    }

    private void startPool(List<Node> candidates, int mode, int gen) {
        if (gen != sGen) {                 // 已经被断开/新连接作废，直接退出，别起内核
            Log2.w("startPool 已作废（gen 过期），退出");
            return;
        }
        sConnecting = true;
        sConnectingAt = System.currentTimeMillis();
        sConnectingNode = (candidates == null || candidates.isEmpty()) ? null : candidates.get(0);
        broadcast("正在连接 " + (sConnectingNode == null ? "" : sConnectingNode.title) + " …");
        // 先把候选节点的服务器域名解析成 IP：内核的 DNS 走代理，
        // 而"解析节点自己的域名"又要先连上节点，不先解析好就是死循环。
        if (candidates != null) {
            for (Node c : candidates) {
                try {
                    c.resolveHost(true);   // 换一个 IP 再试（域名型节点）
                } catch (Throwable ignored) {
                }
            }
        }
        if (candidates != null && !candidates.isEmpty()) {
            final java.util.concurrent.CountDownLatch dnsLatch =
                    new java.util.concurrent.CountDownLatch(candidates.size());
            for (final Node c : candidates) {
                new Thread(new Runnable() {
                    @Override
                    public void run() {
                        try {
                            c.resolveHost(false);
                        } catch (Throwable ignored) {
                        } finally {
                            dnsLatch.countDown();
                        }
                    }
                }, "dns").start();
            }
            try {
                dnsLatch.await(2500, java.util.concurrent.TimeUnit.MILLISECONDS);
            } catch (InterruptedException ignored) {
            }
            Log2.i("候选节点域名解析完成（本地直连，避免内核 DNS 死循环）");
        }
        // ===== 新流程（对齐 4.9.7 实际生效的单节点模式）：=====
        // 1) 先用"无 tun 的扫描配置"把候选全部探一遍（此时 DNS 不参与）
        // 2) 选出真正能上外网的节点
        // 3) 关掉扫描配置，用"单节点最小配置"起 tun —— DNS 直接走这个节点，
        //    避免候选池里 DNS 永远走 node-0（node-0 不行就全盘皆输）
        if (candidates != null && !candidates.isEmpty() && gen == sGen) {
            if (scanSelectAndConnect(candidates, mode, gen)) return;
            if (gen != sGen) { abortPool(gen); return; }
            Log2.w("先选后连失败，退回候选池流程");
        }

        // 快路径：如果这次选的就是上次连通的节点，先只用它起一次（省掉 24 个节点的探测）
        Node first = candidates == null || candidates.isEmpty() ? null : candidates.get(0);
        boolean knownGood = first != null && (
                first.uri.equals(NodeStore.lastGoodUri(this))
                        || first.uri.equals(NodeStore.countryGoodUri(this, first.cc)));
        if (first != null && knownGood && first.supported) {
            Log2.i("上次这个节点是通的，先试快路径：" + first.title);
            broadcast("正在连接 " + first.title + " …");
            boolean fastStarted = false;
            try {
                startOrReload(ConfigBuilder.buildPool(java.util.Collections.singletonList(first), clashPort, clashSecret, NodeStore.isDownloadBoost(this), connectHttpPort));
                poolMode = true;
                fastStarted = true;
                sNode = first;
                updateForegroundText("正在验证外网连通性…");
                Log2.i("快路径内核已启动，正在验证外网连通性");
                int d = proxyDelay("node-0", 4000);
                if (gen != sGen) {
                    Log2.i("连接已被取消（快路径）");
                    abortPool(gen);
                    return;
                }
                if (d > 0) {
                    sNode = first;
                    sRunning = true;
                    startTrafficPoll();
                    sConnecting = false;
                    sConnectedAt = System.currentTimeMillis();
                    sConnectedDelay = d;
                    NodeStore.setLastGood(this, first.uri, d);
                    NodeStore.setCountryGoodUri(this, first.cc, first.uri);
                    NodeStore.addGoodUri(this, first.uri);   // 都连成功了，当然是可用的
                    Log2.i("快路径成功：" + first.title + " " + d + " ms");
                    startConnectedHeartbeat();
                    updateConnectedNotification();
                    correctRegionWithGoogle(first);
                    broadcast("已连接 · " + Country.displayName(first.cc) + " · " + first.title + " · " + d + " ms ✅");
                    return;
                }
                Log2.w("快路径失败（" + d + "），改用候选池");
            } catch (Throwable t) {
                Log2.e("快路径启动失败", t);
            }
            if (!fastStarted) closeServer();
        }
        if (candidates == null || candidates.isEmpty()) {
            reportError("没有可用节点");
            stopBox(true);
            stopSelf();
            return;
        }
        String firstError = null;
        boolean started = false;
        try {
            String cfg = ConfigBuilder.buildPool(candidates, clashPort, clashSecret, NodeStore.isDownloadBoost(this), connectHttpPort);
            Log2.i("候选池 " + candidates.size() + " 个，配置 " + cfg.length() + " 字节");
            startOrReload(cfg);
            started = true;
            poolMode = true;
        } catch (Throwable t) {
            Log2.e("池配置启动失败", t);
            firstError = shortError(t);
            closeServer();
        }
        if (!started) {
            try {
                String minimal = ConfigBuilder.buildMinimal(candidates.get(0), clashPort, clashSecret, NodeStore.isDownloadBoost(this), connectHttpPort);
                Log2.i("改用极简配置重试");
                startOrReload(minimal);
                started = true;
                poolMode = false;
                Log2.i("极简配置启动成功（单节点模式）");
            } catch (Throwable t2) {
                Log2.e("极简配置也启动失败", t2);
                reportError("内核起不来：\n" + firstError + "\n" + shortError(t2));
                sRunning = false;
                stopBox(true);
                stopSelf();
                return;
            }
        }
        int[] best = probePool(candidates, mode);
        if (gen != sGen) {
            Log2.i("连接已被取消（探测结束）");
            abortPool(gen);
            return;
        }
        if (best != null) {
            commitSelection(candidates, best);
            return;
        }
        sRunning = false;
        StringBuilder sb = new StringBuilder();
        if (mode == MODE_NODE) {
            sb.append("这个节点连不通：").append(candidates.get(0).title)
              .append(" (").append(candidates.get(0).host).append(":").append(candidates.get(0).port).append(")");
            sb.append("\n\n点「连接」会让它自己在能通的节点里挑一个。");
        } else if (mode == MODE_COUNTRY) {
            String ccName = Country.displayName(candidates.get(0).cc);
            int inList = NodeStore.all(this).size();
            int listSame = 0;
            for (Node n : NodeStore.all(this)) if (n.cc.equalsIgnoreCase(candidates.get(0).cc)) listSame++;
            int totalCc = NodeStore.allOfCountry(this, candidates.get(0).cc).size();
            sb.append("「").append(ccName).append("」列表里的 ").append(candidates.size())
              .append(" 个节点全部测过，都没连上。");
            sb.append("\n（列表里该地区有 ").append(listSame).append(" 个，该地区共 ")
              .append(totalCc).append(" 个节点）");
            sb.append("\n\n换一个国家，或点「连接」让它在全部节点里挑一个。");
        } else {
            sb.append("试了 ").append(candidates.size()).append(" 个节点，没有一个能连上外网。");
        }
        if (firstError != null) sb.append("\n内核错误：").append(firstError);
        if (lastHealthError != null) sb.append("\n最后一次自检：").append(lastHealthError);
        sb.append("\n\n当前网络看起来是：").append(networkKind());
        sb.append("\n可能原因：节点已失效，或你这条线路（运营商）到这些节点不通。");
        if (mode == MODE_AUTO) {
            sb.append("\n\n换网络（Wi-Fi ↔ 移动数据）再试，或再点一次「连接」会换一批。");
        }
        reportError(sb.toString());
        stopBox(true);
        stopSelf();
    }

    /** 并发让内核用每个候选出站真连一次，返回 {索引, 延迟} 或 null。 */
    private int[] probePool(List<Node> candidates, int mode) {
        final int n = candidates.size();
        final int[] delays = new int[n];
        for (int i = 0; i < n; i++) delays[i] = -2;   // -2 = 还没开始探；-1 = 探了但不通
        if (n == 0) return null;
        // 单节点模式只测 proxy
        final boolean onlyProxy = !poolMode;
        final int tasks = onlyProxy ? 1 : n;
        // 并发上限：节点多时不要开几百个线程，用线程池排队
        int conc = Math.min(tasks, 48);
        final java.util.concurrent.ExecutorService pool =
                java.util.concurrent.Executors.newFixedThreadPool(conc);
        final java.util.concurrent.CountDownLatch latch = new java.util.concurrent.CountDownLatch(tasks);
        for (int i = 0; i < tasks; i++) {
            final int idx = i;
            try {
                pool.execute(new Runnable() {
                    @Override
                    public void run() {
                        try {
                            delays[idx] = proxyDelay(onlyProxy ? "proxy" : ("node-" + idx), 6000);
                        } catch (Throwable ignored) {
                        } finally {
                            latch.countDown();
                        }
                    }
                });
            } catch (Throwable t) {
                latch.countDown();
            }
        }
        long waves = (tasks + conc - 1L) / conc;          // 按波次给足时间
        long waitMs = waves * 8000L + 4000L;              // 每波最多 6s 探测 + 余量
        try {
            latch.await(waitMs, java.util.concurrent.TimeUnit.MILLISECONDS);
        } catch (InterruptedException ignored) {
        }
        try {
            pool.shutdownNow();
        } catch (Throwable ignored) {
        }
        Log2.i("候选探测完成：" + tasks + " 个（并发 " + conc + "，等了 " + waitMs + "ms）");

        int bestIdx = -1, bestDelay = Integer.MAX_VALUE;
        java.util.List<int[]> ranked = new java.util.ArrayList<int[]>();
        for (int i = 0; i < n; i++) {
            Node c = candidates.get(i);
            Log2.i("候选 node-" + i + " (" + c.title + " @" + c.host + ") 自检延迟 " + delays[i]);
            if (delays[i] <= 0) {
                if (onlyProxy && i > 0) continue;    // 没测过的不记坏主机
                BAD_HOSTS.put(c.host, System.currentTimeMillis());
                continue;
            }
            ranked.add(new int[]{i, delays[i]});
            if (delays[i] < bestDelay) {
                bestDelay = delays[i];
                bestIdx = i;
            }
        }
        if (BAD_HOSTS.size() > 400) BAD_HOSTS.clear();
        if (bestIdx < 0) return null;

        // 关键复核：1.1.1.1 在国内也能连上，所以"能连 1.1.1.1"不代表节点真的能上外网。
        // 再拿 gstatic（只有海外才能正常访问）复核前几个候选，挑第一个真能出去的。
        java.util.Collections.sort(ranked, new java.util.Comparator<int[]>() {
            @Override
            public int compare(int[] a, int[] b) { return Integer.compare(a[1], b[1]); }
        });
        int checked = 0;
        for (int[] r : ranked) {
            if (checked >= 4) break;           // 最多复核 4 个，别太慢
            checked++;
            String tag = onlyProxy ? "proxy" : ("node-" + r[0]);
            int d2 = proxyDelay(tag, 5000);
            int d3 = -1;
            if (d2 > 0) {
                d3 = proxyDelayWith(tag, "https://www.gstatic.com/generate_204", 5000);
            }
            int d4 = -1;
            if (d3 > 0) {
                d4 = proxyDelayWith("node-" + r[0], "https://www.google.com/generate_204", 5000);
            }
            Log2.i("复核 node-" + r[0] + "：1.1.1.1=" + d2 + "ms，gstatic=" + d3
                    + "ms，google=" + d4 + "ms");
            if (d3 > 0 && d4 > 0) {
                return new int[]{r[0], r[1], 0};
            }
            BAD_HOSTS.put(candidates.get(r[0]).host, System.currentTimeMillis());
        }
        Log2.w("所有候选都只能连通 1.1.1.1、无法访问 gstatic（很可能节点回国或已被封）");
        return null;
    }

    /** 让内核用指定出站真的连一次外网，返回毫秒；失败 -1。 */
    /** 指定 URL 的延迟探测（复核节点是否真能上外网用）。 */
    private int proxyDelayWith(String tag, String url, int timeoutMs) {
        java.net.HttpURLConnection conn = null;
        try {
            String path = "/proxies/" + tag + "/delay?url=" + java.net.URLEncoder.encode(url, "UTF-8")
                    + "&timeout=" + timeoutMs;
            conn = (java.net.HttpURLConnection) new java.net.URL(panelBase() + path).openConnection();
            conn.setConnectTimeout(2500);
            conn.setReadTimeout(timeoutMs + 3000);
            if (clashSecret != null) conn.setRequestProperty("Authorization", "Bearer " + clashSecret);
            int code = conn.getResponseCode();
            String body = readAll(code == 200 ? conn.getInputStream() : conn.getErrorStream());
            if (code == 200) {
                int d = new org.json.JSONObject(body).optInt("delay", -1);
                if (d > 0) return d;
            }
        } catch (Throwable ignored) {
        } finally {
            if (conn != null) conn.disconnect();
        }
        return -1;
    }

    /** 连上后用 Google 的视角校验出口地区；与当前标签不一致就更新（用户要求以 Google 为准）。 */
    private void correctRegionWithGoogle(final Node node) {
        final int port = connectHttpPort;
        if (port <= 0 || node == null) return;
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    String cc = GeoGoogle.exitRegion(port, 4000);
                    if (cc.length() == 2 && !cc.equalsIgnoreCase(node.cc)) {
                        java.util.Map<String, String> m = new java.util.HashMap<String, String>();
                        m.put(node.uri, cc);
                        NodeStore.markCcFromGoogle(TunnelService.this, node.uri, cc);
                        NodeStore.setImportedCcBatch(TunnelService.this, m);
                        Log2.i("按 Google 出口地区修正：" + node.title + " "
                                + node.cc + " → " + cc);
                        broadcast("已按 Google 修正地区：" + node.title
                                + " → " + Country.displayName(cc));
                    }
                } catch (Throwable t) {
                    Log2.w("出口地区校验失败：" + t);
                }
            }
        }, "exit-region").start();
    }

    private int proxyDelay(String tag, int timeoutMs) {
        // 第一条用 IP 直连的 URL：不需要 DNS，避免"DNS 走 node-0 很慢 → 所有节点都测不通"
        String[] urls = {"https://1.1.1.1/", "http://www.gstatic.com/generate_204"};
        for (String url : urls) {
            java.net.HttpURLConnection conn = null;
            try {
                String path = "/proxies/" + tag + "/delay?url=" + java.net.URLEncoder.encode(url, "UTF-8")
                        + "&timeout=" + timeoutMs;
                conn = (java.net.HttpURLConnection) new java.net.URL(panelBase() + path).openConnection();
                conn.setConnectTimeout(2500);
                conn.setReadTimeout(timeoutMs + 3000);
                if (clashSecret != null) conn.setRequestProperty("Authorization", "Bearer " + clashSecret);
                int code = conn.getResponseCode();
                String body = readAll(code == 200 ? conn.getInputStream() : conn.getErrorStream());
                if (code == 200) {
                    int d = new org.json.JSONObject(body).optInt("delay", -1);
                    if (d > 0) return d;
                } else {
                    lastHealthError = "HTTP " + code + " " + body;
                }
            } catch (Throwable t) {
                lastHealthError = String.valueOf(t);
            } finally {
                if (conn != null) conn.disconnect();
            }
        }
        return -1;
    }

    /** 把 selector 切到 node-N（clash_api: PUT /proxies/proxy）。 */
    private boolean switchSelector(int index) {
        java.net.HttpURLConnection conn = null;
        try {
            conn = (java.net.HttpURLConnection) new java.net.URL(panelBase() + "/proxies/proxy").openConnection();
            conn.setRequestMethod("PUT");
            conn.setDoOutput(true);
            conn.setConnectTimeout(3000);
            conn.setReadTimeout(5000);
            if (clashSecret != null) conn.setRequestProperty("Authorization", "Bearer " + clashSecret);
            conn.setRequestProperty("Content-Type", "application/json");
            conn.getOutputStream().write(("{\"name\":\"node-" + index + "\"}").getBytes("UTF-8"));
            int code = conn.getResponseCode();
            Log2.i("切换 selector → node-" + index + " HTTP " + code);
            return code >= 200 && code < 300;
        } catch (Throwable t) {
            Log2.w("切换 selector 失败：" + t);
            return false;
        } finally {
            if (conn != null) conn.disconnect();
        }
    }

    private String networkKind() {
        try {
            Network n = connectivity.getActiveNetwork();
            NetworkCapabilities caps = connectivity.getNetworkCapabilities(n);
            if (caps == null) return "未知";
            if (caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)) return "Wi-Fi";
            if (caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR)) return "移动数据";
            if (caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET)) return "有线";
            if (caps.hasTransport(NetworkCapabilities.TRANSPORT_VPN)) return "VPN";
            return "其它";
        } catch (Throwable t) {
            return "未知";
        }
    }

    private static String readAll(java.io.InputStream in) {
        if (in == null) return "";
        try {
            java.io.ByteArrayOutputStream bos = new java.io.ByteArrayOutputStream();
            byte[] buf = new byte[4096];
            int n;
            while ((n = in.read(buf)) > 0) bos.write(buf, 0, n);
            return new String(bos.toByteArray(), "UTF-8");
        } catch (Throwable t) {
            return "";
        } finally {
            try {
                in.close();
            } catch (Throwable ignored) {
            }
        }
    }

    private String panelBase() {
        return "http://127.0.0.1:" + clashPort;
    }

    private static int pickFreePort() {
        try {
            java.net.ServerSocket s = new java.net.ServerSocket(0, 1, InetAddress.getByName("127.0.0.1"));
            int port = s.getLocalPort();
            s.close();
            return port;
        } catch (Throwable t) {
            return 0;
        }
    }

    /**
     * 候选节点池。
     *
     * 关键教训：节点列表是按"机场/节点商"成批来的，同一台服务器会有几十条链接
     * （比如美国组前 10 条全是 163.192.14.135 的 hysteria2，只是密码/SNI 不同）。
     * 如果按顺序取 8 条，其实就是"同一台机器试了 8 次"。
     * 所以这里按 **主机** 去重（同一主机最多 2 条），并且优先挑不是 Cloudflare 前置的
     * ——那条线路在国内运营商下最容易 reset / 超时。
     */
    /** 选定节点后的收尾：切 selector、写状态、广播"已连接"。 */
    private void commitSelection(List<Node> cands, int[] best) {
        int index = best[0];
        int delay = best[1];
        if (index != 0) {
            boolean switched = switchSelector(index);
            if (!switched) {
                Log2.w("切换 selector 到 node-" + index + " 失败，回退到 node-0");
                index = 0;
                int d0 = proxyDelay("node-0", 4000);
                if (d0 <= 0) {
                    // node-0 也不通：不要拿上一个节点的延迟冒充"已连接"
                    Log2.w("回退的 node-0 也不通，本次连接判定失败");
                    sConnecting = false;
                    sRunning = false;
                    broadcast("连接失败：选中的节点连不上，换一个地区试试", true);
                    return;
                }
                delay = d0;
            }
        }
        Node chosen = cands.get(index);
        sNode = chosen;
        sRunning = true;
        startTrafficPoll();
        sConnecting = false;
        sConnectedAt = System.currentTimeMillis();
        sConnectedDelay = delay;
        startConnectedHeartbeat();
        NodeStore.setLastGood(this, chosen.uri, delay);
        NodeStore.setCountryGoodUri(this, chosen.cc, chosen.uri);
        NodeStore.addGoodUri(this, chosen.uri);   // 都连成功了，当然是可用的
        String country = Country.displayName(chosen.cc);
        Log2.i("选用 " + country + " / " + chosen.title + " (" + chosen.host + ":" + chosen.port
                + ") 延迟 " + delay + " ms");
        broadcast("已连接 · " + country + " · " + chosen.title + " · " + delay + " ms ✅");
        // 通知栏以"实际连上的节点"为准；折叠只显示短句，展开看完整信息
        notifConnectedShownOnce = false;
        updateConnectedNotification();
    }

    private List<Node> buildCandidates(Node main, int want, int mode) {
        List<Node> out = new ArrayList<Node>();
        if (main == null) return out;
        out.add(main);
        if (mode == MODE_NODE) {
            Log2.i("指定节点模式：只连 " + main.title + " @" + main.host);
            return out;                     // 用户点了具体节点，就只用它，绝不替换
        }
        // 按国家连接时，用"这个国家的全部节点"（含没通过体检的），而不是只从可用名单里挑
        List<Node> pool;
        if (mode == MODE_COUNTRY) {
            // 先把"列表里看得见的"该国节点放前面（用户预期就是这些），再用该国其它节点补足
            List<Node> visible = new ArrayList<Node>();
            java.util.Set<String> seen = new java.util.HashSet<String>();
            seen.add(main.uri);
            for (Node n : NodeStore.all(this)) {
                if (!n.cc.equalsIgnoreCase(main.cc) || seen.contains(n.uri)) continue;
                seen.add(n.uri);
                visible.add(n);
            }
            List<Node> rest = new ArrayList<Node>();
            for (Node n : NodeStore.allOfCountry(this, main.cc)) {
                if (seen.contains(n.uri)) continue;
                if (NodeStore.isBlacklisted(this, n.uri)) continue;
                seen.add(n.uri);
                rest.add(n);
            }
            // 只测"用户看得见"的那些，列表里有几个就测几个
            pool = new ArrayList<Node>();
            pool.add(main);
            pool.addAll(visible);
            Log2.i("「" + Country.displayName(main.cc) + "」候选 = 列表可见 " + pool.size()
                    + " 个（该地区共 " + (pool.size() + rest.size()) + " 个，其余不参与）");
        } else {
            pool = new ArrayList<Node>(NodeStore.all(this));
        }
        Collections.sort(pool, new java.util.Comparator<Node>() {
            @Override
            public int compare(Node a, Node b) {
                boolean am = a.latency > 0, bm = b.latency > 0;
                if (am != bm) return am ? -1 : 1;
                if (am) return Integer.compare(a.latency, b.latency);
                return 0;
            }
        });

        // 用户点的是哪个国家，就主要在那个国家里挑；只留 5 个名额给别的国家兜底
        // 国家模式不设上限：列表里显示 58 个就测 58 个（"want" 只用来限制自动模式）
        int sameLimit = (mode == MODE_COUNTRY) ? Integer.MAX_VALUE : want;
        if (mode == MODE_COUNTRY) {
            // 候选 = 列表里看得见的那几个，严格按 uri 去重。
            // 注意：不能无条件把 main 塞进去——它可能是"上次连通但已隐藏"的节点，
            // 不在列表里，塞进来就会变成"列表 6 个却测 7 个"
            java.util.LinkedHashMap<String, Node> uniq = new java.util.LinkedHashMap<String, Node>();
            boolean mainInList = false;
            for (Node n : pool) {
                if (n != null && n.uri != null && n.uri.equals(main.uri)) { mainInList = true; break; }
            }
            if (mainInList) uniq.put(main.uri, main);
            for (Node n : pool) {
                if (n == null || n.uri == null) continue;
                if (!n.cc.equalsIgnoreCase(main.cc)) continue;
                if (uniq.containsKey(n.uri)) continue;
                if (!n.supported || !ConfigBuilder.canBuild(n)) continue;
                uniq.put(n.uri, n);
            }
            out.clear();
            out.addAll(uniq.values());
            // 兜底：候选数不允许超过"列表里该地区可见的节点数"（以 NodeStore.all 为准），
            // 多出来的（比如上次连通但已隐藏的节点）直接剔除
            int visibleCount = 0;
            for (Node n : NodeStore.all(this)) {
                if (n.cc != null && n.cc.equalsIgnoreCase(main.cc)) visibleCount++;
            }
            if (out.size() > visibleCount && visibleCount > 0) {
                Log2.w("候选 " + out.size() + " 个 > 列表可见 " + visibleCount + " 个，裁掉多余的");
                out = new ArrayList<Node>(out.subList(0, visibleCount));
            }
            StringBuilder ids = new StringBuilder();
            for (int i = 0; i < out.size(); i++) {
                ids.append(i).append("=").append(out.get(i).title).append(" ");
            }
            Log2.i("「" + Country.displayName(main.cc) + "」候选 " + out.size()
                    + " 个（列表可见 " + visibleCount + " 个，池 " + pool.size() + "）：" + ids);
            return out;
        }
        // 国家模式才"优先同国家"；自动模式直接全球挑
        if (mode == MODE_COUNTRY) {
            for (Node n : pool) {
                if (out.size() >= sameLimit) break;
                if (!n.cc.equals(main.cc)) continue;
                if (n.cf || isCloudflare(n.host)) continue;
                if (usableForPool(out, n)) out.add(n);
            }
        }
        if (mode == MODE_COUNTRY) {
            // 国家模式：只在同一个国家里补，CF 前置的也带上，但绝不跨国家、也不设上限
            for (Node n : pool) {
                if (out.size() >= sameLimit) break;
                if (!n.cc.equals(main.cc)) continue;
                if (usableForPool(out, n)) out.add(n);
            }
            if (out.size() < 8) {
                BAD_HOSTS.clear();
                for (Node n : pool) {
                    if (out.size() >= want) break;
                    if (!n.cc.equals(main.cc)) continue;
                    if (usableForPool(out, n)) out.add(n);
                }
            }
            Log2.i("「" + Country.displayName(main.cc) + "」候选 " + out.size() + " 个（不跨国家）");
            return out;
        }
        // 第二轮：非 CF，全球
        for (Node n : pool) {
            if (out.size() >= want) break;
            if (n.cf || isCloudflare(n.host)) continue;
            if (usableForPool(out, n)) out.add(n);
        }
        // 第三轮：CF 前置的也补上（万一别处都不行）
        for (Node n : pool) {
            if (out.size() >= want) break;
            if (usableForPool(out, n)) out.add(n);
        }
        if (out.size() < 8) {
            // 前面失败过的太多，把"坏主机"名单放开，别把池子饿死
            BAD_HOSTS.clear();
            for (Node n : pool) {
                if (out.size() >= want) break;
                if (usableForPool(out, n)) out.add(n);
            }
        }
        Log2.i("候选池：" + out.size() + " 个（首选 " + main.title + " @" + main.host + "）");
        return out;
    }

    /**
     * 同一主机最多 2 条（避免"同一台机器试 8 次"），
     * 另外 hysteria2 是 UDP/QUIC，国内移动网络经常把它 QoS 掉，
     * 所以池子里最多一半是 hy2，另一半留给 TCP 协议（vless/trojan/vmess/ss）。
     */
    private boolean usableForPool(List<Node> existing, Node n) {
        if (n == null || !n.supported) return false;
        if (!ConfigBuilder.canBuild(n)) return false;
        if (isBadHost(n.host)) return false;
        int sameHost = 0;
        int hy2 = 0;
        for (Node e : existing) {
            if (e.uri.equals(n.uri)) return false;
            if (e.host.equals(n.host)) sameHost++;
            if ("hysteria2".equals(e.protocol)) hy2++;
        }
        if (sameHost >= 2) return false;
        if ("hysteria2".equals(n.protocol) && hy2 >= 12) return false;
        try {
            ConfigBuilder.build(n);
            return true;
        } catch (Throwable t) {
            return false;
        }
    }

    /** 常见 Cloudflare anycast 网段（前置 CDN 节点多在这里，国内线路最容易 reset）。 */
    private static final String[] CF_PREFIXES = {
            "104.16.", "104.17.", "104.18.", "104.19.", "104.20.", "104.21.", "104.22.", "104.23.",
            "104.24.", "104.25.", "104.26.", "104.27.", "172.64.", "172.65.", "172.66.", "172.67.",
            "188.114.96.", "188.114.97.", "188.114.98.", "188.114.99.", "162.159.", "173.245.",
            "103.21.244.", "141.101.10", "108.162.",
    };

    private static boolean isCloudflare(String host) {
        if (host == null) return false;
        for (String p : CF_PREFIXES) {
            if (host.startsWith(p)) return true;
        }
        return false;
    }

    /* ---------------------------- 节点体检 ---------------------------- */

    /**
     * 逐个让内核真的连一次外网，判断节点死活。
     * 每批 BATCH 个做进同一份配置（没有 tun），用 clash_api 并发探测；
     * 结果写进延迟缓存，并把「连不通」的记下来，等界面问用户要不要隐藏。
     */
    private void runScan() {
        final int myGen = ++sGen;               // 体检也算一次"会话"，连接来了就作废
        Log2.i("体检线程启动");
        final boolean trashDead = sScanTrashDead;   // 本次体检怎么处理"测不通"的，开始时定死
        try {
            runScanBody(myGen, trashDead);
        } catch (Throwable t) {
            Log2.e("体检异常中止", t);
            try {
                broadcast("体检出错：" + shortError(t), true);
            } catch (Throwable ignored) {
            }
        } finally {
            boolean autoChain = pendingNotifyAfterScan;
            pendingNotifyAfterScan = false;
            if (autoChain) {
                finishAutoRefreshSummary(this, scanAlive);
            }
            clearPendingTask(this);
            stopScanTicker();
            // 关键：只有当"这一轮"仍然是当前会话时，才允许拆内核/停服务。
            // 否则"体检中点连接"会被旧体检线程把新连接的内核、tun、前台服务一起干掉。
            if (myGen == sGen) {
                sScanning = false;              // 无论怎么退出都要复位，否则体检再也起不来
                try {
                    closeServer();
                } catch (Throwable ignored) {
                }
                try {
                    closeTunQuietly();
                } catch (Throwable ignored) {
                }
                try {
                    stopForeground(true);
                } catch (Throwable ignored) {
                }
                stopSelf();
                Log2.i("体检线程退出（finally），已清理内核");
            } else {
                Log2.i("体检线程退出（finally），但会话已被新的连接/体检接管，不动内核");
            }
        }
    }

    private void runScanBody(int myGen, boolean trashDead) {
        NodeStore.snapshotBeforeScan(this);     // 体检会改名单，先存一份可还原的状态
        boolean scanHidden = true;
        try {
            scanHidden = getSharedPreferences("qv", MODE_PRIVATE)
                    .getBoolean("scan_hidden_too", true);
        } catch (Throwable ignored) {
        }
        List<Node> all = new ArrayList<Node>(NodeStore.scanCandidates(this, scanHidden));
        Log2.i("体检范围：" + all.size() + " 个节点（" + (scanHidden ? "包含已隐藏" : "不含已隐藏") + "）");
        // 复检：从已隐藏的节点里抽 40 个一起测，万一之前是误判（当时网络抖动/超时），
        // 这次测通了就自动恢复，避免"能用的被藏在里面"。
        List<Node> hiddenSamples = NodeStore.hiddenSample(this, 120);
        all.addAll(hiddenSamples);
        int total = all.size();
        scanTotal = total;
        scanDone = 0;
        scanAlive = 0;
        try {
            Intent ti = new Intent(ACTION_STATE);
            ti.setPackage(getPackageName());
            ti.putExtra("scan_total_n", total);
            sendBroadcast(ti);
        } catch (Throwable ignored) {
        }
        if (!hiddenSamples.isEmpty()) {
            Log2.i("复检已隐藏节点 " + hiddenSamples.size() + " 个（随机抽，测通就自动恢复）");
        }
        clashPort = pickFreePort();
        clashSecret = java.util.UUID.randomUUID().toString().replace("-", "").substring(0, 16);
        ensureSetup();
        boolean fastScan = false;
        try {
            fastScan = getSharedPreferences("qv", MODE_PRIVATE)
                    .getBoolean("fast_scan", false);
        } catch (Throwable ignored) {
        }
        // 快速体检：只加批量、少加并发、不动超时（避免误杀慢节点）
        final int BATCH = fastScan ? 200 : 100;
        final int CONC = fastScan ? 60 : 40;
        final int TIMEOUT = 5500;   // 单节点等待
        int done = 0;
        int alive = 0;
        List<Node> dead = new ArrayList<Node>();
        List<Node> aliveNodes = new ArrayList<Node>();
        List<Node> scanned = new ArrayList<Node>();   // 真正参与过探测的节点
        scanStartedAt = System.currentTimeMillis();
        scanLastProgressAt = scanStartedAt;
        // 只有"翻新链"的体检才逐批识别地区（手动体检不识别）
        scanHttpPort = sScanTrashDead ? pickFreePort() : 0;
        acquireScanLocks();
        broadcast("体检开始，共 " + total + " 个节点…");
        Log2.i("=== 体检开始 共 " + total + " 个 ===");
        for (int start = 0; start < total && sScanning && myGen == sGen; start += BATCH) {
            List<Node> batch = new ArrayList<Node>(all.subList(start, Math.min(total, start + BATCH)));
            try {
                Intent bi = new Intent(ACTION_STATE);
                bi.setPackage(getPackageName());
                bi.putExtra("batch_start", true);
                bi.putExtra("batch_idx", start / BATCH + 1);
                bi.putExtra("batch_total", (total + BATCH - 1) / BATCH);
                sendBroadcast(bi);
            } catch (Throwable ignored) {
            }
            scanChunk(batch, aliveNodes, dead, TIMEOUT, CONC, scanned);
            done += batch.size();
            NodeStore.saveLatencies(this, batch);
            if (sScanTrashDead && scanHttpPort > 0) {
                updateForegroundText("正在识别地区 " + done + "/" + total);
            }
            if (sScanTrashDead && scanHttpPort > 0) {
                try {
                    // A：只识别本批"测通了"的节点（死的马上隐藏，识别它没意义）
                    final java.util.List<Node> batchRef = new java.util.ArrayList<Node>();
                    for (Node bn : batch) if (bn.latency > 0) batchRef.add(bn);
                    int identified = batchRef.isEmpty() ? 0
                            : GeoClassifier.identify(this, batchRef, new GeoClassifier.GoogleProbe() {
                        @Override
                        public String regionOf(Node node) {
                            int idx = batchRef.indexOf(node);
                            if (idx < 0) return "";
                            String cc = GeoGoogle.regionOf(clashPort, clashSecret, scanHttpPort, idx, 4000);
                            if (cc.length() == 2) return cc;
                            return GeoGoogle.exitRegion(scanHttpPort, 4000);
                        }
                    }, new GeoClassifier.Progress() {
                        @Override
                        public void onProgress(int d, int f) {
                            try {
                                Intent gi = new Intent(ACTION_STATE);
                                gi.setPackage(getPackageName());
                                gi.putExtra("geo_active", true);
                                gi.putExtra("geo_done", d);
                                gi.putExtra("geo_total", batchRef.size());
                                gi.putExtra("geo_found", f);
                                sendBroadcast(gi);
                            } catch (Throwable ignored) {
                            }
                        }
                    });
                    Log2.i("第 " + (done / BATCH) + " 批：体检并识别地区，识别到 " + identified + " 个");
                    broadcast("体检并识别 IP " + done + "/" + total + " · 可用 "
                            + aliveNodes.size() + " 个");
                } catch (Throwable t) {
                    Log2.w("本批识别地区失败：" + t);
                }
            }
            // 进度放在"识别完"之后更新：否则界面先跳到 100%，识别还在跑，看起来像卡住
            scanDone = done;
            scanLastProgressAt = System.currentTimeMillis();
            scanAlive = aliveNodes.size();
            updateForegroundText((sScanTrashDead ? "体检并识别 IP " : "体检节点 ")
                    + done + "/" + total + " · 可用 " + aliveNodes.size() + " 个");
            startScanTicker(done, total, aliveNodes.size());
            broadcast("体检中 " + done + "/" + total + " · 可用 " + aliveNodes.size());
            // 给界面用进度条
            try {
                Intent pi = new Intent(ACTION_STATE);
                pi.setPackage(getPackageName());
                pi.putExtra(EXTRA_SCAN_PROGRESS, true);
                pi.putExtra("scan_done_n", done);
                pi.putExtra("scan_total_n", total);
                pi.putExtra("scan_alive_n", aliveNodes.size());
                sendBroadcast(pi);
            } catch (Throwable ignored) {
            }
        }
        alive = aliveNodes.size();
        long tailStart = System.currentTimeMillis();
        scanStage("正在整理结果…");
        if (myGen != sGen) {
            Log2.w("体检过程中被新连接/断开打断，丢弃本次结果");
            releaseScanLocks();
            return;
        }

        // 按国家统计可用的，并把每个国家最快的那个记成"上次连上" ——
        // 这样列表里能用的国家会自动带 ✓ 浮到最上面。
        final java.util.Map<String, List<Node>> byCc = new java.util.HashMap<String, List<Node>>();
        for (Node n : aliveNodes) {
            List<Node> l = byCc.get(n.cc);
            if (l == null) {
                l = new ArrayList<Node>();
                byCc.put(n.cc, l);
            }
            l.add(n);
        }
        StringBuilder summary = new StringBuilder();
        List<java.util.Map.Entry<String, List<Node>>> entries =
                new ArrayList<java.util.Map.Entry<String, List<Node>>>(byCc.entrySet());
        java.util.Collections.sort(entries, new java.util.Comparator<java.util.Map.Entry<String, List<Node>>>() {
            @Override
            public int compare(java.util.Map.Entry<String, List<Node>> a, java.util.Map.Entry<String, List<Node>> b) {
                return b.getValue().size() - a.getValue().size();
            }
        });
        Node globalBest = null;
        for (java.util.Map.Entry<String, List<Node>> e : entries) {
            List<Node> list = e.getValue();
            Node best = null;
            for (Node n : list) if (best == null || n.latency < best.latency) best = n;
            if (best != null) {
                NodeStore.setCountryGoodUri(this, e.getKey(), best.uri);
                if (globalBest == null || best.latency < globalBest.latency) globalBest = best;
            }
            String name = Country.displayName(e.getKey());
            if (name.length() == 0) name = e.getKey();
            if (summary.length() > 0) summary.append(" · ");
            summary.append(name).append(" ").append(list.size());
        }
        if (globalBest != null) {
            NodeStore.setLastGood(this, globalBest.uri, globalBest.latency);
        }
        // 体检跑完整了 → 直接用这次的结果当"实测可用"名单（默认视图就只显示它们）；
        // 中途停掉的 → 只增不减，避免把没测到的节点误删。
        try {
            if (done >= total) {
                // 本次测通的就是"实测可用"（整体替换），其余按"不通"处理
                NodeStore.setGoodUris(this, new ArrayList<Node>(aliveNodes));
                java.util.List<String> uris = new ArrayList<String>();
                for (Node n : aliveNodes) uris.add(n.uri);
                final java.util.List<String> stateUris = new ArrayList<String>(uris);
                new Thread(new Runnable() {
                    @Override
                    public void run() {
                        NodeStore.saveStateFile(TunnelService.this, stateUris, "Command VPN 上次体检结果 "
                        + new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm", java.util.Locale.US)
                        .format(new java.util.Date())
                        + " · 网络 " + NodeStore.netLabel(TunnelService.this) + " · 可用 " + stateUris.size());
                    }
                }, "statefile").start();

                Log2.i("体检结果：实测可用 = 本次测通的 " + aliveNodes.size() + " 个（整体替换）");
            } else {
                NodeStore.addGoodUris(this, aliveNodes);
            }
        } catch (Throwable t) {
            Log2.w("更新实测可用名单失败：" + t);
        }

        // 测不通的 → 隐藏（可在体检结果弹窗里一键恢复体检前的状态）
        int hidden = 0;
        int restored = 0;
        try {
            // 以"本次扫描的全部节点"为准：除了测通的，其余一律隐藏
            // （包括探测超时/未知的，以及翻新导入后被标记"已显示"的）
            java.util.Set<String> aliveUris = new java.util.HashSet<String>();
            for (Node n : aliveNodes) aliveUris.add(n.uri);
            java.util.List<Node> toHide = new ArrayList<Node>();
            java.util.List<String> toUnshow = new ArrayList<String>();
            // 完整跑完：本轮所有"没测通"的都隐藏（含超时/未知）；
            // 中途被结束：只隐藏"明确失败"的，别把没测到的也藏了
            boolean completed = done >= total;
            // 只隐藏"确认探通失败"的；没探到/未判定的一律不动
            //（之前完整跑完时会把未知节点也隐藏，导致"弹窗说 6 个未识别、列表里却没有"）
            java.util.List<Node> hideFrom = dead;
            for (Node n : hideFrom) {
                if (aliveUris.contains(n.uri)) continue;
                if (!NodeStore.isBlacklisted(this, n.uri)) toHide.add(n);
                if (completed) toUnshow.add(n.uri);
            }
            if (trashDead) {
                // 翻新节点：测不通的直接丢回收站（可还原），并且按"隐藏状态"丢进去，
                // 这样之后从回收站还原出来仍然是隐藏的
                NodeStore.blacklistAddAll(this, toHide);      // 先标成隐藏，回收站才会记下"原本隐藏"
                hidden = NodeStore.trashAddAll(this, toHide);
                NodeStore.removeShownAll(this, toUnshow);
            } else {
                hidden = NodeStore.blacklistAddAll(this, toHide);
                NodeStore.removeShownAll(this, toUnshow);   // 批量，一次写盘
            }
            restored = NodeStore.blacklistRemoveMany(this, aliveNodes);
            NodeStore.pendingRemoveAll(this, aliveNodes);
            Log2.i("体检结果：隐藏 " + hidden + " 个不通的（可恢复），复检恢复 " + restored + " 个");
            if (!completed) {
                // 体检被中断：没测到的节点保持"显示"，但不能标成实测可用
                java.util.Set<String> testedUris = new java.util.HashSet<String>();
                for (Node n : scanned) testedUris.add(n.uri);
                java.util.List<Node> untested = new java.util.ArrayList<Node>();
                java.util.List<String> untestedUris = new java.util.ArrayList<String>();
                for (Node n : all) {
                    if (testedUris.contains(n.uri)) continue;
                    untested.add(n);
                    untestedUris.add(n.uri);
                }
                // 没测到的：完全不动（隐藏就继续隐藏、显示就继续显示，原有的"实测可用"标记也留着）
                // 已测出不通的：也要去掉旧的"实测可用"标记
                java.util.List<String> deadUris = new java.util.ArrayList<String>();
                for (Node n : dead) deadUris.add(n.uri);
                NodeStore.removeGoodUris(this, deadUris);
                Log2.i("体检被中断：未测到 " + untested.size()
                        + " 个完全保持原样（隐藏/显示/可用标记都不动）；已测不通 "
                        + dead.size() + " 个已隐藏并去掉可用标记");
            }
        } catch (Throwable t) {
            Log2.w("隐藏节点失败：" + t);
        }
        // 导出一份可读的报告到 Download（App 私有目录外部读不到）
        try {
            StringBuilder rep = new StringBuilder();
            rep.append("Command VPN 体检报告\n");
            rep.append("时间: ").append(new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss",
                    java.util.Locale.US).format(new java.util.Date())).append("\n");
            rep.append("网络: ").append(NodeStore.netLabel(this)).append("\n");
            rep.append("总数: ").append(done).append("  可用: ").append(alive)
               .append("  隐藏: ").append(hidden).append("\n\n");
            rep.append("== 可用节点按国家 ==\n");
            for (java.util.Map.Entry<String, List<Node>> e : entries) {
                String nm = Country.displayName(e.getKey());
                if (nm.length() == 0) nm = e.getKey();
                rep.append(nm).append(" (").append(e.getKey()).append(") ")
                   .append(e.getValue().size()).append("\n");
            }
            rep.append("\n== 可用节点清单 ==\n");
            for (Node n : aliveNodes) {
                rep.append(Country.displayName(n.cc)).append("\t")
                   .append(n.protocol).append('\t')
                   .append(n.title).append('\t')
                   .append(n.resolvedHost != null ? n.resolvedHost : n.host).append(':').append(n.port).append('\t')
                   .append(n.latency).append("ms\n");
            }
            scanStage("正在生成体检报告…");
            // 报告改成后台写：MediaStore 有时要 1~2 秒甚至更久，
            // 不能让它卡住"体检完成"的收尾（之前就卡在"正在生成体检报告…"）
            final String reportText = rep.toString();
            final String reportName = "CommandVPN-scan-"
                    + new java.text.SimpleDateFormat("yyyyMMdd-HHmm", java.util.Locale.US)
                    .format(new java.util.Date()) + ".txt";
            scanReportPath = "Download/CommandVPN/" + reportName;
            new Thread(new Runnable() {
                @Override
                public void run() {
                    long t0 = System.currentTimeMillis();
                    String where = NodeStore.exportReportNamed(TunnelService.this, reportName, reportText);
                    Log2.i("报告后台写盘完成：" + where + " 耗时 " + (System.currentTimeMillis() - t0) + "ms");
                    if (where != null) scanReportPath = where;
                }
            }, "report").start();
            Log2.i("体检报告已交给后台线程写入: " + scanReportPath);
        } catch (Throwable t) {
            Log2.w("导出体检报告失败：" + t);
        }

        Log2.i("尾部总耗时 " + (System.currentTimeMillis() - tailStart) + "ms");
        releaseScanLocks();
        Log2.i("=== 体检结束：可用 " + alive + " / " + done + "，自动隐藏 " + hidden
                + " 个连不通的（" + NodeStore.netLabel(this) + "）→ " + summary + " ===");
        if (sScanStoppedByUser) {
            try {
                Intent si = new Intent(ACTION_STATE);
                si.setPackage(getPackageName());
                si.putExtra("msg", "体检已结束：已测 " + done + " 个，其中可用 " + alive + " 个");
                sendBroadcast(si);
            } catch (Throwable ignored) {
            }
            Log2.i("体检被用户结束，跳过结果弹窗");
            return;
        }
        try {
            Intent i = new Intent(ACTION_STATE);
            i.setPackage(getPackageName());
            i.putExtra("msg", "体检完成：可用 " + alive + " 个，已隐藏 " + hidden + " 个连不通的");
            i.putExtra(EXTRA_SCAN_DONE, true);
            i.putExtra("scan_trash_dead", sScanTrashDead);
            i.putExtra(EXTRA_SCAN_ALIVE, alive);
            // 注意：用 hidden（真正被移除的数量），不能用 dead.size()——
            // dead 只统计"明确失败"的节点，超时/未知的不会进 dead，
            // 那样界面上会显示"连不通 0 个"，和实际差几千个
            i.putExtra(EXTRA_SCAN_DEAD, Math.max(hidden, dead.size()));
            i.putExtra(EXTRA_SCAN_SUMMARY, summary.toString());
            i.putExtra("scan_hidden", hidden);
            i.putExtra("scan_report", scanReportPath);
            lastScanDead = dead;
            sendBroadcast(i);
        } catch (Throwable ignored) {
        }
    }

    public static final String EXTRA_SCAN_PROGRESS = "scan_progress";

    /** 体检收尾阶段的提示（进度条已满时显示在弹窗里）。 */
    private void scanStage(String stage) {
        try {
            Intent i = new Intent(ACTION_STATE);
            i.setPackage(getPackageName());
            i.putExtra(EXTRA_SCAN_PROGRESS, true);
            i.putExtra("scan_stage", stage);
            sendBroadcast(i);
        } catch (Throwable ignored) {
        }
    }

    private static volatile List<Node> lastScanDead = new ArrayList<Node>();
    public static volatile String scanReportPath = null;

    /** 界面上要"隐藏不可用的"时取这批。 */
    public static List<Node> lastScanDeadNodes() {
        return lastScanDead;
    }

    /**
     * 测一批节点。整批配置起不来（比如某个节点的 flow 内核不认）时，
     * 就拆成两半重试，直到单个节点；单节点还起不来就当成"测不了"跳过 ——
     * 绝不因为一个坏节点把 99 个好节点一起判死。
     */
    private void scanChunk(List<Node> chunk, List<Node> aliveOut, List<Node> deadOut, int timeout, int conc,
                          List<Node> scannedOut) {
        if (chunk == null || chunk.isEmpty() || !sScanning) return;
        if (scannedOut != null) scannedOut.addAll(chunk);
        try {
            // 一批最多花 12 秒做域名解析：网络断/切换时 DNS 可能逐个卡 1.5 秒，
            // 100 个就是两分半，整轮体检会被拖成几十分钟
            long dnsStart = System.currentTimeMillis();
            for (Node n : chunk) {
                if (System.currentTimeMillis() - dnsStart > 12000L) {
                    Log2.w("本批域名解析超过 12 秒，剩余节点直接用域名继续");
                    break;
                }
                n.resolveHost();
            }
            String cfg = ConfigBuilder.buildScanner(chunk, clashPort, clashSecret, scanHttpPort);
            startOrReload(cfg);
            poolMode = true;
        } catch (Throwable t) {
            closeServer();
            if (chunk.size() == 1) {
                Log2.w("跳过测不了的节点：" + chunk.get(0).title + " : " + shortError(t));
                return;
            }
            // 小批量里只要有一个节点配置不合法，整批就起不来。
            // 这时直接逐个小测，比"二分拆半"少一半以上的内核重载次数
            // （之前遇到多个坏节点时会反复拆批，看起来就是体检卡住）
            if (chunk.size() <= 8) {
                Log2.w("这 " + chunk.size() + " 个起不来，改为逐个重试：" + shortError(t));
                if (scannedOut != null) scannedOut.removeAll(chunk);
                for (Node one : chunk) {
                    if (!sScanning) return;
                    List<Node> single = new ArrayList<Node>();
                    single.add(one);
                    scanChunk(single, aliveOut, deadOut, timeout, conc, scannedOut);
                }
                return;
            }
            Log2.w("这批 " + chunk.size() + " 个起不来，拆半重试：" + shortError(t));
            int half = chunk.size() / 2;
            List<Node> left = new ArrayList<Node>(chunk.subList(0, half));
            List<Node> right = new ArrayList<Node>(chunk.subList(half, chunk.size()));
            if (scannedOut != null) {
                scannedOut.removeAll(chunk);        // 拆半重试时避免重复计数
                scannedOut.addAll(left);
            }
            scanChunk(left, aliveOut, deadOut, timeout, conc, scannedOut);
            scanChunk(right, aliveOut, deadOut, timeout, conc, scannedOut);
            return;
        }
        int[] delays = probeBatch(chunk.size(), conc, timeout);
        // 还是"未知"的节点再补一轮（并发减半、超时缩短）：
        // 第一轮没赶上往往是内核排队，不是节点真的不通；不补的话它们会一直是"未判定"，
        // 中断体检时就会表现为"测了 200 个，只有 24 个可用，其余既没隐藏也没标记"
        java.util.List<Integer> unknownIdx = new java.util.ArrayList<Integer>();
        for (int i = 0; i < delays.length; i++) if (delays[i] == PROBE_UNKNOWN) unknownIdx.add(i);
        // 补测只在"少数没探完"时做；大面积没探完是内核排队/超时，重测一遍纯浪费时间，
        // 这些节点保持"未判定"（既不隐藏也不误杀）即可
        boolean retryOk = !unknownIdx.isEmpty() && unknownIdx.size() <= Math.max(8, chunk.size() / 4);
        if (!unknownIdx.isEmpty() && !retryOk) {
            Log2.i("本批有 " + unknownIdx.size() + " 个没探完（超过 1/4），不做补测，保持未判定");
        }
        if (retryOk && sScanning) {
            Log2.i("本批有 " + unknownIdx.size() + " 个没探完，补测一轮");
            java.util.concurrent.ExecutorService pool2 =
                    java.util.concurrent.Executors.newFixedThreadPool(Math.min(20, unknownIdx.size()));
            final java.util.concurrent.CountDownLatch l2 =
                    new java.util.concurrent.CountDownLatch(unknownIdx.size());
            for (final Integer idx : unknownIdx) {
                try {
                    pool2.execute(new Runnable() {
                        @Override
                        public void run() {
                            try {
                                int d = proxyDelayOne("node-" + idx, "https://1.1.1.1/", 4000);
                                delays[idx] = d > 0 ? d : -1;
                            } catch (Throwable ignored) {
                                delays[idx] = -1;
                            } finally {
                                l2.countDown();
                            }
                        }
                    });
                } catch (Throwable t) {
                    l2.countDown();
                }
            }
            try {
                l2.await(unknownIdx.size() / 20L * 9000L + 15000L,
                        java.util.concurrent.TimeUnit.MILLISECONDS);
            } catch (InterruptedException ignored) {
            }
            try {
                pool2.shutdownNow();
            } catch (Throwable ignored) {
            }
        }
        for (int i = 0; i < chunk.size(); i++) {
            Node n = chunk.get(i);
            n.latency = delays[i];
            if (delays[i] > 0) {
                aliveOut.add(n);
            } else if (delays[i] == PROBE_UNKNOWN) {
                // 没探完：不判死、不隐藏、也不进实测可用
            } else {
                deadOut.add(n);
            }
        }
    }

    /** 探测结果：-1 = 探过但不通；-9 = 还没探完（未知，不能当成不通）。 */
    private static final int PROBE_UNKNOWN = -9;

    private int[] probeBatch(int n, int concurrency, int timeoutMs) {
        final int[] delays = new int[n];
        for (int i = 0; i < n; i++) delays[i] = -1;
        final java.util.concurrent.ExecutorService pool =
                java.util.concurrent.Executors.newFixedThreadPool(Math.max(1, concurrency));
        final java.util.concurrent.CountDownLatch latch = new java.util.concurrent.CountDownLatch(n);
        for (int i = 0; i < n; i++) {
            final int idx = i;
            try {
                pool.execute(new Runnable() {
                    @Override
                    public void run() {
                        try {
                            delays[idx] = proxyDelayOne("node-" + idx, "https://1.1.1.1/", timeoutMs);
                        } catch (Throwable ignored) {
                        } finally {
                            latch.countDown();
                            // 每测完 10 个回报一次，让"本批"进度条动起来
                            int d = n - (int) latch.getCount();
                            if (d % 10 == 0 || latch.getCount() == 0) {
                                try {
                                    Intent pi = new Intent(ACTION_STATE);
                                    pi.setPackage(getPackageName());
                                    pi.putExtra("probe_active", true);
                                    pi.putExtra("probe_done", d);
                                    pi.putExtra("probe_total", n);
                                    sendBroadcast(pi);
                                } catch (Throwable ignored) {
                                }
                            }
                        }
                    }
                });
            } catch (Throwable t) {
                latch.countDown();
            }
        }
        try {
            // 按波次算足等待时间：n 个任务、每波 concurrency 个，最坏每波 (timeout+3s)
            long waves = (n + concurrency - 1) / (long) Math.max(1, concurrency);
            long waitMs = waves * (timeoutMs + 3500L) + 8000L;
            latch.await(Math.max(waitMs, timeoutMs + 6000L), java.util.concurrent.TimeUnit.MILLISECONDS);
        } catch (InterruptedException ignored) {
        }
        try {
            pool.shutdownNow();
        } catch (Throwable ignored) {
        }
        // 只有"根本没开始探"的才算未知；探了返回 -1 的是"确认不通"
        for (int i = 0; i < n; i++) if (delays[i] == -2) delays[i] = PROBE_UNKNOWN;
        return delays;
    }

    /** 单 URL 版本的延迟探测（体检用，少一半开销）。 */
    private int proxyDelayOne(String tag, String url, int timeoutMs) {
        java.net.HttpURLConnection conn = null;
        try {
            String path = "/proxies/" + tag + "/delay?url=" + java.net.URLEncoder.encode(url, "UTF-8")
                    + "&timeout=" + timeoutMs;
            conn = (java.net.HttpURLConnection) new java.net.URL(panelBase() + path).openConnection();
            conn.setConnectTimeout(2500);
            conn.setReadTimeout(timeoutMs + 3000);
            if (clashSecret != null) conn.setRequestProperty("Authorization", "Bearer " + clashSecret);
            int code = conn.getResponseCode();
            String body = readAll(code == 200 ? conn.getInputStream() : conn.getErrorStream());
            if (code == 200) {
                int d = new org.json.JSONObject(body).optInt("delay", -1);
                return d > 0 ? d : -1;
            }
        } catch (Throwable ignored) {
        } finally {
            if (conn != null) conn.disconnect();
        }
        return -1;
    }

    /* ------------------------ PlatformInterface ------------------------ */

    @Override
    public LocalDNSTransport localDNSTransport() {
        return null;
    }

    @Override
    public boolean usePlatformAutoDetectInterfaceControl() {
        return true;
    }

    @Override
    public void autoDetectInterfaceControl(int fd) {
        try {
            boolean ok = protect(fd);
            if (!ok) {
                Log2.w("protect(" + fd + ") 返回 false —— 内核的出站连接可能会绕回 tun");
            }
        } catch (Throwable t) {
            Log2.w("protect(" + fd + ") 失败：" + t);
        }
    }

    @Override
    public int openTun(TunOptions options) {
        final int tunGenAtOpen = sGen;      // 建 tun 期间如果被断开，publishTun 会拒绝
        Log2.i("openTun 请求：mtu=" + safeInt(options.getMTU(), 9000)
                + " autoRoute=" + options.getAutoRoute());
        if (prepare(this) != null) {
            throw new IllegalStateException("android: 缺少 VPN 授权");
        }
        Builder builder = new Builder();
        builder.setSession("Command VPN");   // 系统 VPN 通知/设置里显示的就是这个名字
        // MTU 不能小于 IPv6 最小的 1280：否则加 IPv6 地址/路由时 establish() 会报
        // "Cannot set address"，内核直接起不来
        int mtu = options.getMTU() > 0 ? options.getMTU() : 1400;
        if (mtu < 1280) {
            Log2.w("MTU " + mtu + " 太小（IPv6 最少 1280），按 1280 处理");
            mtu = 1280;
        }
        builder.setMtu(mtu);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            builder.setMetered(false);
        }

        boolean has4 = false;
        RoutePrefixIterator v4 = options.getInet4Address();
        while (v4 != null && v4.hasNext()) {
            RoutePrefix p = v4.next();
            builder.addAddress(p.address(), p.prefix());
            has4 = true;
        }
        if (!has4) builder.addAddress("172.19.0.1", 30);

        // IPv6 只在配置明确要求时才加：下载优化模式刻意只给 IPv4，
        // 这样 App 不会先试 IPv6 然后一直等到超时（表现为下载卡住）
        RoutePrefixIterator v6 = options.getInet6Address();
        while (v6 != null && v6.hasNext()) {
            RoutePrefix p = v6.next();
            try {
                builder.addAddress(p.address(), p.prefix());
            } catch (Throwable t) {
                Log2.w("加 IPv6 地址失败（忽略）：" + t);
            }
        }

        if (options.getAutoRoute()) {
            boolean dnsAdded = false;
            try {
                StringIterator dns = options.getDNSServerAddress();
                while (dns != null && dns.hasNext()) {
                    builder.addDnsServer(dns.next());
                    dnsAdded = true;
                }
            } catch (Throwable t) {
                Log2.w("读取 tun DNS 失败：" + t);
            }
            if (!dnsAdded) {
                builder.addDnsServer("223.5.5.5");
                builder.addDnsServer("1.1.1.1");
            }

            boolean route4 = false;
            RoutePrefixIterator r4 = options.getInet4RouteAddress();
            while (r4 != null && r4.hasNext()) {
                RoutePrefix p = r4.next();
                builder.addRoute(p.address(), p.prefix());
                route4 = true;
            }
            if (!route4) builder.addRoute("0.0.0.0", 0);

            boolean route6 = false;
            RoutePrefixIterator r6 = options.getInet6RouteAddress();
            while (r6 != null && r6.hasNext()) {
                RoutePrefix p = r6.next();
                builder.addRoute(p.address(), p.prefix());
                route6 = true;
            }
            if (!route6) builder.addRoute("::", 0);

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                try {
                    RoutePrefixIterator e4 = options.getInet4RouteExcludeAddress();
                    while (e4 != null && e4.hasNext()) {
                        RoutePrefix p = e4.next();
                        builder.excludeRoute(new android.net.IpPrefix(InetAddress.getByName(p.address()), p.prefix()));
                    }
                    RoutePrefixIterator e6 = options.getInet6RouteExcludeAddress();
                    while (e6 != null && e6.hasNext()) {
                        RoutePrefix p = e6.next();
                        builder.excludeRoute(new android.net.IpPrefix(InetAddress.getByName(p.address()), p.prefix()));
                    }
                } catch (Throwable t) {
                    Log2.w("设置排除路由失败：" + t);
                }
            }
        }

        // 把本 App 排除在 VPN 之外：
        // 这样 App（也就是内核进程）的出站 socket 直接走系统真实默认路由，
        // 不会再被"哪个网卡才是默认网卡"这种问题坑到。
        try {
            builder.addDisallowedApplication(getPackageName());
        } catch (Throwable t) {
            Log2.w("排除自身包名失败：" + t);
        }

        ParcelFileDescriptor fd = builder.establish();
        if (fd == null) {
            throw new IllegalStateException("建立 tun 失败：应用没有被授权，或有其它 VPN 正在运行");
        }
        // 注意：这里要自己留着 PFD。关掉它 VPN 才会真正拆除（否则断开后系统里 VPN 图标不消失）
        publishTun(fd, tunGenAtOpen);
        Log2.i("tun 建立成功 fd=" + fd.getFd() + " mtu=" + options.getMTU());
        return fd.getFd();
    }

    @Override
    public boolean useProcFS() {
        return Build.VERSION.SDK_INT < Build.VERSION_CODES.Q;
    }

    @Override
    public ConnectionOwner findConnectionOwner(int ipProtocol, String sourceAddress, int sourcePort,
                                               String destinationAddress, int destinationPort) {
        // 我们不启用按应用分流，这个方法基本不会被调用；给个空壳比抛异常安全得多
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q && connectivity != null) {
                int uid = connectivity.getConnectionOwnerUid(ipProtocol,
                        new InetSocketAddress(sourceAddress, sourcePort),
                        new InetSocketAddress(destinationAddress, destinationPort));
                ConnectionOwner owner = new ConnectionOwner();
                owner.setUserId(uid);
                String[] packages = getPackageManager().getPackagesForUid(uid);
                String name = (packages != null && packages.length > 0) ? packages[0] : "";
                owner.setUserName(name);
                List<String> names = new ArrayList<String>();
                if (packages != null) Collections.addAll(names, packages);
                owner.setAndroidPackageNames(new StringArray(names));
                return owner;
            }
        } catch (Throwable t) {
            Log2.w("getConnectionOwnerUid 失败：" + t);
        }
        ConnectionOwner owner = new ConnectionOwner();
        owner.setUserId(0);
        owner.setUserName("");
        owner.setAndroidPackageNames(new StringArray(new ArrayList<String>()));
        return owner;
    }

    @Override
    public void startDefaultInterfaceMonitor(InterfaceUpdateListener listener) {
        interfaceListener = listener;
        try {
            if (connectivity == null) return;
            if (networkCallback == null) {
                networkCallback = new ConnectivityManager.NetworkCallback() {
                    @Override
                    public void onAvailable(Network network) {
                        pushDefaultInterface(network);
                    }

                    @Override
                    public void onLost(Network network) {
                        try {
                            if (bestNet != null && bestNet.equals(network)) {
                                Log2.i("选中的默认网卡下线，重新选择");
                                bestNet = null;
                                bestNetPriority = -1;
                                Network active = connectivity == null ? null : connectivity.getActiveNetwork();
                                if (active != null) pushDefaultInterface(active);
                            }
                        } catch (Throwable ignored) {
                        }
                    }

                    @Override
                    public void onCapabilitiesChanged(Network network, NetworkCapabilities caps) {
                        pushDefaultInterface(network);
                    }
                };
                NetworkRequest request = new NetworkRequest.Builder()
                        .addCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
                        .build();
                connectivity.registerNetworkCallback(request, networkCallback, main);
                Log2.i("网络监听已注册");
            }
            pushDefaultInterface(bestUnderlyingNetwork());
        } catch (Throwable t) {
            Log2.w("注册网络监听失败：" + t);
        }
    }

    /** 当前真正在用的底层网络（排除 VPN）。 */
    private Network bestUnderlyingNetwork() {
        try {
            Network fallback = null;
            Network wifi = null;
            Network mobile = null;
            for (Network n : connectivity.getAllNetworks()) {
                NetworkCapabilities caps = connectivity.getNetworkCapabilities(n);
                if (caps == null) continue;
                if (!caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)) continue;
                if (caps.hasTransport(NetworkCapabilities.TRANSPORT_VPN)) continue;
                if (caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)) wifi = n;
                else if (caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR)) mobile = n;
                else fallback = n;
            }
            if (wifi != null) return wifi;
            if (mobile != null) return mobile;
            return fallback;
        } catch (Throwable t) {
            return null;
        }
    }

    @Override
    public void closeDefaultInterfaceMonitor(InterfaceUpdateListener listener) {
        interfaceListener = null;
        stopNetworkMonitor();
    }

    private void stopNetworkMonitor() {
        try {
            if (networkCallback != null && connectivity != null) {
                connectivity.unregisterNetworkCallback(networkCallback);
            }
        } catch (Throwable ignored) {
        }
        networkCallback = null;
    }

    /**
     * 关键：内核用这个 index 在它的网卡列表里找"默认网卡"。
     * 如果推给它的是 tun 自己（或 -1），内核就找不到任何可用网卡，
     * 出站连接会全部失败并报 "no available network interface"。
     * 所以这里必须只报"底层真实网络"，并且永远不要把默认网卡置空。
     */
    /** 拿不到网卡信息时用 postDelayed 重试，绝不 sleep 主线程（回调跑在主线程上）。 */
    private void pushDefaultInterfaceRetry(final Network network, final InterfaceUpdateListener listener, final int attempt) {
        if (attempt >= 10) return;
        android.os.Handler h = new android.os.Handler(getMainLooper());
        final Runnable retry = new Runnable() {
            @Override
            public void run() {
                pushDefaultInterfaceRetry(network, listener, attempt + 1);
            }
        };
        try {
            if (connectivity == null) return;
            LinkProperties lp = connectivity.getLinkProperties(network);
            if (lp == null || lp.getInterfaceName() == null) {
                h.postDelayed(retry, 100);
                return;
            }
            String name = lp.getInterfaceName();
            if (name.equals(myTunName) || (myTunName.length() > 0 && name.startsWith(myTunName))) {
                Log2.i("忽略 tun 网卡作为默认网卡：" + name);
                return;
            }
            java.net.NetworkInterface nif = java.net.NetworkInterface.getByName(name);
            if (nif == null) {
                h.postDelayed(retry, 100);
                return;
            }
            Log2.i("默认网卡 " + name + " index=" + nif.getIndex());
            listener.updateDefaultInterface(name, nif.getIndex(), false, false);
        } catch (Throwable t) {
            Log2.w("推送默认网卡失败：" + t);
        }
    }

    private int bestNetPriority = -1;     // 越大越优先：wifi/eth 3 > 其它 2 > 蜂窝 1
    private Network bestNet;

    private static int transportPriority(NetworkCapabilities caps) {
        if (caps == null) return 0;
        if (caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)) return 3;
        if (caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET)) return 3;
        if (caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR)) return 1;
        return 2;
    }

    private void pushDefaultInterface(Network network) {
        InterfaceUpdateListener listener = interfaceListener;
        if (listener == null) return;
        try {
            if (network == null) {
                return;   // 保留上一次可用的默认网卡，别清空
            }
            if (connectivity == null) return;
            NetworkCapabilities caps = connectivity.getNetworkCapabilities(network);
            if (caps != null && caps.hasTransport(NetworkCapabilities.TRANSPORT_VPN)) {
                Log2.i("忽略 VPN 网络作为默认网卡");
                return;
            }
            int pri = transportPriority(caps);
            // 手机同时连了 Wi-Fi 和移动数据时，不能"谁后回调就用谁"——
            // 之前会选到蜂窝（比如没流量的卡），表现为"已连接但什么都上不去"
            if (bestNet != null && pri < bestNetPriority) {
                Log2.i("忽略优先级较低的网卡（当前已选优先级 " + bestNetPriority + "）");
                return;
            }
            bestNet = network;
            bestNetPriority = pri;
            pushDefaultInterfaceRetry(network, listener, 0);
        } catch (Throwable t) {
            Log2.w("推送默认网卡失败：" + t);
        }
    }

    @Override
    public NetworkInterfaceIterator getInterfaces() {
        List<NetworkInterface> result = new ArrayList<NetworkInterface>();
        try {
            if (connectivity == null) return new InterfaceArray(result);
            List<java.net.NetworkInterface> nifs = Collections.list(java.net.NetworkInterface.getNetworkInterfaces());
            for (Network network : connectivity.getAllNetworks()) {
                try {
                    LinkProperties lp = connectivity.getLinkProperties(network);
                    NetworkCapabilities caps = connectivity.getNetworkCapabilities(network);
                    if (lp == null || caps == null || lp.getInterfaceName() == null) continue;
                    if (caps.hasTransport(NetworkCapabilities.TRANSPORT_VPN)) continue;
                    java.net.NetworkInterface nif = null;
                    for (java.net.NetworkInterface candidate : nifs) {
                        if (candidate.getName().equals(lp.getInterfaceName())) {
                            nif = candidate;
                            break;
                        }
                    }
                    if (nif == null) continue;

                    NetworkInterface box = new NetworkInterface();
                    box.setName(lp.getInterfaceName());
                    box.setIndex(nif.getIndex());
                    try {
                        box.setMTU(nif.getMTU());
                    } catch (Throwable ignored) {
                    }

                    List<String> dns = new ArrayList<String>();
                    for (InetAddress address : lp.getDnsServers()) {
                        String host = cleanAddress(address);
                        if (host != null) dns.add(host);
                    }
                    box.setDNSServer(new StringArray(dns));

                    List<String> gateway = new ArrayList<String>();
                    for (android.net.RouteInfo route : lp.getRoutes()) {
                        try {
                            InetAddress gw = route.getGateway();
                            if (route.getDestination().getPrefixLength() == 0 && gw != null && !gw.isAnyLocalAddress()) {
                                String host = cleanAddress(gw);
                                if (host != null) gateway.add(host);
                            }
                        } catch (Throwable ignored) {
                        }
                    }
                    box.setGateway(new StringArray(gateway));

                    if (caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)) {
                        box.setType(Libbox.InterfaceTypeWIFI);
                    } else if (caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR)) {
                        box.setType(Libbox.InterfaceTypeCellular);
                    } else if (caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET)) {
                        box.setType(Libbox.InterfaceTypeEthernet);
                    } else {
                        box.setType(Libbox.InterfaceTypeOther);
                    }

                    // 关键：地址必须严格合法（形如 1.2.3.4/24、fe80::1/64）。
                    // 内核用 netip.MustParsePrefix 解析这些字符串，格式不对会直接 panic 闪退。
                    List<String> addresses = new ArrayList<String>();
                    for (InterfaceAddress ia : nif.getInterfaceAddresses()) {
                        String prefix = prefixString(ia);
                        if (prefix != null) addresses.add(prefix);
                    }
                    box.setAddresses(new StringArray(addresses));

                    int ifFlags = 0;
                    if (caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)) {
                        ifFlags = OsConstants.IFF_UP | OsConstants.IFF_RUNNING;
                    }
                    if (nif.isLoopback()) ifFlags |= OsConstants.IFF_LOOPBACK;
                    if (nif.isPointToPoint()) ifFlags |= OsConstants.IFF_POINTOPOINT;
                    if (nif.supportsMulticast()) ifFlags |= OsConstants.IFF_MULTICAST;
                    box.setFlags(ifFlags);
                    box.setMetered(!caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_NOT_METERED));

                    result.add(box);
                } catch (Throwable t) {
                    Log2.w("跳过一张网卡：" + t);
                }
            }
        } catch (Throwable t) {
            Log2.w("getInterfaces 失败：" + t);
        }
        // 兜底：某一瞬间拿不到网卡（比如 VPN 正在切换）时，别给内核一个空列表，
        // 否则它会直接报 "no available network interface" 把所有出站打死。
        if (result.isEmpty() && !lastInterfaces.isEmpty()) {
            Log2.w("网卡列表为空，沿用上一次的 " + lastInterfaces.size() + " 张");
            result = lastInterfaces;
        } else if (!result.isEmpty()) {
            lastInterfaces = result;
        }
        return new InterfaceArray(result);
    }

    /** 去掉 %scope，并校验前缀长度，避免内核 MustParsePrefix 崩溃。 */
    private static String prefixString(InterfaceAddress ia) {
        try {
            InetAddress address = ia.getAddress();
            if (address == null) return null;
            int bits = (address instanceof Inet6Address) ? 128 : 32;
            int length = ia.getNetworkPrefixLength();
            if (length < 0 || length > bits) return null;
            String ip = cleanAddress(address);
            if (ip == null) return null;
            return ip + "/" + length;
        } catch (Throwable t) {
            return null;
        }
    }

    private static String cleanAddress(InetAddress address) {
        try {
            if (address == null) return null;
            String host = address.getHostAddress();
            if (host == null) return null;
            int pct = host.indexOf('%');
            if (pct > 0) host = host.substring(0, pct);
            host = host.trim();
            if (host.length() == 0) return null;
            if (InetAddress.getByName(host) == null) return null;
            return host;
        } catch (Throwable t) {
            return null;
        }
    }

    @Override
    public boolean underNetworkExtension() {
        return false;
    }

    @Override
    public boolean includeAllNetworks() {
        return false;
    }

    @Override
    public WIFIState readWIFIState() {
        return null;
    }

    @Override
    public void clearDNSCache() {
    }

    @Override
    public void sendNotification(io.nekohasekai.libbox.Notification notification) {
    }

    @Override
    public void cancelNotification(String identifier, int typeID) {
    }

    /** 内核会问邻居表；我们没有实现，但绝不能抛异常（会变成 Go panic）。 */
    @Override
    public void startNeighborMonitor(NeighborUpdateListener listener) {
        Log2.i("内核请求邻居监听，未实现，忽略");
    }

    @Override
    public void closeNeighborMonitor(NeighborUpdateListener listener) {
    }

    @Override
    public void registerMyInterface(String name) {
        myTunName = name == null ? "" : name;
        Log2.i("注册 tun 网卡：" + myTunName);
    }

    @Override
    public boolean usePlatformShell() {
        return false;
    }

    @Override
    public void checkPlatformShell() {
    }

    @Override
    public ShellSession openShellSession(PlatformUser user, String command, StringIterator environ,
                                        String term, int rows, int cols) {
        return null;
    }

    @Override
    public PlatformUser lookupUser(String username) {
        return null;
    }

    @Override
    public String lookupSFTPServer() {
        return "";
    }

    @Override
    public String readSystemSSHHostKey() {
        return "";
    }

    @Override
    public String tailscaleHostname() {
        return "command-vpn";
    }

    @Override
    public boolean usePlatformBridge() {
        return false;
    }

    @Override
    public BridgeSession createBridge(BridgeOptions options) {
        return null;
    }

    /* ------------------------ CommandServerHandler ------------------------ */

    @Override
    public void serviceStop() {
        // 注意：这里是内核的 Go 回调栈，不能就地关掉 CommandServer（会自己关自己）
        Log2.w("内核要求停止服务");
        main.post(new Runnable() {
            @Override
            public void run() {
                broadcast("服务已停止");
                stopBox();
                stopSelf();
            }
        });
    }

    @Override
    public void serviceReload() {
        Log2.i("内核要求重载");
    }

    @Override
    public void setSystemProxyEnabled(boolean enabled) {
    }

    @Override
    public SystemProxyStatus getSystemProxyStatus() {
        SystemProxyStatus status = new SystemProxyStatus();
        status.setAvailable(false);
        status.setEnabled(false);
        return status;
    }

    @Override
    public int connectSSHAgent() {
        return -1;
    }

    @Override
    public void triggerNativeCrash() {
    }

    @Override
    public void writeDebugMessage(String message) {
        try {
            String msg = Log2.stripAnsi(message);      // 去掉颜色控制符，日志更好读
            if (!Log2.kernelEnabled(this)) {
                // 只看行首的级别词：以前用 contains("ERROR")，
                // 结果 "NOERROR"（DNS 成功）也被当成 ERROR 放进来，日志照样被刷屏
                String up = msg == null ? "" : msg.trim().toUpperCase(java.util.Locale.US);
                boolean keep = up.startsWith("WARN") || up.startsWith("ERROR")
                        || up.startsWith("FATAL") || up.startsWith("PANIC");
                if (!keep) return;
            }
            Log2.i("[内核] " + msg);
        } catch (Throwable ignored) {
        }
    }

    /* ------------------------------ 工具 ------------------------------ */

    public static int lastRefreshImported() {
        try {
            return RefreshRunner.imported;
        } catch (Throwable t) {
            return 0;
        }
    }

    private static int safeInt(int value, int fallback) {
        return value > 0 ? value : fallback;
    }

    private void broadcast(String msg) {
        broadcast(msg, false);
    }

    private void broadcast(String msg, boolean error) {
        try {
            Intent i = new Intent(ACTION_STATE);
            i.setPackage(getPackageName());
            i.putExtra("msg", msg);
            i.putExtra(EXTRA_ERROR, error);
            sendBroadcast(i);
        } catch (Throwable ignored) {
        }
    }

    private void reportError(String text) {
        broadcast(text, true);
    }

    /** 云节点测试阶段的提示通知（不进前台服务，只是让通知栏显示"正在连接某源"）。 */
    public static void cloudNotify(Context ctx, String text) {
        try {
            NotificationManager nm = (NotificationManager) ctx.getSystemService(Context.NOTIFICATION_SERVICE);
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                NotificationChannel ch = new NotificationChannel(CHANNEL, "翻新与体检进度",
                        NotificationManager.IMPORTANCE_DEFAULT);
                nm.createNotificationChannel(ch);
            }
            int flags = Build.VERSION.SDK_INT >= Build.VERSION_CODES.M
                    ? PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
                    : PendingIntent.FLAG_UPDATE_CURRENT;
            PendingIntent pi = PendingIntent.getActivity(ctx, 0,
                    new Intent(ctx, MainActivity.class), flags);
            android.app.Notification.Builder b = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                    ? new android.app.Notification.Builder(ctx, CHANNEL)
                    : new android.app.Notification.Builder(ctx);
            b.setContentTitle("Command VPN").setContentText(text)
                    .setSmallIcon(R.drawable.ic_notify).setContentIntent(pi).setOngoing(true);
            nm.notify(NOTIF_ID, b.build());
        } catch (Throwable t) {
            Log2.w("云节点通知失败：" + t);
        }
    }

    public static void cloudNotifyCancel(Context ctx) {
        try {
            NotificationManager nm = (NotificationManager) ctx.getSystemService(Context.NOTIFICATION_SERVICE);
            nm.cancel(NOTIF_ID);
        } catch (Throwable ignored) {
        }
    }

    private static final int NOTIF_MSG_ID = 0x52;

    /** 发一条普通通知（可点击跳回应用，autoCancel）。 */
    private static void postMessage(Context ctx, int id, String title, String text, Intent openIntent) {
        postMessage(ctx, id, title, text, null, openIntent);
    }

    private static void postMessage(Context ctx, int id, String title, String shortText, String bigText,
                                    Intent openIntent) {
        try {
            NotificationManager nm = (NotificationManager) ctx.getSystemService(Context.NOTIFICATION_SERVICE);
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                NotificationChannel ch = new NotificationChannel(CHANNEL, "翻新与体检进度",
                        NotificationManager.IMPORTANCE_DEFAULT);
                ch.setDescription("翻新节点、体检节点时显示进度与完成提醒");
                nm.createNotificationChannel(ch);
            }
            int flags = Build.VERSION.SDK_INT >= Build.VERSION_CODES.M
                    ? PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
                    : PendingIntent.FLAG_UPDATE_CURRENT;
            PendingIntent pi = openIntent == null ? null
                    : PendingIntent.getActivity(ctx, id, openIntent, flags);
            android.app.Notification.Builder b = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                    ? new android.app.Notification.Builder(ctx, CHANNEL)
                    : new android.app.Notification.Builder(ctx);
            b.setContentTitle(title).setContentText(shortText)
                    .setSmallIcon(R.drawable.ic_notify).setAutoCancel(true);
            if (bigText != null) {
                b.setStyle(new android.app.Notification.BigTextStyle().bigText(bigText));
            }
            if (pi != null) b.setContentIntent(pi);
            nm.notify(id, b.build());
        } catch (Throwable t) {
            Log2.w("发通知失败：" + t);
        }
    }

    /** 自动翻新结束时：写日志；按开关发"完成提醒"消息。 */
    private static void finishAutoRefreshSummary(Context ctx, int aliveAfterScan) {
        try {
            int imported = RefreshRunner.imported;
            String hhmm = new java.text.SimpleDateFormat("HH:mm", java.util.Locale.US)
                    .format(new java.util.Date());
            StringBuilder log = new StringBuilder();
            log.append("自动翻新完成：").append(hhmm).append("，新增 ").append(imported).append(" 个节点");
            if (aliveAfterScan >= 0) log.append("，体检后可用 ").append(aliveAfterScan).append(" 个");
            Log2.i(log.toString());
            if (!AutoRefresh.notifyEnabled(ctx)) return;
            String shortText = hhmm + " 新增 " + imported + " 个"
                    + (aliveAfterScan >= 0 ? "，可用 " + aliveAfterScan + " 个" : "");
            String text = hhmm + " 已完成自动翻新，新增 " + imported + " 个节点";
            if (aliveAfterScan >= 0) text += "；体检后还剩 " + aliveAfterScan + " 个可用节点";
            text += "，可在日志查看详情";
            postMessage(ctx, NOTIF_MSG_ID, "自动翻新完成", shortText, text, openAppIntent(ctx));
        } catch (Throwable t) {
            Log2.w("自动翻新总结失败：" + t);
        }
    }

    private static volatile boolean pendingNotifyAfterScan = false;

    private static Intent openAppIntent(Context ctx) {
        return new Intent(ctx, MainActivity.class);
    }

    private static volatile boolean notifConnectedShownOnce = false;

    /** 已连接时按"当前实际节点"渲染通知：折叠短句、展开全文。 */
    private void updateConnectedNotification() {
        try {
            Node cur = sNode;
            if (cur == null) return;
            String country = Country.displayName(cur.cc);
            String flag = cur.flag();
            int d = sConnectedDelay;
            String shortText;
            String fullText;
            if (cloudSourceName != null) {
                shortText = "已连接 " + cur.title;
                fullText = "已连接 " + cur.title + "，该节点来自于 " + cloudSourceName + " 节点源"
                        + (d > 0 ? "（" + d + " ms）" : "");
            } else {
                shortText = "已连接 · " + country + flag + (d > 0 ? " · " + d + "ms" : "");
                fullText = "已连接 · " + country + flag + " · " + cur.title
                        + (d > 0 ? " · " + d + " ms" : "");
            }
            NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
            Intent open = new Intent(this, MainActivity.class);
            int piFlags = Build.VERSION.SDK_INT >= Build.VERSION_CODES.M
                    ? PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
                    : PendingIntent.FLAG_UPDATE_CURRENT;
            PendingIntent pending = PendingIntent.getActivity(this, 0, open, piFlags);
            android.app.Notification.Builder b = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                    ? new android.app.Notification.Builder(this, CHANNEL)
                    : new android.app.Notification.Builder(this);
            b.setContentTitle("Command VPN").setContentText(shortText)
                    .setSmallIcon(R.drawable.ic_notify).setContentIntent(pending).setOngoing(true)
                    .setStyle(new android.app.Notification.BigTextStyle().bigText(fullText));
            nm.notify(NOTIF_ID, b.build());
            if (!notifConnectedShownOnce) {
                notifConnectedShownOnce = true;
                Log2.i("通知显示实际连接节点：" + country + " / " + cur.title);
            }
        } catch (Throwable ignored) {
        }
    }

    /** 只更新通知栏文字（前台服务已在跑时用），保持通知常驻。 */
    private volatile boolean scanTickerOn = false;
    private int scanTickerDone = 0, scanTickerTotal = 1, scanTickerAlive = 0;

    private void startScanTicker(int done, int total, int alive) {
        scanTickerDone = done;
        scanTickerTotal = total;
        scanTickerAlive = alive;
        if (scanTickerOn) return;
        scanTickerOn = true;
        new Thread(new Runnable() {
            @Override
            public void run() {
                while (scanTickerOn) {
                    try {
                        Thread.sleep(1000);
                    } catch (InterruptedException ignored) {
                    }
                    if (!scanTickerOn) break;
                    updateForegroundText("体检节点 " + scanTickerDone + "/" + scanTickerTotal
                            + " · 可用 " + scanTickerAlive + " 个");
                }
            }
        }, "scan-notify").start();
    }

    private void stopScanTicker() {
        scanTickerOn = false;
    }

    private void updateForegroundText(String text) {
        try {
            NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
            Intent open = new Intent(this, MainActivity.class);
            int piFlags = Build.VERSION.SDK_INT >= Build.VERSION_CODES.M ? PendingIntent.FLAG_IMMUTABLE : 0;
            PendingIntent pending = PendingIntent.getActivity(this, 0, open, piFlags);
            android.app.Notification.Builder builder = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                    ? new android.app.Notification.Builder(this, CHANNEL)
                    : new android.app.Notification.Builder(this);
            android.app.Notification ntf = builder
                    .setContentTitle("Command VPN")
                    .setContentText(text)
                    .setSmallIcon(R.drawable.ic_notify)
                    .setContentIntent(pending)
                    .setOngoing(true)
                    .build();
            nm.notify(NOTIF_ID, ntf);
        } catch (Throwable ignored) {
        }
    }

    /** 系统是否允许本应用发通知（Android 13+ 需要运行时权限；渠道也可能被用户关掉）。 */
    public static boolean notificationsAllowed(Context ctx) {
        try {
            NotificationManager nm = (NotificationManager) ctx.getSystemService(Context.NOTIFICATION_SERVICE);
            if (nm == null) return false;
            if (!nm.areNotificationsEnabled()) return false;
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                NotificationChannel ch = nm.getNotificationChannel(CHANNEL);
                if (ch != null && ch.getImportance() == NotificationManager.IMPORTANCE_NONE) return false;
            }
            return true;
        } catch (Throwable t) {
            return true;
        }
    }

    private void startForegroundCompat(String text) {
        try {
            Log2.i("显示前台通知：" + text + "（系统允许通知=" + notificationsAllowed(this) + "）");
            NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                NotificationChannel channel = new NotificationChannel(CHANNEL, "翻新与体检进度",
                        NotificationManager.IMPORTANCE_DEFAULT);
                channel.setDescription("翻新节点、体检节点时显示进度");
                channel.setShowBadge(false);
                channel.setSound(null, null);   // 只显示，不响铃
                nm.createNotificationChannel(channel);
            }
            Intent open = new Intent(this, MainActivity.class);
            int piFlags = Build.VERSION.SDK_INT >= Build.VERSION_CODES.M ? PendingIntent.FLAG_IMMUTABLE : 0;
            PendingIntent pending = PendingIntent.getActivity(this, 0, open, piFlags);

            android.app.Notification.Builder builder = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                    ? new android.app.Notification.Builder(this, CHANNEL)
                    : new android.app.Notification.Builder(this);
            android.app.Notification notification = builder
                    .setContentTitle("Command VPN")
                    .setContentText(text)
                    .setSmallIcon(R.drawable.ic_notify)
                    .setContentIntent(pending)
                    .setOngoing(true)
                    .build();
            startForeground(NOTIF_ID, notification);
        } catch (Throwable t) {
            Log2.e("前台通知创建失败", t);
        }
    }
}
