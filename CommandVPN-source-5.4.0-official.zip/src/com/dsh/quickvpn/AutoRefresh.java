package com.dsh.quickvpn;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;

/** 自动翻新的设置与定时（按整点多选，默认 03:00）。 */
public class AutoRefresh {

    public static final String PREF_ON = "auto_refresh_on";
    public static final String PREF_HOURS = "auto_refresh_hours";
    public static final String PREF_BOOT = "auto_boot_on";
    public static final String PREF_SOURCES = "auto_refresh_sources";

    public static boolean enabled(Context ctx) {
        return prefs(ctx).getBoolean(PREF_ON, false);
    }

    /** 自动翻新后是否顺带体检（默认开）。 */
    public static boolean scanEnabled(Context ctx) {
        return prefs(ctx).getBoolean("auto_refresh_scan", true);
    }

    public static void setScanEnabled(Context ctx, boolean on) {
        prefs(ctx).edit().putBoolean("auto_refresh_scan", on).apply();
    }

    /** 自动翻新完成后是否发消息提醒（默认关）。 */
    public static boolean notifyEnabled(Context ctx) {
        return prefs(ctx).getBoolean("auto_refresh_notify", false);
    }

    public static void setNotifyEnabled(Context ctx, boolean on) {
        prefs(ctx).edit().putBoolean("auto_refresh_notify", on).apply();
    }

    /** 自动翻新是否限制最多导入 3000 个（默认关）。 */
    public static boolean limitAutoEnabled(Context ctx) {
        return prefs(ctx).getBoolean("limit_auto_3000", false);
    }

    public static void setLimitAutoEnabled(Context ctx, boolean on) {
        prefs(ctx).edit().putBoolean("limit_auto_3000", on).apply();
    }

    /** 手动翻新是否限制最多导入 3000 个（默认开）。 */
    public static boolean limitManualEnabled(Context ctx) {
        return prefs(ctx).getBoolean("limit_manual_3000", true);
    }

    public static void setLimitManualEnabled(Context ctx, boolean on) {
        prefs(ctx).edit().putBoolean("limit_manual_3000", on).apply();
    }

    public static boolean bootEnabled(Context ctx) {
        return prefs(ctx).getBoolean(PREF_BOOT, false);
    }

    public static int sources(Context ctx) {
        int total = SourceStore.size(ctx);          // 以"节点源页"里当前数量为准
        if (total <= 0) total = 1;
        return Math.max(1, Math.min(total,
                prefs(ctx).getInt(PREF_SOURCES, total)));
    }

    /** 已选择的整点集合，默认只有 3 点。 */
    public static java.util.TreeSet<Integer> hours(Context ctx) {
        java.util.TreeSet<Integer> out = new java.util.TreeSet<Integer>();
        String raw = prefs(ctx).getString(PREF_HOURS, "3");
        if (raw != null) {
            for (String p : raw.split(",")) {
                try {
                    int h = Integer.parseInt(p.trim());
                    if (h >= 0 && h <= 23) out.add(h);
                } catch (Throwable ignored) {
                }
            }
        }
        if (out.isEmpty()) out.add(3);
        return out;
    }

    public static void setHours(Context ctx, java.util.Collection<Integer> hs) {
        StringBuilder sb = new StringBuilder();
        for (Integer h : new java.util.TreeSet<Integer>(hs)) {
            if (h == null || h < 0 || h > 23) continue;
            if (sb.length() > 0) sb.append(',');
            sb.append(h);
        }
        if (sb.length() == 0) sb.append('3');
        prefs(ctx).edit().putString(PREF_HOURS, sb.toString()).apply();
        schedule(ctx);
    }

    public static void setEnabled(Context ctx, boolean on) {
        prefs(ctx).edit().putBoolean(PREF_ON, on).apply();
        if (on) schedule(ctx);
        else cancel(ctx);
    }

    public static void setBootEnabled(Context ctx, boolean on) {
        prefs(ctx).edit().putBoolean(PREF_BOOT, on).apply();
    }

    private static SharedPreferences prefs(Context ctx) {
        return ctx.getSharedPreferences("qv", Context.MODE_PRIVATE);
    }

    /** 下一次该翻新的时间点（毫秒时间戳）。 */
    public static long nextTrigger(Context ctx) {
        java.util.TreeSet<Integer> hs = hours(ctx);
        java.util.Calendar c = java.util.Calendar.getInstance();
        long now = System.currentTimeMillis();
        long best = Long.MAX_VALUE;
        for (int day = 0; day <= 2; day++) {
            for (Integer h : hs) {
                java.util.Calendar t = (java.util.Calendar) c.clone();
                t.add(java.util.Calendar.DAY_OF_YEAR, day);
                t.set(java.util.Calendar.HOUR_OF_DAY, h);
                t.set(java.util.Calendar.MINUTE, 0);
                t.set(java.util.Calendar.SECOND, 0);
                t.set(java.util.Calendar.MILLISECOND, 0);
                long ts = t.getTimeInMillis();
                // 只要求"还没到"（1 秒容差）。留太大余量会把"23:59:58 选 0 点"的
                // 次日 00:00 过滤掉，白白再等一天。
                if (ts > now + 1_000L && ts < best) best = ts;
            }
        }
        return best == Long.MAX_VALUE ? now + 3_600_000L : best;
    }

    /** 安排下一次触发（用 setAndAllowWhileIdle，不需要精确闹钟权限）。 */
    public static void schedule(Context ctx) {
        if (!enabled(ctx)) {
            cancel(ctx);              // 自动翻新关着：不该继续排闹钟
            return;
        }
        try {
            long at = nextTrigger(ctx);
            AlarmManager am = (AlarmManager) ctx.getSystemService(Context.ALARM_SERVICE);
            if (am == null) return;
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pending(ctx));
            Log2.i("自动翻新已安排：" + new java.text.SimpleDateFormat("MM-dd HH:mm", java.util.Locale.US)
                    .format(new java.util.Date(at)) + "，来源数 " + sources(ctx));
        } catch (Throwable t) {
            Log2.w("安排自动翻新失败：" + t);
        }
    }

    /** 被占用（正在体检/连接）时临时重试一次，不影响主闹钟。 */
    public static void retrySoon(Context ctx, long delayMs) {
        try {
            AlarmManager am = (AlarmManager) ctx.getSystemService(Context.ALARM_SERVICE);
            if (am == null) return;
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,
                    System.currentTimeMillis() + delayMs, retryPending(ctx));
        } catch (Throwable t) {
            Log2.w("安排重试失败：" + t);
        }
    }

    public static void cancel(Context ctx) {
        try {
            AlarmManager am = (AlarmManager) ctx.getSystemService(Context.ALARM_SERVICE);
            if (am != null) am.cancel(pending(ctx));
            Log2.i("自动翻新已关闭");
        } catch (Throwable ignored) {
        }
    }

    private static PendingIntent retryPending(Context ctx) {
        Intent i = new Intent(ctx, AutoRefreshReceiver.class);
        i.setAction(AutoRefreshReceiver.ACTION_RETRY);
        int flags = android.os.Build.VERSION.SDK_INT >= 23
                ? PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
                : PendingIntent.FLAG_UPDATE_CURRENT;
        return PendingIntent.getBroadcast(ctx, 1002, i, flags);
    }

    private static PendingIntent pending(Context ctx) {
        Intent i = new Intent(ctx, AutoRefreshReceiver.class);
        i.setAction(AutoRefreshReceiver.ACTION);
        int flags = android.os.Build.VERSION.SDK_INT >= 23
                ? PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
                : PendingIntent.FLAG_UPDATE_CURRENT;
        return PendingIntent.getBroadcast(ctx, 1001, i, flags);
    }
}
