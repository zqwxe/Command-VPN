package com.dsh.quickvpn;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/** 一个国家/地区 = 一组节点。 */
public class Country {

    private static final Map<String, String> NAMES = new HashMap<String, String>();

    static {
        String[][] table = {
                {"CN", "中国大陆"}, {"US", "美国"}, {"CA", "加拿大"}, {"NL", "荷兰"}, {"JP", "日本"}, {"DE", "德国"},
                {"HK", "中国香港"}, {"SG", "新加坡"}, {"KR", "韩国"}, {"GB", "英国"}, {"TW", "中国台湾"},
                {"FR", "法国"}, {"RU", "俄罗斯"}, {"IN", "印度"}, {"AU", "澳大利亚"}, {"ID", "印尼"},
                {"VN", "越南"}, {"TH", "泰国"}, {"TR", "土耳其"}, {"BR", "巴西"}, {"MY", "马来西亚"},
                {"PH", "菲律宾"}, {"AE", "阿联酋"}, {"PL", "波兰"}, {"SE", "瑞典"}, {"CH", "瑞士"},
                {"IT", "意大利"}, {"ES", "西班牙"}, {"FI", "芬兰"}, {"NO", "挪威"}, {"DK", "丹麦"},
                {"IE", "爱尔兰"}, {"AT", "奥地利"}, {"CZ", "捷克"}, {"UA", "乌克兰"}, {"IL", "以色列"},
                {"ZA", "南非"}, {"MX", "墨西哥"}, {"AR", "阿根廷"}, {"CL", "智利"}, {"NG", "尼日利亚"},
                {"EG", "埃及"}, {"SA", "沙特"}, {"IR", "伊朗"}, {"PK", "巴基斯坦"}, {"BD", "孟加拉"},
                {"NZ", "新西兰"}, {"PT", "葡萄牙"}, {"RO", "罗马尼亚"}, {"HU", "匈牙利"}, {"BG", "保加利亚"},
                {"GR", "希腊"}, {"LT", "立陶宛"}, {"LV", "拉脱维亚"}, {"EE", "爱沙尼亚"}, {"MD", "摩尔多瓦"},
                {"KZ", "哈萨克斯坦"}, {"AM", "亚美尼亚"}, {"GE", "格鲁吉亚"}, {"MO", "中国澳门"}, {"MN", "蒙古"},
                {"IS", "冰岛"}, {"LU", "卢森堡"}, {"BE", "比利时"}, {"SK", "斯洛伐克"}, {"SI", "斯洛文尼亚"},
                {"HR", "克罗地亚"}, {"RS", "塞尔维亚"}, {"CY", "塞浦路斯"}, {"MT", "马耳他"}, {"AL", "阿尔巴尼亚"},
                {"BY", "白俄罗斯"}, {"UZ", "乌兹别克斯坦"}, {"AZ", "阿塞拜疆"}, {"CO", "哥伦比亚"}, {"PE", "秘鲁"},
                {"EC", "厄瓜多尔"}, {"UY", "乌拉圭"}, {"PY", "巴拉圭"}, {"BO", "玻利维亚"}, {"CR", "哥斯达黎加"},
                {"PA", "巴拿马"}, {"GT", "危地马拉"}, {"DO", "多米尼加"}, {"PR", "波多黎各"}, {"JM", "牙买加"},
                {"IQ", "伊拉克"}, {"SY", "叙利亚"}, {"JO", "约旦"}, {"LB", "黎巴嫩"}, {"KW", "科威特"},
                {"QA", "卡塔尔"}, {"OM", "阿曼"}, {"BH", "巴林"}, {"YE", "也门"}, {"LY", "利比亚"},
                {"TN", "突尼斯"}, {"DZ", "阿尔及利亚"}, {"MA", "摩洛哥"}, {"KE", "肯尼亚"}, {"TZ", "坦桑尼亚"},
                {"GH", "加纳"}, {"CI", "科特迪瓦"}, {"CM", "喀麦隆"}, {"ZW", "津巴布韦"}, {"MZ", "莫桑比克"},
                {"AO", "安哥拉"}, {"BW", "博茨瓦纳"}, {"MU", "毛里求斯"}, {"AF", "阿富汗"}, {"NP", "尼泊尔"},
                {"LK", "斯里兰卡"}, {"MM", "缅甸"}, {"KH", "柬埔寨"}, {"LA", "老挝"}, {"BN", "文莱"},
                {"CU", "古巴"}, {"VE", "委内瑞拉"}, {"HN", "洪都拉斯"}, {"SV", "萨尔瓦多"}, {"NI", "尼加拉瓜"},
                {"TT", "特立尼达"}, {"BS", "巴哈马"}, {"BB", "巴巴多斯"}, {"IM", "马恩岛"}, {"GI", "直布罗陀"},
                {"XK", "科索沃"}, {"**", "未识别地区"}, {"FAST", "最快地区"}, {"ZZ", "未识别地区"},
        };
        for (String[] row : table) NAMES.put(row[0], row[1]);
    }

    /** 列表里的优先顺序：中国香港 / 中国台湾 / 新加坡 排最前（用户主要用这三个）。 */
    public static int sortRank(String cc) {
        if (cc == null) return 9;
        String c = cc.toUpperCase(Locale.ROOT);
        if ("HK".equals(c)) return 0;
        if ("TW".equals(c)) return 1;
        if ("SG".equals(c)) return 2;
        if ("US".equals(c)) return 3;      // 美国实测能用，用户要求置顶
        if ("**".equals(c)) return -1;      // 自己导入的永远最前
        return 5;
    }

    /** 按国家码取中文名（没有就用国家码本身）。 */
    /**
     * 从节点标题/链接里猜国家码（导入的节点没有国家信息，靠这个自动归类）。
     * 依次尝试：国旗 emoji → 中文国名 → 两字母代码（HK-01、[US]、JP01…）。
     * 猜不出来返回空字符串。
     */
    public static String detect(String s) {
        if (s == null || s.length() == 0) return "";
        // ① 国旗 emoji（两个区域指示符）
        for (int i = 0; i + 1 < s.length(); ) {
            int c1 = s.codePointAt(i);
            int len1 = Character.charCount(c1);
            int j = i + len1;
            if (j < s.length()) {
                int c2 = s.codePointAt(j);
                if (c1 >= 0x1F1E6 && c1 <= 0x1F1FF && c2 >= 0x1F1E6 && c2 <= 0x1F1FF) {
                    String cc = "" + (char) ('A' + (c1 - 0x1F1E6)) + (char) ('A' + (c2 - 0x1F1E6));
                    if (NAMES.containsKey(cc)) return cc;
                }
            }
            i += len1;
        }
        // ② 中文国名（香港/美国/日本…）
        for (Map.Entry<String, String> e : NAMES.entrySet()) {
            String name = e.getValue();
            if (name.length() >= 2 && s.contains(name)) return e.getKey();
        }
        // ③ 两字母代码
        java.util.regex.Matcher m = java.util.regex.Pattern
                .compile("(?i)(?:^|[\\s\\[【(（_-])([a-z]{2})(?=[\\s\\]】)）_-]|\\d|$)")
                .matcher(s);
        while (m.find()) {
            String cc = m.group(1).toUpperCase(java.util.Locale.ROOT);
            if (NAMES.containsKey(cc) && !"**".equals(cc) && !"ZZ".equals(cc)) return cc;
        }
        return "";
    }

    /** 修掉"UTF-8 被按 latin-1 解码"造成的乱码（emoji/汉字都会变成乱码）。 */
    static String fixUtf8(String s) {
        if (s == null || s.length() == 0) return "";
        boolean needFix = true;
        for (int i = 0; i < s.length(); i++) {
            if (s.charAt(i) > 0xFF) { needFix = false; break; }   // 已经是正常的多字节字符
        }
        if (!needFix) return s;
        try {
            String t = new String(s.getBytes("ISO-8859-1"), "UTF-8");
            if (t.contains("\uFFFD")) return s;
            return t;
        } catch (Throwable t) {
            return s;
        }
    }

    /**
     * 从节点链接里判断国家。规则：
     * 1) 取 # 后面的名字，修掉乱码
     * 2) 形如 "🇨🇳_CN_中国->🇺🇸_US_美国" 的中转节点，按**出口**（箭头后面）算
     * 3) 还识别不出来就看整条链接
     */
    public static String detectFromUri(String uri) {
        try {
            String frag = "";
            int hash = uri.indexOf('#');
            if (hash > 0 && hash + 1 < uri.length()) {
                frag = Link.decode(uri.substring(hash + 1));
                frag = fixUtf8(frag);
                int arrow = frag.lastIndexOf("->");
                int skip = 2;
                if (arrow < 0) {
                    arrow = frag.lastIndexOf("→");
                    skip = 1;
                }
                if (arrow >= 0 && arrow + skip < frag.length()) {
                    String cc = detect(frag.substring(arrow + skip));
                    if (cc.length() == 2) return cc;
                }
                String cc = detect(frag);
                if (cc.length() == 2) return cc;
            }
            // 不再扫描整条链接：ss/vmess 主体是 base64，里面的 "…/it/" 会被误判成意大利
            // （曾一次冒出 132 个"意大利"）。名字里没国家就归为未知，交给「识别未识别地区」按 IP 归类。
            return "";
        } catch (Throwable t) {
            return "";
        }
    }

    /** 统一判断"未识别地区"：ZZ / ** / 非两位国家码 都算。 */
    public static boolean isUnknown(String cc) {
        if (cc == null) return true;
        String v = cc.trim().toUpperCase(java.util.Locale.ROOT);
        return v.length() != 2 || "ZZ".equals(v) || "**".equals(v);
    }

    public static String displayName(String cc) {
        if (cc == null || cc.length() == 0) return "";
        String n = NAMES.get(cc.toUpperCase(Locale.ROOT));
        return n == null ? cc : n;
    }

    public final String cc;
    public final String name;
    public final List<Node> nodes;

    public Country(String cc, List<Node> nodes) {
        this.cc = cc == null ? "ZZ" : cc.toUpperCase(Locale.ROOT);
        String n = NAMES.get(this.cc);
        this.name = n == null ? this.cc : n;
        this.nodes = nodes;
    }

    public String flag() {
        if (nodes.size() > 0) return nodes.get(0).flag();
        return "\uD83C\uDF10";
    }

    /** 已测出延迟里最小的那个；没有就返回 -1。 */
    public int bestLatency() {
        int best = -1;
        for (Node n : nodes) {
            if (n.latency > 0 && (best < 0 || n.latency < best)) best = n.latency;
        }
        return best;
    }

    public int measuredCount() {
        int c = 0;
        for (Node n : nodes) if (n.latency > 0) c++;
        return c;
    }

    /** 只在该国"已显示"的节点里挑最快的（跳过已隐藏的）。 */
    public Node fastestVisible() {
        Node best = null;
        for (Node n : nodes) {
            if (n.hidden) continue;
            if (n.latency > 0 && (best == null || n.latency < best.latency)) best = n;
        }
        return best;
    }

    public Node fastestMeasured() {
        Node best = null;
        for (Node n : nodes) {
            if (n.latency > 0 && (best == null || n.latency < best.latency)) best = n;
        }
        return best;
    }

    public boolean isCurrent() {
        Node cur = TunnelService.currentNode();
        if (cur == null || !TunnelService.isRunning()) return false;
        for (Node n : nodes) if (n.uri.equals(cur.uri)) return true;
        return false;
    }

    /** 按延迟升序（没测出的排后面），让最快的排在子列表第一行。 */
    public void sortByLatency() {
        Collections.sort(nodes, new Comparator<Node>() {
            @Override
            public int compare(Node a, Node b) {
                boolean am = a.latency > 0, bm = b.latency > 0;
                if (am != bm) return am ? -1 : 1;
                if (am) return Integer.compare(a.latency, b.latency);
                return 0;
            }
        });
    }

    /** 从这一组里取样做快速测速时用的候选（均匀取样，最多 limit 个）。 */
    public List<Node> sample(int limit) {
        List<Node> out = new ArrayList<Node>();
        if (nodes.size() <= limit) {
            out.addAll(nodes);
            return out;
        }
        double step = (double) nodes.size() / limit;
        for (int i = 0; i < limit; i++) {
            out.add(nodes.get((int) (i * step)));
        }
        return out;
    }
}
