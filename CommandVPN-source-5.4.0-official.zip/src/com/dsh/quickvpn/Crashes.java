package com.dsh.quickvpn;

import android.content.Context;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;

/** 收集上次异常退出的证据：sing-box 的 Go panic 报告 + 我们自己的日志尾巴。 */
public class Crashes {

    private static String tail(File f, int max) {
        if (f == null || !f.isFile() || f.length() == 0) return null;
        try {
            long len = f.length();
            long skip = Math.max(0, len - max);
            FileInputStream in = new FileInputStream(f);
            try {
                long skipped = 0;
                while (skipped < skip) {
                    long s = in.skip(skip - skipped);
                    if (s <= 0) break;
                    skipped += s;
                }
                ByteArrayOutputStream bos = new ByteArrayOutputStream();
                byte[] buf = new byte[8192];
                int n;
                while ((n = in.read(buf)) > 0) bos.write(buf, 0, n);
                String text = new String(bos.toByteArray(), "UTF-8");
                return text.trim().length() == 0 ? null : text;
            } finally {
                in.close();
            }
        } catch (Throwable t) {
            return null;
        }
    }

    /** sing-box 内核的崩溃报告（Go panic 会写到这里）。 */
    public static String coreCrash(Context ctx) {
        String text = tail(new File(ctx.getCacheDir(), "CrashReport-CommandVPN.log"), 12000);
        if (text == null) text = tail(new File(ctx.getCacheDir(), "CrashReport-.log"), 12000);
        if (text != null) return text;
        File dir = new File(ctx.getCacheDir(), "crash_reports");
        File[] files = dir.listFiles();
        if (files == null || files.length == 0) return null;
        File newest = null;
        for (File f : files) {
            if (newest == null || f.lastModified() > newest.lastModified()) newest = f;
        }
        return tail(newest, 12000);
    }

    /** 我们的日志文件尾巴。 */
    public static String ourLog(Context ctx) {
        return tail(new File(ctx.getFilesDir(), "quickvpn.log"), 8000);
    }

    public static boolean hasCrash(Context ctx) {
        String c = coreCrash(ctx);
        if (c == null) return false;
        // 只把真正的 panic / fatal 当成崩溃
        String lower = c.toLowerCase();
        return lower.contains("panic") || lower.contains("fatal") || lower.contains("sigsegv")
                || lower.contains("sigabrt") || lower.contains("goroutine");
    }

    public static void clear(Context ctx) {
        try {
            new File(ctx.getCacheDir(), "CrashReport-CommandVPN.log").delete();
            File dir = new File(ctx.getCacheDir(), "crash_reports");
            File[] files = dir.listFiles();
            if (files != null) for (File f : files) f.delete();
        } catch (Throwable ignored) {
        }
    }
}
