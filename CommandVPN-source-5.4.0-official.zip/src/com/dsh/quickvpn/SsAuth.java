package com.dsh.quickvpn;

import java.util.Base64;

/** shadowsocks 的 userinfo 解析（SIP002）。 */
public class SsAuth {

    public static final String[] SUPPORTED = {
            "2022-blake3-aes-128-gcm", "2022-blake3-aes-256-gcm", "2022-blake3-chacha20-poly1305",
            "aes-128-gcm", "aes-192-gcm", "aes-256-gcm",
            "chacha20-ietf-poly1305", "xchacha20-ietf-poly1305", "none"
    };

    public static boolean isSupported(String method) {
        if (method == null) return false;
        for (String m : SUPPORTED) if (m.equals(method)) return true;
        return false;
    }

    /** 返回 {method, password} */
    public static String[] split(Link link) {
        String user = link.userInfo;
        String method = "", password = "";
        if (user.contains(":")) {
            int c = user.indexOf(':');
            method = user.substring(0, c);
            password = user.substring(c + 1);
        } else {
            String dec = b64(user);
            int c = dec.indexOf(':');
            if (c > 0) {
                method = dec.substring(0, c);
                password = dec.substring(c + 1);
            }
        }
        return new String[]{Link.decode(method), Link.decode(password)};
    }

    public static String method(Link link) {
        if (link.userInfo.contains(":")) {
            return link.userInfo.substring(0, link.userInfo.indexOf(':'));
        }
        String dec = b64(link.userInfo);
        int c = dec.indexOf(':');
        return c > 0 ? dec.substring(0, c) : "";
    }

    public static String b64(String s) {
        if (s == null) return "";
        String t = s.replace('-', '+').replace('_', '/').trim();
        while (t.length() % 4 != 0) t = t + "=";
        try {
            byte[] raw = Base64.getDecoder().decode(t);
            return new String(raw, "UTF-8");
        } catch (Exception e) {
            return s;
        }
    }
}
