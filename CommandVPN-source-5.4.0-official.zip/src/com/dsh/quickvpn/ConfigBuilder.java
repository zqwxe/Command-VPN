package com.dsh.quickvpn;

import org.json.JSONArray;
import org.json.JSONObject;

/** 把分享链接翻译成 sing-box 配置。 */
public class ConfigBuilder {

    public static boolean canBuild(Node n) {
        return n != null && ("vless".equals(n.protocol) || "vmess".equals(n.protocol)
                || "trojan".equals(n.protocol) || "hysteria2".equals(n.protocol)
                || "shadowsocks".equals(n.protocol));
    }

    /** 极简配置：只留 tun + 单个节点 + 直连兜底，用来判断"是平台/tun 起不来"还是"某段配置有问题"。 */
    public static String buildMinimal(Node node) throws Exception {
        return buildMinimal(node, 0, null);
    }

    /**
     * 降级用的配置：保留"必须能用"的部分（DNS 走代理、DNS 劫持、sniff），
     * 去掉分流规则和 block 出站。用来在完整配置起不来时还能正常上网，
     * 同时把可疑的部分（.cn 直连规则等）排除掉。
     */
    public static String buildMinimal(Node node, int clashPort, String secret) throws Exception {
        return buildMinimal(node, clashPort, secret, false);
    }

    public static String buildMinimal(Node node, int clashPort, String secret, boolean boost) throws Exception {
        return buildMinimal(node, clashPort, secret, boost, 0);
    }

    /** httpPort > 0 时再加一个本地 http 入口，用来在连接后问 Google 出口地区。 */
    public static String buildMinimal(Node node, int clashPort, String secret, boolean boost,
                                      int httpPort) throws Exception {
        JSONObject root = new JSONObject();
        root.put("log", new JSONObject().put("level", clashPort > 0 ? "debug" : "warn").put("timestamp", true));
        if (clashPort > 0) {
            JSONObject api = new JSONObject();
            api.put("external_controller", "127.0.0.1:" + clashPort);
            if (secret != null) api.put("secret", secret);
            root.put("experimental", new JSONObject().put("clash_api", api));
        }

        JSONObject dns = new JSONObject();
        dns.put("servers", new JSONArray().put(
                new JSONObject().put("tag", "dns-remote").put("type", "https").put("server", "8.8.8.8").put("detour", "proxy")));
        dns.put("final", "dns-remote");
        dns.put("strategy", "ipv4_only");

        root.put("dns", dns);

        JSONObject tun = new JSONObject();
        tun.put("type", "tun");
        tun.put("tag", "tun-in");
        tun.put("address", new JSONArray().put("172.19.0.1/30").put("fdfe:dcba:9876::1/126"));
        // 下载优化：换用内核自带的 TCP 栈（system），大文件吞吐明显好于 gvisor；
        // 普通模式用 gvisor（更稳，兼容性更好）
        tun.put("stack", "gvisor");   // system 栈在部分机型上完全不通网，统一用 gvisor
        tun.put("mtu", 1400);   // 9000 在部分机型/链路上会让大文件传到一半卡住
        tun.put("auto_route", true);
        tun.put("strict_route", false);
        JSONArray inbounds = new JSONArray().put(tun);
        if (httpPort > 0) {
            inbounds.put(new JSONObject().put("type", "http").put("tag", "http-in")
                    .put("listen", "127.0.0.1").put("listen_port", httpPort));
        }
        root.put("inbounds", inbounds);

        JSONArray outbounds = new JSONArray();
        JSONObject proxy = outbound(node);
        proxy.put("tag", "proxy");
        outbounds.put(proxy);
        root.put("outbounds", outbounds);

        JSONObject route = new JSONObject();
        JSONArray rules = new JSONArray();
        rules.put(new JSONObject().put("action", "sniff"));
        rules.put(new JSONObject().put("protocol", "dns").put("action", "hijack-dns"));
        // 拒绝 QUIC（UDP/443）：4.9.6 用这套配置时 Play 下载是正常的
        rules.put(new JSONObject().put("network", new JSONArray().put("udp"))
                .put("port", new JSONArray().put(443)).put("action", "reject"));
        route.put("rules", rules);
        route.put("final", "proxy");
        route.put("auto_detect_interface", false);
        route.put("default_domain_resolver", "dns-remote");
        root.put("route", route);
        return root.toString();
    }

    public static String build(Node node) throws Exception {
        return build(node, 0, null);
    }

    /**
     * 把多个候选节点做进同一份配置：每个节点一个出站 + 一个 selector 作为最终出站。
     * 这样内核起来之后，可以用本地 clash_api 逐个"真连一次"来挑活的节点，
     * 也能秒切节点而不用重启内核。
     */
    /**
     * 「体检」用的配置：没有 tun 入站，只有一堆出站 + 本地 clash_api。
     * 用来让内核逐个节点真的连一次外网，从而判断哪些节点是活的。
     */
    public static String buildScanner(java.util.List<Node> nodes, int clashPort, String secret) throws Exception {
        return buildScanner(nodes, clashPort, secret, 0);
    }

    /** httpPort > 0 时加一个本地 http 代理入口，并提供一个可切换的 selector，用于逐个节点查 Google 地区。 */
    public static String buildScanner(java.util.List<Node> nodes, int clashPort, String secret,
                                      int httpPort) throws Exception {
        JSONObject root = new JSONObject();
        root.put("log", new JSONObject().put("level", "warn").put("timestamp", true));
        JSONObject api = new JSONObject();
        api.put("external_controller", "127.0.0.1:" + clashPort);
        if (secret != null) api.put("secret", secret);
        root.put("experimental", new JSONObject().put("clash_api", api));
        JSONArray inbounds = new JSONArray();
        if (httpPort > 0) {
            JSONObject http = new JSONObject();
            http.put("type", "http");
            http.put("tag", "http-in");
            http.put("listen", "127.0.0.1");
            http.put("listen_port", httpPort);
            inbounds.put(http);
        }
        root.put("inbounds", inbounds);
        JSONArray outbounds = new JSONArray();
        JSONArray members = new JSONArray();
        for (int i = 0; i < nodes.size(); i++) {
            JSONObject o = outbound(nodes.get(i));
            o.put("tag", "node-" + i);
            outbounds.put(o);
            members.put("node-" + i);
        }
        outbounds.put(new JSONObject().put("type", "direct").put("tag", "direct"));
        // 扫描配置需要能解析域名（Google 地区查询要走域名），否则 https 请求直接失败
        JSONObject dns = new JSONObject();
        dns.put("servers", new JSONArray().put(
                new JSONObject().put("tag", "dns-scan").put("type", "udp").put("server", "223.5.5.5")));
        dns.put("final", "dns-scan");
        dns.put("strategy", "ipv4_only");
        root.put("dns", dns);
        JSONObject route = new JSONObject();
        if (httpPort > 0 && members.length() > 0) {
            JSONObject selector = new JSONObject();
            selector.put("type", "selector");
            selector.put("tag", "proxy");
            selector.put("outbounds", members);
            selector.put("default", "node-0");
            outbounds.put(selector);
            route.put("final", "proxy");
        } else {
            route.put("final", "direct");
        }
        root.put("outbounds", outbounds);
        root.put("route", route);
        return root.toString();
    }

    public static String buildPool(java.util.List<Node> nodes, int clashPort, String secret) throws Exception {
        return buildPool(nodes, clashPort, secret, false);
    }

    public static String buildPool(java.util.List<Node> nodes, int clashPort, String secret, boolean boost) throws Exception {
        return buildPool(nodes, clashPort, secret, boost, 0);
    }

    public static String buildPool(java.util.List<Node> nodes, int clashPort, String secret, boolean boost,
                                   int httpPort) throws Exception {
        JSONObject root = new JSONObject(build(nodes.get(0), clashPort, secret, boost));
        JSONArray outbounds = new JSONArray();
        JSONArray members = new JSONArray();
        for (int i = 0; i < nodes.size(); i++) {
            JSONObject o = outbound(nodes.get(i));
            o.put("tag", "node-" + i);
            outbounds.put(o);
            members.put("node-" + i);
        }
        outbounds.put(new JSONObject().put("type", "direct").put("tag", "direct"));
        JSONObject selector = new JSONObject();
        selector.put("type", "selector");
        selector.put("tag", "proxy");
        selector.put("outbounds", members);
        selector.put("default", "node-0");
        outbounds.put(selector);
        root.put("outbounds", outbounds);
        if (httpPort > 0) {
            JSONArray inb = root.optJSONArray("inbounds");
            if (inb == null) {
                inb = new JSONArray();
                root.put("inbounds", inb);
            }
            inb.put(new JSONObject().put("type", "http").put("tag", "http-in")
                    .put("listen", "127.0.0.1").put("listen_port", httpPort));
        }
        return root.toString();
    }

    /**
     * @param clashPort  本地管理端口（0 = 不启用），用来做「连上之后节点到底通不通」的自检
     * @param secret     clash_api 的密钥
     */
    public static String build(Node node, int clashPort, String secret) throws Exception {
        return build(node, clashPort, secret, false);
    }

    /** @param boost 下载优化模式：更小 MTU + 拒绝全部 UDP。 */
    public static String build(Node node, int clashPort, String secret, boolean boost) throws Exception {
        JSONObject root = new JSONObject();

        JSONObject log = new JSONObject();
        log.put("level", clashPort > 0 ? "debug" : "warn");
        log.put("timestamp", true);
        root.put("log", log);

        if (clashPort > 0) {
            JSONObject api = new JSONObject();
            api.put("external_controller", "127.0.0.1:" + clashPort);
            if (secret != null) api.put("secret", secret);
            root.put("experimental", new JSONObject().put("clash_api", api));
        }

        JSONObject dns = new JSONObject();
        JSONArray servers = new JSONArray();
        // 主用：Google 的 DoH，经代理；很多节点到 1.1.1.1 的 TLS 会被干扰，
        // 换成 dns.google 后 Play 这类 Google 服务的解析明显更稳
        servers.put(new JSONObject().put("tag", "dns-remote").put("type", "https")
                .put("server", "8.8.8.8").put("detour", "proxy"));
        // 注意：不能再加 detour=direct 的 DNS 服务器 ——
        // sing-box 1.14 会报 "detour to an empty direct outbound makes no sense"，
        // 整个配置直接起不来（表现为所有节点都"连不上"）
        dns.put("servers", servers);
        dns.put("final", "dns-remote");
        dns.put("strategy", "ipv4_only");


        root.put("dns", dns);

        JSONObject tun = new JSONObject();
        tun.put("type", "tun");
        tun.put("tag", "tun-in");
        tun.put("address", new JSONArray().put("172.19.0.1/30").put("fdfe:dcba:9876::1/126"));
        tun.put("stack", "gvisor");   // system 栈在部分机型上完全不通网，统一用 gvisor
        tun.put("mtu", 1400);
        tun.put("auto_route", true);
        tun.put("strict_route", false);
        root.put("inbounds", new JSONArray().put(tun));

        JSONArray outbounds = new JSONArray();
        JSONObject proxy = outbound(node);
        proxy.put("tag", "proxy");
        outbounds.put(proxy);
        outbounds.put(new JSONObject().put("type", "direct").put("tag", "direct"));
        outbounds.put(new JSONObject().put("type", "block").put("tag", "block"));
        root.put("outbounds", outbounds);

        JSONObject route = new JSONObject();
        JSONArray rules = new JSONArray();
        rules.put(new JSONObject().put("action", "sniff"));
        rules.put(new JSONObject().put("protocol", "dns").put("action", "hijack-dns"));
        rules.put(new JSONObject().put("ip_is_private", true).put("action", "route").put("outbound", "direct"));
        // 注意：不能把所有 .cn 都直连！Google Play 会访问 services.googleapis.cn，
        // 直连在国内必然超时，表现就是下载永远「等待中」
        rules.put(new JSONObject()
                .put("domain_suffix", new JSONArray()
                        .put(".googleapis.cn").put(".google.cn").put(".gstatic.cn").put(".googleusercontent.cn"))
                .put("action", "route").put("outbound", "proxy"));
        rules.put(new JSONObject().put("domain_suffix", new JSONArray().put(".cn")).put("action", "route").put("outbound", "direct"));
        // 不拦 QUIC（UDP/443）：实测拦了反而让 Play 卡在「等待中」，
        // 放开后与常见客户端（v2rayNG/Clash）行为一致
        // 拒绝 QUIC（UDP/443）：与 4.9.6（当时 Play 下载正常）保持一致
        rules.put(new JSONObject().put("network", new JSONArray().put("udp"))
                .put("port", new JSONArray().put(443)).put("action", "reject"));
        route.put("rules", rules);
        route.put("final", "proxy");
        route.put("auto_detect_interface", false);
        route.put("default_domain_resolver", "dns-remote");
        root.put("route", route);

        return root.toString();
    }

    private static JSONObject outbound(Node n) throws Exception {
        if ("vless".equals(n.protocol)) return vless(n);
        if ("vmess".equals(n.protocol)) return vmess(n);
        if ("trojan".equals(n.protocol)) return trojan(n);
        if ("hysteria2".equals(n.protocol)) return hysteria2(n);
        if ("shadowsocks".equals(n.protocol)) return shadowsocks(n);
        throw new IllegalArgumentException("不支持的协议: " + n.protocol);
    }

    private static JSONObject vless(Node n) throws Exception {
        Link l = n.link;
        JSONObject o = base("vless", n, l);
        o.put("uuid", l.userInfo);
        String flow = l.q("flow");
        if (flow.length() > 0) {
            String f = flow.trim();
            if (f.contains("vision")) f = "xtls-rprx-vision";   // -udp443 之类的变体内核不认
            else if (!"xtls-rprx-vision".equals(f)) f = "";      // 其它（xtls-rprx-direct 等）一律丢掉
            if (f.length() > 0) o.put("flow", f);
        }
        String security = l.q("security");
        if ("tls".equals(security) || "reality".equals(security) || "xtls".equals(security)) {
            o.put("tls", tls(l, "reality".equals(security)));
        }
        JSONObject tr = transport(l);
        if (tr != null) o.put("transport", tr);
        return o;
    }

    private static JSONObject vmess(Node n) throws Exception {
        String raw = n.uri.substring("vmess://".length());
        int hash = raw.indexOf('#');
        if (hash >= 0) raw = raw.substring(0, hash);
        JSONObject v = new JSONObject(SsAuth.b64(raw));
        JSONObject o = new JSONObject();
        o.put("type", "vmess");
        o.put("server", serverOf(n, n.link));
        o.put("server_port", v.optInt("port", n.port));
        o.put("uuid", v.optString("id"));
        String scy = v.optString("scy", "auto");
        scy = sanitizeVmessSecurity(scy);
        o.put("security", scy);
        int aid = v.optInt("aid", 0);
        if (aid != 0) o.put("alter_id", aid);

        String tlsFlag = v.optString("tls", "");
        String net = v.optString("net", "tcp");
        String host = v.optString("host", "");
        String path = v.optString("path", "");
        if ("tls".equals(tlsFlag)) {
            JSONObject t = new JSONObject();
            t.put("enabled", true);
            String sni = v.optString("sni", "");
            t.put("server_name", sni.length() > 0 ? sni : host);
            t.put("insecure", v.optBoolean("allowInsecure", false) || v.optBoolean("skip-cert-verify", false));
            String alpn = v.optString("alpn", "");
            if (alpn.length() > 0) t.put("alpn", splitAlpn(alpn));
            String fp = sanitizeFp(v.optString("fp", ""));
            if (fp.length() > 0) t.put("utls", new JSONObject().put("enabled", true).put("fingerprint", fp));
            o.put("tls", t);
        }
        JSONObject t = transport(net, host, path, v.optString("serviceName", ""));
        if (t != null) o.put("transport", t);
        return o;
    }

    private static JSONObject trojan(Node n) throws Exception {
        Link l = n.link;
        JSONObject o = base("trojan", n, l);
        o.put("password", Link.decode(l.userInfo));
        if (!"none".equals(l.q("security"))) {
            JSONObject t = new JSONObject();
            t.put("enabled", true);
            String sni = l.q("sni", "peer");
            t.put("server_name", sni.length() > 0 ? sni : l.q("host"));
            t.put("insecure", l.flag("allowInsecure", "insecure", "allow_insecure"));
            String alpn = l.q("alpn");
            if (alpn.length() > 0) t.put("alpn", splitAlpn(alpn));
            o.put("tls", t);
        }
        JSONObject tr = transport(l);
        if (tr != null) o.put("transport", tr);
        return o;
    }

    private static JSONObject hysteria2(Node n) throws Exception {
        Link l = n.link;
        JSONObject o = base("hysteria2", n, l);
        o.put("password", Link.decode(l.userInfo));
        JSONObject t = new JSONObject();
        t.put("enabled", true);
        String sni = l.q("sni", "peer");
        t.put("server_name", sni.length() > 0 ? sni : l.host);
        t.put("insecure", l.flag("insecure", "allowInsecure"));
        String alpn = l.q("alpn");
        if (alpn.length() > 0) t.put("alpn", splitAlpn(alpn));
        o.put("tls", t);
        String obfs = l.q("obfs");
        if (obfs.length() > 0) {
            o.put("obfs", new JSONObject().put("type", obfs).put("password", l.q("obfs-password", "obfs_password")));
        }
        return o;
    }

    private static JSONObject shadowsocks(Node n) throws Exception {
        String[] mp = SsAuth.split(n.link);
        JSONObject o = base("shadowsocks", n, n.link);
        o.put("method", mp[0]);
        o.put("password", mp[1]);
        return o;
    }

    /* ---------------- 工具 ---------------- */

    /** 出站连接用的服务器地址：优先用本地解析出来的 IP（避免内核 DNS 死循环）。 */
    private static String serverOf(Node n, Link l) {
        if (n != null && n.resolvedHost != null && n.resolvedHost.length() > 0) return n.resolvedHost;
        return l != null && l.host != null && l.host.length() > 0 ? l.host : (n == null ? "" : n.host);
    }

    private static JSONObject base(String type, Node n, Link l) throws Exception {
        JSONObject o = new JSONObject();
        o.put("type", type);
        o.put("server", serverOf(n, l));
        o.put("server_port", l.port);
        return o;
    }

    private static JSONObject tls(Link l, boolean reality) throws Exception {
        JSONObject t = new JSONObject();
        t.put("enabled", true);
        String sni = l.q("sni", "peer", "host");
        if (sni.length() == 0) sni = l.host;
        t.put("server_name", sni);
        t.put("insecure", l.flag("allowInsecure", "insecure", "allow_insecure"));
        String alpn = l.q("alpn");
        if (alpn.length() > 0) t.put("alpn", splitAlpn(alpn));
        String fp = l.q("fp");
        if (reality) {
            JSONObject r = new JSONObject();
            r.put("enabled", true);
            r.put("public_key", l.q("pbk", "publicKey"));
            String sid = l.q("sid", "shortId");
            if (sid.length() > 0) r.put("short_id", sid);
            t.put("reality", r);
            String safe = sanitizeFp(fp);
            t.put("utls", new JSONObject().put("enabled", true)
                    .put("fingerprint", safe.length() > 0 ? safe : "chrome"));
        } else {
            String safe = sanitizeFp(fp);
            if (safe.length() > 0) {
                t.put("utls", new JSONObject().put("enabled", true).put("fingerprint", safe));
            }
        }
        return t;
    }

    /** vmess 的加密方式：来源里常见 "null"/乱填的值会让整份配置起不来。 */
    static String sanitizeVmessSecurity(String scy) {
        if (scy == null) return "auto";
        String v = scy.trim().toLowerCase(java.util.Locale.ROOT);
        if (v.length() == 0 || "null".equals(v) || "undefined".equals(v)) return "auto";
        if (v.equals("auto") || v.equals("aes-128-gcm") || v.equals("chacha20-poly1305")
                || v.equals("none") || v.equals("zero")) return v;
        return "auto";
    }

    /**
     * sing-box 只认这几种 uTLS 指纹；来源里常见的 "null"/"none"/乱填的值
     * 会让整份配置起不来（日志：unknown uTLS fingerprint: null），
     * 进而导致体检时整批节点被拆半重试、看起来"卡住"。
     */
    static String sanitizeFp(String fp) {
        if (fp == null) return "";
        String v = fp.trim().toLowerCase(java.util.Locale.ROOT);
        if (v.length() == 0 || "null".equals(v) || "none".equals(v) || "0".equals(v)
                || "false".equals(v) || "undefined".equals(v)) return "";
        if (v.equals("chrome") || v.equals("firefox") || v.equals("edge") || v.equals("safari")
                || v.equals("360") || v.equals("qq") || v.equals("ios") || v.equals("android")
                || v.equals("random") || v.equals("randomized")) return v;
        return "";   // 未知指纹一律丢弃，交给默认值
    }

    private static JSONArray splitAlpn(String alpn) {
        JSONArray a = new JSONArray();
        for (String s : alpn.split(",")) if (s.trim().length() > 0) a.put(s.trim());
        return a;
    }

    private static JSONObject transport(Link l) throws Exception {
        return transport(l.q("type", "headerType"), l.q("host"), l.q("path"), l.q("serviceName"));
    }

    private static JSONObject transport(String net, String host, String path, String serviceName) throws Exception {
        if (net == null || net.length() == 0) net = "tcp";
        if ("ws".equals(net) || "websocket".equals(net)) {
            JSONObject t = new JSONObject();
            t.put("type", "ws");
            t.put("path", path.length() > 0 ? path : "/");
            if (host.length() > 0) t.put("headers", new JSONObject().put("Host", host));
            return t;
        }
        if ("grpc".equals(net)) {
            JSONObject t = new JSONObject();
            t.put("type", "grpc");
            String sn = serviceName.length() > 0 ? serviceName : path;
            if (sn.startsWith("/")) sn = sn.substring(1);
            if (sn.length() > 0) t.put("service_name", sn);
            return t;
        }
        if ("http".equals(net) || "h2".equals(net) || "xhttp".equals(net) || "splithttp".equals(net)) {
            JSONObject t = new JSONObject();
            t.put("type", "http");
            if (host.length() > 0) t.put("host", new JSONArray().put(host));
            if (path.length() > 0) t.put("path", path);
            return t;
        }
        return null;
    }
}
