package com.dsh.quickvpn;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/** 开机自启 / 应用更新 / 时间或时区变化：重新安排自动翻新。 */
public class BootReceiver extends BroadcastReceiver {

    @Override
    public void onReceive(Context ctx, Intent intent) {
        try {
            String a = intent == null ? "" : intent.getAction();
            boolean boot = Intent.ACTION_BOOT_COMPLETED.equals(a)
                    || "android.intent.action.QUICKBOOT_POWERON".equals(a)
                    || "android.intent.action.QUICKBOOT_POWEROFF".equals(a);
            boolean replaced = Intent.ACTION_MY_PACKAGE_REPLACED.equals(a);
            boolean timeChanged = Intent.ACTION_TIME_CHANGED.equals(a)
                    || Intent.ACTION_TIMEZONE_CHANGED.equals(a);
            if (!boot && !replaced && !timeChanged) return;
            Log2.init(ctx);
            if (!AutoRefresh.enabled(ctx)) {
                Log2.i("开机/更新/时间变化：自动翻新未开启，不排闹钟");
                AutoRefresh.cancel(ctx);
                return;
            }
            if (boot && !AutoRefresh.bootEnabled(ctx)) {
                Log2.i("开机：开机自启开关是关的，按设置不重排（打开 App 时会自己排上）");
                return;
            }
            Log2.i((boot ? "开机自启：重新安排自动翻新"
                    : replaced ? "应用更新：重新安排自动翻新"
                    : "时间/时区变化：重新安排自动翻新"));
            AutoRefresh.schedule(ctx);
        } catch (Throwable t) {
            Log2.w("开机/更新/时间变化重排失败：" + t);
        }
    }
}
