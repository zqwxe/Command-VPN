package com.dsh.quickvpn;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/**
 * 后台保活心跳：体检/翻新期间每 4 分钟唤醒一次进程。
 * 手机把后台 App「速冻」后，普通线程会停住；闹钟广播仍能唤醒进程继续跑。
 */
public class KeepAliveReceiver extends BroadcastReceiver {

    public static final String ACTION_KEEPALIVE = "com.dsh.quickvpn.KEEPALIVE";

    @Override
    public void onReceive(Context ctx, Intent intent) {
        // 5.3.35 起不再使用"定时唤醒"：收到旧闹钟只做撤销，不再启动服务
        try {
            Log2.init(ctx);
            TunnelService.cancelKeepAlive(ctx);
            Log2.i("保活心跳已停用：收到旧闹钟，已撤销");
        } catch (Throwable ignored) {
        }
    }
}
