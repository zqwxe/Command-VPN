package com.dsh.quickvpn;

import java.util.List;

import io.nekohasekai.libbox.StringIterator;

/** 把 Java 列表当作 libbox.StringIterator 传给内核。 */
public class StringArray implements StringIterator {
    private final List<String> list;
    private int index = 0;

    public StringArray(List<String> list) {
        this.list = list;
    }

    @Override
    public boolean hasNext() {
        return index < list.size();
    }

    @Override
    public int len() {
        return list.size();
    }

    @Override
    public String next() {
        return list.get(index++);
    }
}
