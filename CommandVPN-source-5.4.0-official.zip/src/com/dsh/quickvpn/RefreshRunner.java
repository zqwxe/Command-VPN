package com.dsh.quickvpn;

import android.content.Context;
import android.content.Intent;

/**
 * 翻新节点的执行体：多个公开源 → 解析 → 只导入软件里没有的 → 广播进度。
 * 放在独立类里，前台（Activity）与后台（AlarmManager 触发的前台服务）共用同一份状态，
 * 这样"后台在翻新时用户打开 App"能直接看到同一份进度，而不是另起一份任务。
 */
public class RefreshRunner {

    public static final String ACTION_REFRESH_STATE = "com.dsh.quickvpn.REFRESH_STATE";

    /** {名称, 地址, 国家提示(可空)}；国家提示非空时该源导入的节点直接按此国家归类。 */
    public static final String[][] SOURCES = {
            {"Au1rxx 美国", "https://raw.githubusercontent.com/Au1rxx/free-vpn-subscriptions/main/output/by-country/v2ray-base64-US.txt", "US"},
            {"Au1rxx 全量", "https://raw.githubusercontent.com/Au1rxx/free-vpn-subscriptions/main/output/v2ray-base64.txt", ""},
            {"mahdibland", "https://raw.githubusercontent.com/mahdibland/V2RayAggregator/master/sub/sub_merge_base64.txt", ""},
            {"peasoft", "https://raw.githubusercontent.com/peasoft/NoMoreWalls/master/list.txt", ""},
            {"ermaozi", "https://raw.githubusercontent.com/ermaozi/get_subscribe/main/subscribe/v2ray.txt", ""},
    };
    public static final int MAX_IMPORT = 3000;
    /** 本次导入上限（3000 或"不限"）。 */
    static volatile int limit = MAX_IMPORT;

    // ---- 共享状态（供 Activity 随时读取）----
    static volatile boolean running = false;
    static volatile boolean cancelled = false;
    static volatile int totalSources = 1;
    static volatile int curSource = 0;      // 0-based
    static volatile int curPct = 0;         // 当前源解析百分比
    static volatile int imported = 0;
    static volatile String stage = "";
    /** 当前来源的细状态：下载中 / 解析 X% / 失败跳过（给界面显示，避免一直 0%）。 */
    static volatile String stageDetail = "";
    /** 当前源"写入节点"阶段的进度（给界面第二条进度条用）。 */
    public static volatile int writeDone = 0;
    public static volatile int writeTotal = 0;
    static volatile long startedAt = 0;
    static volatile long finishedAt = 0;
    static volatile int okSources = 0;      // 本次成功下载的源数
    static volatile android.content.Context currentCtx = null;
    /** 本次实际使用的源（按优先级从节点源页读取）。 */
    static volatile java.util.List<String[]> currentSources = null;

    private static android.os.PowerManager.WakeLock wakeLock = null;

    private static void acquireWakeLock(Context ctx) {
        try {
            android.os.PowerManager pm = (android.os.PowerManager) ctx.getSystemService(Context.POWER_SERVICE);
            if (pm == null) return;
            releaseWakeLock();
            wakeLock = pm.newWakeLock(android.os.PowerManager.PARTIAL_WAKE_LOCK, "CommandVPN:refresh");
            wakeLock.setReferenceCounted(false);
            wakeLock.acquire(15 * 60 * 1000L);     // 最长 15 分钟，正常流程远用不到
            Log2.i("翻新：已持有 CPU 唤醒锁（防止夜里被系统冻住）");
        } catch (Throwable t) {
            Log2.w("获取唤醒锁失败：" + t);
        }
    }

    private static void releaseWakeLock() {
        try {
            if (wakeLock != null && wakeLock.isHeld()) wakeLock.release();
        } catch (Throwable ignored) {
        }
        wakeLock = null;
    }

    public static boolean isRunning() { return running; }
    public static void cancel() { cancelled = true; }

    public static synchronized boolean start(final Context ctx, final int sourceCount, final boolean alsoScan) {
        return start(ctx, sourceCount, alsoScan, MAX_IMPORT);
    }

    public static synchronized boolean start(final Context ctx, final int sourceCount, final boolean alsoScan,
                                             int maxImport) {
        if (running) return false;
        limit = maxImport <= 0 ? Integer.MAX_VALUE : maxImport;
        running = true;
        acquireWakeLock(ctx);
        cancelled = false;
        imported = 0;
        curSource = 0;
        curPct = 0;
        java.util.List<String[]> srcs = SourceStore.list(ctx);
        currentSources = srcs;
        currentCtx = ctx.getApplicationContext();
        totalSources = Math.max(1, Math.min(sourceCount, srcs.size()));
        stage = "准备中";
        startedAt = System.currentTimeMillis();
        finishedAt = 0;
        new Thread(new Runnable() {
            @Override
            public void run() {
                int ok = 0;
                String err = "";
                try {
                    java.util.Set<String> seen = new java.util.HashSet<String>();
                    for (int si = 0; si < totalSources && !cancelled; si++) {
                        if (imported >= limit) {
                            Log2.i("已达导入上限 " + limit + "，跳过剩余来源");
                            break;
                        }
                        curSource = si;
                        curPct = 0;
                        stage = srcs.get(si)[0];
                        Log2.i("翻新源开始下载：" + stage + "（第 " + (si + 1) + "/" + totalSources + " 个）");
                        broadcast(ctx, 1);
                        stageDetail = "下载中…";
                        String body = http(ctx, srcs.get(si)[1], 15000);
                        if (body == null || body.length() == 0) {
                            String mirror = mirrorUrl(srcs.get(si)[1]);
                            if (mirror != null) {
                                Log2.w("翻新源直连失败，改用镜像：" + srcs.get(si)[0]);
                                body = http(ctx, mirror, 15000);
                            }
                        }
                        if (body == null || body.length() == 0) {
                            Log2.w("翻新源超时跳过：" + srcs.get(si)[0]);
                            stageDetail = "这个源下载失败，跳过";
                            curPct = 100;
                            continue;
                        }
                        ok++;
                        String text = decode(body);
                        String hint = srcs.get(si).length > 2 ? srcs.get(si)[2] : "";
                        runSource(ctx, text, hint, seen);
                    }
                } catch (Throwable t) {
                    err = String.valueOf(t);
                    Log2.w("翻新失败：" + t);
                }
                running = false;
                releaseWakeLock();

                okSources = ok;
                finishedAt = System.currentTimeMillis();
                stage = cancelled ? "已取消" : "完成";
                Log2.i("翻新结束：导入 " + imported + " 个，成功源 " + ok + "/" + totalSources
                        + (err.length() > 0 ? "，错误：" + err : ""));
                broadcast(ctx, 2);
            }
        }, "refresh").start();
        return true;
    }

    private static void runSource(Context ctx, String text, String hint, java.util.Set<String> seen) {
        String[] lines = text.split("\r?\n");
        int totalLines = Math.max(1, lines.length);
        java.util.LinkedHashSet<String> cands = new java.util.LinkedHashSet<String>();
        for (int i = 0; i < lines.length; i++) {
            if (cancelled) return;
            if ((i % 50) == 0) {
                curPct = (int) (100L * i / totalLines);
                stageDetail = "解析中 " + curPct + "%";
                broadcast(ctx, 1);
            }
            String line = lines[i].trim();
            if (line.length() < 10 || !line.contains("://")) continue;
            if (!seen.add(line)) continue;
            cands.add(line);
        }
        // 同一台服务器（协议 + 主机 + 端口）只保留一个：
        // 免费源里常见"同一台机器几十个账号"，不去重会把节点池和体检时间撑爆
        java.util.Set<String> hostKeys = new java.util.HashSet<String>();
        for (Node ex : NodeStore.imported(ctx)) {
            hostKeys.add(ex.protocol + "|" + ex.host + "|" + ex.port);
        }
        java.util.Set<String> existing = NodeStore.allUris(ctx);
        java.util.Set<String> trashed = NodeStore.trashedUris(ctx);
        java.util.Set<String> purged = NodeStore.purgedUris(ctx);
        java.util.List<String> add = new java.util.ArrayList<String>();
        java.util.Map<String, String> ccs = new java.util.HashMap<String, String>();
        for (String uri : cands) {
            if (cancelled) return;
            if (imported >= limit) break;
            if (existing.contains(uri) || trashed.contains(uri)) continue;
            if (NodeStore.isBlacklisted(ctx, uri)) continue;
            try {
                if (purged.contains(uri)) NodeStore.unpurge(ctx, uri);
                String cc = "ZZ";   // 一律先记为"未识别地区"，等体检后用 IP 识别出真实国家
                Node n = new Node(uri, cc.length() == 2 ? cc : "ZZ", "");
                if (!n.supported) continue;
                if (!hostKeys.add(n.protocol + "|" + n.host + "|" + n.port)) {
                    continue;      // 同服务器的重复账号，跳过
                }
                add.add(uri);

                imported++;
            } catch (Throwable ignored) {
            }
        }
        if (cancelled) return;                  // 取消后不要再把这一批写进库
        // 新导入的节点一律从"未识别地区"开始：清掉它们以往的地区缓存，
        // 否则旧缓存会让它们一导入就显示成某个国家
        writeDone = 0;
        writeTotal = add.size();
        stageDetail = "写入节点 0/" + add.size();
        broadcast(ctx, 1);
        NodeStore.clearCcHints(ctx, add);
        int written = 0;
        for (int i = 0; i < add.size(); i += 300) {
            if (cancelled) return;
            int end = Math.min(add.size(), i + 300);
            java.util.List<String> chunk = new java.util.ArrayList<String>(add.subList(i, end));
            NodeStore.addImportedBatch(ctx, chunk);
            NodeStore.addShownBatch(ctx, chunk);
            written = end;
            writeDone = written;
            stageDetail = "写入节点 " + written + "/" + add.size();
            broadcast(ctx, 1);
            try {
                Thread.sleep(8);   // 让出锁，界面不卡
            } catch (InterruptedException ignored) {
            }
        }
        NodeStore.setImportedCcBatch(ctx, ccs);
        curPct = 100;
        broadcast(ctx, 1);
    }

    /** GitHub raw → jsDelivr 镜像（国内通常能通）。 */
    private static String mirrorUrl(String url) {
        try {
            String marker = "raw.githubusercontent.com/";
            int i = url.indexOf(marker);
            if (i < 0) return null;
            String rest = url.substring(i + marker.length());     // owner/repo/branch/path...
            String[] parts = rest.split("/", 4);
            if (parts.length < 4) return null;
            return "https://cdn.jsdelivr.net/gh/" + parts[0] + "/" + parts[1]
                    + "@" + parts[2] + "/" + parts[3];
        } catch (Throwable t) {
            return null;
        }
    }

    private static String http(Context ctx, String url, int timeoutMs) {
        String r = httpOnce(ctx, url, timeoutMs);
        if (r != null && r.length() > 0) return r;
        try {
            Thread.sleep(800);
        } catch (InterruptedException ignored) {
        }
        return httpOnce(ctx, url, timeoutMs);      // 再试一次
    }

    private static String httpOnce(Context ctx, String url, int timeoutMs) {
        java.net.HttpURLConnection c = null;
        try {
            c = (java.net.HttpURLConnection) new java.net.URL(url).openConnection();
            c.setConnectTimeout(timeoutMs / 2);
            c.setReadTimeout(timeoutMs);
            c.setRequestProperty("User-Agent", "Mozilla/5.0");
            c.setInstanceFollowRedirects(true);
            if (c.getResponseCode() != 200) return null;
            java.io.InputStream in = c.getInputStream();
            java.io.ByteArrayOutputStream bos = new java.io.ByteArrayOutputStream();
            byte[] buf = new byte[8192];
            int len;
            long deadline = System.currentTimeMillis() + timeoutMs * 2L;   // 总时长封顶
            while ((len = in.read(buf)) > 0) {
                if (System.currentTimeMillis() > deadline) {
                    Log2.w("翻新源下载超过总时长上限（" + (timeoutMs * 2 / 1000) + " 秒），放弃：" + url);
                    try {
                        c.disconnect();
                    } catch (Throwable ignored) {
                    }
                    return null;
                }
                if (cancelled) {
                    try {
                        c.disconnect();
                    } catch (Throwable ignored) {
                    }
                    return null;            // 取消后立刻放弃这次下载
                }
                bos.write(buf, 0, len);
            }
            in.close();
            return new String(bos.toByteArray(), "UTF-8");
        } catch (Throwable t) {
            return null;
        } finally {
            if (c != null) c.disconnect();
        }
    }

    private static String decode(String body) {
        try {
            String clean = body.replaceAll("\\s", "");
            String dec = new String(android.util.Base64.decode(clean, android.util.Base64.DEFAULT), "UTF-8");
            if (dec.contains("://")) return dec;
        } catch (Throwable ignored) {
        }
        return body;
    }

    private static void broadcast(Context ctx, int state) {
        try {
            Intent i = new Intent(ACTION_REFRESH_STATE);
            i.setPackage(ctx.getPackageName());
            i.putExtra("state", state);                 // 1=进行中 2=结束
            i.putExtra("total", totalSources);
            i.putExtra("src", curSource);
            i.putExtra("pct", curPct);
            i.putExtra("imported", imported);
            i.putExtra("stage", stage);
            i.putExtra("cancelled", cancelled);
            ctx.sendBroadcast(i);
        } catch (Throwable ignored) {
        }
    }
}
