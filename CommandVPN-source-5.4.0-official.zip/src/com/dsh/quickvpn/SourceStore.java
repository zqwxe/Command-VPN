package com.dsh.quickvpn;

import android.content.Context;

import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;

/**
 * 节点源列表（按优先级从上到下）。
 * 存 prefs：每行 "名称\t链接\t国家提示(可空)"，行序就是优先级。
 */
public class SourceStore {

    public static final int MAX = 10;
    private static final String KEY = "sources_v1";

    /** 默认 5 个源（与原来写死在代码里的一致）。 */
    public static String[][] defaults() {
        return new String[][]{
                {"Au1rxx 美国",
                        "https://raw.githubusercontent.com/Au1rxx/free-vpn-subscriptions/main/output/by-country/v2ray-base64-US.txt", ""},
                {"Au1rxx 全量", "https://raw.githubusercontent.com/Au1rxx/free-vpn-subscriptions/main/output/v2ray-base64.txt", ""},
                {"mahdibland", "https://raw.githubusercontent.com/mahdibland/V2RayAggregator/master/sub/sub_merge_base64.txt", ""},
                {"peasoft", "https://raw.githubusercontent.com/peasoft/NoMoreWalls/master/list.txt", ""},
                {"ermaozi", "https://raw.githubusercontent.com/ermaozi/get_subscribe/main/subscribe/v2ray.txt", ""},
                {"美国节点（roosterkid）",
                        "https://raw.githubusercontent.com/roosterkid/openproxylist/main/V2RAY_BASE64.txt", ""},
        };
    }

    public static synchronized List<String[]> list(Context ctx) {
        List<String[]> out = new ArrayList<String[]>();
        try {
            String raw = ctx.getSharedPreferences("qv", Context.MODE_PRIVATE).getString(KEY, "");
            if (raw == null || raw.trim().length() == 0) return defaultsList();
            for (String line : raw.split("\n")) {
                if (line.trim().length() == 0) continue;
                String[] p = line.split("\t", -1);
                if (p.length < 2) continue;
                String name = p[0].trim();
                String url = p[1].trim();
                if (url.length() < 8) continue;
                String hint = p.length > 2 ? p[2].trim() : "";
                out.add(new String[]{name, url, hint});
            }
        } catch (Throwable ignored) {
        }
        if (out.isEmpty()) return defaultsList();
        return out;
    }

    /** 一次性升级：Au1rxx 的"美国"清单已退化成同一台 hy2 机器，换成含美国节点更多的源。 */
    public static synchronized void upgradeV1(Context ctx) {
        try {
            android.content.SharedPreferences sp = ctx.getSharedPreferences("qv", Context.MODE_PRIVATE);
            if (sp.getBoolean("source_upgrade_v1", false)) return;
            List<String[]> l = new ArrayList<String[]>();
            String raw = sp.getString(KEY, "");
            if (raw != null && raw.trim().length() > 0) {
                for (String line : raw.split("\n")) {
                    if (line.trim().length() == 0) continue;
                    String[] p = line.split("\t", -1);
                    if (p.length < 2) continue;
                    String name = p[0], url = p[1];
                    if (url.contains("by-country/v2ray-base64-US.txt")) {
                        url = "https://raw.githubusercontent.com/roosterkid/openproxylist/main/V2RAY_BASE64.txt";
                        name = "美国节点（roosterkid）";
                        Log2.i("节点源升级：Au1rxx 美国 → 美国节点（roosterkid）");
                    }
                    l.add(new String[]{name, url, p.length > 2 ? p[2] : ""});
                }
                if (!l.isEmpty()) save(ctx, l);
            }
            sp.edit().putBoolean("source_upgrade_v1", true).apply();
        } catch (Throwable t) {
            Log2.w("节点源升级失败：" + t);
        }
    }

    /** 一次性升级：追加两个含美国节点的源。 */
    public static synchronized void upgradeV2(Context ctx) {
        try {
            android.content.SharedPreferences sp = ctx.getSharedPreferences("qv", Context.MODE_PRIVATE);
            if (sp.getBoolean("source_upgrade_v2", false)) return;
            List<String[]> l = list(ctx);
            String[] add1 = {"ALIILAPRO（含美国）",
                    "https://raw.githubusercontent.com/ALIILAPRO/v2rayNG-Config/main/server.txt", ""};
            String[] add2 = {"barry-far（含美国）",
                    "https://raw.githubusercontent.com/barry-far/V2ray-Config/main/All_Configs_Sub.txt", ""};
            boolean has1 = false, has2 = false;
            for (String[] x : l) {
                if (x[1].equals(add1[1])) has1 = true;
                if (x[1].equals(add2[1])) has2 = true;
            }
            if (!has1 && l.size() < MAX) {
                l.add(add1);
                Log2.i("节点源追加：ALIILAPRO（含美国）");
            }
            if (!has2 && l.size() < MAX) {
                l.add(add2);
                Log2.i("节点源追加：barry-far（含美国）");
            }
            save(ctx, l);
            sp.edit().putBoolean("source_upgrade_v2", true).apply();
        } catch (Throwable t) {
            Log2.w("节点源追加失败：" + t);
        }
    }

    /** 一次性回退：移除两个超大源（几千个死节点，把体检拖到几小时）。 */
    public static synchronized void upgradeV3(Context ctx) {
        try {
            android.content.SharedPreferences sp = ctx.getSharedPreferences("qv", Context.MODE_PRIVATE);
            if (sp.getBoolean("source_upgrade_v3", false)) return;
            List<String[]> l = list(ctx);
            List<String[]> keep = new ArrayList<String[]>();
            int removed = 0;
            for (String[] x : l) {
                if (x[1].contains("ALIILAPRO/v2rayNG-Config")
                        || x[1].contains("barry-far/V2ray-Config")) {
                    removed++;
                    Log2.i("节点源回退：移除超大源 " + x[0]);
                    continue;
                }
                keep.add(x);
            }
            if (!keep.isEmpty()) save(ctx, keep);
            sp.edit().putBoolean("source_upgrade_v3", true).apply();
            if (removed > 0) Log2.i("节点源回退完成：移除 " + removed + " 个超大源，剩 " + keep.size() + " 个");
        } catch (Throwable t) {
            Log2.w("节点源回退失败：" + t);
        }
    }

    /** 一次性：把 Au1rxx 美国放回第一位，roosterkid 排到第六。 */
    public static synchronized void upgradeV4(Context ctx) {
        try {
            android.content.SharedPreferences sp = ctx.getSharedPreferences("qv", Context.MODE_PRIVATE);
            if (sp.getBoolean("source_upgrade_v4", false)) return;
            List<String[]> l = list(ctx);
            final String auUrl = "https://raw.githubusercontent.com/Au1rxx/free-vpn-subscriptions/main/output/by-country/v2ray-base64-US.txt";
            final String rooUrl = "https://raw.githubusercontent.com/roosterkid/openproxylist/main/V2RAY_BASE64.txt";
            List<String[]> keep = new ArrayList<String[]>();
            boolean hasAu = false;
            for (String[] x : l) {
                if (x[1].contains("by-country/v2ray-base64-US.txt")) { hasAu = true; continue; }
                if (x[1].equals(rooUrl)) continue;
                keep.add(x);
            }
            List<String[]> out = new ArrayList<String[]>();
            out.add(new String[]{"Au1rxx 美国", auUrl, ""});
            out.addAll(keep);
            if (out.size() < MAX) out.add(new String[]{"美国节点（roosterkid）", rooUrl, ""});
            save(ctx, out);
            sp.edit().putBoolean("source_upgrade_v4", true).apply();
            Log2.i("节点源调整：Au1rxx 美国回到第 1 位，roosterkid 排第 " + out.size() + " 位");
        } catch (Throwable t) {
            Log2.w("节点源调整失败：" + t);
        }
    }

    public static List<String[]> defaultsList() {
        List<String[]> out = new ArrayList<String[]>();
        for (String[] d : defaults()) out.add(new String[]{d[0], d[1], d[2]});
        return out;
    }

    public static synchronized void save(Context ctx, List<String[]> list) {
        StringBuilder sb = new StringBuilder();
        for (String[] s : list) {
            sb.append(s[0]).append('\t').append(s[1]).append('\t')
                    .append(s.length > 2 ? s[2] : "").append('\n');
        }
        ctx.getSharedPreferences("qv", Context.MODE_PRIVATE).edit().putString(KEY, sb.toString()).apply();
        Log2.i("节点源已保存，共 " + list.size() + " 个");
    }

    public static synchronized int size(Context ctx) {
        return list(ctx).size();
    }

    /** 追加一个源；已有 10 个时返回 false。 */
    public static synchronized boolean add(Context ctx, String name, String url, String hint) {
        List<String[]> l = list(ctx);
        if (l.size() >= MAX) return false;
        for (String[] s : l) {
            if (s[1].equalsIgnoreCase(url)) return false;   // 重复
        }
        if (name == null || name.trim().length() == 0) name = "自定义源 " + (l.size() + 1);
        l.add(new String[]{name.trim(), url.trim(), hint == null ? "" : hint});
        save(ctx, l);
        return true;
    }

    public static synchronized void remove(Context ctx, int index) {
        List<String[]> l = list(ctx);
        if (index < 0 || index >= l.size()) return;
        String[] gone = l.remove(index);
        save(ctx, l);
        Log2.i("节点源：删除 " + gone[0] + "（剩余 " + l.size() + " 个）");
    }

    public static synchronized boolean moveUp(Context ctx, int index) {
        List<String[]> l = list(ctx);
        if (index <= 0 || index >= l.size()) return false;
        String[] s = l.remove(index);
        l.add(index - 1, s);
        save(ctx, l);
        Log2.i("节点源：优先级调整，" + s[0] + " 第 " + (index + 1) + " → 第 " + index);
        return true;
    }

    public static synchronized boolean moveDown(Context ctx, int index) {
        List<String[]> l = list(ctx);
        if (index < 0 || index >= l.size() - 1) return false;
        String[] s = l.remove(index);
        l.add(index + 1, s);
        save(ctx, l);
        Log2.i("节点源：优先级调整，" + s[0] + " 第 " + (index + 1) + " → 第 " + (index + 2));
        return true;
    }

    public static synchronized void reset(Context ctx) {
        ctx.getSharedPreferences("qv", Context.MODE_PRIVATE).edit().remove(KEY).apply();
        Log2.i("节点源：已重置为默认 5 个");
    }

    public static boolean isDefault(Context ctx) {
        return size(ctx) == 5;
    }
}
