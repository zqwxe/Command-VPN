package com.dsh.quickvpn;

import java.nio.file.*;
import java.util.*;

/** 离线测试：用真实 Java 代码把每个节点翻译成 sing-box 配置并落盘，交给 sing-box check 校验。 */
public class GenForTest {
    public static void main(String[] args) throws Exception {
        List<String> lines = Files.readAllLines(Paths.get(args[0]));
        Path out = Paths.get(args[1]);
        if (Files.exists(out)) {
            Files.walk(out).sorted(Comparator.reverseOrder()).forEach(p -> p.toFile().delete());
        }
        Files.createDirectories(out);

        int i = 0, ok = 0, broken = 0, unsupported = 0;
        Map<String, Integer> protos = new TreeMap<>();
        List<String> errors = new ArrayList<>();
        for (String line : lines) {
            line = line.trim();
            if (line.isEmpty()) continue;
            String cc = "", uri = line;
            int tab = line.indexOf('\t');
            if (tab > 0) {
                cc = line.substring(0, tab).trim();
                uri = line.substring(tab + 1).trim();
            }
            Node n;
            try {
                n = new Node(uri, cc, "");
            } catch (Exception e) {
                broken++;
                errors.add("construct: " + e);
                continue;
            }
            if (!n.supported) {
                unsupported++;
                continue;
            }
            protos.merge(n.protocol, 1, Integer::sum);
            try {
                String cfg = ConfigBuilder.build(n);
                Files.write(out.resolve(String.format("%05d-%s.json", i++, n.protocol)), cfg.getBytes("UTF-8"));
                ok++;
            } catch (Exception e) {
                broken++;
                errors.add("build " + n.protocol + " " + e);
            }
        }
        System.out.println("generated=" + ok + " unsupported=" + unsupported + " broken=" + broken);
        System.out.println("protocols=" + protos);
        for (int k = 0; k < Math.min(8, errors.size()); k++) System.out.println("  err: " + errors.get(k));
    }
}
