package com.dsh.quickvpn;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/** 到点触发：启动前台服务翻新节点，并安排下一次。 */
public class AutoRefreshReceiver extends BroadcastReceiver {

    public static final String ACTION = "com.dsh.quickvpn.AUTO_REFRESH_TICK";
    /** 上一次被占用（体检/连接中），10 分钟后重试用的 action。 */
    public static final String ACTION_RETRY = "com.dsh.quickvpn.AUTO_REFRESH_RETRY";

    @Override
    public void onReceive(Context ctx, Intent intent) {
        try {
            Log2.init(ctx);      // 接收器可能先于界面/服务启动，先初始化日志才不会丢记录
            if (!AutoRefresh.enabled(ctx)) {
                Log2.i("自动翻新：开关已关闭，跳过本次");
                return;
            }
            Log2.i("自动翻新：到点触发");
            Intent svc = new Intent(ctx, TunnelService.class);
            svc.setAction(TunnelService.ACTION_REFRESH);
            svc.putExtra("sources", AutoRefresh.sources(ctx));
            svc.putExtra("fromAuto", true);
            // 这是"上次被占用后的一次性重试"，服务里据此不再无限重排
            svc.putExtra("retry", ACTION_RETRY.equals(intent == null ? null : intent.getAction()));
            if (android.os.Build.VERSION.SDK_INT >= 26) ctx.startForegroundService(svc);
            else ctx.startService(svc);
        } catch (Throwable t) {
            Log2.w("自动翻新启动失败：" + t);
        } finally {
            try {
                // 只在开关仍然打开时排下一次（schedule 内部也会再判断一次）
                if (AutoRefresh.enabled(ctx)) AutoRefresh.schedule(ctx);
            } catch (Throwable ignored) {
            }
        }
    }
}
