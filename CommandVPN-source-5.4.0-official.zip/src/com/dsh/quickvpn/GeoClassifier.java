package com.dsh.quickvpn;

import android.content.Context;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * 按 IP 识别节点地区。
 * 规则（速度优先）：
 *   1) 同一 IP 只查一次（内存 + 本地缓存）
 *   2) ip-api 批量 + ipwho.is 逐个，两源一致就采用
 *   3) 不一致/缺数据时再查 ipinfo.io，三源里任意两票一致就采用
 *   4) 仍然矛盾的，如果调用方提供 GoogleProbe（翻新链体检时内核可用），问一次 Google
 *   5) 都不行就保持"未识别地区"
 */
public class GeoClassifier {

    public interface Listener {
        void onProgress(int done, int total, int found);
        void onDone(int found, int remain, boolean cancelled);
    }

    public interface GoogleProbe {
        String regionOf(Node node);
    }

    public interface Progress {
        void onProgress(int done, int found);
    }

    static volatile boolean running = false;
    static volatile String lastDetail = "";
    static volatile boolean cancelled = false;

    /** IP → 国家码 的进程内缓存（同一 IP 不重复查）。 */
    private static final Map<String, String> IP_CACHE = new ConcurrentHashMap<String, String>();
    private static boolean cacheLoaded = false;
    private static final String CACHE_KEY = "geo_ip_cache_v1";

    public static boolean isRunning() { return running; }

    public static void cancel() { cancelled = true; }

    private static boolean isUnknown(Node n) {
        return n == null || Country.isUnknown(n.cc);
    }

    private static synchronized void loadCache(Context ctx) {
        if (cacheLoaded) return;
        cacheLoaded = true;
        try {
            String raw = ctx.getSharedPreferences("qv", Context.MODE_PRIVATE).getString(CACHE_KEY, "");
            if (raw != null) {
                for (String line : raw.split("\n")) {
                    int tab = line.indexOf('\t');
                    if (tab <= 0) continue;
                    String ip = line.substring(0, tab).trim();
                    String cc = line.substring(tab + 1).trim();
                    if (ip.length() > 0 && cc.length() == 2) IP_CACHE.put(ip, cc);
                }
            }
        } catch (Throwable ignored) {
        }
    }

    private static void saveCache(Context ctx) {
        try {
            StringBuilder sb = new StringBuilder();
            int n = 0;
            for (Map.Entry<String, String> e : IP_CACHE.entrySet()) {
                if (n++ > 5000) break;
                sb.append(e.getKey()).append('\t').append(e.getValue()).append('\n');
            }
            ctx.getSharedPreferences("qv", Context.MODE_PRIVATE).edit()
                    .putString(CACHE_KEY, sb.toString()).apply();
        } catch (Throwable ignored) {
        }
    }

    /** 只识别"未识别地区"的节点。 */
    public static void start(final Context ctx, final Listener listener) {
        startMode(ctx, listener, false);
    }

    /** 重新识别全部节点（包括已有国家的），用于"重新识别全部地区"。 */
    public static void startAll(final Context ctx, final Listener listener) {
        startMode(ctx, listener, true);
    }

    private static void startMode(final Context ctx, final Listener listener, final boolean all) {
        if (running) return;
        running = true;
        cancelled = false;
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    List<Node> unknown = new ArrayList<Node>();
                    java.util.Set<String> seen = new java.util.HashSet<String>();
                    for (Node n : NodeStore.allForClassify(ctx)) {
                        if (!all && !isUnknown(n)) continue;
                        if (n.host == null || n.host.length() == 0) continue;
                        if (!seen.add(n.uri)) continue;
                        unknown.add(n);
                    }
                    if (listener == null && unknown.size() > 900) {
                        int all = unknown.size();
                        unknown = new ArrayList<Node>(unknown.subList(0, 900));
                        Log2.i("自动识别地区：共 " + all + " 个未知，本次先查前 900 个");
                    }
                    final int total = unknown.size();
                    Log2.i("识别未识别地区：共 " + total + " 个节点");
                    if (total == 0) {
                        running = false;
                        if (listener != null) listener.onDone(0, 0, false);
                        return;
                    }
                    int found = identify(ctx, unknown, null, all, new Progress() {
                        @Override
                        public void onProgress(int d, int f) {
                            if (listener != null) listener.onProgress(d, total, f);
                        }
                    });
                    saveCache(ctx);
                    running = false;
                    if (listener != null) listener.onDone(found, total - found, false);
                } catch (Throwable t) {
                    Log2.w("识别未识别地区失败：" + t);
                    running = false;
                    if (listener != null) listener.onDone(0, 0, false);
                }
            }
        }, "geo-classify").start();
    }

    /**
     * 同步识别一批节点（翻新链体检每批调用，通常只传"可用"的节点）。
     * 优先级：Google（如果可用）→ ip-api → ipwho.is → ipinfo.io → 未识别。
     */
    public static int identify(Context ctx, List<Node> nodes, GoogleProbe google, Progress progress) {
        return identify(ctx, nodes, google, false, progress);
    }

    /**
     * @param force true = 已有国家的节点也重新查一遍（"重新识别全部地区"用）
     */
    public static int identify(Context ctx, List<Node> nodes, GoogleProbe google, boolean force,
                               Progress progress) {
        if (nodes == null || nodes.isEmpty()) return 0;
        loadCache(ctx);

        List<Node> todo = new ArrayList<Node>();
        Map<String, String> ipOfUri = new HashMap<String, String>();
        Map<String, String> ccOfIp = new HashMap<String, String>();
        java.util.Set<String> needIps = new LinkedHashSet<String>();
        for (Node n : nodes) {
            if (!force && !isUnknown(n)) continue;
            // 已经被 Google 出口判定过的，手动三源识别不覆盖
            if (force && NodeStore.isCcFromGoogle(ctx, n.uri)) continue;
            try {
                n.resolveHost(4000);
            } catch (Throwable ignored) {
            }
            String ip = n.resolvedHost != null ? n.resolvedHost : n.host;
            if (ip == null || !ip.matches("^\\d+\\.\\d+\\.\\d+\\.\\d+$")) continue;
            ipOfUri.put(n.uri, ip);
            String cached = force ? null : IP_CACHE.get(ip);
            if (cached != null && cached.length() == 2) ccOfIp.put(ip, cached);
            else needIps.add(ip);
            todo.add(n);
        }
        if (todo.isEmpty()) return 0;

        // ① 先问 Google（能问的时候，它就是最高优先级）
        int googleHits = 0;
        int gDone = 0;
        if (google != null) {
            for (Node n : todo) {
                if (cancelled) break;
                String ip = ipOfUri.get(n.uri);
                if (ip == null || ccOfIp.containsKey(ip)) {
                    gDone++;
                    if (progress != null) progress.onProgress(gDone, googleHits);
                    continue;
                }
                String cc = "";
                try {
                    cc = google.regionOf(n);
                } catch (Throwable ignored) {
                }
                if (cc != null && cc.length() == 2) {
                    ccOfIp.put(ip, cc);
                    NodeStore.markCcFromGoogle(ctx, n.uri, cc);   // 标记：以后手动识别不覆盖
                    googleHits++;
                }
                gDone++;
                if (progress != null) progress.onProgress(gDone, googleHits);
            }
        }

        // ② Google 没给结果的，再用三个地理源（按 ip-api > ipwho > ipinfo 的优先级）
        List<String> ips = new ArrayList<String>();
        for (String ip : needIps) if (!ccOfIp.containsKey(ip)) ips.add(ip);
        Map<String, String> api = new HashMap<String, String>();
        for (int i = 0; i < ips.size(); i += 100) {
            api.putAll(ipApi(ips.subList(i, Math.min(ips.size(), i + 100))));
            if (cancelled) break;
        }
        List<String> needWho = new ArrayList<String>();
        for (String ip : ips) if (norm(api.get(ip)).length() != 2) needWho.add(ip);
        final Map<String, String> who = new ConcurrentHashMap<String, String>();
        queryConcurrent(needWho, who, new Query() {
            @Override
            public String ask(String ip) {
                return ipWho(ip);
            }
        }, 24);

        List<String> needInfo = new ArrayList<String>();
        for (String ip : ips) {
            if (norm(api.get(ip)).length() == 2) continue;
            if (norm(who.get(ip)).length() == 2) continue;
            needInfo.add(ip);
        }
        final Map<String, String> info = new ConcurrentHashMap<String, String>();
        queryConcurrent(needInfo, info, new Query() {
            @Override
            public String ask(String ip) {
                return ipInfo(ip);
            }
        }, 16);

        Log2.i("识别批次：待查 IP " + ips.size() + "，Google 命中 " + googleHits
                + "，ip-api 命中 " + api.size() + "，ipwho 命中 " + who.size()
                + "，ipinfo 命中 " + info.size());

        // ③ 三源投票：有两票一致就用多数；三个各不相同才按固定优先级
        for (String ip : ips) {
            String cc = majorityOrPriority(api.get(ip), who.get(ip), info.get(ip));
            if (cc.length() == 2) ccOfIp.put(ip, cc);
        }

        Map<String, String> ccMap = new HashMap<String, String>();
        int done = 0, found = 0;
        for (Node n : todo) {
            if (cancelled) break;
            String ip = ipOfUri.get(n.uri);
            if (ip == null) continue;
            String cc = ccOfIp.get(ip);
            done++;
            if (cc != null && cc.length() == 2) {
                n.cc = cc;          // 同步更新内存里的节点，体检结束的统计才不会还是"未识别地区"
                ccMap.put(n.uri, cc);
                found++;
            }
            if (progress != null && done % 20 == 0) progress.onProgress(done, found);
        }
        if (progress != null) progress.onProgress(done, found);
        for (Map.Entry<String, String> e : ccOfIp.entrySet()) {
            if (e.getValue() != null && e.getValue().length() == 2) IP_CACHE.put(e.getKey(), e.getValue());
        }
        if (!ccMap.isEmpty()) NodeStore.setImportedCcBatch(ctx, ccMap);
        Log2.i("识别未识别地区完成：识别 " + found + " 个（" + detail(ccMap) + "）");
        return found;
    }

    /**
     * 三个源投票：
     *  - 有两票一致 → 采用那个（多数）
     *  - 三个各不相同（或只有两个且不同）→ 按固定优先级 ip-api > ipwho > ipinfo
     *  - 都没有 → ""
     */
    private static String majorityOrPriority(String a, String b, String c) {
        String x = norm(a), y = norm(b), z = norm(c);
        if (x.length() == 2 && x.equals(y)) return x;
        if (x.length() == 2 && x.equals(z)) return x;
        if (y.length() == 2 && y.equals(z)) return y;
        if (x.length() == 2) return x;
        if (y.length() == 2) return y;
        return z;
    }

    /**
     * 给一批 IP 查国家（云节点测速后补地区用，不连接节点）：
     * 顺序仍是 ip-api → ipwho.is → ipinfo.io，命中即用，带 IP 缓存。
     */
    public static java.util.Map<String, String> identifyIpCountries(Context ctx,
                                                                   java.util.List<String> ips) {
        java.util.Map<String, String> out = new java.util.HashMap<String, String>();
        if (ips == null || ips.isEmpty()) return out;
        loadCache(ctx);
        java.util.List<String> need = new java.util.ArrayList<String>();
        for (String ip : ips) {
            if (ip == null || !ip.matches("^\\d+\\.\\d+\\.\\d+\\.\\d+$")) continue;
            String cached = IP_CACHE.get(ip);
            if (cached != null && cached.length() == 2) out.put(ip, cached);
            else if (!need.contains(ip)) need.add(ip);
        }
        java.util.Map<String, String> api = new java.util.HashMap<String, String>();
        for (int i = 0; i < need.size(); i += 100) {
            api.putAll(ipApi(need.subList(i, Math.min(need.size(), i + 100))));
        }
        java.util.List<String> whoIps = new java.util.ArrayList<String>();
        for (String ip : need) if (norm(api.get(ip)).length() != 2) whoIps.add(ip);
        final java.util.Map<String, String> who = new ConcurrentHashMap<String, String>();
        queryConcurrent(whoIps, who, new Query() {
            @Override
            public String ask(String ip) {
                return ipWho(ip);
            }
        }, 24);
        java.util.List<String> infoIps = new java.util.ArrayList<String>();
        for (String ip : need) {
            if (norm(api.get(ip)).length() == 2) continue;
            if (norm(who.get(ip)).length() == 2) continue;
            infoIps.add(ip);
        }
        final java.util.Map<String, String> info = new ConcurrentHashMap<String, String>();
        queryConcurrent(infoIps, info, new Query() {
            @Override
            public String ask(String ip) {
                return ipInfo(ip);
            }
        }, 16);
        for (String ip : need) {
            String cc = majorityOrPriority(api.get(ip), who.get(ip), info.get(ip));
            if (cc.length() == 2) {
                out.put(ip, cc);
                IP_CACHE.put(ip, cc);
            }
        }
        return out;
    }

    public static void clearIpCache() {
        IP_CACHE.clear();
        cacheLoaded = false;
    }

    public static void flushCache(Context ctx) {
        saveCache(ctx);
    }

    private interface Query {
        String ask(String ip);
    }

    private static void queryConcurrent(List<String> ips, final Map<String, String> out,
                                        final Query q, int conc) {
        if (ips.isEmpty()) return;
        ExecutorService pool = Executors.newFixedThreadPool(Math.min(conc, ips.size()));
        final CountDownLatch latch = new CountDownLatch(ips.size());
        for (final String ip : ips) {
            try {
                pool.execute(new Runnable() {
                    @Override
                    public void run() {
                        try {
                            String cc = q.ask(ip);
                            if (cc != null && cc.length() == 2) out.put(ip, cc);
                        } catch (Throwable ignored) {
                        } finally {
                            latch.countDown();
                        }
                    }
                });
            } catch (Throwable t) {
                latch.countDown();
            }
        }
        try {
            latch.await(Math.max(8000L, ips.size() * 400L), java.util.concurrent.TimeUnit.MILLISECONDS);
        } catch (InterruptedException ignored) {
        }
        try { pool.shutdownNow(); } catch (Throwable ignored) { }
    }

    /** 有结果就用；只有"两个以上不同值且没有多数"时才返回空（交给 Google）。 */
    private static String agree(String a, String b, String c) {
        java.util.Map<String, Integer> cnt = new java.util.HashMap<String, Integer>();
        for (String v : new String[]{a, b, c}) {
            if (v == null || v.length() != 2) continue;
            Integer n = cnt.get(v);
            cnt.put(v, n == null ? 1 : n + 1);
        }
        if (cnt.isEmpty()) return "";
        if (cnt.size() == 1) return cnt.keySet().iterator().next();
        String best = null;
        int bestN = 0;
        for (java.util.Map.Entry<String, Integer> e : cnt.entrySet()) {
            if (e.getValue() > bestN) {
                bestN = e.getValue();
                best = e.getKey();
            }
        }
        return bestN >= 2 ? best : "";
    }

    private static String vote(String a, String b, String c) {
        a = norm(a); b = norm(b); c = norm(c);
        if (a.length() == 2 && a.equals(b)) return a;
        if (a.length() == 2 && a.equals(c)) return a;
        if (b.length() == 2 && b.equals(c)) return b;
        return "";
    }

    private static String norm(String cc) {
        if (cc == null) return "";
        String v = cc.trim().toUpperCase(java.util.Locale.ROOT);
        return v.length() == 2 ? v : "";
    }

    private static String detail(Map<String, String> ccMap) {
        Map<String, Integer> cnt = new HashMap<String, Integer>();
        for (String cc : ccMap.values()) {
            Integer n = cnt.get(cc);
            cnt.put(cc, n == null ? 1 : n + 1);
        }
        List<Map.Entry<String, Integer>> list = new ArrayList<Map.Entry<String, Integer>>(cnt.entrySet());
        java.util.Collections.sort(list, new java.util.Comparator<Map.Entry<String, Integer>>() {
            @Override
            public int compare(Map.Entry<String, Integer> x, Map.Entry<String, Integer> y) {
                return y.getValue() - x.getValue();
            }
        });
        StringBuilder sb = new StringBuilder();
        int shown = 0;
        for (Map.Entry<String, Integer> e : list) {
            if (shown >= 12) { sb.append("…等 ").append(list.size()).append(" 个国家/地区"); break; }
            if (sb.length() > 0) sb.append("、");
            String name = Country.displayName(e.getKey());
            sb.append(name.length() == 0 ? e.getKey() : name).append(" ").append(e.getValue()).append(" 个");
            shown++;
        }
        lastDetail = sb.toString();
        return lastDetail;
    }

    /* ------------------------ 三个地理源 ------------------------ */

    private static Map<String, String> ipApi(List<String> ips) {
        Map<String, String> out = new HashMap<String, String>();
        HttpURLConnection c = null;
        try {
            c = (HttpURLConnection) new URL("http://ip-api.com/batch?fields=status,countryCode,query")
                    .openConnection();
            c.setConnectTimeout(5000);
            c.setReadTimeout(6000);
            c.setDoOutput(true);
            c.setRequestProperty("Content-Type", "application/json");
            StringBuilder req = new StringBuilder("[");
            for (int i = 0; i < ips.size(); i++) {
                if (i > 0) req.append(',');
                req.append('"').append(ips.get(i)).append('"');
            }
            req.append(']');
            java.io.OutputStream os = c.getOutputStream();
            os.write(req.toString().getBytes("UTF-8"));
            os.close();
            String body = readAll(c.getInputStream());
            for (String obj : body.split("\\{")) {
                java.util.regex.Matcher mq = java.util.regex.Pattern
                        .compile("\"query\"\\s*:\\s*\"([^\"]+)\"").matcher(obj);
                java.util.regex.Matcher mc = java.util.regex.Pattern
                        .compile("\"countryCode\"\\s*:\\s*\"([A-Z]{2})\"").matcher(obj);
                if (mq.find() && mc.find()) out.put(mq.group(1), mc.group(1));
            }
        } catch (Throwable ignored) {
        } finally {
            if (c != null) c.disconnect();
        }
        return out;
    }

    private static String ipWho(String ip) {
        return single("https://ipwho.is/" + ip, "\"country_code\"\\s*:\\s*\"([A-Za-z]{2})\"");
    }

    private static String ipInfo(String ip) {
        return single("https://ipinfo.io/" + ip + "/json", "\"country\"\\s*:\\s*\"([A-Za-z]{2})\"");
    }

    private static String single(String url, String regex) {
        HttpURLConnection c = null;
        try {
            c = (HttpURLConnection) new URL(url).openConnection();
            c.setConnectTimeout(2500);
            c.setReadTimeout(3000);
            String body = readAll(c.getInputStream());
            java.util.regex.Matcher m = java.util.regex.Pattern.compile(regex).matcher(body);
            if (m.find()) return m.group(1);
        } catch (Throwable ignored) {
        } finally {
            if (c != null) c.disconnect();
        }
        return "";
    }

    private static String readAll(InputStream in) throws Exception {
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        byte[] buf = new byte[4096];
        int len;
        while ((len = in.read(buf)) > 0) bos.write(buf, 0, len);
        in.close();
        return new String(bos.toByteArray(), "UTF-8");
    }
}
