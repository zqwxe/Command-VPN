package com.dsh.quickvpn;

import java.net.InetSocketAddress;
import java.net.Socket;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.RejectedExecutionException;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * 节点延迟探测：并发 TCP 握手，握手耗时近似往返延迟。
 * 支持取消：取消后旧的这批任务不会再回调（用 runId 作废）。
 */
public class LatencyTester {

    public interface Callback {
        void onResult(Node node);

        void onFinished();
    }

    private volatile boolean active;
    private volatile int runId;
    private volatile ExecutorService pool;

    public boolean isRunning() {
        return active;
    }

    /** 取消当前这一轮（并作废它的回调）。 */
    public void cancel() {
        runId++;
        active = false;
        ExecutorService p = pool;
        pool = null;
        if (p != null) {
            try {
                p.shutdownNow();
            } catch (Throwable ignored) {
            }
        }
    }

    public void test(List<Node> nodes, Callback cb) {
        test(nodes, 1500, 48, cb);
    }

    public void test(final List<Node> nodes, final int timeoutMs, final int threads, final Callback cb) {
        cancel();
        final int myRun = ++runId;
        active = true;
        final ExecutorService executor = Executors.newFixedThreadPool(Math.max(1, threads));
        pool = executor;
        final AtomicInteger remaining = new AtomicInteger(nodes.size());

        Thread coordinator = new Thread(new Runnable() {
            @Override
            public void run() {
                for (final Node n : nodes) {
                    try {
                        executor.execute(new Runnable() {
                            @Override
                            public void run() {
                                try {
                                    if (myRun != runId) return;
                                    n.latency = probe(n.host, n.port, timeoutMs);
                                    if (myRun == runId && cb != null) cb.onResult(n);
                                } finally {
                                    remaining.decrementAndGet();
                                }
                            }
                        });
                    } catch (RejectedExecutionException e) {
                        remaining.decrementAndGet();
                    } catch (Throwable t) {
                        remaining.decrementAndGet();
                    }
                }
                while (remaining.get() > 0 && myRun == runId) {
                    try {
                        Thread.sleep(40);
                    } catch (InterruptedException e) {
                        break;
                    }
                }
                try {
                    executor.shutdownNow();
                } catch (Throwable ignored) {
                }
                if (myRun == runId) {
                    active = false;
                    pool = null;
                    if (cb != null) cb.onFinished();
                }
            }
        }, "latency");
        coordinator.setPriority(Thread.MIN_PRIORITY + 2);
        coordinator.start();
    }

    public static int probe(String host, int port) {
        return probe(host, port, 2500);
    }

    /** 返回毫秒；-3 表示不通或参数非法。 */
    public static int probe(String host, int port, int timeoutMs) {
        if (host == null || host.length() == 0 || port <= 0 || port > 65535) return -3;
        Socket socket = new Socket();
        long start = System.nanoTime();
        try {
            socket.connect(new InetSocketAddress(host, port), timeoutMs);
            long ms = (System.nanoTime() - start) / 1000000L;
            return (int) Math.max(1, ms);
        } catch (Throwable e) {
            return -3;
        } finally {
            try {
                socket.close();
            } catch (Throwable ignored) {
            }
        }
    }
}
