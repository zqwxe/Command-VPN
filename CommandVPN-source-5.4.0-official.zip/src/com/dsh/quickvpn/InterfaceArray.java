package com.dsh.quickvpn;

import java.util.List;

import io.nekohasekai.libbox.NetworkInterface;
import io.nekohasekai.libbox.NetworkInterfaceIterator;

/** 把网络接口列表交给内核。 */
public class InterfaceArray implements NetworkInterfaceIterator {
    private final List<NetworkInterface> list;
    private int index = 0;

    public InterfaceArray(List<NetworkInterface> list) {
        this.list = list;
    }

    @Override
    public boolean hasNext() {
        return index < list.size();
    }

    @Override
    public NetworkInterface next() {
        return list.get(index++);
    }
}
