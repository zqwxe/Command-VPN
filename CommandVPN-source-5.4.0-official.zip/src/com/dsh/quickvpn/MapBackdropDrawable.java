package com.dsh.quickvpn;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.PixelFormat;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.drawable.Drawable;

/**
 * 世界地图背景层：画的时候就地做四边羽化（DST_IN 蒙版），
 * 所以不会出现"贴了张图片"的方形边界，也不会往图上盖色块（不会发雾）。
 */
public class MapBackdropDrawable extends Drawable {

    private final Bitmap bitmap;
    private final Paint paint = new Paint(Paint.FILTER_BITMAP_FLAG | Paint.ANTI_ALIAS_FLAG);
    private final Paint maskPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Rect src = new Rect();
    private final RectF dst = new RectF();
    private int alpha = 255;
    private float topFraction = 0.58f;   // 地图只占卡片顶部这部分高度
    private int tintColor = 0xFFFFFFFF;  // MULTIPLY 叠加色（深色模式压暗用）
    private boolean grayscale = false;
    private boolean night = false;   // 夜景：反相 + 拉对比，让大陆比海洋亮

    public MapBackdropDrawable(Bitmap bmp) {
        this.bitmap = bmp;
        if (bmp != null) src.set(0, 0, bmp.getWidth(), bmp.getHeight());
        maskPaint.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.DST_IN));
    }

    public void setAlphaInt(int a) {
        alpha = a;
        invalidateSelf();
    }

    /** 地图只画在卡片顶部这一段（0~1）。 */
    public void setTopFraction(float f) {
        if (f > 0.1f && f <= 1f) {
            topFraction = f;
            invalidateSelf();
        }
    }

    /** 给地图整体乘一个颜色：深色模式用暗蓝压暗，浅色模式传白色（不改变）。 */
    public void setTintColor(int color) {
        tintColor = color;
        applyFilter();
        invalidateSelf();
    }

    /** 夜景模式：反相并拉高对比，海洋压黑、大陆留亮，轮廓更明显。 */
    public void setNight(boolean n) {
        night = n;
        applyFilter();
        invalidateSelf();
    }

    /** 去色：深色模式把地图变成纯灰，不再偏蓝。 */
    public void setGrayscale(boolean g) {
        grayscale = g;
        applyFilter();
        invalidateSelf();
    }

    private void applyFilter() {
        android.graphics.ColorMatrix m = new android.graphics.ColorMatrix();
        if (grayscale) m.setSaturation(0f);       // 去掉蓝色，变纯灰
        if (night) {
            // 反相：原图海洋接近白、大陆偏暗 → 反转后海洋黑、大陆亮，对比清楚
            m.postConcat(new android.graphics.ColorMatrix(new float[]{
                    -3.1f, 0, 0, 0, 800,
                    0, -3.1f, 0, 0, 800,
                    0, 0, -3.1f, 0, 800,
                    0, 0, 0, 1, 0}));
        }
        float r = android.graphics.Color.red(tintColor) / 255f;
        float g = android.graphics.Color.green(tintColor) / 255f;
        float b = android.graphics.Color.blue(tintColor) / 255f;
        android.graphics.ColorMatrix mul = new android.graphics.ColorMatrix(new float[]{
                r, 0, 0, 0, 0,
                0, g, 0, 0, 0,
                0, 0, b, 0, 0,
                0, 0, 0, 1, 0});
        m.postConcat(mul);
        paint.setColorFilter(new android.graphics.ColorMatrixColorFilter(m));
    }

    @Override
    public void draw(Canvas canvas) {
        if (bitmap == null || bitmap.isRecycled()) return;
        Rect b = getBounds();
        if (b.width() <= 0 || b.height() <= 0) return;
        // 只占顶部一段高度，下面留白/渐变给文字和控件
        dst.set(b.left, b.top, b.right, b.top + b.height() * topFraction);

        int save = canvas.saveLayer(dst, null);
        paint.setAlpha(alpha);
        canvas.drawBitmap(bitmap, src, dst, paint);

        // 上下羽化（只在顶部这块区域内，底边渐隐得更狠）
        maskPaint.setShader(new LinearGradient(0, dst.top, 0, dst.bottom,
                new int[]{0x00000000, 0xFF000000, 0xFF000000, 0x00000000},
                new float[]{0f, 0.18f, 0.55f, 1f}, Shader.TileMode.CLAMP));
        canvas.drawRect(dst, maskPaint);

        // 左右羽化
        maskPaint.setShader(new LinearGradient(dst.left, 0, dst.right, 0,
                new int[]{0x00000000, 0xFF000000, 0xFF000000, 0x00000000},
                new float[]{0f, 0.13f, 0.87f, 1f}, Shader.TileMode.CLAMP));
        canvas.drawRect(dst, maskPaint);

        maskPaint.setShader(null);
        canvas.restoreToCount(save);
    }

    @Override
    public void setAlpha(int a) {
        alpha = a;
    }

    @Override
    public void setColorFilter(ColorFilter cf) {
    }

    @Override
    public int getOpacity() {
        return PixelFormat.TRANSLUCENT;
    }
}
