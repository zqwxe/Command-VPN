package com.dsh.quickvpn;

import android.app.Application;

/** 只做一件事：尽早把日志和"未捕获异常"记下来，这样闪退后下次打开还能看到原因。 */
public class App extends Application {

    @Override
    public void onCreate() {
        super.onCreate();
        Log2.init(this);
        Log2.i("==== App 启动 ====");
        NodeStore.fixWrongItCache(this);
        NodeStore.dedupeTrash(this);
        NodeStore.resetNameDerivedCountries(this);
        NodeStore.dedupeByServer(this);
        SourceStore.upgradeV1(this);
        SourceStore.upgradeV2(this);
        SourceStore.upgradeV3(this);
        SourceStore.upgradeV4(this);
        CloudTester.cleanStaleCaches(this);
        String ext = Log2.externalPath();
        Log2.i(ext == null ? "外部日志不可用（Android 版本太低？）"
                : "日志同时写到 " + ext + "（手机 Download 目录，可直接发给别人看）");
        final Thread.UncaughtExceptionHandler previous = Thread.getDefaultUncaughtExceptionHandler();
        Thread.setDefaultUncaughtExceptionHandler(new Thread.UncaughtExceptionHandler() {
            @Override
            public void uncaughtException(Thread thread, Throwable throwable) {
                try {
                    Log2.e("未捕获异常（线程 " + thread.getName() + "）", throwable);
                } catch (Throwable ignored) {
                }
                if (previous != null) previous.uncaughtException(thread, throwable);
            }
        });
    }
}
